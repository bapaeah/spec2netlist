# =============================================================================
#  setup_synthesis.ps1 - synthesis / GLS / STA prerequisites on Windows
#
#  Native Windows:
#    * Yosys        -> pip "yowasp-yosys" (official YosysHQ WebAssembly build)
#    * Icarus       -> winget (handled by setup_windows.ps1; checked here)
#    * Liberty libs -> techlib\*\full\ (pinned commit, sha256-verified)
#  Static timing (OpenSTA) and Verilator have no supported native Windows builds:
#    -> if WSL is installed, setup_synthesis.sh is run inside WSL Ubuntu and the
#       `sta` binary is used from there; otherwise you get synthesis + GLS only.
#
#  Usage:  powershell -ExecutionPolicy Bypass -File .\setup_synthesis.ps1 [-NoWSL]
# =============================================================================
param([switch]$NoWSL)
$ErrorActionPreference = "Continue"
$Dir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $Dir

function Ok($m)   { Write-Host "    [ok] $m" -ForegroundColor Green }
function Warn($m) { Write-Host "    [!]  $m" -ForegroundColor Yellow }
function Have($c) { [bool](Get-Command $c -ErrorAction SilentlyContinue) }

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " LLM_Local - Synthesis / GLS / STA setup (Windows)"         -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# 1. Yosys
Write-Host "`n[1/5] Yosys" -ForegroundColor Cyan
if ((Have yosys) -or (Have yowasp-yosys)) {
    Ok "yosys present"
} else {
    python -m pip install --user --quiet yowasp-yosys
    $scripts = python -c "import sysconfig;print(sysconfig.get_path('scripts','nt_user'))"
    if ($env:Path -notlike "*$scripts*") {
        [Environment]::SetEnvironmentVariable("Path", "$([Environment]::GetEnvironmentVariable('Path','User'));$scripts", "User")
        $env:Path += ";$scripts"
    }
    if (Have yowasp-yosys) { Ok "yowasp-yosys installed ($scripts)" } else { Warn "yowasp-yosys not on PATH - open a new terminal" }
}

# 2. Icarus Verilog (GLS)
Write-Host "`n[2/5] Icarus Verilog (gate-level simulation)" -ForegroundColor Cyan
if (Have iverilog) { Ok "iverilog present" } else { Warn "iverilog missing - run setup_windows.ps1 or install from https://bleyer.org/icarus/" }

# 3. Liberty files
Write-Host "`n[3/5] Standard-cell Liberty files with timing" -ForegroundColor Cyan
python techlib\synth_flow.py --install-libs

# 4. OpenSTA via WSL
Write-Host "`n[4/5] OpenSTA (static timing) via WSL" -ForegroundColor Cyan
$wsl = (Have wsl) -and -not $NoWSL
if ($wsl) {
    $distros = ((wsl -l -q) -join " ") -replace "`0", ""   # wsl.exe prints UTF-16 (NUL bytes)
    if ($distros -notmatch "Ubuntu") {
        Warn "WSL found but no Ubuntu distro. Install once with:  wsl --install -d Ubuntu   then re-run this script."
    } else {
        $wslDir = (wsl wslpath -a ($Dir -replace '\\','/')).Trim()
        Write-Host "    running setup_synthesis.sh inside WSL Ubuntu (builds OpenSTA once, ~5 min)..."
        wsl -d Ubuntu -- bash -lc "cd '$wslDir' && ./setup_synthesis.sh --no-libs"
        # expose a Windows shim so synth_flow can call STA
        $shim = Join-Path $env:LOCALAPPDATA "llm_local_eda"
        New-Item -ItemType Directory -Force -Path $shim | Out-Null
        Set-Content -Path (Join-Path $shim "sta.cmd") -Value "@wsl -d Ubuntu -- bash -lc ""~/.local/bin/sta %*"""
        if ($env:Path -notlike "*$shim*") {
            [Environment]::SetEnvironmentVariable("Path", "$([Environment]::GetEnvironmentVariable('Path','User'));$shim", "User")
            $env:Path += ";$shim"
        }
        Ok "sta available through WSL (sta.cmd shim in $shim)"
    }
} else {
    Warn "WSL not available - synthesis + GLS will work, STA (timing reports) will be skipped."
    Warn "Enable it with:  wsl --install -d Ubuntu   (then re-run this script)"
}

# 5. Self-test
Write-Host "`n[5/5] Self-test" -ForegroundColor Cyan
python techlib\synth_flow.py --doctor
python techlib\synth_flow.py --selftest
Write-Host "`nDone. Usage:  rtl --synth design.sv --lib nangate45 --period 5 --tb tb_design.sv" -ForegroundColor Cyan
