#!/usr/bin/env python3
"""
================================================================================
  Markdown Universal Document Converter (md_converter.py)
  100% Offline & Pure Python (Zero Mandatory Dependencies)
================================================================================
Converts any Markdown (.md) document into:
  - PDF   (.pdf)   - Clean multi-page vector PDF with headers, code blocks & tables
  - TXT   (.txt)   - Formatted plain text with ASCII-aligned tables & clean headers
  - HTML  (.html)  - Standalone styled HTML document with modern responsive CSS
  - DOCX  (.docx)  - Microsoft Word document (OpenXML standard)
  - RTF   (.rtf)   - Rich Text Format (compatible with Word, Pages, WordPad)
  - LaTeX (.tex)   - Typeset LaTeX document with syntax blocks and tables
  - JSON  (.json)  - Structured parse tree (sections, paragraphs, tables, code)

Works on macOS, Linux, and Windows.
================================================================================
"""

import os
import sys
import re
import json
import zipfile
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple


# ==============================================================================
# 1. MARKDOWN PARSER (Block & Inline Extractor)
# ==============================================================================

class MarkdownBlock:
    def __init__(self, block_type: str, content: Any = None, level: int = 0, lang: str = ""):
        self.type = block_type      # 'h1'-'h6', 'p', 'code', 'table', 'list', 'quote', 'hr'
        self.content = content      # string, list of items, or table data (rows)
        self.level = level          # heading level or list indent level
        self.lang = lang            # code language (verilog, python, etc.)


def parse_markdown(text: str) -> List[MarkdownBlock]:
    """Parse markdown text into structured blocks."""
    lines = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    blocks: List[MarkdownBlock] = []
    
    in_code = False
    code_lang = ""
    code_lines = []
    
    in_table = False
    table_rows = []
    
    in_list = False
    list_items = []
    
    i = 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # 1. Code blocks
        if stripped.startswith("```"):
            if in_code:
                # End of code block
                blocks.append(MarkdownBlock("code", "\n".join(code_lines), lang=code_lang))
                code_lines = []
                code_lang = ""
                in_code = False
            else:
                # Flush pending table or list
                if in_table:
                    blocks.append(MarkdownBlock("table", table_rows))
                    table_rows = []
                    in_table = False
                if in_list:
                    blocks.append(MarkdownBlock("list", list_items))
                    list_items = []
                    in_list = False

                in_code = True
                code_lang = stripped[3:].strip().lower()
            i += 1
            continue

        if in_code:
            code_lines.append(line)
            i += 1
            continue

        # 2. Tables
        if "|" in line and (line.startswith("|") or line.endswith("|") or " | " in line):
            # Check if divider line (| :--- | :--- |)
            if re.match(r"^\s*\|?\s*:?-+:?\s*(\|?\s*:?-+:?\s*)+\|?\s*$", line):
                i += 1
                continue
            cells = [c.strip() for c in line.split("|")]
            if line.startswith("|"):
                cells = cells[1:]
            if line.endswith("|"):
                cells = cells[:-1]
            if any(cells):
                in_table = True
                table_rows.append(cells)
                i += 1
                continue
        elif in_table:
            blocks.append(MarkdownBlock("table", table_rows))
            table_rows = []
            in_table = False

        # 3. Horizontal Rule
        if re.match(r"^(\*{3,}|-{3,}|_{3,})$", stripped):
            if in_list:
                blocks.append(MarkdownBlock("list", list_items))
                list_items = []
                in_list = False
            blocks.append(MarkdownBlock("hr"))
            i += 1
            continue

        # 4. Headings
        h_match = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if h_match:
            if in_list:
                blocks.append(MarkdownBlock("list", list_items))
                list_items = []
                in_list = False
            level = len(h_match.group(1))
            title = h_match.group(2).strip()
            blocks.append(MarkdownBlock(f"h{level}", title, level=level))
            i += 1
            continue

        # Setext headings (Heading underlined with === or ---)
        if i + 1 < len(lines) and lines[i+1].strip() and re.match(r"^(=+|-+)$", lines[i+1].strip()) and stripped:
            if in_list:
                blocks.append(MarkdownBlock("list", list_items))
                list_items = []
                in_list = False
            level = 1 if lines[i+1].strip().startswith("=") else 2
            blocks.append(MarkdownBlock(f"h{level}", stripped, level=level))
            i += 2
            continue

        # 5. Lists (unordered and ordered)
        list_match = re.match(r"^(\s*)([*+-]|\d+\.)\s+(.*)$", line)
        if list_match:
            indent = len(list_match.group(1)) // 2
            item_text = list_match.group(3).strip()
            list_items.append((indent, item_text))
            in_list = True
            i += 1
            continue
        elif in_list and stripped:
            # Continuation of previous list item
            if list_items:
                prev_indent, prev_text = list_items[-1]
                list_items[-1] = (prev_indent, prev_text + " " + stripped)
            i += 1
            continue
        elif in_list and not stripped:
            blocks.append(MarkdownBlock("list", list_items))
            list_items = []
            in_list = False

        # 6. Blockquote
        if stripped.startswith(">"):
            quote_text = stripped[1:].strip()
            # Alert blocks: > [!NOTE], > [!TIP], etc.
            alert_m = re.match(r"^\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION)\]\s*(.*)$", quote_text, re.IGNORECASE)
            alert_type = ""
            if alert_m:
                alert_type = alert_m.group(1).upper()
                quote_text = alert_m.group(2)
            quote_lines = [quote_text] if quote_text else []
            while i + 1 < len(lines) and lines[i+1].strip().startswith(">"):
                next_q = lines[i+1].strip()[1:].strip()
                if next_q:
                    quote_lines.append(next_q)
                i += 1
            blocks.append(MarkdownBlock("quote", " ".join(quote_lines), lang=alert_type))
            i += 1
            continue

        # 7. Blank lines
        if not stripped:
            i += 1
            continue

        # 8. Regular paragraph
        p_lines = [stripped]
        while i + 1 < len(lines):
            next_l = lines[i+1].strip()
            if not next_l or next_l.startswith(("#", "```", ">", "*", "-", "+", "|")) or re.match(r"^\d+\.", next_l):
                break
            p_lines.append(next_l)
            i += 1
        blocks.append(MarkdownBlock("p", " ".join(p_lines)))
        i += 1

    # Flush remaining
    if in_code:
        blocks.append(MarkdownBlock("code", "\n".join(code_lines), lang=code_lang))
    if in_table:
        blocks.append(MarkdownBlock("table", table_rows))
    if in_list:
        blocks.append(MarkdownBlock("list", list_items))

    return blocks


def clean_inline_md(text: Optional[str]) -> str:
    """Strip markdown formatting from inline text for plain text output."""
    if not text:
        return ""
    t = str(text)
    t = re.sub(r"\*\*([^*]+)\*\*", r"\1", t)          # Bold **text**
    t = re.sub(r"__([^_]+)__", r"\1", t)              # Bold __text__
    t = re.sub(r"\*([^*]+)\*", r"\1", t)              # Italic *text*
    t = re.sub(r"_([^_]+)_", r"\1", t)                # Italic _text_
    t = re.sub(r"`([^`]+)`", r"\1", t)                # Inline `code`
    t = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", t)    # Links [text](url) -> text
    t = re.sub(r"!\[([^\]]*)\]\([^\)]+\)", r"\1", t)   # Images ![alt](url) -> alt
    return t


def inline_to_html(text: Optional[str]) -> str:
    """Convert inline markdown to HTML tags."""
    if not text:
        return ""
    t = str(text)
    # Escape HTML special chars first
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    # Inline code
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    # Bold
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"__([^_]+)__", r"<strong>\1</strong>", t)
    # Italic
    t = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", t)
    t = re.sub(r"_([^_]+)_", r"<em>\1</em>", t)
    # Links
    t = re.sub(r"\[([^\]]+)\]\(([^\)]+)\)", r'<a href="\2">\1</a>', t)
    return t


# ==============================================================================
# 2. PLAIN TEXT CONVERTER (.txt)
# ==============================================================================

def convert_to_txt(blocks: List[MarkdownBlock]) -> str:
    """Format markdown blocks into clean, structured plain text."""
    out = []
    
    for b in blocks:
        if b.type == "h1":
            title = clean_inline_md(b.content)
            out.append(title.upper())
            out.append("=" * len(title))
            out.append("")
        elif b.type == "h2":
            title = clean_inline_md(b.content)
            out.append(title)
            out.append("-" * len(title))
            out.append("")
        elif b.type in ["h3", "h4", "h5", "h6"]:
            out.append(f"[{clean_inline_md(b.content)}]")
            out.append("")
        elif b.type == "p":
            out.append(clean_inline_md(b.content))
            out.append("")
        elif b.type == "code":
            lang_str = f" ({b.lang})" if b.lang else ""
            out.append(f"--- Code Block{lang_str} ---")
            for c_line in b.content.split("\n"):
                out.append(f"    {c_line}")
            out.append("-------------------------")
            out.append("")
        elif b.type == "quote":
            prefix = f"[{b.lang}] " if b.lang else ""
            out.append(f"| {prefix}{clean_inline_md(b.content)}")
            out.append("")
        elif b.type == "list":
            for indent, item_text in b.content:
                sp = "  " * indent
                out.append(f"{sp}• {clean_inline_md(item_text)}")
            out.append("")
        elif b.type == "table":
            rows = b.content
            if not rows:
                continue
            num_cols = max(len(r) for r in rows)
            # Normalize row lengths
            norm_rows = []
            for r in rows:
                cleaned_r = [clean_inline_md(c) for c in r]
                while len(cleaned_r) < num_cols:
                    cleaned_r.append("")
                norm_rows.append(cleaned_r)
            
            # Compute column widths
            col_widths = [max(len(norm_rows[r][c]) for r in range(len(norm_rows))) for c in range(num_cols)]
            col_widths = [max(w, 4) for w in col_widths]

            # Divider line
            divider = "+" + "+".join("-" * (w + 2) for w in col_widths) + "+"
            out.append(divider)
            for idx, r in enumerate(norm_rows):
                line = "| " + " | ".join(f"{r[c]:<{col_widths[c]}}" for c in range(num_cols)) + " |"
                out.append(line)
                if idx == 0:
                    header_div = "+" + "+".join("=" * (w + 2) for w in col_widths) + "+"
                    out.append(header_div)
            out.append(divider)
            out.append("")
        elif b.type == "hr":
            out.append("-" * 72)
            out.append("")

    return "\n".join(out).strip() + "\n"


# ==============================================================================
# 3. HTML CONVERTER (.html)
# ==============================================================================

def convert_to_html(blocks: List[MarkdownBlock], title: str = "Document") -> str:
    """Format markdown blocks into a standalone, styled HTML document."""
    html_parts = []
    
    html_parts.append("<!DOCTYPE html>")
    html_parts.append('<html lang="en">')
    html_parts.append("<head>")
    html_parts.append('  <meta charset="utf-8">')
    html_parts.append('  <meta name="viewport" content="width=device-width, initial-scale=1.0">')
    html_parts.append(f"  <title>{title}</title>")
    html_parts.append("  <style>")
    html_parts.append("""
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
      line-height: 1.6;
      color: #1e293b;
      background-color: #f8fafc;
      margin: 0;
      padding: 40px 20px;
    }
    .container {
      max-width: 900px;
      margin: 0 auto;
      background: #ffffff;
      padding: 48px;
      border-radius: 8px;
      box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -2px rgba(0, 0, 0, 0.05);
      border: 1px solid #e2e8f0;
    }
    h1 { font-size: 2.2em; color: #0f172a; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; margin-top: 0; }
    h2 { font-size: 1.6em; color: #1e3a8a; border-bottom: 1px solid #e2e8f0; padding-bottom: 8px; margin-top: 32px; }
    h3 { font-size: 1.25em; color: #0369a1; margin-top: 24px; }
    h4 { font-size: 1.1em; color: #334155; }
    p { margin: 16px 0; }
    code {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 0.88em;
      background-color: #f1f5f9;
      padding: 3px 6px;
      border-radius: 4px;
      color: #0f766e;
    }
    pre {
      background-color: #0f172a;
      color: #f8fafc;
      padding: 16px;
      border-radius: 6px;
      overflow-x: auto;
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 0.9em;
      line-height: 1.5;
    }
    pre code {
      background: transparent;
      padding: 0;
      color: inherit;
    }
    .code-badge {
      display: inline-block;
      font-size: 0.75em;
      text-transform: uppercase;
      color: #94a3b8;
      margin-bottom: 4px;
      font-weight: 600;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin: 24px 0;
      font-size: 0.95em;
    }
    th, td {
      border: 1px solid #cbd5e1;
      padding: 10px 14px;
      text-align: left;
    }
    th {
      background-color: #f1f5f9;
      font-weight: 600;
      color: #0f172a;
    }
    tr:nth-child(even) { background-color: #f8fafc; }
    blockquote {
      margin: 20px 0;
      padding: 12px 20px;
      background-color: #f8fafc;
      border-left: 4px solid #3b82f6;
      border-radius: 0 6px 6px 0;
      color: #334155;
    }
    blockquote.alert-note { border-left-color: #3b82f6; background-color: #eff6ff; }
    blockquote.alert-tip { border-left-color: #10b981; background-color: #ecfdf5; }
    blockquote.alert-warning { border-left-color: #f59e0b; background-color: #fffbeb; }
    blockquote.alert-caution { border-left-color: #ef4444; background-color: #fef2f2; }
    blockquote.alert-important { border-left-color: #8b5cf6; background-color: #f5f3ff; }
    hr {
      border: 0;
      height: 1px;
      background: #e2e8f0;
      margin: 32px 0;
    }
    ul, ol { padding-left: 24px; }
    li { margin: 6px 0; }
    a { color: #2563eb; text-decoration: none; }
    a:hover { text-decoration: underline; }
    @media print {
      body { background: white; padding: 0; }
      .container { box-shadow: none; border: none; padding: 0; max-width: 100%; }
    }
    """)
    html_parts.append("  </style>")
    html_parts.append("</head>")
    html_parts.append("<body>")
    html_parts.append('  <div class="container">')

    for b in blocks:
        if b.type.startswith("h") and len(b.type) == 2:
            tag = b.type
            html_parts.append(f"    <{tag}>{inline_to_html(b.content)}</{tag}>")
        elif b.type == "p":
            html_parts.append(f"    <p>{inline_to_html(b.content)}</p>")
        elif b.type == "code":
            badge = f'<div class="code-badge">{b.lang}</div>' if b.lang else ""
            html_parts.append(f'    <pre>{badge}<code>{b.content.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")}</code></pre>')
        elif b.type == "quote":
            alert_cls = f" alert-{b.lang.lower()}" if b.lang else ""
            badge = f"<strong>[{b.lang}]</strong> " if b.lang else ""
            html_parts.append(f'    <blockquote class="{alert_cls.strip()}">{badge}{inline_to_html(b.content)}</blockquote>')
        elif b.type == "list":
            html_parts.append("    <ul>")
            for _, item_text in b.content:
                html_parts.append(f"      <li>{inline_to_html(item_text)}</li>")
            html_parts.append("    </ul>")
        elif b.type == "table":
            rows = b.content
            if rows:
                html_parts.append("    <table>")
                html_parts.append("      <thead><tr>")
                for cell in rows[0]:
                    html_parts.append(f"        <th>{inline_to_html(cell)}</th>")
                html_parts.append("      </tr></thead>")
                if len(rows) > 1:
                    html_parts.append("      <tbody>")
                    for r in rows[1:]:
                        html_parts.append("        <tr>")
                        for cell in r:
                            html_parts.append(f"          <td>{inline_to_html(cell)}</td>")
                        html_parts.append("        </tr>")
                    html_parts.append("      </tbody>")
                html_parts.append("    </table>")
        elif b.type == "hr":
            html_parts.append("    <hr>")

    html_parts.append("  </div>")
    html_parts.append("</body>")
    html_parts.append("</html>")
    return "\n".join(html_parts) + "\n"


# ==============================================================================
# 4. PURE-PYTHON PDF CONVERTER (.pdf)
# ==============================================================================

class PurePythonPDF:
    """Zero-dependency vector PDF generator."""
    def __init__(self, page_width: float = 612.0, page_height: float = 792.0):
        self.width = page_width
        self.height = page_height
        self.pages: List[List[str]] = []
        self.current_page: List[str] = []
        self.margin_x = 54.0
        self.printable_width = self.width - 2 * self.margin_x
        self.y = self.height - 54.0

    def new_page(self):
        if self.current_page:
            self.pages.append(self.current_page)
        self.current_page = []
        self.y = self.height - 54.0

    def ensure_space(self, needed: float):
        if self.y - needed < 54.0:
            self.new_page()

    def add_rect(self, x: float, y: float, w: float, h: float, r: float = 0.95, g: float = 0.95, b: float = 0.95, border: bool = False):
        fill_cmd = f"{r:.3f} {g:.3f} {b:.3f} rg\n{x:.1f} {y:.1f} {w:.1f} {h:.1f} re f\n"
        self.current_page.append(fill_cmd)
        if border:
            stroke_cmd = f"0.800 0.840 0.880 RG\n0.75 w\n{x:.1f} {y:.1f} {w:.1f} {h:.1f} re S\n"
            self.current_page.append(stroke_cmd)

    def add_line(self, x1: float, y1: float, x2: float, y2: float, r: float = 0.8, g: float = 0.84, b: float = 0.88, width: float = 1.0):
        cmd = f"{r:.3f} {g:.3f} {b:.3f} RG\n{width:.2f} w\n{x1:.1f} {y1:.1f} m {x2:.1f} {y2:.1f} l S\n"
        self.current_page.append(cmd)

    def add_text_line(self, text: str, font: str = "F1", size: float = 10.0, r: float = 0.1, g: float = 0.1, b: float = 0.1, x_offset: float = 0.0):
        clean = text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        cmd = (
            f"{r:.3f} {g:.3f} {b:.3f} rg\n"
            f"BT /{font} {size:.1f} Tf {self.margin_x + x_offset:.1f} {self.y:.1f} Td ({clean}) Tj ET\n"
        )
        self.current_page.append(cmd)

    def wrap_text(self, text: str, font: str, size: float, max_w: float) -> List[str]:
        # Approximate font metrics
        c_width = size * (0.60 if "Courier" in font else 0.50)
        max_chars = max(10, int(max_w / c_width))
        
        words = text.split(" ")
        lines = []
        cur = []
        cur_len = 0
        for w in words:
            if cur_len + len(w) + (1 if cur else 0) <= max_chars:
                cur.append(w)
                cur_len += len(w) + (1 if len(cur) > 1 else 0)
            else:
                if cur:
                    lines.append(" ".join(cur))
                cur = [w]
                cur_len = len(w)
        if cur:
            lines.append(" ".join(cur))
        return lines or [text]

    def render_blocks(self, blocks: List[MarkdownBlock]):
        for b in blocks:
            if b.type == "h1":
                self.ensure_space(45)
                self.y -= 15
                title = clean_inline_md(b.content)
                self.add_text_line(title, font="F2", size=20, r=0.08, g=0.15, b=0.40)
                self.y -= 8
                self.add_line(self.margin_x, self.y, self.margin_x + self.printable_width, self.y, r=0.2, g=0.3, b=0.6, width=1.5)
                self.y -= 14

            elif b.type == "h2":
                self.ensure_space(35)
                self.y -= 14
                title = clean_inline_md(b.content)
                self.add_text_line(title, font="F2", size=14, r=0.12, g=0.23, b=0.55)
                self.y -= 6
                self.add_line(self.margin_x, self.y, self.margin_x + self.printable_width, self.y, r=0.8, g=0.84, b=0.88, width=0.8)
                self.y -= 10

            elif b.type in ["h3", "h4", "h5", "h6"]:
                self.ensure_space(25)
                self.y -= 10
                size = 12 if b.type == "h3" else 11
                self.add_text_line(clean_inline_md(b.content), font="F2", size=size, r=0.10, g=0.20, b=0.35)
                self.y -= 10

            elif b.type == "p":
                lines = self.wrap_text(clean_inline_md(b.content), font="F1", size=10, max_w=self.printable_width)
                for l in lines:
                    self.ensure_space(14)
                    self.y -= 13
                    self.add_text_line(l, font="F1", size=10, r=0.12, g=0.15, b=0.20)
                self.y -= 6

            elif b.type == "quote":
                alert_prefix = f"[{b.lang}] " if b.lang else ""
                lines = self.wrap_text(alert_prefix + clean_inline_md(b.content), font="F1", size=9.5, max_w=self.printable_width - 24)
                block_h = len(lines) * 13 + 12
                self.ensure_space(block_h + 10)
                # Background rect
                self.add_rect(self.margin_x, self.y - block_h + 4, self.printable_width, block_h, r=0.96, g=0.97, b=0.99, border=True)
                # Accent left bar
                self.add_rect(self.margin_x, self.y - block_h + 4, 4, block_h, r=0.20, g=0.45, b=0.85)
                self.y -= 6
                for l in lines:
                    self.y -= 13
                    self.add_text_line(l, font="F1", size=9.5, r=0.15, g=0.25, b=0.40, x_offset=12)
                self.y -= 10

            elif b.type == "code":
                code_lines = b.content.split("\n")
                # Wrap long code lines
                fmt_lines = []
                for cl in code_lines:
                    if len(cl) > 85:
                        fmt_lines.extend([cl[k:k+85] for k in range(0, len(cl), 85)])
                    else:
                        fmt_lines.append(cl)
                
                block_h = len(fmt_lines) * 11 + 14
                self.ensure_space(min(block_h + 10, 200))
                
                # Draw shaded background
                self.add_rect(self.margin_x, self.y - block_h + 4, self.printable_width, block_h, r=0.96, g=0.97, b=0.98, border=True)
                self.y -= 6
                for cl in fmt_lines:
                    self.ensure_space(12)
                    self.y -= 11
                    self.add_text_line(cl, font="F3", size=8.5, r=0.08, g=0.25, b=0.25, x_offset=8)
                self.y -= 12

            elif b.type == "list":
                for indent, item_text in b.content:
                    off = indent * 14 + 10
                    lines = self.wrap_text(clean_inline_md(item_text), font="F1", size=9.5, max_w=self.printable_width - off - 10)
                    for idx, l in enumerate(lines):
                        self.ensure_space(13)
                        self.y -= 12
                        bullet = "• " if idx == 0 else "  "
                        self.add_text_line(f"{bullet}{l}", font="F1", size=9.5, r=0.12, g=0.15, b=0.20, x_offset=off)
                self.y -= 6

            elif b.type == "table":
                rows = b.content
                if not rows:
                    continue
                num_cols = max(len(r) for r in rows)
                col_w = self.printable_width / num_cols
                
                for r_idx, row in enumerate(rows):
                    self.ensure_space(20)
                    self.y -= 16
                    is_header = (r_idx == 0)
                    # Row background
                    if is_header:
                        self.add_rect(self.margin_x, self.y - 4, self.printable_width, 18, r=0.92, g=0.94, b=0.97, border=True)
                    else:
                        bg_c = 0.98 if r_idx % 2 == 0 else 1.0
                        self.add_rect(self.margin_x, self.y - 4, self.printable_width, 18, r=bg_c, g=bg_c, b=bg_c, border=True)

                    for c_idx in range(num_cols):
                        val = clean_inline_md(row[c_idx]) if c_idx < len(row) else ""
                        # Truncate if too long for table cell
                        max_chars = max(6, int(col_w / 5.5))
                        if len(val) > max_chars:
                            val = val[:max_chars-2] + ".."
                        font = "F2" if is_header else "F1"
                        self.add_text_line(val, font=font, size=8.5, r=0.05 if is_header else 0.15, g=0.05, b=0.15, x_offset=c_idx * col_w + 4)
                self.y -= 12

            elif b.type == "hr":
                self.ensure_space(16)
                self.y -= 8
                self.add_line(self.margin_x, self.y, self.margin_x + self.printable_width, self.y, r=0.85, g=0.85, b=0.85, width=0.75)
                self.y -= 10

    def build(self) -> bytes:
        if self.current_page:
            self.pages.append(self.current_page)
        if not self.pages:
            self.pages.append([])

        total_pages = len(self.pages)
        # Add footers with page numbering to each page
        for p_idx, page in enumerate(self.pages, start=1):
            footer_text = f"Page {p_idx} of {total_pages}"
            footer_clean = footer_text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
            cmd = (
                f"0.550 0.550 0.550 rg\n"
                f"BT /F1 8.5 Tf {self.width - self.margin_x - 60:.1f} 28.0 Td ({footer_clean}) Tj ET\n"
            )
            page.append(cmd)

        objects = []
        def add_obj(content: bytes) -> int:
            objects.append(content)
            return len(objects)

        pages_id = 2
        font_f1 = add_obj(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
        font_f2 = add_obj(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>")
        font_f3 = add_obj(b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>")

        content_obj_ids = []
        for p in self.pages:
            stream_data = "".join(p).encode("latin-1", errors="replace")
            c_id = add_obj(b"<< /Length " + str(len(stream_data)).encode() + b" >>\nstream\n" + stream_data + b"\nendstream")
            content_obj_ids.append(c_id)

        page_obj_ids = []
        for c_id in content_obj_ids:
            p_dict = (
                f"<< /Type /Page /Parent {pages_id} 0 R /MediaBox [0 0 {self.width:.1f} {self.height:.1f}] "
                f"/Resources << /Font << /F1 {font_f1} 0 R /F2 {font_f2} 0 R /F3 {font_f3} 0 R >> >> "
                f"/Contents {c_id} 0 R >>"
            ).encode()
            page_obj_ids.append(add_obj(p_dict))

        kids = " ".join(f"{pid} 0 R" for pid in page_obj_ids)
        pages_dict = f"<< /Type /Pages /Kids [ {kids} ] /Count {len(page_obj_ids)} >>".encode()

        all_objs = [
            f"<< /Type /Catalog /Pages {pages_id} 0 R >>".encode(),
            pages_dict,
        ] + objects

        out = [b"%PDF-1.4\n"]
        offsets = []
        pos = len(out[0])
        for i, obj in enumerate(all_objs, start=1):
            offsets.append(pos)
            chunk = f"{i} 0 obj\n".encode() + obj + b"\nendobj\n"
            out.append(chunk)
            pos += len(chunk)

        xref_pos = pos
        xref = f"xref\n0 {len(all_objs) + 1}\n0000000000 65535 f \n".encode()
        for off in offsets:
            xref += f"{off:010d} 00000 n \n".encode()
        out.append(xref)
        trailer = (
            f"trailer\n<< /Size {len(all_objs) + 1} /Root 1 0 R >>\n"
            f"startxref\n{xref_pos}\n%%EOF\n"
        ).encode()
        out.append(trailer)
        return b"".join(out)


def convert_to_pdf(blocks: List[MarkdownBlock]) -> bytes:
    """Generate pure-python vector PDF bytes."""
    pdf = PurePythonPDF()
    pdf.render_blocks(blocks)
    return pdf.build()


# ==============================================================================
# 5. MICROSOFT WORD OPENXML CONVERTER (.docx)
# ==============================================================================

def convert_to_docx(blocks: List[MarkdownBlock], output_file: Path):
    """Generate pure-python OpenXML DOCX file without requiring python-docx."""
    content_types = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

    rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

    doc_rels = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

    styles = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal">
    <w:name w:val="Normal"/>
    <w:rPr>
      <w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/>
      <w:sz w:val="22"/>
      <w:color w:val="1E293B"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:rPr>
      <w:b/>
      <w:color w:val="0F172A"/>
      <w:sz w:val="36"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading2">
    <w:name w:val="heading 2"/>
    <w:rPr>
      <w:b/>
      <w:color w:val="1E3A8A"/>
      <w:sz w:val="28"/>
    </w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading3">
    <w:name w:val="heading 3"/>
    <w:rPr>
      <w:b/>
      <w:color w:val="0369A1"/>
      <w:sz w:val="24"/>
    </w:rPr>
  </w:style>
</w:styles>"""

    body_xml = []
    
    def escape_xml(s: str) -> str:
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

    for b in blocks:
        if b.type == "h1":
            body_xml.append(f'<w:p><w:pPr><w:pStyle w:val="Heading1"/><w:spacing w:before="240" w:after="120"/></w:pPr><w:r><w:t>{escape_xml(clean_inline_md(b.content))}</w:t></w:r></w:p>')
        elif b.type == "h2":
            body_xml.append(f'<w:p><w:pPr><w:pStyle w:val="Heading2"/><w:spacing w:before="200" w:after="80"/></w:pPr><w:r><w:t>{escape_xml(clean_inline_md(b.content))}</w:t></w:r></w:p>')
        elif b.type == "h3":
            body_xml.append(f'<w:p><w:pPr><w:pStyle w:val="Heading3"/><w:spacing w:before="160" w:after="60"/></w:pPr><w:r><w:t>{escape_xml(clean_inline_md(b.content))}</w:t></w:r></w:p>')
        elif b.type in ["h4", "h5", "h6"]:
            body_xml.append(f'<w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>{escape_xml(clean_inline_md(b.content))}</w:t></w:r></w:p>')
        elif b.type == "p":
            body_xml.append(f'<w:p><w:pPr><w:spacing w:after="120"/></w:pPr><w:r><w:t>{escape_xml(clean_inline_md(b.content))}</w:t></w:r></w:p>')
        elif b.type == "quote":
            prefix = f"[{b.lang}] " if b.lang else ""
            body_xml.append(f'<w:p><w:pPr><w:ind w:left="400"/><w:spacing w:after="120"/></w:pPr><w:r><w:rPr><w:i/><w:color w:val="2563EB"/></w:rPr><w:t>{escape_xml(prefix + clean_inline_md(b.content))}</w:t></w:r></w:p>')
        elif b.type == "code":
            for cl in b.content.split("\n"):
                body_xml.append(f'<w:p><w:pPr><w:ind w:left="300"/><w:spacing w:after="20"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Consolas" w:hAnsi="Consolas"/><w:sz w:val="18"/><w:color w:val="0F766E"/></w:rPr><w:t xml:space="preserve">{escape_xml(cl)}</w:t></w:r></w:p>')
        elif b.type == "list":
            for indent, item_text in b.content:
                margin = 360 * (indent + 1)
                body_xml.append(f'<w:p><w:pPr><w:ind w:left="{margin}"/><w:spacing w:after="60"/></w:pPr><w:r><w:t>• {escape_xml(clean_inline_md(item_text))}</w:t></w:r></w:p>')
        elif b.type == "table":
            rows = b.content
            if rows:
                body_xml.append('<w:tbl><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="CBD5E1"/></w:tblBorders></w:tblPr>')
                for r_idx, r in enumerate(rows):
                    is_h = (r_idx == 0)
                    body_xml.append('<w:tr>')
                    for cell in r:
                        shd = '<w:tcPr><w:shd w:val="clear" w:color="auto" w:fill="F1F5F9"/></w:tcPr>' if is_h else ''
                        bld = '<w:b/>' if is_h else ''
                        body_xml.append(f'<w:tc>{shd}<w:p><w:r><w:rPr>{bld}</w:rPr><w:t>{escape_xml(clean_inline_md(cell))}</w:t></w:r></w:p></w:tc>')
                    body_xml.append('</w:tr>')
                body_xml.append('</w:tbl>')

    doc_xml = f"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    {''.join(body_xml)}
  </w:body>
</w:document>"""

    with zipfile.ZipFile(output_file, "w", zipfile.ZIP_DEFLATED) as docx:
        docx.writestr("[Content_Types].xml", content_types)
        docx.writestr("_rels/.rels", rels)
        docx.writestr("word/_rels/document.xml.rels", doc_rels)
        docx.writestr("word/styles.xml", styles)
        docx.writestr("word/document.xml", doc_xml)


# ==============================================================================
# 6. RICH TEXT FORMAT CONVERTER (.rtf)
# ==============================================================================

def convert_to_rtf(blocks: List[MarkdownBlock]) -> str:
    """Format markdown blocks into Rich Text Format."""
    rtf_lines = [
        r"{\rtf1\ansi\deff0",
        r"{\fonttbl{\f0\fswiss\fcharset0 Helvetica;}{\f1\fmodern\fcharset0 Courier;}}",
        r"{\colortbl ;\red15\green23\blue42;\red30\green58\blue138;\red15\green118\blue110;}",
    ]
    
    for b in blocks:
        if b.type == "h1":
            rtf_lines.append(r"\fs36\b\cf2 " + clean_inline_md(b.content) + r"\b0\cf0\fs22\par\par")
        elif b.type == "h2":
            rtf_lines.append(r"\fs28\b\cf2 " + clean_inline_md(b.content) + r"\b0\cf0\fs22\par\par")
        elif b.type in ["h3", "h4"]:
            rtf_lines.append(r"\fs24\b " + clean_inline_md(b.content) + r"\b0\fs22\par\par")
        elif b.type == "p":
            rtf_lines.append(clean_inline_md(b.content) + r"\par\par")
        elif b.type == "quote":
            rtf_lines.append(r"\li400\i " + clean_inline_md(b.content) + r"\i0\li0\par\par")
        elif b.type == "code":
            for cl in b.content.split("\n"):
                rtf_lines.append(r"\f1\fs18\cf3 " + cl.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}") + r"\f0\fs22\cf0\par")
            rtf_lines.append(r"\par")
        elif b.type == "list":
            for indent, item in b.content:
                margin = (indent + 1) * 300
                rtf_lines.append(rf"\li{margin}\bullet  " + clean_inline_md(item) + r"\li0\par")
            rtf_lines.append(r"\par")
        elif b.type == "hr":
            rtf_lines.append(r"--------------------------------------------------\par\par")

    rtf_lines.append("}")
    return "\n".join(rtf_lines)


# ==============================================================================
# 7. LATEX CONVERTER (.tex)
# ==============================================================================

def convert_to_latex(blocks: List[MarkdownBlock], title: str = "Document") -> str:
    """Format markdown blocks into LaTeX article."""
    tex = [
        r"\documentclass[11pt,a4paper]{article}",
        r"\usepackage[margin=1in]{geometry}",
        r"\usepackage{hyperref}",
        r"\usepackage{listings}",
        r"\usepackage{xcolor}",
        r"\usepackage{booktabs}",
        r"\usepackage{microtype}",
        "",
        r"\definecolor{codegray}{rgb}{0.96,0.97,0.98}",
        r"\definecolor{codecyan}{rgb}{0.06,0.46,0.43}",
        r"\lstset{backgroundcolor=\color{codegray},basicstyle=\ttfamily\small\color{codecyan},breaklines=true,frame=single,framerule=0.5pt,rulecolor=\color{gray!30}}",
        "",
        rf"\title{{{title}}}",
        r"\author{Generated by LLM\_Local}",
        r"\date{\today}",
        r"\begin{document}",
        r"\maketitle",
        ""
    ]

    def esc_tex(s: str) -> str:
        chars = {"&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}"}
        pattern = re.compile("|".join(re.escape(k) for k in chars.keys()))
        return pattern.sub(lambda m: chars[m.group(0)], clean_inline_md(s))

    for b in blocks:
        if b.type == "h1":
            tex.append(rf"\section{{{esc_tex(b.content)}}}")
        elif b.type == "h2":
            tex.append(rf"\subsection{{{esc_tex(b.content)}}}")
        elif b.type == "h3":
            tex.append(rf"\subsubsection{{{esc_tex(b.content)}}}")
        elif b.type == "p":
            tex.append(esc_tex(b.content) + "\n")
        elif b.type == "code":
            tex.append(r"\begin{lstlisting}")
            tex.append(b.content)
            tex.append(r"\end{lstlisting}")
            tex.append("")
        elif b.type == "quote":
            tex.append(r"\begin{quote}")
            tex.append(esc_tex(b.content))
            tex.append(r"\end{quote}")
            tex.append("")
        elif b.type == "list":
            tex.append(r"\begin{itemize}")
            for _, item in b.content:
                tex.append(rf"  \item {esc_tex(item)}")
            tex.append(r"\end{itemize}")
            tex.append("")
        elif b.type == "hr":
            tex.append(r"\hrulefill" + "\n")

    tex.append(r"\end{document}")
    return "\n".join(tex) + "\n"


# ==============================================================================
# 8. STRUCTURED JSON CONVERTER (.json)
# ==============================================================================

def convert_to_json(blocks: List[MarkdownBlock]) -> str:
    """Format markdown blocks into structured JSON AST."""
    ast = []
    for b in blocks:
        item = {"type": b.type}
        if b.lang:
            item["lang"] = b.lang
        if b.level:
            item["level"] = b.level
        if b.type == "list":
            item["items"] = [{"indent": ind, "text": txt} for ind, txt in b.content]
        elif b.type == "table":
            item["rows"] = b.content
        else:
            item["content"] = b.content
        ast.append(item)
    return json.dumps({"document": ast}, indent=2)


# ==============================================================================
# 9. UNIVERSAL CONVERTER ENGINE (Orchestrator)
# ==============================================================================

class MarkdownConverter:
    SUPPORTED_FORMATS = ["pdf", "txt", "html", "htm", "docx", "rtf", "tex", "latex", "json"]

    @classmethod
    def convert_file(
        cls,
        input_path: str,
        output_path: Optional[str] = None,
        target_format: Optional[str] = None
    ) -> List[Path]:
        """
        Converts a markdown file into target format(s).
        If target_format is 'all', produces PDF, TXT, HTML, and DOCX simultaneously.
        """
        in_p = Path(input_path).resolve()
        if not in_p.exists():
            raise FileNotFoundError(f"Input markdown file '{input_path}' not found.")

        raw_md = in_p.read_text(encoding="utf-8", errors="ignore")
        blocks = parse_markdown(raw_md)
        doc_title = in_p.stem.replace("_", " ").title()

        # Determine target formats
        formats_to_build: List[Tuple[str, Path]] = []
        is_all = (target_format and target_format.lower() == "all") or (output_path and Path(output_path).suffix.lower() == ".all")

        if is_all:
            if output_path:
                out_p = Path(output_path).resolve()
                if out_p.is_dir():
                    for f in ["pdf", "txt", "html", "docx"]:
                        formats_to_build.append((f, out_p / f"{in_p.stem}.{f}"))
                else:
                    base = out_p.with_suffix("") if out_p.suffix else out_p
                    for f in ["pdf", "txt", "html", "docx"]:
                        formats_to_build.append((f, base.with_suffix(f".{f}")))
            else:
                for f in ["pdf", "txt", "html", "docx"]:
                    formats_to_build.append((f, in_p.with_suffix(f".{f}")))
        elif output_path:
            out_p = Path(output_path).resolve()
            ext = out_p.suffix.lower().lstrip(".")
            if not ext and target_format:
                ext = target_format.lower()
                out_p = out_p.with_suffix(f".{ext}")
            elif not ext:
                ext = "pdf"
                out_p = out_p.with_suffix(".pdf")
            formats_to_build.append((ext, out_p))
        elif target_format:
            fmt = target_format.lower()
            formats_to_build.append((fmt, in_p.with_suffix(f".{fmt}")))
        else:
            # Default to PDF
            formats_to_build.append(("pdf", in_p.with_suffix(".pdf")))

        generated_files: List[Path] = []

        for fmt, target_file in formats_to_build:
            target_file.parent.mkdir(parents=True, exist_ok=True)
            norm_fmt = fmt.lower()

            if norm_fmt == "pdf":
                pdf_bytes = convert_to_pdf(blocks)
                target_file.write_bytes(pdf_bytes)
            elif norm_fmt == "txt":
                txt_str = convert_to_txt(blocks)
                target_file.write_text(txt_str, encoding="utf-8")
            elif norm_fmt in ["html", "htm"]:
                html_str = convert_to_html(blocks, title=doc_title)
                target_file.write_text(html_str, encoding="utf-8")
            elif norm_fmt == "docx":
                convert_to_docx(blocks, target_file)
            elif norm_fmt == "rtf":
                rtf_str = convert_to_rtf(blocks)
                target_file.write_text(rtf_str, encoding="utf-8")
            elif norm_fmt in ["tex", "latex"]:
                tex_str = convert_to_latex(blocks, title=doc_title)
                target_file.write_text(tex_str, encoding="utf-8")
            elif norm_fmt == "json":
                json_str = convert_to_json(blocks)
                target_file.write_text(json_str, encoding="utf-8")
            else:
                raise ValueError(f"Unsupported format '{fmt}'. Choose from: {', '.join(cls.SUPPORTED_FORMATS)} or 'all'.")

            generated_files.append(target_file)
            print(f"  ✔ Generated \033[92m{target_file.name}\033[0m ({target_file.stat().st_size:,} bytes) -> {target_file}")

        return generated_files


# ==============================================================================
# 10. CLI INTERFACE
# ==============================================================================

def main():
    parser = argparse.ArgumentParser(
        prog="md_converter",
        description="Convert Markdown (.md) documents to PDF, TXT, HTML, DOCX, RTF, LaTeX, or JSON (100% Offline & Pure Python)."
    )
    parser.add_argument("input_file", help="Path to input Markdown (.md) file")
    parser.add_argument("-o", "--output", help="Path to output file (e.g. document.pdf, spec.docx, notes.txt)")
    parser.add_argument("-t", "--to", choices=["pdf", "txt", "html", "docx", "rtf", "tex", "json", "all"], help="Target format extension (default: inferred from -o or pdf)")

    args = parser.parse_args()

    print("==================================================")
    print("      Markdown Universal Document Converter       ")
    print("==================================================")
    print(f"  • Source Document : {args.input_file}")

    try:
        results = MarkdownConverter.convert_file(args.input_file, args.output, args.to)
        print(f"\nCompleted {len(results)} conversion(s) successfully!\n")
    except Exception as e:
        print(f"\n[Error] Conversion failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
