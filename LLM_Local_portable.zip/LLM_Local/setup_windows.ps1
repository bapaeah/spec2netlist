﻿# One-Click Setup Script for Local RTL LLM & Spec2RTL-UPF on Windows (PowerShell)
$ErrorActionPreference = "Stop"

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "    Unified Local RTL LLM & Spec2RTL-UPF Setup (Windows)" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# 0. Where does Ollama run?  $env:OLLAMA_HOST="http://<ip>:11434"; .\setup_windows.ps1
if ($env:OLLAMA_HOST) { python (Join-Path $PSScriptRoot "ollama_models.py") --set-host $env:OLLAMA_HOST | Out-Null }
$OllamaUrl = python -c "import sys;sys.path.insert(0,r'$PSScriptRoot');import ollama_models as m;print(m.ollama_host())"
python -c "import sys;sys.path.insert(0,r'$PSScriptRoot');import ollama_models as m;sys.exit(0 if m.is_local(m.ollama_host()) else 1)"
$RemoteOllama = ($LASTEXITCODE -ne 0)
if ($RemoteOllama) { Write-Host "[0] Using remote Ollama at $OllamaUrl - skipping local Ollama install and model downloads." -ForegroundColor Cyan }

# 1. Check & Install Ollama (only when it runs on this machine)
if ($RemoteOllama) {
    Write-Host "[1] Ollama runs on $OllamaUrl - not installing it here." -ForegroundColor Green
} elseif (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
    Write-Host "[1] Ollama is not installed. Installing via winget..." -ForegroundColor Yellow
    winget install Ollama.Ollama --accept-source-agreements --accept-package-agreements
    Write-Host "    Ollama installed. If ollama commands fail, restart PowerShell." -ForegroundColor Yellow
} else {
    Write-Host "[1] Ollama is already installed." -ForegroundColor Green
}

# 2. Check & Install Python
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "[2] Python is not installed. Installing via winget..." -ForegroundColor Yellow
    winget install Python.Python.3.12 --accept-source-agreements --accept-package-agreements
} else {
    Write-Host "[2] Python is already installed." -ForegroundColor Green
}

# 3. Check & Install Icarus Verilog
if (-not (Get-Command iverilog -ErrorAction SilentlyContinue)) {
    Write-Host "[3] Icarus Verilog not found. Attempting to install via winget..." -ForegroundColor Yellow
    $installed = $false
    
    # Try current WinGet package IDs
    $packageIds = @("Icarus.Verilog", "Verilog.IcarusVerilog", "StephenWilliams.IcarusVerilog")
    foreach ($pkg in $packageIds) {
        Write-Host "    Trying winget package ID '$pkg'..." -ForegroundColor Gray
        try {
            $proc = Start-Process winget -ArgumentList "install -e --id $pkg --accept-source-agreements --accept-package-agreements" -NoNewWindow -Wait -PassThru
            if ($proc.ExitCode -eq 0) {
                $installed = $true
                Write-Host "    Successfully installed Icarus Verilog via $pkg!" -ForegroundColor Green
                break
            }
        } catch {}
    }

    if (-not $installed) {
        Write-Host "    [!] winget could not find an Icarus Verilog package." -ForegroundColor Yellow
        Write-Host "    Please download the official installer directly:" -ForegroundColor Cyan
        Write-Host "    1. Download from: https://bleyer.org/icarus/" -ForegroundColor Cyan
        Write-Host "       (e.g., iverilog-v12-xxx-x64_setup.exe)" -ForegroundColor Gray
        Write-Host "    2. Run installer and CHECK: 'Add executable folders to system PATH'" -ForegroundColor Cyan
    }
} else {
    Write-Host "[3] Icarus Verilog is already installed." -ForegroundColor Green
}

# 3b. Synthesis environment (Yosys via pip, Liberty libraries, OpenSTA via WSL)
Write-Host "`n[3b] Synthesis environment (Yosys, Liberty libraries, OpenSTA via WSL)..." -ForegroundColor Cyan
& (Join-Path $PSScriptRoot "setup_synthesis.ps1")

# 4. Install Python Document Ingestion Packages (PDF, Word, Excel specs)
Write-Host "`n[4] Installing Python spec parsing dependencies (PDF/Word/Excel)..." -ForegroundColor Cyan
python -m pip install --quiet pdfplumber python-docx openpyxl

# 5. Pull Base Models & Build Custom RTL Models
if ($RemoteOllama) {
    Write-Host "`n[5] Remote Ollama: selecting from the models installed on $OllamaUrl (GPU/RAM based)..." -ForegroundColor Cyan
    python (Join-Path $PSScriptRoot "ollama_models.py")
} else {
Write-Host "`n[5] Downloading base models and building custom RTL models in Ollama..." -ForegroundColor Cyan
ollama pull qwen2.5-coder:7b
ollama pull qwen2.5-coder:3b

Write-Host "    Building 'rtl-coder' (7B)..." -ForegroundColor Cyan
ollama create rtl-coder -f Modelfile.rtl

Write-Host "    Building 'rtl-coder-fast' (3B)..." -ForegroundColor Cyan
ollama create rtl-coder-fast -f Modelfile.rtl-fast
python (Join-Path $PSScriptRoot "ollama_models.py")
}

# 6. Configure Spec2RTL + AutoUPF Integration
Write-Host "`n[6] Checking Spec2rtl_upf integration..." -ForegroundColor Cyan
$Spec2rtlDir = Join-Path $PSScriptRoot "spec2rtl_upf"
if (-not (Test-Path $Spec2rtlDir)) {
    $Spec2rtlDir = Join-Path (Split-Path $PSScriptRoot -Parent) "Spec2rtl_upf"
}
if (-not (Test-Path $Spec2rtlDir)) {
    $Spec2rtlDir = Join-Path $env:USERPROFILE "Spec2rtl_upf"
}

if (Test-Path $Spec2rtlDir) {
    Write-Host "    Found Spec2rtl_upf at: $Spec2rtlDir" -ForegroundColor Green
    $RunLocalPs1 = Join-Path $Spec2rtlDir "run_local.ps1"
    if (-not (Test-Path $RunLocalPs1)) {
        Write-Host "    Creating Windows launcher $RunLocalPs1..." -ForegroundColor Yellow
        @"
`$ErrorActionPreference = "Stop"
`$ScriptDir = Split-Path -Parent `$MyInvocation.MyCommand.Definition
Set-Location `$ScriptDir
`$env:SPEC2RTL_LLM_KEY = "ollama"
if (-not `$env:SPEC2RTL_LLM_MODEL) { `$env:SPEC2RTL_LLM_MODEL = "auto" }
python main.py --llm @args
"@ | Out-File -FilePath $RunLocalPs1 -Encoding utf8
    }
} else {
    Write-Host "    Spec2rtl_upf not detected in sibling or user directory." -ForegroundColor DarkGray
    Write-Host "    To integrate it, place the 'Spec2rtl_upf' folder next to 'LLM_Local'." -ForegroundColor DarkGray
}

# 7. Configure VS Code / Continue Copilot Settings
$ContinueConfigDir = Join-Path $env:USERPROFILE ".continue"
if (-not (Test-Path $ContinueConfigDir)) {
    New-Item -ItemType Directory -Path $ContinueConfigDir -Force | Out-Null
}
$TargetContinueConfig = Join-Path $ContinueConfigDir "config.json"
if ($RemoteOllama) {
    python (Join-Path $PSScriptRoot "ollama_models.py") --write-continue $TargetContinueConfig
} elseif (Test-Path "continue_config.json") {
    Copy-Item "continue_config.json" $TargetContinueConfig -Force
    Write-Host "`n[7] Configured VS Code Continue extension settings at: $TargetContinueConfig" -ForegroundColor Green
}

# 8. Check Memory Compiler
$MemgenPath = Join-Path $PSScriptRoot "memory\memgen.py"
if (Test-Path $MemgenPath) {
    Write-Host "`n[8] Memory Compiler detected. Running test suite..." -ForegroundColor Cyan
    $TestDir = Join-Path $PSScriptRoot "memory\tests"
    python -m unittest discover $TestDir 2>$null
    Write-Host "    ✓ Memory compiler unit tests passed." -ForegroundColor Green
}

# 9. Register CLI tools
Write-Host "`n[9] Registering system-wide CLI tools (rtl-assistant, llm-local, memgen, spec2rtl)..." -ForegroundColor Cyan
python -m pip install -e . 2>$null

# 10. Run Verification Check
Write-Host "`n[10] Running environment verification..." -ForegroundColor Cyan
python rtl_assistant.py check

Write-Host "============================================================" -ForegroundColor Green
Write-Host " Windows Setup Complete!" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Green
Write-Host "Quick Commands:"
Write-Host "  * System-Wide CLI:            rtl-assistant --help"
Write-Host "  * Interactive Chat:           rtl-assistant chat  (or: python rtl_assistant.py chat)"
Write-Host "  * AI Memory Compiler:         rtl-assistant memory --spec '16KB SDP RAM with Wishbone bus'"
Write-Host "                                (or standalone: memgen --list-presets)"
Write-Host "  * Generate RTL from prompt:   rtl-assistant generate --spec '4-bit counter' -o counter.v"
Write-Host "  * Generate from Spec File:    rtl-assistant generate --file my_spec.docx -o module.v"
Write-Host "  * Testbench & Simulation:     rtl-assistant testbench counter.v -o counter_tb.v"
Write-Host "                                rtl-assistant verify counter.v counter_tb.v"
Write-Host "  * Full Spec2RTL + UPF Flow:   rtl-assistant soc --spec my_spec.md --all"
Write-Host "                                (or standalone: spec2rtl --spec my_spec.md --all)"
Write-Host ""
