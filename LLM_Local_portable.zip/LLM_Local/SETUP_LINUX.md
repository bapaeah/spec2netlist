# Linux Setup Guide: Local RTL LLM & EDA Verification

This guide explains how to deploy this local RTL LLM workspace on any Linux workstation or headless server (Ubuntu, Debian, RHEL, Rocky, Fedora).

---

## Quick Start (Automated Script)

On your Linux machine, navigate into this directory and run:
```bash
chmod +x setup_linux.sh
./setup_linux.sh
```

---

## Manual Step-by-Step Instructions

### 1. Copy Files to the Linux Machine
From your source machine, transfer this directory using `rsync` or `scp`:
```bash
rsync -avz ./ user@<linux-ip>:~/LLM_Local/
```

### 2. Install Ollama on Linux
Run the official one-line installation command:
```bash
curl -fsSL https://ollama.com/install.sh | sh
```
* Automatically detects NVIDIA GPUs (CUDA) and AMD GPUs (ROCm).
* Configures and starts a background `systemd` service (`ollama.service`).
* Check service status:
  ```bash
  systemctl status ollama
  ```

### 3. Install Linux EDA & Python Tools
Install Icarus Verilog, Verilator, and Yosys:

**Ubuntu / Debian:**
```bash
sudo apt update
sudo apt install -y iverilog verilator yosys python3 python3-pip
```

**RHEL / Rocky / Fedora:**
```bash
sudo dnf install -y iverilog verilator yosys python3
```

### Synthesis, gate-level simulation & static timing (`./setup_synthesis.sh`)
`rtl --synth` and `spec2rtl --all` need more than Yosys:

| Item | Why | Installed by `setup_synthesis.sh` |
|---|---|---|
| Yosys, Icarus, Verilator | synthesis, GLS, lint | package manager (falls back to `pip install yowasp-yosys`) |
| OpenSTA (`sta`) | timing reports from the SDC | built from a pinned commit (+ CUDD) into `~/.local/llm_local_eda`, linked to `~/.local/bin` (~5 min, once) |
| NanGate45 + sky130 Liberty **with timing** | real cells, area, timing | downloaded (pinned commit, sha256-verified) to `techlib/<lib>/full/` |
| GLS models / synthesis views | simulate the netlist; drop dont_use cells | generated from the Liberty |

```bash
./setup_synthesis.sh            # everything + self-test (synth -> GLS -> STA on both libraries)
./setup_synthesis.sh --no-sta   # skip the OpenSTA build
rtl --synth top.sv sub.sv --lib sky130 --period 8 --tb tb_top.sv
```
Without it, synthesis falls back to the bundled 30-cell subsets: logic mapping and GLS work,
but there is no timing data, so area is indicative and STA is not possible.

### 4. Build Custom RTL Models
Navigate to the project folder and build the specialized RTL models:
```bash
cd ~/LLM_Local

# 1. Pull the base Qwen 2.5 Coder models
ollama pull qwen2.5-coder:7b
ollama pull qwen2.5-coder:3b

# 2. Build the specialized RTL models
ollama create rtl-coder -f Modelfile.rtl
ollama create rtl-coder-fast -f Modelfile.rtl-fast
```

---

## GPU VRAM Scaling on Linux

If your Linux server has a dedicated GPU with more VRAM, you can scale to larger models for even higher accuracy:

| GPU VRAM | Recommended Model | Modelfile Change |
| :--- | :--- | :--- |
| **6 GB - 12 GB** (RTX 3060/4060) | `qwen2.5-coder:7b` | (Default in `Modelfile.rtl`) |
| **16 GB** (RTX 4080 / T4 / V100) | `qwen2.5-coder:14b` | Change line 2 in `Modelfile.rtl` to `FROM qwen2.5-coder:14b` |
| **24 GB+** (RTX 3090/4090 / A10 / A5000) | `qwen2.5-coder:32b` | Change line 2 in `Modelfile.rtl` to `FROM qwen2.5-coder:32b` |

---

## Remote Access (Headless Server)

If the Linux server is headless and you want to use the models from your laptop's editor:

### Option A: Secure SSH Port Forwarding (Recommended)
From your client laptop (Mac/Windows/Linux):
```bash
ssh -N -L 11434:localhost:11434 user@<linux-server-ip>
```
Your local VS Code Continue extension will interact with `http://localhost:11434` securely without opening firewall ports.

### Option B: Bind to All Interfaces (LAN / VPN)
1. Edit the systemd service:
   ```bash
   sudo systemctl edit ollama.service
   ```
2. Insert:
   ```ini
   [Service]
   Environment="OLLAMA_HOST=0.0.0.0:11434"
   ```
3. Restart:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl restart ollama
   ```
4. Point [`continue_config.json`](file:///Users/bappi/LLM_Local/continue_config.json) `"apiBase"` to `http://<linux-server-ip>:11434`.

---

## Verification & Usage

### 1. General RTL Generation & Testbench Verification (`rtl_assistant.py`)
```bash
python3 rtl_assistant.py check

# Generate RTL from prompt or document (.pdf, .docx, .md)
python3 rtl_assistant.py generate --spec "4-bit priority encoder" -o encoder.v
python3 rtl_assistant.py generate --file /path/to/spec.docx -o module.v

# Generate Testbench & Run Simulation with Self-Healing Verification
python3 rtl_assistant.py testbench encoder.v -o encoder_tb.v
python3 rtl_assistant.py verify encoder.v encoder_tb.v
```

### 2. Technology-Agnostic Memory Compiler (`memgen.py`)
Compile custom on-chip memories directly or via natural language AI specification:
```bash
# AI Natural language memory synthesis:
python3 rtl_assistant.py memory --spec "16KB Simple Dual-Port RAM with 64-bit width and Wishbone bus"

# Direct flag compilation:
python3 rtl_assistant.py memory --type spram --size 4KB --bus axi5 --name sram_4k -o generated_mem

# View all supported presets:
python3 rtl_assistant.py memory --list-presets
```

### 3. Full SoC Architecture, CDC, UPF 2.1 & Gate Netlist Flow (`Spec2rtl_upf`)
Deploy `Spec2rtl_upf` side-by-side (`~/Spec2rtl_upf` or bundled inside `LLM_Local/spec2rtl_upf`):
```bash
cd ~/Spec2rtl_upf

# RTL-Only Mode (RTL + CDC Constraints + Verilator Lint + TB Simulation)
./run_local.sh --spec benchmarks/H264D-U1000_cfg_regs_spec.md --rtl-only

# Full Flow (RTL + CDC + UPF 2.1 Power Intent + SDC + 45nm Gate Netlist)
./run_local.sh --spec benchmarks/H264D-U1000_cfg_regs_spec.md \
               --config benchmarks/power_config.json \
               --filelist benchmarks/soc_filelist.f \
               --all

# Batch Generation across an entire folder of specs:
./run_local.sh --spec market_specs/ --rtl-only
```

Or trigger it directly from `LLM_Local`:
```bash
python3 ~/LLM_Local/rtl_assistant.py soc --spec market_specs/ --rtl-only
```
