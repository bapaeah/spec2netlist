#!/usr/bin/env bash
# =============================================================================
#  setup_synthesis.sh - everything `rtl --synth` / spec2rtl need for real
#  logic synthesis, gate-level simulation (GLS) and static timing (STA).
#
#  Installs / verifies:
#    1. Yosys, Icarus Verilog, Verilator              (brew / apt / dnf / pacman)
#    2. OpenSTA `sta` + CUDD (built from pinned source into $EDA_HOME)
#    3. Real Liberty files with timing (pinned commit, sha256-verified):
#         NanGate45 OpenCell typical  ->  techlib/nangate45/full/
#         SkyWater sky130_fd_sc_hd tt ->  techlib/sky130/full/
#    4. Synthesis views (dont_use cells removed) + GLS models from the Liberty
#    5. Self-test: synth + GLS + STA on both libraries
#
#  Usage:  ./setup_synthesis.sh [--no-sta] [--no-libs] [--eda-home DIR]
#  Re-runnable: every step is skipped when already satisfied.
#  Works on: macOS (Homebrew), Ubuntu/Debian, Fedora, Arch, and Termux via
#            `proot-distro login ubuntu` (run this script inside the proot).
# =============================================================================
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
EDA_HOME="${EDA_HOME:-$HOME/.local/llm_local_eda}"
BUILD_STA=1
GET_LIBS=1
OPENSTA_COMMIT="30653db490e13e4e2201439aa7090c64b3d7caa9"   # verified build, Nov 2026
CUDD_TAG="cudd-3.0.0"

while [ $# -gt 0 ]; do
  case "$1" in
    --no-sta)   BUILD_STA=0 ;;
    --no-libs)  GET_LIBS=0 ;;
    --eda-home) EDA_HOME="$2"; shift ;;
    -h|--help)  sed -n 2,22p "$0"; exit 0 ;;
    *) echo "Unknown option $1"; exit 1 ;;
  esac
  shift
done

say()  { printf "\n\033[1;36m%s\033[0m\n" "$*"; }
ok()   { printf "    \033[32m✓\033[0m %s\n" "$*"; }
warn() { printf "    \033[33m!\033[0m %s\n" "$*"; }
die()  { printf "    \033[31m✗\033[0m %s\n" "$*"; exit 1; }
have() { command -v "$1" >/dev/null 2>&1; }

OS="$(uname -s)"
if [ -n "${PREFIX:-}" ] && echo "$PREFIX" | grep -q com.termux; then
  die "Native Termux has no Yosys/OpenSTA packages. Run:  proot-distro install ubuntu && proot-distro login ubuntu
      then inside Ubuntu:  apt update && apt install -y git python3 && cd <LLM_Local> && ./setup_synthesis.sh"
fi
SUDO=""; [ "$(id -u)" -ne 0 ] && have sudo && SUDO="sudo"
PY="$(command -v python3 || command -v python)"

echo "============================================================"
echo " LLM_Local - Synthesis / GLS / STA environment setup ($OS)"
echo "============================================================"

# -----------------------------------------------------------------------------
say "[1/5] Yosys, Icarus Verilog, Verilator"
NEED=()
have yosys     || NEED+=(yosys)
have iverilog  || NEED+=(iverilog)
have verilator || NEED+=(verilator)
if [ ${#NEED[@]} -eq 0 ]; then
  ok "all present ($(yosys -V | head -1))"
else
  echo "    missing: ${NEED[*]}"
  if [ "$OS" = "Darwin" ]; then
    have brew || die "Homebrew is required on macOS: https://brew.sh"
    PKGS=(); for t in "${NEED[@]}"; do [ "$t" = iverilog ] && PKGS+=(icarus-verilog) || PKGS+=("$t"); done
    brew install "${PKGS[@]}"
  elif have apt-get; then
    $SUDO apt-get update -qq && $SUDO apt-get install -y "${NEED[@]}"
  elif have dnf; then
    $SUDO dnf install -y "${NEED[@]}"
  elif have pacman; then
    $SUDO pacman -S --needed --noconfirm "${NEED[@]}"
  else
    warn "unknown package manager - install ${NEED[*]} manually"
  fi
fi
if ! have yosys && ! have yowasp-yosys; then
  warn "no native yosys - installing the portable WebAssembly build (pip yowasp-yosys)"
  "$PY" -m pip install --user --quiet yowasp-yosys || "$PY" -m pip install --user --break-system-packages --quiet yowasp-yosys
fi
YV="$( (yosys -V 2>/dev/null || yowasp-yosys -V 2>/dev/null) | grep -oE '[0-9]+\.[0-9]+' | head -1 || true)"
[ -n "$YV" ] && ok "yosys $YV" || die "yosys still not available"

# -----------------------------------------------------------------------------
say "[2/5] OpenSTA (static timing analysis)"
mkdir -p "$EDA_HOME/bin" "$HOME/.local/bin"
if have sta; then
  ok "sta found at $(command -v sta)"
elif [ -x "$EDA_HOME/bin/sta" ]; then
  ok "sta found at $EDA_HOME/bin/sta"
elif [ "$BUILD_STA" -eq 0 ]; then
  warn "skipped (--no-sta). Timing reports will not be produced."
else
  echo "    building from source (~5 min, one time)..."
  if [ "$OS" = "Darwin" ]; then
    brew install cmake swig bison flex eigen tcl-tk@8 autoconf automake libtool
    export PATH="$(brew --prefix bison)/bin:$(brew --prefix flex)/bin:$PATH"
    export CMAKE_INCLUDE_PATH="$(brew --prefix flex)/include"
    export CMAKE_LIBRARY_PATH="$(brew --prefix flex)/lib;$(brew --prefix bison)/lib"
    TCLP="$(brew --prefix tcl-tk@8)"
    TCL_LIB="$(ls "$TCLP"/lib/libtcl8*.dylib 2>/dev/null | head -1)"
    TCL_HDR="$(ls "$TCLP"/include/tcl-tk/tcl.h "$TCLP"/include/tcl.h 2>/dev/null | head -1)"
    TCL_ARGS=(-DTCL_LIBRARY="$TCL_LIB" -DTCL_HEADER="$TCL_HDR")
    JOBS="$(sysctl -n hw.ncpu)"
  else
    if have apt-get; then
      $SUDO apt-get install -y build-essential cmake git tcl-dev swig flex bison libeigen3-dev zlib1g-dev \
                                autoconf automake libtool
    elif have dnf; then
      $SUDO dnf install -y gcc-c++ make cmake git tcl-devel swig flex bison eigen3-devel zlib-devel \
                           autoconf automake libtool
    elif have pacman; then
      $SUDO pacman -S --needed --noconfirm base-devel cmake git tcl swig flex bison eigen zlib
    fi
    TCL_ARGS=()
    JOBS="$(nproc 2>/dev/null || echo 4)"
  fi
  SRC="$EDA_HOME/src"; mkdir -p "$SRC"
  # CUDD (BSD) - required by current OpenSTA
  if [ ! -f "$EDA_HOME/cudd/lib/libcudd.a" ]; then
    rm -rf "$SRC/cudd"
    git -c advice.detachedHead=false clone -q --depth 1 -b "$CUDD_TAG" https://github.com/ivmai/cudd "$SRC/cudd"
    # the tag ships autotools output from automake 1.14; regenerate for the local toolchain
    ( cd "$SRC/cudd" && autoreconf -fi >/dev/null 2>&1 \
      && ./configure --prefix="$EDA_HOME/cudd" >/dev/null && make -j"$JOBS" >/dev/null && make install >/dev/null )
    ok "CUDD built"
  fi
  # OpenSTA (GPL-3.0) at a pinned, verified commit
  rm -rf "$SRC/OpenSTA"; mkdir -p "$SRC/OpenSTA"
  ( cd "$SRC/OpenSTA" && git init -q && git remote add origin https://github.com/parallaxsw/OpenSTA \
    && git fetch -q --depth 1 origin "$OPENSTA_COMMIT" && git -c advice.detachedHead=false checkout -q FETCH_HEAD )
  cmake -S "$SRC/OpenSTA" -B "$SRC/OpenSTA/build" -DCMAKE_BUILD_TYPE=Release \
        -DCUDD_DIR="$EDA_HOME/cudd" ${TCL_ARGS[@]+"${TCL_ARGS[@]}"} > "$EDA_HOME/opensta_cmake.log" 2>&1 \
    || die "OpenSTA cmake failed - see $EDA_HOME/opensta_cmake.log"
  cmake --build "$SRC/OpenSTA/build" -j"$JOBS" > "$EDA_HOME/opensta_build.log" 2>&1 \
    || die "OpenSTA build failed - see $EDA_HOME/opensta_build.log"
  cp "$SRC/OpenSTA/build/sta" "$EDA_HOME/bin/sta"
  ok "OpenSTA built -> $EDA_HOME/bin/sta"
fi
if [ -x "$EDA_HOME/bin/sta" ] && ! have sta; then
  ln -sf "$EDA_HOME/bin/sta" "$HOME/.local/bin/sta"
  export PATH="$HOME/.local/bin:$PATH"
  for rc in "$HOME/.zshrc" "$HOME/.bashrc"; do
    [ -f "$rc" ] && ! grep -q 'llm_local_eda\|\.local/bin' "$rc" && \
      echo 'export PATH="$HOME/.local/bin:$PATH"   # LLM_Local EDA tools' >> "$rc"
  done
  ok "linked sta into ~/.local/bin (open a new terminal or: export PATH=\"\$HOME/.local/bin:\$PATH\")"
fi

# -----------------------------------------------------------------------------
say "[3/5] Standard-cell Liberty files with timing"
if [ "$GET_LIBS" -eq 1 ]; then
  "$PY" "$DIR/techlib/synth_flow.py" --install-libs || warn "library download incomplete (see messages above)"
else
  warn "skipped (--no-libs): synthesis will use the bundled 30-cell subsets (no timing, no STA)"
fi

# -----------------------------------------------------------------------------
say "[4/5] Tool / library inventory"
"$PY" "$DIR/techlib/synth_flow.py" --doctor

# -----------------------------------------------------------------------------
say "[5/5] Self-test: synthesis -> gate-level simulation -> STA"
if "$PY" "$DIR/techlib/synth_flow.py" --selftest; then
  ok "synthesis environment is ready"
else
  warn "self-test reported a failure - see the table above"
fi

cat <<EOF

Usage:
  rtl --synth design.sv --lib nangate45 --period 5 --tb tb_design.sv   # synth + GLS + STA
  python3 techlib/synth_flow.py rtl/*.sv --top my_ip --lib sky130 --period 10
Notes:
  * The NanGate45 Liberty is distributed under the Nangate Open Cell Library license and
    sky130 under Apache-2.0; they are downloaded to techlib/*/full/ and are NOT committed.
  * memgen ASIC views instantiate HARD_MACRO_* black boxes: real SRAM macros (.lib/.lef) come
    from a memory compiler (e.g. OpenRAM for sky130); without them, synthesize memories with
    the FPGA/behavioural view or declare the macro as a black box.
EOF
