"""
Technology-Agnostic SystemVerilog Memory Compiler Package
Generates universal SystemVerilog Memory Modules & Wrappers (ROM, SPRAM, SDP, TDP)
for FPGA, Behavioral Simulation, ASIC, and Processor Bus Targets (AXI5, RISC-V i-Bus, AHB-Lite, Wishbone).
"""

from .memgen import main

__all__ = ["main"]
