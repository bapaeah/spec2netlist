import sys
import unittest
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from memory_compiler.spec import MemorySpec, MemoryType, ReadWriteBehavior
from memory_compiler.parser import parse_size_string, validate_universal_size
from memory_compiler.generators import (
    generate_behavioral_sv,
    generate_fpga_sv,
    generate_asic_sv,
    generate_top_sv,
    generate_axi5_sv
)


class TestMemoryCompiler(unittest.TestCase):

    def test_size_parsing(self):
        # 1. Capacity parsing
        depth, width = parse_size_string("4KB", default_width=32)
        self.assertEqual(depth, 1024)
        self.assertEqual(width, 32)

        depth, width = parse_size_string("16KB", default_width=64)
        self.assertEqual(depth, 2048)
        self.assertEqual(width, 64)

        # 2. Matrix parsing
        depth, width = parse_size_string("1Kx32")
        self.assertEqual(depth, 1024)
        self.assertEqual(width, 32)

        depth, width = parse_size_string("2Kx64")
        self.assertEqual(depth, 2048)
        self.assertEqual(width, 64)

        depth, width = parse_size_string("512x8")
        self.assertEqual(depth, 512)
        self.assertEqual(width, 8)

        # 3. Presets
        depth, width = parse_size_string("36KB")
        self.assertEqual(depth, 1024)
        self.assertEqual(width, 36)

        self.assertTrue(validate_universal_size(1024, 32))

    def test_rom_generation(self):
        spec = MemorySpec(
            name="rom_4k",
            mem_type=MemoryType.ROM,
            depth=1024,
            width=32,
            init_file="rom_init.hex"
        )
        beh_code = generate_behavioral_sv(spec)
        fpga_code = generate_fpga_sv(spec)
        asic_code = generate_asic_sv(spec)
        top_code = generate_top_sv(spec)

        self.assertIn("module rom_4k_behavioral", beh_code)
        self.assertIn("$readmemh", beh_code)
        self.assertIn("xpm_memory_sprom", fpga_code)
        self.assertIn("module rom_4k_asic", asic_code)
        self.assertIn("module rom_4k", top_code)

    def test_spram_generation(self):
        spec = MemorySpec(
            name="spram_1k",
            mem_type=MemoryType.SPRAM,
            depth=1024,
            width=32,
            byte_enable=True
        )
        beh_code = generate_behavioral_sv(spec)
        fpga_code = generate_fpga_sv(spec)
        top_code = generate_top_sv(spec)

        self.assertIn("input  logic [3:0] byte_we", beh_code)
        self.assertIn("xpm_memory_spram", fpga_code)
        self.assertIn("module spram_1k", top_code)

    def test_sdp_ram_generation(self):
        spec = MemorySpec(
            name="sdp_2k",
            mem_type=MemoryType.SDP_RAM,
            depth=2048,
            width=64
        )
        beh_code = generate_behavioral_sv(spec)
        fpga_code = generate_fpga_sv(spec)
        top_code = generate_top_sv(spec)

        self.assertIn("input  logic               clk_w", beh_code)
        self.assertIn("input  logic               clk_r", beh_code)
        self.assertIn("xpm_memory_sdpram", fpga_code)
        self.assertIn("module sdp_2k", top_code)

    def test_tdp_ram_generation(self):
        spec = MemorySpec(
            name="tdp_512",
            mem_type=MemoryType.TDP_RAM,
            depth=512,
            width=128
        )
        beh_code = generate_behavioral_sv(spec)
        fpga_code = generate_fpga_sv(spec)
        top_code = generate_top_sv(spec)

        self.assertIn("clk_a", beh_code)
        self.assertIn("clk_b", beh_code)
        self.assertIn("module tdp_512", top_code)

    def test_axi5_all_architectures(self):
        # 1. ROM AXI5 (Read Only)
        spec_rom = MemorySpec(name="rom_axi", mem_type=MemoryType.ROM, depth=1024, width=32, bus_interface="axi5")
        rom_code = generate_axi5_sv(spec_rom)
        self.assertIn("module rom_axi_axi5", rom_code)
        self.assertIn("s_axi_arvalid", rom_code)
        self.assertNotIn("s_axi_awvalid", rom_code)

        # 2. SPRAM AXI5
        spec_sp = MemorySpec(name="sp_axi", mem_type=MemoryType.SPRAM, depth=1024, width=32, byte_enable=True, bus_interface="axi5")
        sp_code = generate_axi5_sv(spec_sp)
        self.assertIn("module sp_axi_axi5", sp_code)
        self.assertIn("s_axi_awvalid", sp_code)

        # 3. SDP RAM AXI5 (Async Write & Read Clocks)
        spec_sdp = MemorySpec(name="sdp_axi", mem_type=MemoryType.SDP_RAM, depth=2048, width=64, bus_interface="axi5")
        sdp_code = generate_axi5_sv(spec_sdp)
        self.assertIn("module sdp_axi_axi5", sdp_code)
        self.assertIn("aclk_w", sdp_code)
        self.assertIn("aclk_r", sdp_code)

        # 4. TDP RAM AXI5 (Dual Slave Interfaces: Port A & Port B)
        spec_tdp = MemorySpec(name="tdp_axi", mem_type=MemoryType.TDP_RAM, depth=512, width=128, bus_interface="axi5")
        tdp_code = generate_axi5_sv(spec_tdp)
        self.assertIn("module tdp_axi_axi5", tdp_code)
        self.assertIn("s_axi_a_awvalid", tdp_code)
        self.assertIn("s_axi_b_awvalid", tdp_code)


if __name__ == "__main__":
    unittest.main()
