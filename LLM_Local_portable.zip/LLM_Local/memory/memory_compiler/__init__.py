"""
Technology-Agnostic SystemVerilog Memory Compiler Package
"""

__version__ = "1.0.0"
