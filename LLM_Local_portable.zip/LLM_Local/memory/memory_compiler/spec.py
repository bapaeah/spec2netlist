from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Optional
import math

class MemoryType(Enum):
    ROM = "rom"
    SPRAM = "spram"       # Single-Port RAM
    SDP_RAM = "sdp_ram"   # Simple Dual-Port RAM (1 Write Port, 1 Read Port)
    TDP_RAM = "tdp_ram"   # True Dual-Port RAM (2 Read/Write Ports)

class ReadWriteBehavior(Enum):
    NO_CHANGE = "no_change"
    READ_FIRST = "read_first"
    WRITE_FIRST = "write_first"

@dataclass
class MemorySpec:
    name: str
    mem_type: MemoryType
    depth: int
    width: int
    byte_enable: bool = False
    byte_size: int = 8
    init_file: Optional[str] = None
    read_during_write: ReadWriteBehavior = ReadWriteBehavior.NO_CHANGE
    output_register: bool = False
    asic_macro_name: Optional[str] = None
    bus_interface: Optional[str] = None  # None, 'axi5', or 'axi5-lite'

    @property
    def addr_width(self) -> int:
        return max(1, math.ceil(math.log2(self.depth)))

    @property
    def num_bytes(self) -> int:
        return max(1, self.width // self.byte_size)

    @property
    def capacity_bits(self) -> int:
        return self.depth * self.width

    @property
    def capacity_bytes(self) -> float:
        return (self.depth * self.width) / 8.0

    def get_formatted_capacity(self) -> str:
        bytes_val = self.capacity_bytes
        if bytes_val >= 1024 * 1024:
            return f"{bytes_val / (1024 * 1024):.1f}MB"
        elif bytes_val >= 1024:
            return f"{bytes_val / 1024:.1f}KB"
        else:
            return f"{int(bytes_val)}B"
