from memory_compiler.spec import MemorySpec, MemoryType

def generate_asic_sv(spec: MemorySpec) -> str:
    """
    Generates ASIC hard macro wrapper with active-low signal inversion,
    byte-mask mapping, BIST/DFT test hooks, and a fallback simulation behavioral stub.
    """
    mod_name = f"{spec.name}_asic"
    macro_name = spec.asic_macro_name or f"HARD_MACRO_{spec.name.upper()}"
    addr_w = spec.addr_width
    data_w = spec.width
    num_bytes = spec.num_bytes

    lines = []
    lines.append("// ========================================================================")
    lines.append(f"// SystemVerilog ASIC Target Hard Macro Wrapper: {mod_name}")
    lines.append(f"// Target Macro IP: {macro_name}")
    lines.append("// ========================================================================")
    lines.append("`timescale 1ns / 1ps")
    lines.append("")

    if spec.mem_type == MemoryType.SPRAM:
        lines.extend(_gen_asic_spram(mod_name, macro_name, spec, addr_w, data_w, num_bytes))
    elif spec.mem_type == MemoryType.SDP_RAM:
        lines.extend(_gen_asic_sdpram(mod_name, macro_name, spec, addr_w, data_w, num_bytes))
    elif spec.mem_type == MemoryType.ROM:
        lines.extend(_gen_asic_rom(mod_name, macro_name, spec, addr_w, data_w))
    else: # TDP_RAM
        lines.extend(_gen_asic_tdpram(mod_name, macro_name, spec, addr_w, data_w, num_bytes))

    # Append functional simulation model stub for the hard macro
    lines.extend(_gen_asic_macro_stub(macro_name, spec, addr_w, data_w, num_bytes))

    return "\n".join(lines)


def _gen_asic_spram(mod_name: str, macro_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} (")
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               en,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,")
    else:
        lines.append("    input  logic               we,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr,")
    lines.append(f"    input  logic [{data_w-1}:0] din,")
    lines.append(f"    output logic [{data_w-1}:0] dout,")
    lines.append("    ")
    lines.append("    // ASIC DFT / BIST / Power Control Signals")
    lines.append("    input  logic               bist_en,")
    lines.append("    input  logic               sleep_mode")
    lines.append(");")
    lines.append("")
    lines.append("    // Internal Active-Low Conversion for Standard Foundry Macros")
    lines.append("    wire ceb = ~(en & ~sleep_mode);")
    if spec.byte_enable:
        lines.append("    wire web = ~|byte_we;")
        lines.append(f"    wire [{data_w-1}:0] bweb;")
        for i in range(num_bytes):
            lsb = i * 8
            msb = lsb + 7
            lines.append(f"    assign bweb[{msb}:{lsb}] = {{8{{~byte_we[{i}]}}}};")
    else:
        lines.append("    wire web = ~we;")
    lines.append("")
    lines.append(f"    // Hard Macro Instance: {macro_name}")
    lines.append(f"    {macro_name} u_hard_macro (")
    lines.append("        .CLK(clk),")
    lines.append("        .CEB(ceb),")
    lines.append("        .WEB(web),")
    if spec.byte_enable:
        lines.append("        .BWEB(bweb),")
    lines.append("        .A(addr),")
    lines.append("        .D(din),")
    lines.append("        .Q(dout),")
    lines.append("        .SLP(sleep_mode),")
    lines.append("        .BIST(bist_en)")
    lines.append("    );")
    lines.append("endmodule")
    return lines


def _gen_asic_sdpram(mod_name: str, macro_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} (")
    lines.append("    input  logic               clk_w,")
    lines.append("    input  logic               we,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_w,")
    lines.append(f"    input  logic [{data_w-1}:0] din,")
    lines.append("    ")
    lines.append("    input  logic               clk_r,")
    lines.append("    input  logic               en_r,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_r,")
    lines.append(f"    output logic [{data_w-1}:0] dout,")
    lines.append("    ")
    lines.append("    input  logic               bist_en,")
    lines.append("    input  logic               sleep_mode")
    lines.append(");")
    lines.append("")
    lines.append("    wire cewb = ~we;")
    lines.append("    wire cerb = ~(en_r & ~sleep_mode);")
    lines.append("")
    lines.append(f"    {macro_name} u_sdp_hard_macro (")
    lines.append("        .CLKA(clk_w),")
    lines.append("        .CEAB(cewb),")
    lines.append("        .AA(addr_w),")
    lines.append("        .D(din),")
    lines.append("        .CLKB(clk_r),")
    lines.append("        .CEBB(cerb),")
    lines.append("        .AB(addr_r),")
    lines.append("        .Q(dout),")
    lines.append("        .SLP(sleep_mode),")
    lines.append("        .BIST(bist_en)")
    lines.append("    );")
    lines.append("endmodule")
    return lines


def _gen_asic_rom(mod_name: str, macro_name: str, spec: MemorySpec, addr_w: int, data_w: int) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} (")
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               en,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr,")
    lines.append(f"    output logic [{data_w-1}:0] dout,")
    lines.append("    input  logic               sleep_mode")
    lines.append(");")
    lines.append("    wire ceb = ~(en & ~sleep_mode);")
    lines.append("")
    lines.append(f"    {macro_name} u_rom_hard_macro (")
    lines.append("        .CLK(clk),")
    lines.append("        .CEB(ceb),")
    lines.append("        .A(addr),")
    lines.append("        .Q(dout)")
    lines.append("    );")
    lines.append("endmodule")
    return lines


def _gen_asic_tdpram(mod_name: str, macro_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} (")
    lines.append("    input  logic               clk_a,")
    lines.append("    input  logic               en_a,")
    lines.append("    input  logic               we_a,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_a,")
    lines.append(f"    input  logic [{data_w-1}:0] din_a,")
    lines.append(f"    output logic [{data_w-1}:0] dout_a,")
    lines.append("    ")
    lines.append("    input  logic               clk_b,")
    lines.append("    input  logic               en_b,")
    lines.append("    input  logic               we_b,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_b,")
    lines.append(f"    input  logic [{data_w-1}:0] din_b,")
    lines.append(f"    output logic [{data_w-1}:0] dout_b,")
    lines.append("    ")
    lines.append("    input  logic               bist_en,")
    lines.append("    input  logic               sleep_mode")
    lines.append(");")
    lines.append("    wire ceb_a = ~(en_a & ~sleep_mode);")
    lines.append("    wire web_a = ~we_a;")
    lines.append("    wire ceb_b = ~(en_b & ~sleep_mode);")
    lines.append("    wire web_b = ~we_b;")
    lines.append("")
    lines.append(f"    {macro_name} u_tdp_hard_macro (")
    lines.append("        .CLKA(clk_a), .CEBA(ceb_a), .WEBA(web_a), .AA(addr_a), .DA(din_a), .QA(dout_a),")
    lines.append("        .CLKB(clk_b), .CEBB(ceb_b), .WEBB(web_b), .AB(addr_b), .DB(din_b), .QB(dout_b),")
    lines.append("        .SLP(sleep_mode), .BIST(bist_en)")
    lines.append("    );")
    lines.append("endmodule")
    return lines


def _gen_asic_macro_stub(macro_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int) -> list[str]:
    lines = []
    lines.append("")
    lines.append("// ========================================================================")
    lines.append(f"// Fallback Functional Simulation Model for Foundry Hard Macro: {macro_name}")
    lines.append("// (Compiled during simulation/linting if foundry IP .v model is not provided)")
    lines.append("// ========================================================================")
    lines.append("`ifdef SIM")

    if spec.mem_type == MemoryType.SPRAM:
        lines.append(f"module {macro_name} (")
        lines.append("    input  logic        CLK,")
        lines.append("    input  logic        CEB,  // Active-low Chip Enable")
        lines.append("    input  logic        WEB,  // Active-low Write Enable")
        if spec.byte_enable:
            lines.append(f"    input  logic [{data_w-1}:0] BWEB, // Active-low Bit Write Enable")
        lines.append(f"    input  logic [{addr_w-1}:0] A,")
        lines.append(f"    input  logic [{data_w-1}:0] D,")
        lines.append(f"    output logic [{data_w-1}:0] Q,")
        lines.append("    input  logic        SLP,  // Sleep mode")
        lines.append("    input  logic        BIST  // BIST mode")
        lines.append(");")
        lines.append(f"    logic [{data_w-1}:0] mem [0:{spec.depth-1}];")
        lines.append(f"    logic [{data_w-1}:0] q_reg;")
        lines.append("")
        lines.append("    always_ff @(posedge CLK) begin")
        lines.append("        if (!CEB && !SLP) begin")
        if spec.byte_enable:
            lines.append(f"            for (int i = 0; i < {data_w}; i++) begin")
            lines.append("                if (!BWEB[i] && !WEB) mem[A][i] <= D[i];")
            lines.append("            end")
        else:
            lines.append("            if (!WEB) mem[A] <= D;")
        lines.append("            q_reg <= mem[A];")
        lines.append("        end")
        lines.append("    end")
        lines.append("    assign Q = q_reg;")
        lines.append("endmodule")

    elif spec.mem_type == MemoryType.SDP_RAM:
        lines.append(f"module {macro_name} (")
        lines.append("    input  logic        CLKA,")
        lines.append("    input  logic        CEAB,")
        lines.append(f"    input  logic [{addr_w-1}:0] AA,")
        lines.append(f"    input  logic [{data_w-1}:0] D,")
        lines.append("    input  logic        CLKB,")
        lines.append("    input  logic        CEBB,")
        lines.append(f"    input  logic [{addr_w-1}:0] AB,")
        lines.append(f"    output logic [{data_w-1}:0] Q,")
        lines.append("    input  logic        SLP,")
        lines.append("    input  logic        BIST")
        lines.append(");")
        lines.append(f"    logic [{data_w-1}:0] mem [0:{spec.depth-1}];")
        lines.append(f"    logic [{data_w-1}:0] q_reg;")
        lines.append("")
        lines.append("    always_ff @(posedge CLKA) begin")
        lines.append("        if (!CEAB && !SLP) mem[AA] <= D;")
        lines.append("    end")
        lines.append("    always_ff @(posedge CLKB) begin")
        lines.append("        if (!CEBB && !SLP) q_reg <= mem[AB];")
        lines.append("    end")
        lines.append("    assign Q = q_reg;")
        lines.append("endmodule")

    elif spec.mem_type == MemoryType.ROM:
        lines.append(f"module {macro_name} (")
        lines.append("    input  logic        CLK,")
        lines.append("    input  logic        CEB,")
        lines.append(f"    input  logic [{addr_w-1}:0] A,")
        lines.append(f"    output logic [{data_w-1}:0] Q")
        lines.append(");")
        lines.append(f"    logic [{data_w-1}:0] mem [0:{spec.depth-1}];")
        lines.append(f"    logic [{data_w-1}:0] q_reg;")
        lines.append("")
        lines.append("    always_ff @(posedge CLK) begin")
        lines.append("        if (!CEB) q_reg <= mem[A];")
        lines.append("    end")
        lines.append("    assign Q = q_reg;")
        lines.append("endmodule")

    else: # TDP_RAM
        lines.append(f"module {macro_name} (")
        lines.append("    input  logic        CLKA, CEBA, WEBA,")
        lines.append(f"    input  logic [{addr_w-1}:0] AA,")
        lines.append(f"    input  logic [{data_w-1}:0] DA,")
        lines.append(f"    output logic [{data_w-1}:0] QA,")
        lines.append("    input  logic        CLKB, CEBB, WEBB,")
        lines.append(f"    input  logic [{addr_w-1}:0] AB,")
        lines.append(f"    input  logic [{data_w-1}:0] DB,")
        lines.append(f"    output logic [{data_w-1}:0] QB,")
        lines.append("    input  logic        SLP, BIST")
        lines.append(");")
        lines.append(f"    logic [{data_w-1}:0] mem [0:{spec.depth-1}];")
        lines.append(f"    logic [{data_w-1}:0] qa_reg, qb_reg;")
        lines.append("")
        lines.append("    always_ff @(posedge CLKA) begin")
        lines.append("        if (!CEBA && !SLP) begin")
        lines.append("            if (!WEBA) mem[AA] <= DA;")
        lines.append("            qa_reg <= mem[AA];")
        lines.append("        end")
        lines.append("    end")
        lines.append("    always_ff @(posedge CLKB) begin")
        lines.append("        if (!CEBB && !SLP) begin")
        lines.append("            if (!WEBB) mem[AB] <= DB;")
        lines.append("            qb_reg <= mem[AB];")
        lines.append("        end")
        lines.append("    end")
        lines.append("    assign QA = qa_reg;")
        lines.append("    assign QB = qb_reg;")
        lines.append("endmodule")

    lines.append("`endif")
    return lines
