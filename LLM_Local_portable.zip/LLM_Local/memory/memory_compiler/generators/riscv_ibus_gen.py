from memory_compiler.spec import MemorySpec, MemoryType

def generate_riscv_ibus_sv(spec: MemorySpec) -> str:
    """
    Generates a synthesizable Direct RISC-V Core Instruction & Data Bus Memory Adapter in SystemVerilog.
    Translates RISC-V 32-bit CPU pipeline PC/Data requests to memory signals.
    """
    mod_name = f"{spec.name}_riscv_ibus"
    top_name = spec.name
    addr_w = spec.addr_width
    data_w = spec.width
    num_bytes = spec.num_bytes
    is_rom = (spec.mem_type == MemoryType.ROM)

    lines = []
    lines.append("// ========================================================================")
    lines.append(f"// SystemVerilog RISC-V Core Native i-Bus Memory Subsystem: {mod_name}")
    lines.append(f"// Wraps module '{top_name}' for Direct RISC-V CPU Pipeline Connection")
    lines.append(f"// Spec: {spec.mem_type.value.upper()} | Depth={spec.depth} | Width={data_w} ({spec.get_formatted_capacity()})")
    lines.append("// ========================================================================")
    lines.append("`timescale 1ns / 1ps")
    lines.append("")
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               rst_n,")
    lines.append("    ")
    lines.append("    // RISC-V Core Bus Interface")
    lines.append("    input  logic               req,         // Fetch / Data Request")
    lines.append("    input  logic [31:0]        addr,        // 32-bit CPU Byte Address")
    if not is_rom:
        lines.append("    input  logic               we,          // Write Enable (1'b0 for ROM)")
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,     // Byte Strobe Mask")
        lines.append(f"    input  logic [{data_w-1}:0]        wdata,       // Write Data from RISC Core")
    lines.append(f"    output logic [{data_w-1}:0]        rdata,       // Instruction / Read Data to RISC Core")
    lines.append("    output logic               rvalid,      // Read Data Valid Handshake")
    lines.append("    output logic               gnt,         // Request Grant Handshake")
    lines.append("    output logic               err          // Address Out-of-Bounds Error")
    lines.append(");")
    lines.append("")
    lines.append(f"    wire [{addr_w-1}:0] mem_addr = addr[{addr_w+1}:2];")
    lines.append(f"    wire addr_out_of_bounds = |addr[31:{addr_w+2}];")
    lines.append("    assign err = req & addr_out_of_bounds;")
    lines.append("    assign gnt = req & ~addr_out_of_bounds;")
    lines.append("")
    lines.append("    logic rvalid_reg;")
    lines.append("    always_ff @(posedge clk or negedge rst_n) begin")
    lines.append("        if (!rst_n) begin")
    lines.append("            rvalid_reg <= 1'b0;")
    lines.append("        end else begin")
    lines.append("            rvalid_reg <= gnt;")
    lines.append("        end")
    lines.append("    end")
    lines.append("    assign rvalid = rvalid_reg;")
    lines.append("")
    lines.append(f"    {top_name} #(")
    lines.append("`ifndef SYNTHESIS")
    lines.append("        .INIT_FILE(INIT_FILE)")
    lines.append("`endif")
    lines.append("    ) u_top_memory (")
    lines.append("        .clk(clk),")
    lines.append("        .en(gnt),")
    if not is_rom:
        if spec.byte_enable:
            lines.append("        .byte_we(byte_we),")
        else:
            lines.append("        .we(we),")
    lines.append("        .addr(mem_addr),")
    if not is_rom:
        lines.append("        .din(wdata),")
    lines.append("        .dout(rdata)")
    lines.append("    );")
    lines.append("endmodule")
    return "\n".join(lines)
