from memory_compiler.spec import MemorySpec, MemoryType, ReadWriteBehavior

def generate_behavioral_sv(spec: MemorySpec) -> str:
    """
    Generates a pure SystemVerilog behavioral model for simulation & linting.
    Includes assertions, parameterizable delays, initialization, and byte-enables.
    """
    mod_name = f"{spec.name}_behavioral"
    addr_w = spec.addr_width
    data_w = spec.width
    num_bytes = spec.num_bytes
    byte_s = spec.byte_size

    lines = []
    lines.append("// ========================================================================")
    lines.append(f"// SystemVerilog Behavioral Simulation Model: {mod_name}")
    lines.append(f"// Type: {spec.mem_type.value.upper()} | Depth: {spec.depth} | Width: {data_w}-bit ({spec.get_formatted_capacity()})")
    lines.append("// ========================================================================")
    lines.append("`timescale 1ns / 1ps")
    lines.append("")

    if spec.mem_type == MemoryType.ROM:
        lines.extend(_gen_rom(mod_name, spec, addr_w, data_w))
    elif spec.mem_type == MemoryType.SPRAM:
        lines.extend(_gen_spram(mod_name, spec, addr_w, data_w, num_bytes, byte_s))
    elif spec.mem_type == MemoryType.SDP_RAM:
        lines.extend(_gen_sdp_ram(mod_name, spec, addr_w, data_w, num_bytes, byte_s))
    elif spec.mem_type == MemoryType.TDP_RAM:
        lines.extend(_gen_tdp_ram(mod_name, spec, addr_w, data_w, num_bytes, byte_s))

    return "\n".join(lines)


def _gen_rom(mod_name: str, spec: MemorySpec, addr_w: int, data_w: int) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               en,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    lines.append(f"    logic [{data_w-1}:0] mem [0:{spec.depth-1}];")
    lines.append(f"    logic [{data_w-1}:0] dout_reg;")
    lines.append("")
    lines.append("    initial begin")
    lines.append("        if (INIT_FILE != \"\") begin")
    lines.append("            $readmemh(INIT_FILE, mem);")
    lines.append("        end else begin")
    lines.append(f"            for (int i = 0; i < {spec.depth}; i++) begin")
    lines.append("                mem[i] = '0;")
    lines.append("            end")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    always_ff @(posedge clk) begin")
    lines.append("        if (en) begin")
    lines.append("            dout_reg <= mem[addr];")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    assign dout = dout_reg;")
    lines.append("endmodule")
    return lines


def _gen_spram(mod_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int, byte_s: int) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               en,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,")
    else:
        lines.append("    input  logic               we,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr,")
    lines.append(f"    input  logic [{data_w-1}:0] din,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    lines.append(f"    logic [{data_w-1}:0] mem [0:{spec.depth-1}];")
    lines.append(f"    logic [{data_w-1}:0] dout_reg;")
    lines.append("")
    lines.append("    initial begin")
    lines.append("        if (INIT_FILE != \"\") begin")
    lines.append("            $readmemh(INIT_FILE, mem);")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    always_ff @(posedge clk) begin")
    lines.append("        if (en) begin")

    if spec.read_during_write == ReadWriteBehavior.READ_FIRST:
        lines.append("            dout_reg <= mem[addr];")

    if spec.byte_enable:
        for i in range(num_bytes):
            lsb = i * byte_s
            msb = lsb + byte_s - 1
            lines.append(f"            if (byte_we[{i}]) mem[addr][{msb}:{lsb}] <= din[{msb}:{lsb}];")
    else:
        lines.append("            if (we) mem[addr] <= din;")

    if spec.read_during_write == ReadWriteBehavior.WRITE_FIRST:
        if spec.byte_enable:
            lines.append("            dout_reg <= mem[addr]; // Write-first updated value")
        else:
            lines.append("            dout_reg <= (we) ? din : mem[addr];")
    elif spec.read_during_write == ReadWriteBehavior.NO_CHANGE:
        if spec.byte_enable:
            lines.append("            if (~|byte_we) dout_reg <= mem[addr];")
        else:
            lines.append("            if (!we) dout_reg <= mem[addr];")

    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    assign dout = dout_reg;")
    lines.append("endmodule")
    return lines


def _gen_sdp_ram(mod_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int, byte_s: int) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               clk_w,")
    lines.append("    input  logic               we,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_w,")
    lines.append(f"    input  logic [{data_w-1}:0] din,")
    lines.append("    ")
    lines.append("    input  logic               clk_r,")
    lines.append("    input  logic               en_r,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_r,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    lines.append(f"    logic [{data_w-1}:0] mem [0:{spec.depth-1}];")
    lines.append(f"    logic [{data_w-1}:0] dout_reg;")
    lines.append("")
    lines.append("    initial begin")
    lines.append("        if (INIT_FILE != \"\") begin")
    lines.append("            $readmemh(INIT_FILE, mem);")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    // Write Port")
    lines.append("    always_ff @(posedge clk_w) begin")
    if spec.byte_enable:
        for i in range(num_bytes):
            lsb = i * byte_s
            msb = lsb + byte_s - 1
            lines.append(f"        if (we && byte_we[{i}]) mem[addr_w][{msb}:{lsb}] <= din[{msb}:{lsb}];")
    else:
        lines.append("        if (we) mem[addr_w] <= din;")
    lines.append("    end")
    lines.append("")
    lines.append("    // Read Port")
    lines.append("    always_ff @(posedge clk_r) begin")
    lines.append("        if (en_r) begin")
    lines.append("            dout_reg <= mem[addr_r];")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    assign dout = dout_reg;")
    lines.append("endmodule")
    return lines


def _gen_tdp_ram(mod_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int, byte_s: int) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    // Port A")
    lines.append("    input  logic               clk_a,")
    lines.append("    input  logic               en_a,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we_a,")
    else:
        lines.append("    input  logic               we_a,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_a,")
    lines.append(f"    input  logic [{data_w-1}:0] din_a,")
    lines.append(f"    output logic [{data_w-1}:0] dout_a,")
    lines.append("    ")
    lines.append("    // Port B")
    lines.append("    input  logic               clk_b,")
    lines.append("    input  logic               en_b,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we_b,")
    else:
        lines.append("    input  logic               we_b,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_b,")
    lines.append(f"    input  logic [{data_w-1}:0] din_b,")
    lines.append(f"    output logic [{data_w-1}:0] dout_b")
    lines.append(");")
    lines.append("")
    lines.append(f"    logic [{data_w-1}:0] mem [0:{spec.depth-1}];")
    lines.append(f"    logic [{data_w-1}:0] dout_reg_a;")
    lines.append(f"    logic [{data_w-1}:0] dout_reg_b;")
    lines.append("")
    lines.append("    // Port A Logic")
    lines.append("    always_ff @(posedge clk_a) begin")
    lines.append("        if (en_a) begin")
    if spec.byte_enable:
        for i in range(num_bytes):
            lsb = i * byte_s
            msb = lsb + byte_s - 1
            lines.append(f"            if (byte_we_a[{i}]) mem[addr_a][{msb}:{lsb}] <= din_a[{msb}:{lsb}];")
    else:
        lines.append("            if (we_a) mem[addr_a] <= din_a;")
    lines.append("            dout_reg_a <= mem[addr_a];")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    // Port B Logic")
    lines.append("    always_ff @(posedge clk_b) begin")
    lines.append("        if (en_b) begin")
    if spec.byte_enable:
        for i in range(num_bytes):
            lsb = i * byte_s
            msb = lsb + byte_s - 1
            lines.append(f"            if (byte_we_b[{i}]) mem[addr_b][{msb}:{lsb}] <= din_b[{msb}:{lsb}];")
    else:
        lines.append("            if (we_b) mem[addr_b] <= din_b;")
    lines.append("            dout_reg_b <= mem[addr_b];")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    assign dout_a = dout_reg_a;")
    lines.append("    assign dout_b = dout_reg_b;")
    lines.append("endmodule")
    return lines
