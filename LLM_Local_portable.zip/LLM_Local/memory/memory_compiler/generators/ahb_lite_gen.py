from memory_compiler.spec import MemorySpec, MemoryType

def generate_ahb_lite_sv(spec: MemorySpec) -> str:
    """
    Generates a synthesizable AMBA AHB-Lite Processor Bus Memory Subsystem in SystemVerilog.
    Translates AHB-Lite bus transfers (HCLK, HRESETn, HSEL, HADDR, HTRANS, HWDATA, HRDATA) to memory.
    """
    mod_name = f"{spec.name}_ahb_lite"
    top_name = spec.name
    addr_w = spec.addr_width
    data_w = spec.width
    num_bytes = spec.num_bytes
    is_rom = (spec.mem_type == MemoryType.ROM)

    lines = []
    lines.append("// ========================================================================")
    lines.append(f"// SystemVerilog AMBA AHB-Lite Processor Bus Subsystem: {mod_name}")
    lines.append(f"// Wraps module '{top_name}' for AMBA AHB-Lite Interconnect")
    lines.append(f"// Spec: {spec.mem_type.value.upper()} | Depth={spec.depth} | Width={data_w} ({spec.get_formatted_capacity()})")
    lines.append("// ========================================================================")
    lines.append("`timescale 1ns / 1ps")
    lines.append("")
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               HCLK,")
    lines.append("    input  logic               HRESETn,")
    lines.append("    ")
    lines.append("    // AHB-Lite Bus Interface")
    lines.append("    input  logic               HSEL,")
    lines.append("    input  logic [31:0]        HADDR,")
    lines.append("    input  logic [1:0]         HTRANS,     // 2'b00: IDLE, 2'b10: NONSEQ, 2'b11: SEQ")
    lines.append("    input  logic               HWRITE,")
    lines.append("    input  logic [2:0]         HSIZE,")
    lines.append(f"    input  logic [{data_w-1}:0]        HWDATA,")
    lines.append(f"    output logic [{data_w-1}:0]        HRDATA,")
    lines.append("    output logic               HREADYOUT,")
    lines.append("    output logic               HRESP       // 1'b0: OKAY, 1'b1: ERROR")
    lines.append(");")
    lines.append("")
    lines.append("    wire trans_req = HSEL && HTRANS[1];")
    lines.append(f"    wire [{addr_w-1}:0] mem_addr = HADDR[{addr_w+1}:2];")
    lines.append("    assign HREADYOUT = 1'b1; // 1-cycle zero wait-state response")
    lines.append("    assign HRESP     = 1'b0; // Always OKAY")
    lines.append("")

    if not is_rom:
        lines.append("    logic write_phase_reg;")
        lines.append(f"    logic [{addr_w-1}:0] addr_reg;")
        lines.append("    logic [2:0] size_reg;")
        lines.append("")
        lines.append("    always_ff @(posedge HCLK or negedge HRESETn) begin")
        lines.append("        if (!HRESETn) begin")
        lines.append("            write_phase_reg <= 1'b0;")
        lines.append("            addr_reg        <= '0;")
        lines.append("            size_reg        <= '0;")
        lines.append("        end else begin")
        lines.append("            if (trans_req && HWRITE) begin")
        lines.append("                write_phase_reg <= 1'b1;")
        lines.append("                addr_reg        <= mem_addr;")
        lines.append("                size_reg        <= HSIZE;")
        lines.append("            end else begin")
        lines.append("                write_phase_reg <= 1'b0;")
        lines.append("            end")
        lines.append("        end")
        lines.append("    end")
        lines.append("")
        if spec.byte_enable:
            lines.append(f"    logic [{num_bytes-1}:0] byte_we;")
            lines.append("    always_comb begin")
            lines.append("        case (size_reg)")
            lines.append(f"            3'b000: byte_we = {num_bytes}'b0001; // Byte")
            lines.append(f"            3'b001: byte_we = {num_bytes}'b0011; // Half-word")
            lines.append(f"            default: byte_we = {num_bytes}'b1111; // Word")
            lines.append("        endcase")
            lines.append("    end")
        lines.append("")

    lines.append("    wire mem_en = trans_req || " + ("write_phase_reg;" if not is_rom else "1'b0;"))
    if not is_rom:
        lines.append(f"    wire [{addr_w-1}:0] final_addr = write_phase_reg ? addr_reg : mem_addr;")
    else:
        lines.append(f"    wire [{addr_w-1}:0] final_addr = mem_addr;")
    lines.append("")

    lines.append(f"    {top_name} #(")
    lines.append("`ifndef SYNTHESIS")
    lines.append("        .INIT_FILE(INIT_FILE)")
    lines.append("`endif")
    lines.append("    ) u_top_memory (")
    lines.append("        .clk(HCLK),")
    lines.append("        .en(mem_en),")
    if not is_rom:
        if spec.byte_enable:
            lines.append("        .byte_we(write_phase_reg ? byte_we : '0),")
        else:
            lines.append("        .we(write_phase_reg),")
    lines.append("        .addr(final_addr),")
    if not is_rom:
        lines.append("        .din(HWDATA),")
    lines.append("        .dout(HRDATA)")
    lines.append("    );")
    lines.append("endmodule")
    return "\n".join(lines)
