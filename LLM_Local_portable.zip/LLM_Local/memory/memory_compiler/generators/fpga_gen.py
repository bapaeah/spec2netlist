from memory_compiler.spec import MemorySpec, MemoryType

def generate_fpga_sv(spec: MemorySpec) -> str:
    """
    Generates FPGA-friendly SystemVerilog with automatic synthesis pragmas
    (BRAM vs URAM auto-selection) and AMD Xilinx XPM macro instantiations.
    """
    mod_name = f"{spec.name}_fpga"
    addr_w = spec.addr_width
    data_w = spec.width
    num_bytes = spec.num_bytes
    byte_s = spec.byte_size

    # Choose RAM style: URAM if capacity > 128Kb (16KB), else BRAM
    ram_style = "ultra" if spec.capacity_bits >= (128 * 1024) else "block"

    lines = []
    lines.append("// ========================================================================")
    lines.append(f"// SystemVerilog FPGA Target Wrapper: {mod_name}")
    lines.append(f"// Target: Inferred ({ram_style.upper()}) & AMD Xilinx XPM Macro")
    lines.append("// ========================================================================")
    lines.append("`timescale 1ns / 1ps")
    lines.append("")

    if spec.mem_type == MemoryType.ROM:
        lines.extend(_gen_fpga_rom(mod_name, spec, addr_w, data_w, ram_style))
    elif spec.mem_type == MemoryType.SPRAM:
        lines.extend(_gen_fpga_spram(mod_name, spec, addr_w, data_w, num_bytes, byte_s, ram_style))
    elif spec.mem_type == MemoryType.SDP_RAM:
        lines.extend(_gen_fpga_sdpram(mod_name, spec, addr_w, data_w, num_bytes, byte_s, ram_style))
    elif spec.mem_type == MemoryType.TDP_RAM:
        lines.extend(_gen_fpga_tdpram(mod_name, spec, addr_w, data_w, num_bytes, byte_s, ram_style))

    return "\n".join(lines)


def _gen_fpga_rom(mod_name: str, spec: MemorySpec, addr_w: int, data_w: int, ram_style: str) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               en,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    lines.append("`ifdef USE_XPM_PRIMITIVE")
    lines.append("    // AMD Xilinx XPM SPROM Macro")
    lines.append("    xpm_memory_sprom #(")
    lines.append(f"        .ADDR_WIDTH_A({addr_w}),")
    lines.append(f"        .AUTO_SLEEP_TIME(0),")
    lines.append(f"        .MEMORY_INIT_FILE(INIT_FILE),")
    lines.append(f"        .MEMORY_INIT_PARAM(\"0\"),")
    lines.append(f"        .MEMORY_SIZE({spec.capacity_bits}),")
    lines.append(f"        .READ_DATA_WIDTH_A({data_w}),")
    lines.append("        .READ_LATENCY_A(1)")
    lines.append("    ) xpm_sprom_inst (")
    lines.append("        .dbterra(),")
    lines.append("        .douta(dout),")
    lines.append("        .sbterra(),")
    lines.append("        .addra(addr),")
    lines.append("        .clka(clk),")
    lines.append("        .ena(en),")
    lines.append("        .injectdbterra(1'b0),")
    lines.append("        .injectsbterra(1'b0),")
    lines.append("        .regcea(1'b1),")
    lines.append("        .rsta(1'b0)")
    lines.append("    );")
    lines.append("`else")
    lines.append(f"    // Inferred FPGA ROM ({ram_style.upper()})")
    lines.append(f"    (* ram_style = \"{ram_style}\" *)")
    lines.append(f"    logic [{data_w-1}:0] rom [0:{spec.depth-1}];")
    lines.append(f"    logic [{data_w-1}:0] dout_reg;")
    lines.append("")
    lines.append("    initial begin")
    lines.append("        if (INIT_FILE != \"\") begin")
    lines.append("            $readmemh(INIT_FILE, rom);")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    always_ff @(posedge clk) begin")
    lines.append("        if (en) begin")
    lines.append("            dout_reg <= rom[addr];")
    lines.append("        end")
    lines.append("    end")
    lines.append("    assign dout = dout_reg;")
    lines.append("`endif")
    lines.append("endmodule")
    return lines


def _gen_fpga_spram(mod_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int, byte_s: int, ram_style: str) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               en,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,")
    else:
        lines.append("    input  logic               we,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr,")
    lines.append(f"    input  logic [{data_w-1}:0] din,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    lines.append("`ifdef USE_XPM_PRIMITIVE")
    lines.append("    // AMD Xilinx XPM SPRAM Macro")
    lines.append("    xpm_memory_spram #(")
    lines.append(f"        .ADDR_WIDTH_A({addr_w}),")
    lines.append(f"        .BYTE_WRITE_WIDTH_A({'8' if spec.byte_enable else data_w}),")
    lines.append(f"        .MEMORY_SIZE({spec.capacity_bits}),")
    lines.append(f"        .READ_DATA_WIDTH_A({data_w}),")
    lines.append(f"        .WRITE_DATA_WIDTH_A({data_w}),")
    lines.append("        .READ_LATENCY_A(1)")
    lines.append("    ) xpm_spram_inst (")
    lines.append("        .dbterra(),")
    lines.append("        .douta(dout),")
    lines.append("        .sbterra(),")
    lines.append("        .addra(addr),")
    lines.append("        .clka(clk),")
    lines.append("        .dina(din),")
    lines.append("        .ena(en),")
    lines.append("        .injectdbterra(1'b0),")
    lines.append("        .injectsbterra(1'b0),")
    lines.append("        .regcea(1'b1),")
    lines.append("        .rsta(1'b0),")
    if spec.byte_enable:
        lines.append("        .wea(byte_we)")
    else:
        lines.append("        .wea(we)")
    lines.append("    );")
    lines.append("`else")
    lines.append(f"    // Inferred FPGA RAM ({ram_style.upper()})")
    lines.append(f"    (* ram_style = \"{ram_style}\" *)")
    lines.append(f"    logic [{data_w-1}:0] ram [0:{spec.depth-1}];")
    lines.append(f"    logic [{data_w-1}:0] dout_reg;")
    lines.append("")
    lines.append("    always_ff @(posedge clk) begin")
    lines.append("        if (en) begin")
    if spec.byte_enable:
        for i in range(num_bytes):
            lsb = i * byte_s
            msb = lsb + byte_s - 1
            lines.append(f"            if (byte_we[{i}]) ram[addr][{msb}:{lsb}] <= din[{msb}:{lsb}];")
    else:
        lines.append("            if (we) ram[addr] <= din;")
    lines.append("            dout_reg <= ram[addr];")
    lines.append("        end")
    lines.append("    end")
    lines.append("    assign dout = dout_reg;")
    lines.append("`endif")
    lines.append("endmodule")
    return lines


def _gen_fpga_sdpram(mod_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int, byte_s: int, ram_style: str) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               clk_w,")
    lines.append("    input  logic               we,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_w,")
    lines.append(f"    input  logic [{data_w-1}:0] din,")
    lines.append("    ")
    lines.append("    input  logic               clk_r,")
    lines.append("    input  logic               en_r,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_r,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    lines.append("`ifdef USE_XPM_PRIMITIVE")
    lines.append("    // AMD Xilinx XPM SDPRV Macro")
    lines.append("    xpm_memory_sdpram #(")
    lines.append(f"        .ADDR_WIDTH_A({addr_w}),")
    lines.append(f"        .ADDR_WIDTH_B({addr_w}),")
    lines.append(f"        .BYTE_WRITE_WIDTH_A({'8' if spec.byte_enable else data_w}),")
    lines.append(f"        .MEMORY_SIZE({spec.capacity_bits}),")
    lines.append(f"        .READ_DATA_WIDTH_B({data_w}),")
    lines.append(f"        .WRITE_DATA_WIDTH_A({data_w}),")
    lines.append("        .READ_LATENCY_B(1)")
    lines.append("    ) xpm_sdpram_inst (")
    lines.append("        .dbterrby(),")
    lines.append("        .doutb(dout),")
    lines.append("        .sbterrby(),")
    lines.append("        .addra(addr_w),")
    lines.append("        .addrb(addr_r),")
    lines.append("        .clka(clk_w),")
    lines.append("        .clkb(clk_r),")
    lines.append("        .dina(din),")
    lines.append("        .ena(we),")
    lines.append("        .enb(en_r),")
    lines.append("        .injectdbterra(1'b0),")
    lines.append("        .injectsbterra(1'b0),")
    lines.append("        .regceb(1'b1),")
    lines.append("        .rstb(1'b0),")
    if spec.byte_enable:
        lines.append("        .wea(byte_we)")
    else:
        lines.append("        .wea(1'b1)")
    lines.append("    );")
    lines.append("`else")
    lines.append(f"    // Inferred FPGA Dual-Port RAM ({ram_style.upper()})")
    lines.append(f"    (* ram_style = \"{ram_style}\" *)")
    lines.append(f"    logic [{data_w-1}:0] ram [0:{spec.depth-1}];")
    lines.append(f"    logic [{data_w-1}:0] dout_reg;")
    lines.append("")
    lines.append("    always_ff @(posedge clk_w) begin")
    if spec.byte_enable:
        for i in range(num_bytes):
            lsb = i * byte_s
            msb = lsb + byte_s - 1
            lines.append(f"        if (we && byte_we[{i}]) ram[addr_w][{msb}:{lsb}] <= din[{msb}:{lsb}];")
    else:
        lines.append("        if (we) ram[addr_w] <= din;")
    lines.append("    end")
    lines.append("")
    lines.append("    always_ff @(posedge clk_r) begin")
    lines.append("        if (en_r) dout_reg <= ram[addr_r];")
    lines.append("    end")
    lines.append("    assign dout = dout_reg;")
    lines.append("`endif")
    lines.append("endmodule")
    return lines


def _gen_fpga_tdpram(mod_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int, byte_s: int, ram_style: str) -> list[str]:
    lines = []
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               clk_a,")
    lines.append("    input  logic               en_a,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we_a,")
    else:
        lines.append("    input  logic               we_a,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_a,")
    lines.append(f"    input  logic [{data_w-1}:0] din_a,")
    lines.append(f"    output logic [{data_w-1}:0] dout_a,")
    lines.append("    ")
    lines.append("    input  logic               clk_b,")
    lines.append("    input  logic               en_b,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we_b,")
    else:
        lines.append("    input  logic               we_b,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_b,")
    lines.append(f"    input  logic [{data_w-1}:0] din_b,")
    lines.append(f"    output logic [{data_w-1}:0] dout_b")
    lines.append(");")
    lines.append("")
    lines.append(f"    // Inferred FPGA True Dual-Port RAM ({ram_style.upper()})")
    lines.append(f"    (* ram_style = \"{ram_style}\" *)")
    lines.append(f"    logic [{data_w-1}:0] ram [0:{spec.depth-1}];")
    lines.append(f"    logic [{data_w-1}:0] dout_reg_a, dout_reg_b;")
    lines.append("")
    lines.append("    always_ff @(posedge clk_a) begin")
    lines.append("        if (en_a) begin")
    if spec.byte_enable:
        for i in range(num_bytes):
            lsb = i * byte_s
            msb = lsb + byte_s - 1
            lines.append(f"            if (byte_we_a[{i}]) ram[addr_a][{msb}:{lsb}] <= din_a[{msb}:{lsb}];")
    else:
        lines.append("            if (we_a) ram[addr_a] <= din_a;")
    lines.append("            dout_reg_a <= ram[addr_a];")
    lines.append("        end")
    lines.append("    end")
    lines.append("")
    lines.append("    always_ff @(posedge clk_b) begin")
    lines.append("        if (en_b) begin")
    if spec.byte_enable:
        for i in range(num_bytes):
            lsb = i * byte_s
            msb = lsb + byte_s - 1
            lines.append(f"            if (byte_we_b[{i}]) ram[addr_b][{msb}:{lsb}] <= din_b[{msb}:{lsb}];")
    else:
        lines.append("            if (we_b) ram[addr_b] <= din_b;")
    lines.append("            dout_reg_b <= ram[addr_b];")
    lines.append("        end")
    lines.append("    end")
    lines.append("    assign dout_a = dout_reg_a;")
    lines.append("    assign dout_b = dout_reg_b;")
    lines.append("endmodule")
    return lines
