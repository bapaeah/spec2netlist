from memory_compiler.spec import MemorySpec, MemoryType

def generate_top_sv(spec: MemorySpec) -> str:
    """
    Generates a unified Top-Level SystemVerilog Module that acts as the technology-agnostic interface.
    Uses target macros (`SIM`, `FPGA`, `SYNTHESIS`) to automatically select the backend.
    Encloses simulation/FPGA parameters inside `ifndef SYNTHESIS for ASIC synthesis compatibility.
    """
    top_name = spec.name
    addr_w = spec.addr_width
    data_w = spec.width
    num_bytes = spec.num_bytes

    lines = []
    lines.append("// ========================================================================")
    lines.append(f"// Unified Technology-Agnostic Top Memory Wrapper: {top_name}")
    lines.append(f"// Spec: {spec.mem_type.value.upper()} | Depth={spec.depth} | Width={data_w} ({spec.get_formatted_capacity()})")
    lines.append("// ========================================================================")
    lines.append("`timescale 1ns / 1ps")
    lines.append("")

    if spec.mem_type == MemoryType.ROM:
        lines.extend(_gen_top_rom(top_name, spec, addr_w, data_w))
    elif spec.mem_type == MemoryType.SPRAM:
        lines.extend(_gen_top_spram(top_name, spec, addr_w, data_w, num_bytes))
    elif spec.mem_type == MemoryType.SDP_RAM:
        lines.extend(_gen_top_sdpram(top_name, spec, addr_w, data_w, num_bytes))
    elif spec.mem_type == MemoryType.TDP_RAM:
        lines.extend(_gen_top_tdpram(top_name, spec, addr_w, data_w, num_bytes))

    return "\n".join(lines)


def _append_header_with_param(lines: list[str], top_name: str, spec: MemorySpec):
    lines.append(f"module {top_name}")
    lines.append("`ifndef SYNTHESIS")
    lines.append("#(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(")")
    lines.append("`endif")
    lines.append("(")


def _gen_top_rom(top_name: str, spec: MemorySpec, addr_w: int, data_w: int) -> list[str]:
    lines = []
    _append_header_with_param(lines, top_name, spec)
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               en,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    lines.append("`ifdef FPGA")
    lines.append(f"    {top_name}_fpga #(.INIT_FILE(INIT_FILE)) u_mem_backend (")
    lines.append("        .clk(clk), .en(en), .addr(addr), .dout(dout)")
    lines.append("    );")
    lines.append("`elsif SYNTHESIS")
    lines.append(f"    {top_name}_asic u_mem_backend (")
    lines.append("        .clk(clk), .en(en), .addr(addr), .dout(dout), .sleep_mode(1'b0)")
    lines.append("    );")
    lines.append("`else // Default: SIM / Behavioral Simulation")
    lines.append(f"    {top_name}_behavioral #(.INIT_FILE(INIT_FILE)) u_mem_backend (")
    lines.append("        .clk(clk), .en(en), .addr(addr), .dout(dout)")
    lines.append("    );")
    lines.append("`endif")
    lines.append("endmodule")
    return lines


def _gen_top_spram(top_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int) -> list[str]:
    lines = []
    _append_header_with_param(lines, top_name, spec)
    lines.append("    input  logic               clk,")
    lines.append("    input  logic               en,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,")
    else:
        lines.append("    input  logic               we,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr,")
    lines.append(f"    input  logic [{data_w-1}:0] din,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    we_signal = ".byte_we(byte_we)" if spec.byte_enable else ".we(we)"
    lines.append("`ifdef FPGA")
    lines.append(f"    {top_name}_fpga #(.INIT_FILE(INIT_FILE)) u_mem_backend (")
    lines.append(f"        .clk(clk), .en(en), {we_signal}, .addr(addr), .din(din), .dout(dout)")
    lines.append("    );")
    lines.append("`elsif SYNTHESIS")
    lines.append(f"    {top_name}_asic u_mem_backend (")
    lines.append(f"        .clk(clk), .en(en), {we_signal}, .addr(addr), .din(din), .dout(dout),")
    lines.append("        .bist_en(1'b0), .sleep_mode(1'b0)")
    lines.append("    );")
    lines.append("`else // Default: SIM / Behavioral Simulation")
    lines.append(f"    {top_name}_behavioral #(.INIT_FILE(INIT_FILE)) u_mem_backend (")
    lines.append(f"        .clk(clk), .en(en), {we_signal}, .addr(addr), .din(din), .dout(dout)")
    lines.append("    );")
    lines.append("`endif")
    lines.append("endmodule")
    return lines


def _gen_top_sdpram(top_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int) -> list[str]:
    lines = []
    _append_header_with_param(lines, top_name, spec)
    lines.append("    input  logic               clk_w,")
    lines.append("    input  logic               we,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_w,")
    lines.append(f"    input  logic [{data_w-1}:0] din,")
    lines.append("    ")
    lines.append("    input  logic               clk_r,")
    lines.append("    input  logic               en_r,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_r,")
    lines.append(f"    output logic [{data_w-1}:0] dout")
    lines.append(");")
    lines.append("")
    we_extra = ", .byte_we(byte_we)" if spec.byte_enable else ""
    lines.append("`ifdef FPGA")
    lines.append(f"    {top_name}_fpga #(.INIT_FILE(INIT_FILE)) u_mem_backend (")
    lines.append(f"        .clk_w(clk_w), .we(we){we_extra}, .addr_w(addr_w), .din(din),")
    lines.append("        .clk_r(clk_r), .en_r(en_r), .addr_r(addr_r), .dout(dout)")
    lines.append("    );")
    lines.append("`elsif SYNTHESIS")
    lines.append(f"    {top_name}_asic u_mem_backend (")
    lines.append(f"        .clk_w(clk_w), .we(we){we_extra}, .addr_w(addr_w), .din(din),")
    lines.append("        .clk_r(clk_r), .en_r(en_r), .addr_r(addr_r), .dout(dout),")
    lines.append("        .bist_en(1'b0), .sleep_mode(1'b0)")
    lines.append("    );")
    lines.append("`else // Default: SIM / Behavioral Simulation")
    lines.append(f"    {top_name}_behavioral #(.INIT_FILE(INIT_FILE)) u_mem_backend (")
    lines.append(f"        .clk_w(clk_w), .we(we){we_extra}, .addr_w(addr_w), .din(din),")
    lines.append("        .clk_r(clk_r), .en_r(en_r), .addr_r(addr_r), .dout(dout)")
    lines.append("    );")
    lines.append("`endif")
    lines.append("endmodule")
    return lines


def _gen_top_tdpram(top_name: str, spec: MemorySpec, addr_w: int, data_w: int, num_bytes: int) -> list[str]:
    lines = []
    _append_header_with_param(lines, top_name, spec)
    lines.append("    input  logic               clk_a,")
    lines.append("    input  logic               en_a,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we_a,")
    else:
        lines.append("    input  logic               we_a,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_a,")
    lines.append(f"    input  logic [{data_w-1}:0] din_a,")
    lines.append(f"    output logic [{data_w-1}:0] dout_a,")
    lines.append("    ")
    lines.append("    input  logic               clk_b,")
    lines.append("    input  logic               en_b,")
    if spec.byte_enable:
        lines.append(f"    input  logic [{num_bytes-1}:0] byte_we_b,")
    else:
        lines.append("    input  logic               we_b,")
    lines.append(f"    input  logic [{addr_w-1}:0] addr_b,")
    lines.append(f"    input  logic [{data_w-1}:0] din_b,")
    lines.append(f"    output logic [{data_w-1}:0] dout_b")
    lines.append(");")
    lines.append("")
    we_a = ".byte_we_a(byte_we_a)" if spec.byte_enable else ".we_a(we_a)"
    we_b = ".byte_we_b(byte_we_b)" if spec.byte_enable else ".we_b(we_b)"
    lines.append("`ifdef FPGA")
    lines.append(f"    {top_name}_fpga #(.INIT_FILE(INIT_FILE)) u_mem_backend (")
    lines.append(f"        .clk_a(clk_a), .en_a(en_a), {we_a}, .addr_a(addr_a), .din_a(din_a), .dout_a(dout_a),")
    lines.append(f"        .clk_b(clk_b), .en_b(en_b), {we_b}, .addr_b(addr_b), .din_b(din_b), .dout_b(dout_b)")
    lines.append("    );")
    lines.append("`elsif SYNTHESIS")
    lines.append(f"    {top_name}_asic u_mem_backend (")
    lines.append(f"        .clk_a(clk_a), .en_a(en_a), {we_a}, .addr_a(addr_a), .din_a(din_a), .dout_a(dout_a),")
    lines.append(f"        .clk_b(clk_b), .en_b(en_b), {we_b}, .addr_b(addr_b), .din_b(din_b), .dout_b(dout_b),")
    lines.append("        .bist_en(1'b0), .sleep_mode(1'b0)")
    lines.append("    );")
    lines.append("`else // Default: SIM / Behavioral Simulation")
    lines.append(f"    {top_name}_behavioral #(.INIT_FILE(INIT_FILE)) u_mem_backend (")
    lines.append(f"        .clk_a(clk_a), .en_a(en_a), {we_a}, .addr_a(addr_a), .din_a(din_a), .dout_a(dout_a),")
    lines.append(f"        .clk_b(clk_b), .en_b(en_b), {we_b}, .addr_b(addr_b), .din_b(din_b), .dout_b(dout_b)")
    lines.append("    );")
    lines.append("`endif")
    lines.append("endmodule")
    return lines
