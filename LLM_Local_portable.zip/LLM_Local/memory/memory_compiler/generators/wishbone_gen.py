from memory_compiler.spec import MemorySpec, MemoryType

def generate_wishbone_sv(spec: MemorySpec) -> str:
    """
    Generates a synthesizable Wishbone B4 Pipeline Bus Memory Adapter in SystemVerilog.
    Translates Wishbone B4 signals (wb_clk_i, wb_rst_i, wb_cyc_i, wb_stb_i, wb_we_i, wb_adr_i, wb_dat_i, wb_dat_o, wb_ack_o) to memory.
    """
    mod_name = f"{spec.name}_wishbone"
    top_name = spec.name
    addr_w = spec.addr_width
    data_w = spec.width
    num_bytes = spec.num_bytes
    is_rom = (spec.mem_type == MemoryType.ROM)

    lines = []
    lines.append("// ========================================================================")
    lines.append(f"// SystemVerilog Wishbone B4 Pipeline Bus Subsystem: {mod_name}")
    lines.append(f"// Wraps module '{top_name}' for Open-Source Wishbone B4 Interconnect")
    lines.append(f"// Spec: {spec.mem_type.value.upper()} | Depth={spec.depth} | Width={data_w} ({spec.get_formatted_capacity()})")
    lines.append("// ========================================================================")
    lines.append("`timescale 1ns / 1ps")
    lines.append("")
    lines.append(f"module {mod_name} #(")
    lines.append(f"    parameter string INIT_FILE = \"{spec.init_file or ''}\"")
    lines.append(") (")
    lines.append("    input  logic               wb_clk_i,")
    lines.append("    input  logic               wb_rst_i,")
    lines.append("    ")
    lines.append("    // Wishbone Bus Interface Signals")
    lines.append("    input  logic               wb_cyc_i,")
    lines.append("    input  logic               wb_stb_i,")
    if not is_rom:
        lines.append("    input  logic               wb_we_i,")
        lines.append(f"    input  logic [{num_bytes-1}:0] wb_sel_i,")
        lines.append(f"    input  logic [{data_w-1}:0]        wb_dat_i,")
    lines.append(f"    input  logic [31:0]        wb_adr_i,")
    lines.append(f"    output logic [{data_w-1}:0]        wb_dat_o,")
    lines.append("    output logic               wb_ack_o,")
    lines.append("    output logic               wb_err_o")
    lines.append(");")
    lines.append("")
    lines.append("    wire req = wb_cyc_i && wb_stb_i;")
    lines.append(f"    wire [{addr_w-1}:0] mem_addr = wb_adr_i[{addr_w+1}:2];")
    lines.append("    assign wb_err_o = 1'b0;")
    lines.append("")
    lines.append("    logic ack_reg;")
    lines.append("    always_ff @(posedge wb_clk_i or posedge wb_rst_i) begin")
    lines.append("        if (wb_rst_i) begin")
    lines.append("            ack_reg <= 1'b0;")
    lines.append("        end else begin")
    lines.append("            ack_reg <= req & ~ack_reg;")
    lines.append("        end")
    lines.append("    end")
    lines.append("    assign wb_ack_o = ack_reg;")
    lines.append("")
    lines.append(f"    {top_name} #(")
    lines.append("`ifndef SYNTHESIS")
    lines.append("        .INIT_FILE(INIT_FILE)")
    lines.append("`endif")
    lines.append("    ) u_top_memory (")
    lines.append("        .clk(wb_clk_i),")
    lines.append("        .en(req),")
    if not is_rom:
        if spec.byte_enable:
            lines.append("        .byte_we(wb_we_i ? wb_sel_i : '0),")
        else:
            lines.append("        .we(wb_we_i),")
    lines.append("        .addr(mem_addr),")
    if not is_rom:
        lines.append("        .din(wb_dat_i),")
    lines.append("        .dout(wb_dat_o)")
    lines.append("    );")
    lines.append("endmodule")
    return "\n".join(lines)
