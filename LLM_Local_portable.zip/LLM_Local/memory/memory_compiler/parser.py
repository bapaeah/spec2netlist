import re
from typing import Tuple, Dict

# Standard Universal Memory Size Presets
UNIVERSAL_PRESETS: Dict[str, Tuple[int, int]] = {
    # Matrix presets (Name -> Depth, Width)
    "512X8": (512, 8),
    "1KX8": (1024, 8),
    "1KX16": (1024, 16),
    "1KX32": (1024, 32),
    "1KX64": (1024, 64),
    "2KX32": (2048, 32),
    "2KX64": (2048, 64),
    "4KX32": (4096, 32),
    "4KX64": (4096, 64),
    "8KX32": (8192, 32),
    "8KX64": (8192, 64),
    "16KX32": (16384, 32),
    "32KX32": (32768, 32),
    "64KX32": (65536, 32),
    "128KX32": (131072, 32),
    # Common FPGA Primitive Block Presets
    "9KB": (512, 18),      # Intel M9K block equivalent
    "18KB": (1024, 18),    # AMD Xilinx 18Kb BRAM block
    "36KB": (1024, 36),    # AMD Xilinx 36Kb BRAM block
    "20KB": (512, 40),     # Intel M20K block equivalent
}

def parse_size_string(size_str: str, default_width: int = 32) -> Tuple[int, int]:
    """
    Parses size string formats such as:
    - '4KB', '16KB', '1MB' -> returns calculated (depth, width)
    - '1Kx32', '512x8', '2Kx64' -> returns (depth, width)
    - '36Kb' -> returns (1024, 36)
    """
    cleaned = size_str.strip().upper()

    # 1. Check presets
    if cleaned in UNIVERSAL_PRESETS:
        return UNIVERSAL_PRESETS[cleaned]

    # 2. Check matrix format: e.g., '1KX32', '512X8', '4KX64', '2MX128'
    matrix_match = re.match(r"^(\d+)([KM])?X(\d+)$", cleaned)
    if matrix_match:
        val, multiplier, width = matrix_match.groups()
        depth = int(val)
        if multiplier == "K":
            depth *= 1024
        elif multiplier == "M":
            depth *= 1024 * 1024
        return depth, int(width)

    # 3. Check byte capacity format: e.g., '4KB', '16KB', '1MB', '512B'
    byte_match = re.match(r"^(\d+)([KM])?(B|BYTES)$", cleaned)
    if byte_match:
        val, multiplier, _ = byte_match.groups()
        bytes_count = int(val)
        if multiplier == "K":
            bytes_count *= 1024
        elif multiplier == "M":
            bytes_count *= 1024 * 1024
        total_bits = bytes_count * 8
        depth = total_bits // default_width
        if depth <= 0:
            raise ValueError(f"Capacity {size_str} is too small for width {default_width}")
        return depth, default_width

    # 4. Check bit capacity format: e.g., '36KB', '18KB' (interpreted as kilobits if lower 'b')
    bit_match = re.match(r"^(\d+)([KM])?BITS$", cleaned)
    if bit_match:
        val, multiplier, _ = bit_match.groups()
        bits_count = int(val)
        if multiplier == "K":
            bits_count *= 1024
        elif multiplier == "M":
            bits_count *= 1024 * 1024
        depth = bits_count // default_width
        return depth, default_width

    raise ValueError(
        f"Unable to parse size specification '{size_str}'. "
        f"Supported formats: '4KB', '16KB', '1Kx32', '4Kx64', or explicit --depth and --width."
    )

def validate_universal_size(depth: int, width: int) -> bool:
    """
    Checks if depth and width align with standard power-of-two FPGA/ASIC memory architectures.
    """
    is_depth_pow2 = (depth & (depth - 1) == 0) and depth > 0
    return is_depth_pow2
