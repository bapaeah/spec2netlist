#!/usr/bin/env python3
"""
Technology-Agnostic SystemVerilog Memory Compiler CLI Script (memgen.py)
Generates universal SystemVerilog Memory Modules & Wrappers (ROM, SPRAM, SDP, TDP)
for FPGA, Behavioral Simulation, ASIC, and Processor Bus Targets (AXI5, RISC-V i-Bus, AHB-Lite, Wishbone).
"""

import sys
import os
import argparse
from pathlib import Path

# Ensure local memory_compiler package is in python path
sys.path.insert(0, str(Path(__file__).parent.resolve()))

from memory_compiler.spec import MemorySpec, MemoryType, ReadWriteBehavior
from memory_compiler.parser import parse_size_string, UNIVERSAL_PRESETS
from memory_compiler.generators import (
    generate_behavioral_sv,
    generate_fpga_sv,
    generate_asic_sv,
    generate_top_sv,
    generate_axi5_sv,
    generate_riscv_ibus_sv,
    generate_ahb_lite_sv,
    generate_wishbone_sv
)


def print_presets():
    print("\n========================================================================")
    print(" UNIVERSAL MEMORY SIZE PRESETS (Supported by --size)")
    print("========================================================================")
    print(f"{'PRESET':<12} | {'DEPTH (Words)':<15} | {'WIDTH (Bits)':<12} | {'CAPACITY':<10}")
    print("-" * 60)
    for name, (depth, width) in UNIVERSAL_PRESETS.items():
        cap_bits = depth * width
        cap_bytes = cap_bits / 8.0
        if cap_bytes >= 1024:
            fmt_cap = f"{cap_bytes / 1024:.1f}KB"
        else:
            fmt_cap = f"{int(cap_bytes)}B"
        print(f"{name:<12} | {depth:<15} | {width:<12} | {fmt_cap:<10}")
    print("-" * 60)
    print("Capacity Formats Supported: --size 4KB, --size 16KB, --size 1MB, --size 36Kb")
    print("Matrix Formats Supported:   --size 1Kx32, --size 2Kx64, --size 512x8, --size 4Kx32")
    print("========================================================================\n")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Technology-Agnostic SystemVerilog Memory Compiler & Wrapper Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate 4KB ROM with init file & RISC-V Core i-Bus wrapper:
  python memgen.py --type rom --size 4KB --width 32 --init-file bootrom.hex --riscv-ibus --out-dir generated/

  # Generate 4KB Single-Port RAM with AMBA AHB-Lite bus wrapper:
  python memgen.py --type spram --size 4KB --width 32 --ahb-lite --out-dir generated/

  # Generate 1Kx32 Single-Port RAM (SPRAM) with AXI5 interface:
  python memgen.py --type spram --size 1Kx32 --byte-enable --axi5 --out-dir generated/

  # Generate 2Kx64 Simple Dual-Port RAM with Wishbone bus:
  python memgen.py --type sdp --size 2Kx64 --wishbone --name sdp_2k_wb --out-dir generated/

  # List universal size presets:
  python memgen.py --list-presets
        """
    )

    parser.add_argument("--type", "-t", choices=["rom", "spram", "sdp", "tdp"], default="spram",
                        help="Memory Architecture type (default: spram)")
    parser.add_argument("--size", "-s", type=str, default=None,
                        help="Universal size spec e.g. 4KB, 16KB, 1Kx32, 2Kx64, 512x8, 36Kb")
    parser.add_argument("--depth", "-d", type=int, default=None,
                        help="Explicit depth in words (e.g. 1024, 2048)")
    parser.add_argument("--width", "-w", type=int, default=32,
                        help="Explicit data width in bits (default: 32)")
    parser.add_argument("--name", "-n", type=str, default=None,
                        help="Top module name (auto-generated if omitted)")
    parser.add_argument("--byte-enable", "-b", action="store_true",
                        help="Enable byte-write enable mask (8-bit granularity)")

    # Bus Interface Options & Shortcuts
    parser.add_argument("--bus", choices=["none", "axi5", "riscv-ibus", "ahb-lite", "wishbone"], default="none",
                        help="Select Bus Protocol Interface (default: none)")
    parser.add_argument("--axi5", action="store_true",
                        help="Generate AMBA AXI5 / AXI5-Lite Bus Subsystem Wrapper")
    parser.add_argument("--riscv-ibus", action="store_true",
                        help="Generate Direct RISC-V Core Instruction & Data Bus Adapter")
    parser.add_argument("--ahb-lite", action="store_true",
                        help="Generate AMBA AHB-Lite Processor Bus Adapter")
    parser.add_argument("--wishbone", action="store_true",
                        help="Generate Wishbone B4 Pipeline Bus Adapter")

    parser.add_argument("--init-file", "-i", type=str, default=None,
                        help="Path to hex memory initialization file for $readmemh")
    parser.add_argument("--read-behavior", choices=["read_first", "write_first", "no_change"], default="no_change",
                        help="Read-during-write collision behavior")
    parser.add_argument("--asic-macro-name", type=str, default=None,
                        help="ASIC foundry macro module name (e.g., TSMC_SRAM_SP_1024X32)")
    parser.add_argument("--target", choices=["all", "top", "behavioral", "fpga", "asic", "axi5", "riscv_ibus", "ahb_lite", "wishbone"], default="all",
                        help="Target wrapper to generate (default: all)")
    parser.add_argument("--out-dir", "-o", type=str, default="generated",
                        help="Output directory for generated SystemVerilog (.sv) files")
    parser.add_argument("--list-presets", action="store_true",
                        help="List all universal memory size presets and exit")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if args.list_presets:
        print_presets()
        sys.exit(0)

    # Calculate depth and width
    if args.size:
        depth, width = parse_size_string(args.size, default_width=args.width)
    elif args.depth is not None:
        depth = args.depth
        width = args.width
    else:
        # Default fallback size: 1Kx32
        depth = 1024
        width = args.width

    # Determine bus interface choice
    bus_interface = None
    if args.axi5 or args.bus == "axi5" or args.target == "axi5":
        bus_interface = "axi5"
    elif args.riscv_ibus or args.bus == "riscv-ibus" or args.target == "riscv_ibus":
        bus_interface = "riscv-ibus"
    elif args.ahb_lite or args.bus == "ahb-lite" or args.target == "ahb_lite":
        bus_interface = "ahb-lite"
    elif args.wishbone or args.bus == "wishbone" or args.target == "wishbone":
        bus_interface = "wishbone"

    # Parse memory type enum
    type_map = {
        "rom": MemoryType.ROM,
        "spram": MemoryType.SPRAM,
        "sdp": MemoryType.SDP_RAM,
        "tdp": MemoryType.TDP_RAM
    }
    mem_type = type_map[args.type]

    # Auto name if not supplied
    if not args.name:
        name_str = f"{args.type}_{depth}x{width}"
        if args.byte_enable:
            name_str += "_be"
        name = name_str.lower()
    else:
        name = args.name

    rw_behavior = ReadWriteBehavior(args.read_behavior)

    spec = MemorySpec(
        name=name,
        mem_type=mem_type,
        depth=depth,
        width=width,
        byte_enable=args.byte_enable or (bus_interface is not None and mem_type != MemoryType.ROM),
        init_file=args.init_file,
        read_during_write=rw_behavior,
        asic_macro_name=args.asic_macro_name,
        bus_interface=bus_interface
    )

    print("========================================================================")
    print(" SYSTEMVERILOG MEMORY COMPILER GENERATION SUMMARY")
    print("========================================================================")
    print(f" Module Name:    {spec.name}")
    print(f" Memory Type:    {spec.mem_type.value.upper()}")
    print(f" Dimension:      Depth = {spec.depth} words, Width = {spec.width} bits")
    print(f" Address Width:  {spec.addr_width} bits")
    print(f" Total Capacity: {spec.get_formatted_capacity()} ({spec.capacity_bits} bits)")
    print(f" Byte Enable:    {'Enabled' if spec.byte_enable else 'Disabled'}")
    print(f" Bus Interface:  {spec.bus_interface.upper() if spec.bus_interface else 'None'}")
    print(f" Target Mode:    {args.target.upper()}")
    print("========================================================================\n")

    out_path = Path(args.out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    generated_files = []

    if args.target in ["all", "behavioral"]:
        code = generate_behavioral_sv(spec)
        fpath = out_path / f"{spec.name}_behavioral.sv"
        fpath.write_text(code)
        generated_files.append(fpath)

    if args.target in ["all", "fpga"]:
        code = generate_fpga_sv(spec)
        fpath = out_path / f"{spec.name}_fpga.sv"
        fpath.write_text(code)
        generated_files.append(fpath)

    if args.target in ["all", "asic"]:
        code = generate_asic_sv(spec)
        fpath = out_path / f"{spec.name}_asic.sv"
        fpath.write_text(code)
        generated_files.append(fpath)

    if args.target in ["all", "top"]:
        code = generate_top_sv(spec)
        fpath = out_path / f"{spec.name}.sv"
        fpath.write_text(code)
        generated_files.append(fpath)

    # Bus-specific module generation
    if bus_interface == "axi5" or args.target == "axi5":
        code = generate_axi5_sv(spec)
        fpath = out_path / f"{spec.name}_axi5.sv"
        fpath.write_text(code)
        generated_files.append(fpath)

    if bus_interface == "riscv-ibus" or args.target == "riscv_ibus":
        code = generate_riscv_ibus_sv(spec)
        fpath = out_path / f"{spec.name}_riscv_ibus.sv"
        fpath.write_text(code)
        generated_files.append(fpath)

    if bus_interface == "ahb-lite" or args.target == "ahb_lite":
        code = generate_ahb_lite_sv(spec)
        fpath = out_path / f"{spec.name}_ahb_lite.sv"
        fpath.write_text(code)
        generated_files.append(fpath)

    if bus_interface == "wishbone" or args.target == "wishbone":
        code = generate_wishbone_sv(spec)
        fpath = out_path / f"{spec.name}_wishbone.sv"
        fpath.write_text(code)
        generated_files.append(fpath)

    print("Successfully generated SystemVerilog memory files:")
    for f in generated_files:
        print(f"  [+] {f}")
    print("\nGeneration complete!\n")


if __name__ == "__main__":
    main()
