# Technology-Agnostic SystemVerilog Memory Compiler & Generator (`memgen.py`)

A lightweight, automated Python command-line compiler for generating technology-agnostic **SystemVerilog (`.sv`)** memory modules and target wrappers for **Behavioral Simulation**, **FPGA (Inferred / AMD Xilinx XPM Primitives)**, **ASIC Hard Macros**, and **Processor Bus Interfaces (RISC-V i-Bus, AMBA AHB-Lite, Wishbone, AMBA AXI5)**.

---

## Features

- **Architectures Supported**:
  - **ROM**: Read-Only Memory with `$readmemh`/`$readmemb` initialization file support.
  - **SPRAM**: Single-Port RAM (1 read/write port) with optional byte-write enables.
  - **SDP_RAM**: Simple Dual-Port RAM (1 dedicated write port, 1 dedicated read port).
  - **TDP_RAM**: True Dual-Port RAM (2 independent read/write ports).
- **Processor & Bus Interfaces Supported**:
  - **RISC-V Core i-Bus** (`--riscv-ibus` or `--bus riscv-ibus`): Direct RISC-V CPU pipeline fetch/data interface (`req`, `addr[31:0]`, `rdata[31:0]`, `rvalid`, `gnt`, `err`).
  - **AMBA AHB-Lite** (`--ahb-lite` or `--bus ahb-lite`): ARM & RISC Microcontroller On-Chip Bus (`HCLK`, `HRESETn`, `HSEL`, `HADDR`, `HTRANS`, `HWDATA`, `HRDATA`, `HREADYOUT`, `HRESP`).
  - **Wishbone B4** (`--wishbone` or `--bus wishbone`): Open-source RISC Pipeline Bus (`wb_clk_i`, `wb_rst_i`, `wb_cyc_i`, `wb_stb_i`, `wb_adr_i`, `wb_dat_i`, `wb_dat_o`, `wb_ack_o`).
  - **AMBA AXI5 / AXI5-Lite** (`--axi5` or `--bus axi5`): Synthesizable AMBA AXI5 Slave Subsystem Wrapper (AW, W, B, AR, R channels).
- **Universal Size Automation**:
  - Supports standard capacity strings (`--size 4KB`, `--size 16KB`, `--size 64KB`, `--size 1MB`, `--size 36Kb`).
  - Supports matrix strings (`--size 1Kx32`, `--size 2Kx64`, `--size 512x8`, `--size 4Kx32`).
  - Automatically calculates word depth from total byte capacity and data width.
  - Built-in universal presets (`1KX32`, `2KX64`, `4KX32`, `18KB`, `36KB`, etc.).
- **Target Wrappers Generated**:
  1. `<name>_behavioral.sv`: SystemVerilog simulation model with timing checks, assertions, and `$readmemh`.
  2. `<name>_fpga.sv`: Synthesizable FPGA model with `ram_style` BRAM/URAM auto-selection and AMD Xilinx XPM macro support (`USE_XPM_PRIMITIVE`).
  3. `<name>_asic.sv`: ASIC foundry wrapper with active-low signal translations (`CEB`, `WEB`, `BWEB`), BIST/DFT hooks, power gating, and fallback hard macro simulation model (`SIM`).
  4. `<name>_<bus>.sv`: Synthesizable Processor Bus Interface Subsystem Module (`--riscv-ibus`, `--ahb-lite`, `--wishbone`, `--axi5`).
  5. `<name>.sv`: Unified Top-Level wrapper selecting backend via `SIM`, `FPGA`, or `SYNTHESIS`.

---

## Quick Start & Usage

### 1. View All Universal Presets
```bash
python3 memgen.py --list-presets
```

### 2. Generate Boot ROM for Direct RISC-V CPU Pipeline
```bash
python3 memgen.py --type rom --size 4KB --width 32 --init-file bootrom.hex --riscv-ibus --name boot_rom_riscv --out-dir generated/
```

### 3. Generate Boot ROM for AMBA AHB-Lite (ARM / RISC-V MCU)
```bash
python3 memgen.py --type rom --size 4KB --width 32 --init-file bootrom.hex --ahb-lite --name boot_rom_ahb --out-dir generated/
```

### 4. Generate Single-Port RAM (SPRAM) with AXI5 Bus Interface
```bash
python3 memgen.py --type spram --size 4KB --width 32 --axi5 --name sram_4k_axi --out-dir generated/
```

### 5. Generate SPRAM with Wishbone B4 Pipeline Bus Interface
```bash
python3 memgen.py --type spram --size 1Kx32 --wishbone --name sram_1k_wb --out-dir generated/
```

### 6. Generate Simple Dual-Port RAM (SDP)
```bash
python3 memgen.py --type sdp --size 2Kx64 --name sdp_2k --out-dir generated/
```

### 7. Generate True Dual-Port RAM (TDP)
```bash
python3 memgen.py --type tdp --depth 512 --width 128 --name tdp_512 --out-dir generated/
```

---

## SystemVerilog Compilation & Target Selection

When compiling your SoC in EDA tools:
- **Simulation**: Compile without extra flags or with `` `define SIM `` (defaults to behavioral simulation module & fallback stubs).
- **FPGA Synthesis (Vivado / Quartus)**: Add `` `define FPGA `` to your build scripts.
- **ASIC Synthesis (Design Compiler / Genus)**: Add `` `define SYNTHESIS `` to your build scripts.

---

## Running Automated Tests

```bash
python3 -m unittest discover tests
```
