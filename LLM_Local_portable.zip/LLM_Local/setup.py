#!/usr/bin/env python3
"""
Setup script for llm-local: 100% Offline & Token-Free Hardware Engineering Assistant,
Memory Compiler, and SoC CAD Suite.
"""

from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))

long_description = ""
readme_path = os.path.join(here, "README.md")
if os.path.exists(readme_path):
    with open(readme_path, "r", encoding="utf-8") as f:
        long_description = f.read()

setup(
    name="llm-local",
    version="1.0.0",
    author="Hardware & EDA Engineering Team",
    author_email="eda-tools@local.dev",
    description="100% Offline, Local RTL & VLSI Hardware Assistant, Memory Compiler, and SoC CAD Suite",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/local-hardware/llm-local",
    license="MIT",
    py_modules=["rtl_assistant", "llm_local", "md_converter"],
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "": [
            "Modelfile.rtl",
            "Modelfile.rtl-fast",
            "continue_config.json",
            "*.md",
            "*.sh",
            "*.ps1",
        ],
        "memory": [
            "*.md",
            "tests/*",
        ],
        "spec2rtl_upf": [
            "benchmarks/*",
            "market_specs/*",
            "*.md",
            "*.sh",
            "*.ps1",
        ],
        "techlib": [
            "nangate45/*.lib",
            "nangate45/*.v",
            "sky130/*.lib",
            "sky130/*.v",
        ],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Electronic Design Automation (EDA)",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: POSIX :: Linux",
        "Operating System :: Microsoft :: Windows",
    ],
    python_requires=">=3.8",
    install_requires=[
        # Core CLI operates on standard library with zero mandatory dependencies.
    ],
    extras_require={
        "all": [
            "pypdf>=3.0.0",
            "openpyxl>=3.0.0",
            "pyyaml>=6.0",
        ],
        "dev": [
            "wheel",
            "setuptools>=58.0.0",
            "pytest",
        ],
    },
    entry_points={
        "console_scripts": [
            "rtl=rtl_assistant:main",
            "rtl-gen=rtl_assistant:main",
            "rtl-assistant=rtl_assistant:main",
            "llm-local=rtl_assistant:main",
            "memgen=memory.memgen:main",
            "spec2rtl=spec2rtl_upf.main:main",
            "md-convert=md_converter:main",
            "md_converter=md_converter:main",
        ],
    },
)
