#!/usr/bin/env python3
"""
rtl_checks.py - standalone RTL checks on ANY RTL (hand-written, LLM- or spec2rtl-generated).

  python3 rtl_checks.py lint   <inputs> [--top T] [--waivers lint.waive]
  python3 rtl_checks.py cdc    <inputs> [--top T] [--sdc top.sdc] [--sync-clocks a,b] [--async-inputs re]
  python3 rtl_checks.py sim    <inputs> --tb tb.sv
  python3 rtl_checks.py synth  <inputs> [--lib nangate45|sky130] [--period ns] [--tb tb.sv]
  python3 rtl_checks.py all    <inputs> [...]          lint -> cdc -> sim (if a TB is found) -> synth

<inputs> (any mix):
  a.sv b.v ...            RTL files
  -d / --dir DIR          every *.sv / *.v below DIR (tb/ and tb_* excluded)
  -f / --filelist F.f     EDA filelist (+incdir+, +define+, -f nested, -v)
  IP_DIR                  a spec2rtl output dir (files.f + top.txt; testbench tb/tb_<top>.sv used for sim)

Exit code: 0 = clean, 1 = check failed, 2 = tool/input error.  --json FILE writes a machine-readable report.

CDC/RDC (structural, from the Yosys netlist - not a text search):
  * clock domains = root of every flop clock (top port, generated clock = flop Q, gated clock = logic)
  * every flop D / EN / sync-reset input is traced back through combinational logic to its source flops;
    a source in another (asynchronous) domain is a crossing, classified as
      SYNC_2FF        direct flop->flop capture followed by a second flop       (OK)
      QUALIFIED       data captured with an enable that comes from the destination domain (OK if enable is a handshake)
      SINGLE_FLOP     direct capture with no second stage                       (ERROR - metastability)
      COMB_BEFORE_SYNC / UNSYNC   crossing through logic or straight into logic (ERROR)
      MULTIBIT_SYNC   a bus synchronized bit-by-bit                             (WARNING - needs gray code / handshake)
  * RDC: async resets driven from another domain, raw reset ports shared by several clock domains,
    reset synchronizers recognised (flop chain with constant D and async reset)
  * SDC (optional): create_clock names, set_clock_groups -asynchronous, set_input_delay -clock
"""
from __future__ import annotations

import argparse
import fnmatch
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

HERE = Path(__file__).resolve().parent
C = {"r": "\033[91m", "g": "\033[92m", "y": "\033[93m", "c": "\033[96m", "0": "\033[0m"}
if not sys.stdout.isatty() or os.name == "nt" and "WT_SESSION" not in os.environ:
    C = {k: "" for k in C}


def col(s, k):
    return f"{C[k]}{s}{C['0']}"


def run(cmd, cwd=None, timeout=900):
    try:
        r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except FileNotFoundError:
        return 127, f"tool not found: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, "TIMEOUT"


def yosys_bin():
    return shutil.which("yosys") or shutil.which("yowasp-yosys")


# =============================================================================== inputs
class Design:
    def __init__(self):
        self.files: List[str] = []
        self.incdirs: List[str] = []
        self.defines: List[str] = []
        self.top: Optional[str] = None
        self.tb: Optional[str] = None
        self.sdc: Optional[str] = None


def parse_filelist(f: Path, d: Design, seen=None):
    seen = seen or set()
    f = f.resolve()
    if f in seen:
        return
    seen.add(f)
    for raw in f.read_text(errors="ignore").splitlines():
        line = re.sub(r"//.*|#.*", "", raw).strip()
        if not line:
            continue
        line = os.path.expandvars(line)
        if line.startswith("+incdir+"):
            d.incdirs += [str((f.parent / p).resolve()) for p in line[8:].split("+") if p]
        elif line.startswith("+define+"):
            d.defines += [x for x in line[8:].split("+") if x]
        elif line.split()[0] in ("-f", "-F"):
            parse_filelist(f.parent / line.split()[1], d, seen)
        elif line.split()[0] == "-v":
            d.files.append(str((f.parent / line.split()[1]).resolve()))
        elif line.startswith("-") or line.startswith("+"):
            continue
        else:
            p = Path(line)
            d.files.append(str(p if p.is_absolute() else (f.parent / p).resolve()))


def resolve_inputs(a) -> Design:
    d = Design()
    for item in a.inputs:
        p = Path(item)
        if p.is_dir() and (p / "files.f").exists():
            parse_filelist(p / "files.f", d)
            if (p / "top.txt").exists():
                d.top = d.top or (p / "top.txt").read_text().strip()
            tbs = sorted((p / "tb").glob("tb_*.sv")) if (p / "tb").is_dir() else []
            d.tb = d.tb or (str(tbs[0]) if tbs else None)
            sdcs = sorted(p.glob("*.sdc"))
            d.sdc = d.sdc or (str(sdcs[0]) if sdcs else None)
        elif p.is_dir():
            a.dir = (a.dir or []) + [item]
        elif p.suffix in (".f", ".flist", ".vc"):
            parse_filelist(p, d)
        else:
            d.files.append(str(p.resolve()))
    for dd in a.dir or []:
        for q in sorted(list(Path(dd).rglob("*.sv")) + list(Path(dd).rglob("*.v"))):
            if "/tb/" in q.as_posix() or q.name.startswith("tb_") or q.name.endswith("_tb.sv"):
                continue
            d.files.append(str(q.resolve()))
    for fl in a.filelist or []:
        parse_filelist(Path(fl), d)
    d.incdirs += a.incdir or []
    d.defines += a.define or []
    d.files = list(dict.fromkeys(d.files))
    missing = [f for f in d.files if not Path(f).exists()]
    if missing:
        raise SystemExit(f"[rtl_checks] missing input files: {missing[:5]}")
    if not d.files:
        raise SystemExit("[rtl_checks] no RTL input given (files, --dir, --filelist or an IP dir)")
    d.top = a.top or d.top or find_top(d.files)
    d.tb = getattr(a, "tb", None) or d.tb
    d.sdc_explicit = getattr(a, "sdc", None)
    d.sdc = d.sdc_explicit or d.sdc
    return d


def find_top(files: List[str]) -> Optional[str]:
    defined, used = [], set()
    for f in files:
        t = re.sub(r"//.*|/\*[\s\S]*?\*/", "", Path(f).read_text(errors="ignore"))
        defined += re.findall(r"^\s*module\s+(\w+)", t, re.M)
        used |= set(re.findall(r"^\s*(\w+)\s*(?:#\s*\([\s\S]*?\))?\s+\w+\s*\(", t, re.M))
    tops = [m for m in defined if m not in used]
    return tops[-1] if tops else (defined[-1] if defined else None)


# =============================================================================== LINT
def check_lint(d: Design, a) -> dict:
    res = {"check": "lint", "top": d.top, "tool": None, "errors": 0, "warnings": 0, "waived": 0,
           "by_rule": {}, "messages": [], "inline_waivers": 0}
    waivers = []
    if a.waivers and Path(a.waivers).exists():
        for l in Path(a.waivers).read_text().splitlines():
            l = l.split("#")[0].strip()
            if l:
                parts = l.split(None, 1)
                waivers.append((parts[0], parts[1] if len(parts) > 1 else "*"))
    for f in d.files:
        res["inline_waivers"] += len(re.findall(r"lint_off", Path(f).read_text(errors="ignore")))
    if shutil.which("verilator"):
        res["tool"] = "verilator -Wall"
        cmd = ["verilator", "--lint-only", "-Wall", "-Wno-fatal", "--top-module", d.top] + \
              [f"-I{i}" for i in d.incdirs] + [f"-D{x}" for x in d.defines] + d.files
        rc, out = run(cmd)
        for m in re.finditer(r"^%(Warning|Error)(?:-(\w+))?: ([^:\n]+):(\d+):(?:\d+:)? ?(.*)$", out, re.M):
            kind, rule, f, line, msg = m.groups()
            rule = rule or ("SYNTAX" if kind == "Error" else "OTHER")
            loc = f"{Path(f).name}:{line}"
            if any(rule == r and (fnmatch.fnmatch(Path(f).name, g) or fnmatch.fnmatch(loc, g)) for r, g in waivers):
                res["waived"] += 1
                continue
            res["errors" if kind == "Error" else "warnings"] += 1
            res["by_rule"][rule] = res["by_rule"].get(rule, 0) + 1
            res["messages"].append({"severity": kind.upper(), "rule": rule, "loc": loc, "msg": msg.strip()})
        if rc != 0 and res["errors"] == 0 and "%Error" in out:
            res["errors"] += 1
            res["messages"].append({"severity": "ERROR", "rule": "TOOL", "loc": "", "msg": out.strip()[-300:]})
    elif shutil.which("iverilog"):
        res["tool"] = "iverilog -Wall (verilator not installed)"
        rc, out = run(["iverilog", "-g2012", "-Wall", "-tnull", "-s", d.top] + [f"-I{i}" for i in d.incdirs] +
                      [f"-D{x}" for x in d.defines] + d.files)
        for l in out.splitlines():
            sev = "ERROR" if "error" in l.lower() else "WARNING"
            res["errors" if sev == "ERROR" else "warnings"] += 1
            res["messages"].append({"severity": sev, "rule": "IVERILOG", "loc": l.split(":")[0], "msg": l})
    else:
        res["tool"] = None
        res["messages"].append({"severity": "ERROR", "rule": "TOOL", "loc": "", "msg": "no verilator / iverilog"})
        res["errors"] = 1
    fail_warn = getattr(a, "fail_on", "warning") == "warning"
    res["status"] = "FAIL" if res["errors"] or (fail_warn and res["warnings"]) else "PASS"
    return res


def print_lint(r):
    print(f"\n== LINT [{r['tool']}]  top={r['top']}")
    for rule, n in sorted(r["by_rule"].items(), key=lambda x: -x[1]):
        print(f"   {rule:22} {n}")
    for m in r["messages"][:25]:
        print(f"   {col(m['severity'], 'r' if m['severity'] == 'ERROR' else 'y'):9} {m['rule']:16} {m['loc']:28} {m['msg'][:90]}")
    if len(r["messages"]) > 25:
        print(f"   ... {len(r['messages']) - 25} more (see --json)")
    if r["inline_waivers"]:
        print(f"   note: {r['inline_waivers']} inline `lint_off` pragmas in the sources hide warnings from this report")
    st = col(r["status"], "g" if r["status"] == "PASS" else "r")
    print(f"   LINT: {st}  ({r['errors']} errors, {r['warnings']} warnings, {r['waived']} waived)")


# =============================================================================== CDC / RDC
FF_TYPES = {"$dff", "$dffe", "$adff", "$adffe", "$sdff", "$sdffe", "$sdffce", "$dffsr", "$dffsre",
            "$aldff", "$aldffe", "$dlatch", "$adlatch", "$dlatchsr"}
BITWISE = {"$and", "$or", "$xor", "$xnor", "$not", "$pos", "$buf", "$neg"}
BUFLIKE = {"$pos", "$buf"}


def parse_sdc(path: Optional[str]):
    """port->clock name, async groups, input port -> clock."""
    clocks, groups, inputs = {}, [], {}
    if not path or not Path(path).exists():
        return clocks, groups, inputs
    t = Path(path).read_text(errors="ignore").replace("\\\n", " ")
    for m in re.finditer(r"create_clock\b([^\n]*)", t):
        line = m.group(1)
        n = re.search(r"-name\s+(\S+)", line)
        p = re.search(r"get_ports\s+\{?\s*([\w\[\]]+)", line)
        if p:
            clocks[p.group(1)] = n.group(1) if n else p.group(1)
    for m in re.finditer(r"set_clock_groups\b[^\n]*-asynchronous([^\n]*)", t):
        groups.append([re.findall(r"[\w]+", g) for g in re.findall(r"-group\s+(\{[^}]*\}|\[[^\]]*\]|\S+)", m.group(1))])
    for m in re.finditer(r"set_input_delay\b[^\n]*-clock\s+(\S+)[^\n]*get_ports\s+\{?([^}\]]+)", t):
        for p in m.group(2).split():
            inputs[p] = m.group(1)
    return clocks, groups, inputs


class Netlist:
    def __init__(self, js: dict, top: str):
        mod = js["modules"][top]
        self.cells = mod["cells"]
        self.ports = mod["ports"]
        self.names: Dict[int, str] = {}
        for n, info in sorted(mod.get("netnames", {}).items(), key=lambda kv: kv[1].get("hide_name", 0)):
            bits = info["bits"]
            for i, b in enumerate(bits):
                if isinstance(b, int) and (b not in self.names or (not info.get("hide_name") and self.names[b].startswith("$"))):
                    self.names[b] = n if len(bits) == 1 else f"{n}[{i}]"
        self.driver: Dict[int, Tuple[str, str, int]] = {}
        for p, info in self.ports.items():
            if info["direction"] == "input":
                for i, b in enumerate(info["bits"]):
                    if isinstance(b, int):
                        self.driver[b] = ("PORT", p, i)
        for cn, c in self.cells.items():
            for pn, bits in c["connections"].items():
                if c.get("port_directions", {}).get(pn) == "output":
                    for i, b in enumerate(bits):
                        if isinstance(b, int):
                            self.driver[b] = (cn, pn, i)
        self.ffs = {cn: c for cn, c in self.cells.items() if c["type"] in FF_TYPES}
        self.mems = {cn: c for cn, c in self.cells.items() if c["type"].startswith("$mem")}
        self.fanout: Dict[int, List[Tuple[str, str, int]]] = defaultdict(list)
        for cn, c in self.cells.items():
            for pn, bits in c["connections"].items():
                if c.get("port_directions", {}).get(pn) == "input":
                    for i, b in enumerate(bits):
                        if isinstance(b, int):
                            self.fanout[b].append((cn, pn, i))

    def nm(self, b) -> str:
        return self.names.get(b, f"net{b}") if isinstance(b, int) else f"const{b}"

    def ff_name(self, cn: str) -> str:
        q = self.ffs[cn]["connections"].get("Q", [])
        nmq = [self.nm(b) for b in q if isinstance(b, int)]
        base = re.sub(r"\[\d+\]$", "", nmq[0]) if nmq else cn
        return base

    # ---- clock roots
    def clock_root(self, b, depth=0) -> Tuple[str, str]:
        """(kind, name): kind = port | gen (flop Q) | gated (logic) | const."""
        if not isinstance(b, int):
            return ("const", str(b))
        drv = self.driver.get(b)
        if drv is None:
            return ("undriven", self.nm(b))
        cn, pn, i = drv
        if cn == "PORT":
            return ("port", pn)
        c = self.cells[cn]
        if c["type"] in FF_TYPES:
            return ("gen", self.ff_name(cn))
        if c["type"] in BUFLIKE | {"$not"} and depth < 50:
            src = c["connections"]["A"]
            return self.clock_root(src[i] if i < len(src) else src[0], depth + 1)
        return ("gated", f"{c['type']}:{self.nm(b)}")

    # ---- combinational source tracing
    def sources(self, b, memo) -> Tuple[frozenset, bool]:
        """(set of ('ff', cell, bit) / ('port', name) / ('mem', cell), through_logic)."""
        if not isinstance(b, int):
            return frozenset(), False
        if b in memo:
            return memo[b]
        memo[b] = (frozenset(), False)          # break combinational loops
        drv = self.driver.get(b)
        if drv is None:
            out = (frozenset(), False)
        else:
            cn, pn, i = drv
            if cn == "PORT":
                out = (frozenset({("port", pn)}), False)
            else:
                c = self.cells[cn]
                t = c["type"]
                if t in FF_TYPES:
                    out = (frozenset({("ff", cn, i)}), False)
                elif t.startswith("$mem"):
                    out = (frozenset({("mem", cn, i)}), True)
                else:
                    ins = []
                    conn = c["connections"]
                    if t in BITWISE or t == "$mux":
                        for p in ("A", "B"):
                            if p in conn:
                                v = conn[p]
                                ins.append(v[i] if i < len(v) else v[-1])
                        if t == "$mux":
                            ins += conn["S"]
                    else:
                        for p, bits in conn.items():
                            if c.get("port_directions", {}).get(p) == "input":
                                ins += bits
                    s, logic = set(), t not in BUFLIKE
                    for x in ins:
                        ss, _ = self.sources(x, memo)
                        s |= ss
                    out = (frozenset(s), logic)
        memo[b] = out
        return out


def check_cdc(d: Design, a) -> dict:
    res = {"check": "cdc", "top": d.top, "domains": {}, "crossings": [], "rdc": [], "clock_issues": [],
           "errors": 0, "warnings": 0, "status": "PASS"}
    y = yosys_bin()
    if not y:
        res.update(status="ERROR", errors=1, error="yosys not found (./setup_synthesis.sh)")
        return res
    with tempfile.TemporaryDirectory() as td:
        jf = Path(td) / "n.json"
        defs = " ".join(f"-D{x}" for x in d.defines)
        incs = " ".join(f"-I{i}" for i in d.incdirs)
        script = (f"read_verilog -sv {defs} {incs} {' '.join(d.files)}; hierarchy -check -top {d.top}; "
                  f"proc; flatten; opt_clean; opt_dff; opt_clean; memory -nomap; opt_clean; write_json {jf}")
        rc, out = run([y, "-q", "-p", script])
        if rc != 0 or not jf.exists():
            err = [l for l in out.splitlines() if "ERROR" in l] or out.strip().splitlines()[-3:]
            msg = "yosys could not elaborate the design: " + " | ".join(err)[:400]
            if "Multiple edge sensitive events" in out:
                msg += ("\n   cause: an always_ff with `or negedge rst` tests a reset expression that mixes other signals, "
                        "e.g. `if (!rst_n || !pwr_ok)`.\n   fix:   wire rst_x_n = rst_n & pwr_ok;  "
                        "always_ff @(posedge clk or negedge rst_x_n) if (!rst_x_n) ...")
            res.update(status="ERROR", errors=1, error=msg)
            return res
        js = json.loads(jf.read_text())
    N = Netlist(js, d.top)
    sdc_clocks, sdc_groups, sdc_inputs = parse_sdc(d.sdc)

    # ---- clock domains
    dom_of: Dict[str, str] = {}
    domain_ffs = defaultdict(int)
    for cn, c in N.ffs.items():
        clk = c["connections"].get("CLK") or c["connections"].get("EN")   # latches: EN is the gate
        kind, root = N.clock_root(clk[0]) if clk else ("none", "-")
        name = sdc_clocks.get(root, root) if kind == "port" else f"{kind}:{root}"
        dom_of[cn] = name
        domain_ffs[name] += max(1, len(c["connections"].get("Q", [0])))
        if kind == "gated":
            res["clock_issues"].append({"severity": "WARNING", "type": "GATED_CLOCK", "flop": N.ff_name(cn),
                                        "detail": f"clock comes through logic ({root}); use an ICG cell / clock enable"})
        if c["type"] in ("$dlatch", "$adlatch", "$dlatchsr"):
            res["clock_issues"].append({"severity": "WARNING", "type": "LATCH", "flop": N.ff_name(cn), "detail": "latch inferred"})
    for k, v in sorted(domain_ffs.items(), key=lambda x: -x[1]):
        res["domains"][k] = v
    for k in res["domains"]:
        if k.startswith("gen:"):
            res["clock_issues"].append({"severity": "INFO", "type": "GENERATED_CLOCK", "flop": k[4:],
                                        "detail": "clock generated by a flop - declare create_generated_clock in the SDC"})

    # ---- synchronous clock relations
    same: Dict[str, str] = {}
    for grp in (a.sync_clocks or []):
        names = [x.strip() for x in grp.split(",") if x.strip()]
        for x in names[1:]:
            same[x] = names[0]
    if sdc_groups:
        idx = {}
        for gi, g in enumerate(sdc_groups[0]):
            for clk in g:
                idx[clk] = gi
        for x in list(res["domains"]):
            for z in list(res["domains"]):
                if x != z and x in idx and z in idx and idx[x] == idx[z]:
                    same.setdefault(z, same.get(x, x))
    canon = lambda dn: same.get(dn, dn)  # noqa: E731
    async_in = re.compile(a.async_inputs) if a.async_inputs else None

    def src_domain(s):
        if s[0] == "ff":
            return canon(dom_of[s[1]])
        if s[0] == "port":
            if s[1] in sdc_inputs:
                return canon(sdc_clocks.get(sdc_inputs[s[1]], sdc_inputs[s[1]]))
            if async_in and async_in.search(s[1]):
                return "ASYNC_INPUT"
            return None                      # assumed synchronous to whoever captures it
        if s[0] == "mem":
            wr = N.mems[s[1]]["connections"].get("WR_CLK", [])
            k, r = N.clock_root(wr[0]) if wr else ("none", "-")
            return canon(sdc_clocks.get(r, r) if k == "port" else f"{k}:{r}") if wr else None
        return None

    # second-stage lookup: flops whose D is directly driven by another flop's Q
    direct_next = defaultdict(list)
    for cn, c in N.ffs.items():
        for i, b in enumerate(c["connections"].get("D", [])):
            drv = N.driver.get(b) if isinstance(b, int) else None
            if drv and drv[0] in N.ffs and drv[1] == "Q":
                direct_next[(drv[0], drv[2])].append(cn)

    memo = {}
    raw = []
    for cn, c in N.ffs.items():
        dd = canon(dom_of[cn])
        en_doms = set()
        if "EN" in c["connections"] and c["type"] not in ("$dlatch", "$adlatch"):
            for b in c["connections"]["EN"]:
                ss, _ = N.sources(b, memo)
                en_doms |= {src_domain(s) for s in ss} - {None}
        for pin in ("D", "EN", "SRST"):
            if pin not in c["connections"] or (pin == "EN" and c["type"] in ("$dlatch", "$adlatch")):
                continue
            for i, b in enumerate(c["connections"][pin]):
                ss, logic = N.sources(b, memo)
                foreign = [s for s in ss if src_domain(s) not in (None, dd)]
                if not foreign:
                    continue
                direct = (not logic and len(ss) == 1 and pin == "D")
                if direct:
                    nxt = [x for x in direct_next.get((cn, i), []) if canon(dom_of[x]) == dd]
                    if nxt:
                        kind, sev = "SYNC_2FF", "OK"
                    elif en_doms and en_doms <= {dd}:
                        kind, sev = "QUALIFIED", "INFO"
                    else:
                        kind, sev = "SINGLE_FLOP", "ERROR"
                else:
                    if pin == "D" and en_doms and en_doms <= {dd} and not logic:
                        kind, sev = "QUALIFIED", "INFO"
                    else:
                        kind, sev = ("COMB_BEFORE_SYNC" if any(direct_next.get((cn, i), [])) else "UNSYNC"), "ERROR"
                for s in foreign:
                    sname = N.ff_name(s[1]) if s[0] in ("ff",) else s[1]
                    raw.append({"severity": sev, "type": kind, "from_domain": src_domain(s), "to_domain": dd,
                                "source": sname, "dest": f"{N.ff_name(cn)}" + (f".{pin}" if pin != "D" else ""),
                                "bit": i})
    # merge per (source register, dest register, type)
    agg = {}
    for r in raw:
        k = (r["type"], r["source"], r["dest"], r["from_domain"], r["to_domain"])
        if k not in agg:
            agg[k] = dict(r, bits=0)
            agg[k].pop("bit")
        agg[k]["bits"] += 1
    crossings = list(agg.values())
    # multi-bit buses synchronized bit-wise
    for x in crossings:
        if x["type"] == "SYNC_2FF" and x["bits"] > 1 and not re.search(r"gray|gry", x["source"], re.I):
            x.update(type="MULTIBIT_SYNC", severity="WARNING",
                     detail=f"{x['bits']}-bit value synchronized bit-by-bit: use gray code, a handshake or an async FIFO")
    res["crossings"] = sorted(crossings, key=lambda x: {"ERROR": 0, "WARNING": 1, "INFO": 2, "OK": 3}[x["severity"]])

    # ---- RDC: asynchronous reset analysis
    # reset-synchronizer flops: async-reset chain whose first stage has a constant D
    rsync: Set[str] = set()
    changed = True
    while changed:
        changed = False
        for cn, c in N.ffs.items():
            if cn in rsync or not (c["connections"].get("ARST") or c["connections"].get("CLR")):
                continue
            dbits = c["connections"].get("D", [])
            const_d = dbits and all(not isinstance(b, int) for b in dbits)
            from_stage = dbits and all(isinstance(b, int) and N.driver.get(b, ("",))[0] in rsync for b in dbits)
            if const_d or from_stage:
                rsync.add(cn)
                changed = True
    rst_users = defaultdict(lambda: defaultdict(int))     # root -> domain -> flops
    rdc = []
    for cn, c in N.ffs.items():
        arst = c["connections"].get("ARST") or c["connections"].get("CLR")
        if not arst:
            continue
        ss, logic = N.sources(arst[0], memo)
        dd = canon(dom_of[cn])
        for s in ss:
            if s[0] == "port" and cn in rsync:
                continue                                  # the synchronizer itself may use the raw reset
            if s[0] == "port":
                rst_users[s[1]][dd] += 1
            elif s[0] == "ff" and s[1] in rsync and canon(dom_of[s[1]]) == dd:
                continue                                  # properly synchronized reset for this domain
            elif s[0] == "ff":
                sd = canon(dom_of[s[1]])
                src_ff = N.ffs[s[1]]
                dconst = all(not isinstance(b, int) for b in src_ff["connections"].get("D", [1]))
                if sd != dd:
                    rdc.append({"severity": "WARNING", "type": "RESET_FROM_OTHER_DOMAIN", "dest": N.ff_name(cn),
                                "source": N.ff_name(s[1]), "detail": f"async reset of a {dd} flop comes from {sd}"})
                elif not dconst and logic:
                    rdc.append({"severity": "INFO", "type": "RESET_FROM_LOGIC", "dest": N.ff_name(cn),
                                "source": N.ff_name(s[1]), "detail": "async reset generated by logic"})
    for root, doms in rst_users.items():
        if len(doms) > 1:
            for dn, n in doms.items():
                rdc.append({"severity": "WARNING", "type": "UNSYNC_RESET_DEASSERT", "source": root, "dest": dn,
                            "detail": f"raw reset '{root}' used by {n} flops in {dn} and by other domains - "
                                      f"add a per-domain reset synchronizer"})
        elif len(res["domains"]) == 1:
            pass                                    # single clock: deassertion assumed synchronized upstream
    # merge RDC duplicates
    seen, merged = {}, []
    for r in rdc:
        k = (r["type"], r["source"], r.get("dest"))
        if k in seen:
            seen[k]["count"] = seen[k].get("count", 1) + 1
            continue
        seen[k] = r
        merged.append(r)
    res["rdc"] = merged
    res["reset_synchronizers"] = sorted({N.ff_name(x) for x in rsync})

    allv = res["crossings"] + res["rdc"] + res["clock_issues"]
    res["errors"] = sum(1 for x in allv if x["severity"] == "ERROR")
    res["warnings"] = sum(1 for x in allv if x["severity"] == "WARNING")
    res["synchronized"] = sum(1 for x in res["crossings"] if x["severity"] in ("OK", "INFO"))
    fail_warn = getattr(a, "fail_on", "error") == "warning"
    res["status"] = "FAIL" if res["errors"] or (fail_warn and res["warnings"]) else (
        "PASS" if not res["warnings"] else "PASS (with warnings)")
    return res


def print_cdc(r):
    print(f"\n== CDC / RDC [structural, yosys netlist]  top={r['top']}")
    if r.get("error"):
        print("   " + col(r["error"], "r"))
        print(f"   CDC: {col('ERROR', 'r')}")
        return
    print("   clock domains: " + ", ".join(f"{k} ({v} flops)" for k, v in r["domains"].items()))
    if len(r["domains"]) <= 1 and not r["crossings"]:
        print("   single clock domain - no clock-domain crossings")
    sev_c = {"ERROR": "r", "WARNING": "y", "INFO": "c", "OK": "g"}
    for x in r["crossings"][:40]:
        print(f"   {col(x['severity'], sev_c[x['severity']]):9} {x['type']:17} {x['from_domain']} -> {x['to_domain']}: "
              f"{x['source']} -> {x['dest']} ({x['bits']} bit{'s' if x['bits'] > 1 else ''})"
              + (f"  - {x['detail']}" if x.get("detail") else ""))
    if len(r["crossings"]) > 40:
        print(f"   ... {len(r['crossings']) - 40} more crossings (see --json)")
    for x in r["rdc"] + r["clock_issues"]:
        print(f"   {col(x['severity'], sev_c.get(x['severity'], 'c')):9} {x['type']:24} {x.get('source', x.get('flop', ''))} "
              f"-> {x.get('dest', '')}  {x['detail']}" + (f" (x{x['count']})" if x.get("count") else ""))
    st = r["status"]
    print(f"   CDC: {col(st, 'g' if st.startswith('PASS') else 'r')}  ({len(r['crossings'])} crossings, "
          f"{r.get('synchronized', 0)} synchronized, {r['errors']} errors, {r['warnings']} warnings)")


# =============================================================================== SIM
def check_sim(d: Design, a) -> dict:
    res = {"check": "sim", "tb": d.tb, "status": "SKIPPED"}
    if not d.tb:
        res["detail"] = "no testbench (--tb)"
        return res
    tbtop = find_top([d.tb]) or Path(d.tb).stem
    with tempfile.TemporaryDirectory() as td:
        if shutil.which("iverilog"):
            rc, out = run(["iverilog", "-g2012", "-o", f"{td}/s.vvp", "-s", tbtop] + [f"-I{i}" for i in d.incdirs] +
                          [f"-D{x}" for x in d.defines] + d.files + [d.tb])
            if rc == 0:
                rc, out = run(["vvp", "-n", f"{td}/s.vvp"], cwd=td, timeout=int(os.getenv("RTL_SIM_TIMEOUT", "600")))
        elif shutil.which("verilator"):
            rc, out = run(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module",
                           tbtop, "-Mdir", f"{td}/o", "-o", "simv"] + d.files + [d.tb])
            if rc == 0:
                rc, out = run([f"{td}/o/simv"], cwd=td, timeout=int(os.getenv("RTL_SIM_TIMEOUT", "600")))
        else:
            res.update(status="ERROR", detail="no simulator")
            return res
    # failure = a line that STARTS with ERROR/FAIL, a TEST FAILED verdict, $fatal or an assertion
    # (headings such as "--- Test 3: unmapped address -> error response ---" are not failures)
    bad = [l for l in out.splitlines() if re.search(r"^\s*(ERROR|FAIL(ED)?)\b|TEST(S)?\s+FAILED|\$fatal|assertion\s+(failed|error)", l, re.I)]
    zero = re.search(r"\(\s*0\s+checks", out)
    passed = rc == 0 and not bad and not zero and re.search(r"PASS", out, re.I)
    res.update(status="PASS" if passed else "FAIL", rc=rc,
               detail=("0 checks executed" if zero else (bad[0] if bad else ("timeout" if rc == 124 else ""))),
               tail=out[-1500:])
    return res


def print_sim(r):
    print(f"\n== SIMULATION  tb={r.get('tb')}")
    st = r["status"]
    print(f"   SIM: {col(st, 'g' if st == 'PASS' else ('y' if st == 'SKIPPED' else 'r'))}  {r.get('detail', '')}")


# =============================================================================== SYNTH
def check_synth(d: Design, a) -> dict:
    sys.path.insert(0, str(HERE))
    from techlib import synth_flow as SF
    out = getattr(a, "out", None) or "."
    Path(out).mkdir(parents=True, exist_ok=True)
    net = str(Path(out) / f"{d.top}_{a.lib}_gate.v")
    r = SF.synthesize(d.files, d.top, a.lib, net, a.period)
    res = {"check": "synth", "status": "PASS" if r["ok"] else "FAIL", **{k: v for k, v in r.items() if k != "log"}}
    if r["ok"] and d.tb and a.gls:
        g = SF.gls(r["netlist"], d.tb, a.lib, r["liberty"] if r["full_library"] else None)
        res["gls"] = "PASS" if g["ok"] else "FAIL"
    if r["ok"] and r["full_library"] and SF.sta_bin():
        sdc = d.sdc_explicit or SF.auto_sdc(d.top, d.files, a.clock, a.period, a.reset, a.lib, net.replace(".v", ".sdc"))
        st = SF.run_sta(r["netlist"], d.top, str(SF.full_lib(a.lib)), sdc)
        res["sta"] = {k: st.get(k) for k in ("wns_setup", "wns_hold", "tns", "report")}
    return res


def print_synth(r):
    print(f"\n== SYNTHESIS  lib={r.get('lib')} ({'with timing' if r.get('full_library') else 'bundled subset, no timing'})")
    if r["status"] != "PASS":
        print("   " + col(r.get("error", "failed"), "r"))
    else:
        print(f"   cells {r.get('cells')}  flops {r.get('flops')}  area {r.get('area_um2')} um2  netlist {r.get('netlist')}")
        if "gls" in r:
            print(f"   gate-level sim: {r['gls']}")
        if r.get("sta"):
            print(f"   STA: setup WNS {r['sta']['wns_setup']} ns, hold WNS {r['sta']['wns_hold']} ns ({r['sta']['report']})")
    print(f"   SYNTH: {col(r['status'], 'g' if r['status'] == 'PASS' else 'r')}")


# =============================================================================== CLI
def build_parser():
    ap = argparse.ArgumentParser(prog="rtl_checks", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("check", choices=["lint", "cdc", "sim", "synth", "all"])
    ap.add_argument("inputs", nargs="*", help="RTL files, .f filelists, directories or spec2rtl IP dirs")
    ap.add_argument("-d", "--dir", action="append", help="directory of RTL (recursive)")
    ap.add_argument("-f", "--filelist", action="append", help="EDA filelist")
    ap.add_argument("--top")
    ap.add_argument("-I", "--incdir", action="append")
    ap.add_argument("-D", "--define", action="append")
    ap.add_argument("--tb", help="testbench (sim / all)")
    ap.add_argument("--json", help="write report JSON here")
    ap.add_argument("--fail-on", choices=["error", "warning"], default=None,
                    help="lint default: warning; cdc default: error")
    # lint
    ap.add_argument("--waivers", help="lint waiver file: '<RULE> [file-glob[:line]]' per line")
    # cdc
    ap.add_argument("--sdc", help="SDC with create_clock / set_clock_groups / set_input_delay")
    ap.add_argument("--sync-clocks", action="append", help="clocks that are synchronous, e.g. clk,clk_div2")
    ap.add_argument("--async-inputs", help="regex of top inputs that are asynchronous (e.g. 'rx|gpio_in|_async')")
    # synth
    ap.add_argument("--lib", choices=["nangate45", "sky130"], default="nangate45")
    ap.add_argument("--period", type=float, default=10.0)
    ap.add_argument("--clock", default="clk")
    ap.add_argument("--reset", default="rst_n")
    ap.add_argument("--gls", action="store_true", help="gate-level simulation of the netlist with --tb")
    ap.add_argument("-o", "--out", default="checks_out", help="output dir for synthesis results")
    return ap


def main(argv=None) -> int:
    a = build_parser().parse_args(argv)
    try:
        d = resolve_inputs(a)
    except SystemExit as e:
        print(e)
        return 2
    print(f"[rtl_checks] top={d.top}  files={len(d.files)}" + (f"  tb={Path(d.tb).name}" if d.tb else "")
          + (f"  sdc={Path(d.sdc).name}" if d.sdc else ""))
    report, ok = {}, True
    steps = ["lint", "cdc", "sim", "synth"] if a.check == "all" else [a.check]
    user_fail_on = a.fail_on
    for s in steps:
        a.fail_on = user_fail_on or ("warning" if s == "lint" else "error")
        if s == "lint":
            r = check_lint(d, a); print_lint(r)
        elif s == "cdc":
            r = check_cdc(d, a); print_cdc(r)
        elif s == "sim":
            r = check_sim(d, a); print_sim(r)
        else:
            r = check_synth(d, a); print_synth(r)
        report[s] = r
        ok &= r["status"].startswith("PASS") or r["status"] == "SKIPPED"
    if len(steps) > 1:
        print("\n== SUMMARY  " + "  ".join(f"{k.upper()}={v['status']}" for k, v in report.items()))
    if a.json:
        Path(a.json).write_text(json.dumps(report, indent=2, default=str))
        print(f"[rtl_checks] report: {a.json}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
