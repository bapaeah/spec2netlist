#!/usr/bin/env bash
# ==============================================================================
#  LLM_Local One-Click Maintenance & Update Script (macOS & Linux)
# ==============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================================="
echo "           Updating LLM_Local Environment                 "
echo "=========================================================="

# 1. Update Python package installation
echo "[1/4] Updating package registration in editable mode..."
python3 -m pip install -e . --no-build-isolation > /dev/null 2>&1 || python3 -m pip install -e . --user > /dev/null 2>&1 || true
echo "      ✓ CLI package updated (rtl, rtl-assistant, memgen, spec2rtl)."

# 2. Rebuild local LLM models from Modelfiles
echo "[2/4] Updating local RTL models from Modelfiles..."
if ! python3 -c "import ollama_models as m,sys;sys.exit(0 if m.is_local(m.ollama_host()) else 1)" 2>/dev/null; then
    echo "      Remote Ollama ($(python3 -c 'import ollama_models as m;print(m.ollama_host())')): re-measuring model fit..."
    python3 ollama_models.py --reprobe || true
elif command -v ollama &>/dev/null; then
    if [ -f "Modelfile.rtl" ]; then
        echo "      Building rtl-coder (7B)..."
        ollama create rtl-coder -f Modelfile.rtl > /dev/null 2>&1 && echo "      ✓ rtl-coder rebuilt successfully." || echo "      ! Note: Ensure Ollama is running to rebuild models."
    fi
    if [ -f "Modelfile.rtl-fast" ]; then
        echo "      Building rtl-coder-fast (3B)..."
        ollama create rtl-coder-fast -f Modelfile.rtl-fast > /dev/null 2>&1 && echo "      ✓ rtl-coder-fast rebuilt successfully." || true
    fi
else
    echo "      ! Ollama binary not found in PATH; skipping model rebuild."
fi

# 3. Run Memory Compiler unit tests
echo "[3/4] Running memory compiler test suite..."
if [ -d "memory/tests" ]; then
    python3 -m unittest discover memory/tests > /dev/null 2>&1 && echo "      ✓ Memory compiler unit tests passed." || echo "      ! Some unit tests failed."
fi

# 3b. Synthesis libraries (download if missing, verify checksums)
echo "[3b] Checking synthesis libraries..."
python3 techlib/synth_flow.py --install-libs > /dev/null 2>&1 && echo "      ✓ Liberty files present and verified." || \
    echo "      ! Liberty files missing - run ./setup_synthesis.sh"

# 4. Run environment check
echo "[4/4] Verifying environment health..."
python3 rtl_assistant.py --check

echo ""
echo "=========================================================="
echo "          LLM_Local Update Complete!                      "
echo "=========================================================="
