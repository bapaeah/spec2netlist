#!/usr/bin/env python3
"""
LLM_Local: 100% Offline & Token-Free Hardware Engineering Assistant,
Memory Compiler & SoC CAD Suite.
"""

import sys
from rtl_assistant import main, call_ollama, check_status

__all__ = ["main", "call_ollama", "check_status"]

if __name__ == "__main__":
    main()
