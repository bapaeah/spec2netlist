// All non-clock/reset inputs are synchronous to pmu_clk. P/Q pins require
// CDC adapters; reset_released must come from each domain's local reset
// synchronizer. Power/isolation/clock outputs control external cells.
// *_clk_enable drives an integrated clock-gating cell; it is not a clock.
/* verilator lint_off DECLFILENAME */
module pmu_power_domain #(
    parameter integer Q_CHANNELS = 1,
    parameter bit USE_Q_CHANNEL = 1'b0,
    parameter integer TIMEOUT_CYCLES = 100000
) (
    input  logic                    pmu_clk,
    input  logic                    por_n,
    input  logic                    sleep_req,
    input  logic                    powerdown_req,
    input  logic                    idle,
    input  logic                    axi_quiescent,
    input  logic                    powerdown_safe,
    input  logic                    power_good,
    input  logic                    reset_released,
    input  logic [Q_CHANNELS-1:0]   qacceptn_pmu,
    input  logic [Q_CHANNELS-1:0]   qdeny_pmu,
    input  logic [Q_CHANNELS-1:0]   qactive_pmu,
    output logic [Q_CHANNELS-1:0]   qreqn_pmu,
    output logic                    clk_enable,
    output logic                    power_enable,
    output logic                    isolation_enable,
    output logic                    reset_hold,
    output logic                    online,
    output logic                    quiesce_req,
    output logic                    fault
);

    typedef enum logic [3:0] {
        POWERUP,
        WAIT_RESET_RELEASE,
        WAIT_Q_ACTIVE,
        RUN,
        WAIT_QUIET,
        WAIT_Q_STOP,
        CLOCK_STOPPED,
        ASSERT_ISOLATION,
        POWERED_OFF,
        WAKE_POWER,
        WAKE_RESET,
        WAKE_Q
    } state_t;

    localparam integer TIMEOUT_LIMIT =
        (TIMEOUT_CYCLES < 1) ? 1 : TIMEOUT_CYCLES;
    localparam integer TIMER_WIDTH =
        (TIMEOUT_LIMIT <= 1) ? 1 : $clog2(TIMEOUT_LIMIT + 1);
    localparam logic [TIMER_WIDTH-1:0] TIMEOUT_COUNT =
        TIMER_WIDTH'(TIMEOUT_LIMIT);
    localparam logic [TIMER_WIDTH-1:0] TIMEOUT_LAST =
        TIMER_WIDTH'(TIMEOUT_LIMIT - 1);

    state_t state;
    state_t previous_state;
    logic q_rejected;
    logic [TIMER_WIDTH-1:0] wait_cycles;

    always_comb begin
        online = (state == RUN);
        quiesce_req = !online || sleep_req || powerdown_req;
    end

    always_ff @(posedge pmu_clk or negedge por_n) begin
        if (!por_n) begin
            state             <= POWERUP;
            previous_state    <= POWERUP;
            wait_cycles       <= 0;
            qreqn_pmu         <= '1;
            clk_enable        <= 1'b0;
            power_enable      <= 1'b1;
            isolation_enable  <= 1'b1;
            reset_hold        <= 1'b1;
            fault             <= 1'b0;
            q_rejected        <= 1'b0;
        end else begin
            previous_state <= state;
            if (state != previous_state)
                wait_cycles <= 0;
            else if ((state == POWERUP) ||
                     (state == WAIT_RESET_RELEASE) ||
                     (state == WAIT_Q_ACTIVE) ||
                     (state == WAIT_Q_STOP) ||
                     (state == WAKE_POWER) ||
                     (state == WAKE_RESET) ||
                     (state == WAKE_Q)) begin
                if (wait_cycles < TIMEOUT_COUNT)
                    wait_cycles <= wait_cycles + 1'b1;
            end
            else
                wait_cycles <= 0;

            case (state)
                POWERUP: begin
                    power_enable     <= 1'b1;
                    isolation_enable <= 1'b1;
                    reset_hold       <= 1'b1;
                    clk_enable       <= 1'b0;
                    qreqn_pmu        <= '1;
                    if (power_good) begin
                        clk_enable <= 1'b1;
                        reset_hold <= 1'b0;
                        state <= WAIT_RESET_RELEASE;
                    end else if (wait_cycles >= TIMEOUT_LAST) begin
                        fault <= 1'b1;
                    end
                end

                WAIT_RESET_RELEASE: begin
                    if (reset_released) begin
                        isolation_enable <= 1'b0;
                        if (USE_Q_CHANNEL) begin
                            qreqn_pmu <= '1;
                            state <= WAIT_Q_ACTIVE;
                        end else begin
                            state <= RUN;
                        end
                    end else if (wait_cycles >= TIMEOUT_LAST) begin
                        fault <= 1'b1;
                    end
                end

                WAIT_Q_ACTIVE: begin
                    if (&qacceptn_pmu)
                        state <= RUN;
                    else if (wait_cycles >= TIMEOUT_LAST)
                        fault <= 1'b1;
                end

                RUN: begin
                    if (!(sleep_req || powerdown_req))
                        q_rejected <= 1'b0;
                    if ((sleep_req || powerdown_req) && !q_rejected)
                        state <= WAIT_QUIET;
                end

                WAIT_QUIET: begin
                    if (!(sleep_req || powerdown_req)) begin
                        q_rejected <= 1'b0;
                        state <= RUN;
                    end else if (idle && axi_quiescent &&
                                 (!powerdown_req || powerdown_safe)) begin
                        if (USE_Q_CHANNEL) begin
                            qreqn_pmu <= '0;
                            state <= WAIT_Q_STOP;
                        end else begin
                            clk_enable <= 1'b0;
                            if (powerdown_req)
                                state <= ASSERT_ISOLATION;
                            else
                                state <= CLOCK_STOPPED;
                        end
                    end
                end

                WAIT_Q_STOP: begin
                    if (|qdeny_pmu) begin
                        qreqn_pmu <= '1;
                        fault <= 1'b1;
                        q_rejected <= 1'b1;
                        state <= WAIT_Q_ACTIVE;
                    end else if ((qacceptn_pmu == '0) &&
                                 (qactive_pmu == '0)) begin
                        clk_enable <= 1'b0;
                        if (powerdown_req && powerdown_safe)
                            state <= ASSERT_ISOLATION;
                        else
                            state <= CLOCK_STOPPED;
                    end else if (wait_cycles >= TIMEOUT_LAST) begin
                        qreqn_pmu <= '1;
                        q_rejected <= 1'b1;
                        fault <= 1'b1;
                        state <= WAIT_Q_ACTIVE;
                    end
                end

                CLOCK_STOPPED: begin
                    if (powerdown_req && powerdown_safe) begin
                        state <= ASSERT_ISOLATION;
                    end else if (!(sleep_req || powerdown_req)) begin
                        clk_enable <= 1'b1;
                        if (USE_Q_CHANNEL) begin
                            qreqn_pmu <= '1;
                            state <= WAKE_Q;
                        end else begin
                            state <= RUN;
                        end
                    end
                end

                ASSERT_ISOLATION: begin
                    reset_hold       <= 1'b1;
                    isolation_enable <= 1'b1;
                    state <= POWERED_OFF;
                end

                POWERED_OFF: begin
                    clk_enable <= 1'b0;
                    power_enable <= 1'b0;
                    if (!(sleep_req || powerdown_req))
                        state <= WAKE_POWER;
                end

                WAKE_POWER: begin
                    power_enable <= 1'b1;
                    isolation_enable <= 1'b1;
                    reset_hold <= 1'b1;
                    if (power_good) begin
                        clk_enable <= 1'b1;
                        reset_hold <= 1'b0;
                        state <= WAKE_RESET;
                    end else if (wait_cycles >= TIMEOUT_LAST) begin
                        fault <= 1'b1;
                    end
                end

                WAKE_RESET: begin
                    if (reset_released) begin
                        isolation_enable <= 1'b0;
                        if (USE_Q_CHANNEL) begin
                            qreqn_pmu <= '1;
                            state <= WAKE_Q;
                        end else begin
                            state <= RUN;
                        end
                    end else if (wait_cycles >= TIMEOUT_LAST) begin
                        fault <= 1'b1;
                    end
                end

                WAKE_Q: begin
                    if (&qacceptn_pmu)
                        state <= RUN;
                    else if (wait_cycles >= TIMEOUT_LAST)
                        fault <= 1'b1;
                end

                default: begin
                    state             <= POWERUP;
                    qreqn_pmu         <= '1;
                    clk_enable        <= 1'b0;
                    power_enable      <= 1'b1;
                    isolation_enable  <= 1'b1;
                    reset_hold        <= 1'b1;
                    fault             <= 1'b1;
                end
            endcase
        end
    end

endmodule
/* verilator lint_on DECLFILENAME */

module a55_ibex_pmu #(
    // Set channel counts to the exact ports exposed by the configured A55.
    parameter integer A55_Q_CHANNELS = 1,
    parameter integer A55_P_CHANNELS = 1,
    parameter integer PSTATE_WIDTH = 4,
    parameter integer TIMEOUT_CYCLES = 100000
) (
    input  logic pmu_clk,
    input  logic por_n,

    input  logic a55_sleep_req,
    input  logic a55_powerdown_req,
    input  logic [1:0] a55_core_idle,
    input  logic a55_axi_quiescent,
    input  logic a55_powerdown_safe,
    input  logic a55_power_good,
    input  logic a55_reset_released,
    input  logic [A55_Q_CHANNELS-1:0] a55_qacceptn_pmu,
    input  logic [A55_Q_CHANNELS-1:0] a55_qdeny_pmu,
    input  logic [A55_Q_CHANNELS-1:0] a55_qactive_pmu,
    output logic [A55_Q_CHANNELS-1:0] a55_qreqn_pmu,
    input  logic [A55_P_CHANNELS-1:0] a55_pvalid,
    output logic [A55_P_CHANNELS-1:0] a55_pready,
    input  logic [A55_P_CHANNELS*PSTATE_WIDTH-1:0] a55_pstate_req,
    input  logic [A55_P_CHANNELS-1:0] a55_paccept_pmu,
    input  logic [A55_P_CHANNELS-1:0] a55_pdeny_pmu,
    input  logic [A55_P_CHANNELS-1:0] a55_pactive_pmu,
    output logic [A55_P_CHANNELS-1:0] a55_preq_pmu,
    output logic [A55_P_CHANNELS*PSTATE_WIDTH-1:0] a55_pstate_pmu,
    output logic [A55_P_CHANNELS-1:0] a55_pdone,
    output logic [A55_P_CHANNELS-1:0] a55_pdenied,
    output logic [A55_P_CHANNELS-1:0] a55_pactive_status,
    output logic a55_clk_enable,
    output logic a55_power_enable,
    output logic a55_isolation_enable,
    output logic a55_reset_hold,
    output logic a55_online,
    output logic a55_axi_quiesce_req,
    output logic a55_fault,

    input  logic ibex_sleep_req,
    input  logic ibex_powerdown_req,
    input  logic ibex_idle,
    input  logic ibex_axi_quiescent,
    input  logic ibex_powerdown_safe,
    input  logic ibex_power_good,
    input  logic ibex_reset_released,
    output logic ibex_clk_enable,
    output logic ibex_power_enable,
    output logic ibex_isolation_enable,
    output logic ibex_reset_hold,
    output logic ibex_online,
    output logic ibex_axi_quiesce_req,
    output logic ibex_fault
);

    logic [A55_P_CHANNELS-1:0] p_busy;
    logic [A55_P_CHANNELS*PSTATE_WIDTH-1:0] pstate_held;
    logic a55_domain_fault;
    logic [A55_P_CHANNELS-1:0] p_fault;
    localparam integer P_TIMEOUT_LIMIT =
        (TIMEOUT_CYCLES < 1) ? 1 : TIMEOUT_CYCLES;
    localparam integer P_TIMER_WIDTH =
        (P_TIMEOUT_LIMIT <= 1) ? 1 : $clog2(P_TIMEOUT_LIMIT + 1);
    localparam logic [P_TIMER_WIDTH-1:0] P_TIMEOUT_LAST =
        P_TIMER_WIDTH'(P_TIMEOUT_LIMIT - 1);

    /* verilator lint_off PINCONNECTEMPTY */
    // Ibex uses idle/quiescence handshakes, not an AMBA Q-channel.
    pmu_power_domain #(
        .Q_CHANNELS(A55_Q_CHANNELS),
        .USE_Q_CHANNEL(1'b1),
        .TIMEOUT_CYCLES(TIMEOUT_CYCLES)
    ) u_a55_domain (
        .pmu_clk(pmu_clk),
        .por_n(por_n),
        .sleep_req(a55_sleep_req),
        .powerdown_req(a55_powerdown_req),
        .idle((&a55_core_idle) && !(|p_busy)),
        .axi_quiescent(a55_axi_quiescent),
        .powerdown_safe(a55_powerdown_safe && !(|p_busy)),
        .power_good(a55_power_good),
        .reset_released(a55_reset_released),
        .qacceptn_pmu(a55_qacceptn_pmu),
        .qdeny_pmu(a55_qdeny_pmu),
        .qactive_pmu(a55_qactive_pmu),
        .qreqn_pmu(a55_qreqn_pmu),
        .clk_enable(a55_clk_enable),
        .power_enable(a55_power_enable),
        .isolation_enable(a55_isolation_enable),
        .reset_hold(a55_reset_hold),
        .online(a55_online),
        .quiesce_req(a55_axi_quiesce_req),
        .fault(a55_domain_fault)
    );

    assign a55_fault = a55_domain_fault | (|p_fault);

    genvar p;
    generate
        for (p = 0; p < A55_P_CHANNELS; p = p + 1) begin : gen_a55_pchannel
            logic [P_TIMER_WIDTH-1:0] p_wait_cycles;

            always_ff @(posedge pmu_clk or negedge por_n) begin
                if (!por_n) begin
                    p_busy[p] <= 1'b0;
                    a55_preq_pmu[p] <= 1'b0;
                    pstate_held[p*PSTATE_WIDTH +: PSTATE_WIDTH] <= '0;
                    a55_pdone[p] <= 1'b0;
                    a55_pdenied[p] <= 1'b0;
                    p_wait_cycles <= 0;
                    p_fault[p] <= 1'b0;
                end else begin
                    a55_pdone[p] <= 1'b0;
                    a55_pdenied[p] <= 1'b0;

                    if (!p_busy[p] && a55_pvalid[p] && a55_online) begin
                        pstate_held[p*PSTATE_WIDTH +: PSTATE_WIDTH]
                            <= a55_pstate_req[p*PSTATE_WIDTH +: PSTATE_WIDTH];
                        a55_preq_pmu[p] <= 1'b1;
                        p_busy[p] <= 1'b1;
                        p_wait_cycles <= 0;
                    end else if (p_busy[p] && a55_pdeny_pmu[p]) begin
                        a55_preq_pmu[p] <= 1'b0;
                        p_busy[p] <= 1'b0;
                        a55_pdenied[p] <= 1'b1;
                        p_wait_cycles <= 0;
                    end else if (p_busy[p] && a55_paccept_pmu[p]) begin
                        a55_preq_pmu[p] <= 1'b0;
                        p_busy[p] <= 1'b0;
                        a55_pdone[p] <= 1'b1;
                        p_wait_cycles <= 0;
                    end else if (p_busy[p]) begin
                        if (p_wait_cycles >= P_TIMEOUT_LAST) begin
                            a55_preq_pmu[p] <= 1'b0;
                            p_busy[p] <= 1'b0;
                            a55_pdenied[p] <= 1'b1;
                            p_fault <= 1'b1;
                            p_wait_cycles <= 0;
                        end else begin
                            p_wait_cycles <= p_wait_cycles + 1;
                        end
                    end
                end
            end

            assign a55_pready[p] = !p_busy[p] && a55_online;
            assign a55_pstate_pmu[p*PSTATE_WIDTH +: PSTATE_WIDTH]
                = pstate_held[p*PSTATE_WIDTH +: PSTATE_WIDTH];
            assign a55_pactive_status[p] = a55_pactive_pmu[p];
        end
    endgenerate

    pmu_power_domain #(
        .Q_CHANNELS(1),
        .USE_Q_CHANNEL(1'b0),
        .TIMEOUT_CYCLES(TIMEOUT_CYCLES)
    ) u_ibex_domain (
        .pmu_clk(pmu_clk),
        .por_n(por_n),
        .sleep_req(ibex_sleep_req),
        .powerdown_req(ibex_powerdown_req),
        .idle(ibex_idle),
        .axi_quiescent(ibex_axi_quiescent),
        .powerdown_safe(ibex_powerdown_safe),
        .power_good(ibex_power_good),
        .reset_released(ibex_reset_released),
        .qacceptn_pmu(1'b1),
        .qdeny_pmu(1'b0),
        .qactive_pmu(1'b0),
        .qreqn_pmu(),
        .clk_enable(ibex_clk_enable),
        .power_enable(ibex_power_enable),
        .isolation_enable(ibex_isolation_enable),
        .reset_hold(ibex_reset_hold),
        .online(ibex_online),
        .quiesce_req(ibex_axi_quiesce_req),
        .fault(ibex_fault)
    );
    /* verilator lint_on PINCONNECTEMPTY */

endmodule
