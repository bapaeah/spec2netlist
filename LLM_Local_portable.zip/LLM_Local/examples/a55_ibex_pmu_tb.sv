module tb_a55_ibex_pmu;

    localparam integer Q_CHANNELS = 2;
    localparam integer P_CHANNELS = 1;
    localparam integer PSTATE_WIDTH = 4;

    logic pmu_clk = 1'b0;
    logic por_n = 1'b0;

    logic a55_sleep_req = 1'b0;
    logic a55_powerdown_req = 1'b0;
    logic [1:0] a55_core_idle = 2'b00;
    logic a55_axi_quiescent = 1'b0;
    logic a55_powerdown_safe = 1'b0;
    logic a55_power_good = 1'b1;
    logic a55_reset_released;
    logic [Q_CHANNELS-1:0] a55_qacceptn_pmu = '1;
    logic [Q_CHANNELS-1:0] a55_qdeny_pmu = '0;
    logic [Q_CHANNELS-1:0] a55_qactive_pmu = '0;
    logic [Q_CHANNELS-1:0] a55_qreqn_pmu;
    logic [P_CHANNELS-1:0] a55_pvalid = '0;
    logic [P_CHANNELS-1:0] a55_pready;
    logic [P_CHANNELS*PSTATE_WIDTH-1:0] a55_pstate_req = '0;
    logic [P_CHANNELS-1:0] a55_paccept_pmu = '0;
    logic [P_CHANNELS-1:0] a55_pdeny_pmu = '0;
    logic [P_CHANNELS-1:0] a55_pactive_pmu = '0;
    logic [P_CHANNELS-1:0] a55_preq_pmu;
    logic [P_CHANNELS*PSTATE_WIDTH-1:0] a55_pstate_pmu;
    logic [P_CHANNELS-1:0] a55_pdone;
    logic [P_CHANNELS-1:0] a55_pdenied;
    logic [P_CHANNELS-1:0] a55_pactive_status;
    logic a55_clk_enable;
    logic a55_power_enable;
    logic a55_isolation_enable;
    logic a55_reset_hold;
    logic a55_online;
    logic a55_axi_quiesce_req;
    logic a55_fault;

    logic ibex_sleep_req = 1'b0;
    logic ibex_powerdown_req = 1'b0;
    logic ibex_idle = 1'b0;
    logic ibex_axi_quiescent = 1'b0;
    logic ibex_powerdown_safe = 1'b0;
    logic ibex_power_good = 1'b1;
    logic ibex_reset_released;
    logic ibex_clk_enable;
    logic ibex_power_enable;
    logic ibex_isolation_enable;
    logic ibex_reset_hold;
    logic ibex_online;
    logic ibex_axi_quiesce_req;
    logic ibex_fault;

    always #5 pmu_clk = ~pmu_clk;

    assign a55_reset_released = !a55_reset_hold;
    assign ibex_reset_released = !ibex_reset_hold;

    a55_ibex_pmu #(
        .A55_Q_CHANNELS(Q_CHANNELS),
        .A55_P_CHANNELS(P_CHANNELS),
        .PSTATE_WIDTH(PSTATE_WIDTH),
        .TIMEOUT_CYCLES(8)
    ) dut (
        .pmu_clk,
        .por_n,
        .a55_sleep_req,
        .a55_powerdown_req,
        .a55_core_idle,
        .a55_axi_quiescent,
        .a55_powerdown_safe,
        .a55_power_good,
        .a55_reset_released,
        .a55_qacceptn_pmu,
        .a55_qdeny_pmu,
        .a55_qactive_pmu,
        .a55_qreqn_pmu,
        .a55_pvalid,
        .a55_pready,
        .a55_pstate_req,
        .a55_paccept_pmu,
        .a55_pdeny_pmu,
        .a55_pactive_pmu,
        .a55_preq_pmu,
        .a55_pstate_pmu,
        .a55_pdone,
        .a55_pdenied,
        .a55_pactive_status,
        .a55_clk_enable,
        .a55_power_enable,
        .a55_isolation_enable,
        .a55_reset_hold,
        .a55_online,
        .a55_axi_quiesce_req,
        .a55_fault,
        .ibex_sleep_req,
        .ibex_powerdown_req,
        .ibex_idle,
        .ibex_axi_quiescent,
        .ibex_powerdown_safe,
        .ibex_power_good,
        .ibex_reset_released,
        .ibex_clk_enable,
        .ibex_power_enable,
        .ibex_isolation_enable,
        .ibex_reset_hold,
        .ibex_online,
        .ibex_axi_quiesce_req,
        .ibex_fault
    );

    task automatic check(input logic condition, input string message);
        if (!condition) begin
            $error("%s", message);
            $fatal(1);
        end
    endtask

    initial begin
        repeat (2) @(negedge pmu_clk);
        por_n = 1'b1;

        wait (a55_online && ibex_online);
        check(a55_clk_enable && ibex_clk_enable, "clocks enabled after power-up");
        check(!a55_isolation_enable && !ibex_isolation_enable,
              "isolation released after reset");

        a55_pstate_req = 4'hA;
        a55_pvalid = 1'b1;
        wait (a55_preq_pmu);
        check(a55_pstate_pmu == 4'hA, "PSTATE held stable for request");
        a55_pvalid = 1'b0;
        a55_paccept_pmu = 1'b1;
        wait (a55_pdone);
        check(!a55_preq_pmu, "PREQ withdrawn after acceptance");
        @(negedge pmu_clk);
        a55_paccept_pmu = 1'b0;

        a55_sleep_req = 1'b1;
        a55_core_idle = 2'b11;
        a55_axi_quiescent = 1'b0;
        repeat (3) @(negedge pmu_clk);
        check(&a55_qreqn_pmu, "A55 must not quiesce before AXI is idle");

        a55_axi_quiescent = 1'b1;
        wait (a55_qreqn_pmu == '0);
        a55_qacceptn_pmu = '0;
        wait (!a55_clk_enable);
        check(a55_power_enable, "sleep request should retain A55 power");

        a55_sleep_req = 1'b0;
        wait (a55_qreqn_pmu == '1);
        a55_qacceptn_pmu = '1;
        wait (a55_online);
        check(a55_clk_enable, "A55 clock re-enabled on wake");

        a55_sleep_req = 1'b1;
        a55_powerdown_req = 1'b1;
        a55_powerdown_safe = 1'b0;
        repeat (3) @(negedge pmu_clk);
        check(&a55_qreqn_pmu, "A55 powerdown waits for system-safe indication");
        a55_powerdown_safe = 1'b1;
        wait (a55_qreqn_pmu == '0);
        a55_qacceptn_pmu = '0;
        wait (!a55_power_enable);
        check(a55_isolation_enable && a55_reset_hold,
              "A55 isolated and held in reset before power-off");

        a55_sleep_req = 1'b0;
        a55_powerdown_req = 1'b0;
        wait (a55_qreqn_pmu == '1);
        a55_qacceptn_pmu = '1;
        wait (a55_online);
        check(a55_power_enable && a55_clk_enable,
              "A55 power and clock restored on wake");

        ibex_sleep_req = 1'b1;
        ibex_idle = 1'b1;
        ibex_axi_quiescent = 1'b1;
        wait (!ibex_clk_enable);
        check(ibex_power_enable, "Ibex sleep should retain power");
        ibex_sleep_req = 1'b0;
        wait (ibex_online);
        check(ibex_clk_enable, "Ibex clock re-enabled on wake");

        a55_sleep_req = 1'b1;
        a55_core_idle = 2'b11;
        a55_axi_quiescent = 1'b1;
        wait (a55_qreqn_pmu == '0);
        a55_qdeny_pmu = 2'b01;
        wait (a55_qreqn_pmu == '1);
        @(negedge pmu_clk);
        check(a55_clk_enable, "QDENY must leave A55 clock running");
        check(a55_fault, "QDENY must report a sticky fault");
        a55_qdeny_pmu = '0;
        wait (a55_online);
        a55_sleep_req = 1'b0;
        @(posedge pmu_clk);
        @(negedge pmu_clk);

        a55_sleep_req = 1'b1;
        wait (a55_qreqn_pmu == '0);
        wait (a55_qreqn_pmu == '1);
        check(a55_clk_enable, "Q-channel timeout must abort clock stop");
        wait (a55_online);
        a55_sleep_req = 1'b0;

        $display("A55/Ibex PMU sequencing tests passed.");
        $finish;
    end

    initial begin
        #10000;
        $fatal(1, "Testbench timeout");
    end

endmodule
