module tb_priority_encoder_8;

    logic [7:0] request;
    logic [2:0] index;
    logic       valid;
    integer     expected_index;
    integer     value;
    integer     bit_position;

    priority_encoder_8 dut (
        .request(request),
        .index(index),
        .valid(valid)
    );

    initial begin
        for (value = 0; value < 256; value = value + 1) begin
            request = value[7:0];
            expected_index = 0;

            for (bit_position = 0; bit_position < 8; bit_position = bit_position + 1) begin
                if (request[bit_position])
                    expected_index = bit_position;
            end

            #1;
            if (valid !== (request != 8'b0) ||
                index !== expected_index[2:0]) begin
                $error("request=%b valid=%b index=%0d expected_index=%0d",
                       request, valid, index, expected_index);
                $fatal(1);
            end
        end

        $display("All 256 priority encoder tests passed.");
        $finish;
    end

endmodule
