# A55 / Ibex Power Management Unit

## 1. Purpose and scope

[`a55_ibex_pmu.sv`](./a55_ibex_pmu.sv) is a control-plane PMU reference for:

- A dual-core Cortex-A55 treated as one shared power island.
- An independently managed Ibex power/clock domain.
- An external PLL that generates the clocks, including the A55 2 GHz clock and system/AXI 200 MHz clock.
- An AXI5 subsystem connected across the A55-to-system clock boundary through an asynchronous AXI bridge.

The PMU itself runs from `pmu_clk` (intended to be the 200 MHz always-on/control clock). It does **not** generate clocks, implement a PLL, switch a supply, implement isolation cells, reset synchronizers, AXI CDC bridges, cache-coherency operations, or software-visible registers. Its outputs are control requests for those blocks.

The RTL is an integration template, not a drop-in replacement for the configured Cortex-A55 integration manual or the AMBA Low Power Interface specification. Confirm the A55 configuration's actual P/Q ports, signal polarity, legal PSTATE encodings, and handshake requirements before connecting silicon IP.

## 2. High-level structure

```text
                 200 MHz always-on/control clock
       +---------------------------------------------+
       |                 a55_ibex_pmu                |
       |                                             |
PMU --+--> A55 domain FSM + A55 P-channel handlers  +--> A55 clock-gate request
       |                                             +--> A55 power/isolation/reset requests
       |                                             +<-> A55 Q-channel CDC adapter
       |                                             +<-> A55 P-channel CDC adapter
       |                                             +--> A55 AXI quiesce request
       |                                             |
       +--> Ibex domain FSM -------------------------+--> Ibex clock/power/isolation/reset
       |                                             +--> Ibex AXI quiesce request
       +---------------------------------------------+

PLL: 2 GHz A55 clock and 200 MHz system/AXI clock (generated externally)
A55 AXI master @ 2 GHz --> asynchronous AXI bridge --> AXI5 subsystem @ 200 MHz
Ibex AXI master -------------------------------> AXI5 subsystem (actual clock per design)
```

`pmu_power_domain` is the reusable single-domain state machine. `a55_ibex_pmu` instantiates it once for the A55 (with Q-channel support) and once for Ibex (without a Q-channel). The A55 P-channel request handlers are separate from the domain state machine.

## 3. State sequencing

Each domain has its own state and does not wait for the other domain to sleep or wake.

```text
POWERUP -> WAIT_RESET_RELEASE -> [WAIT_Q_ACTIVE for A55] -> RUN
RUN -> WAIT_QUIET -> [WAIT_Q_STOP for A55] -> CLOCK_STOPPED
                                      \-> ASSERT_ISOLATION -> POWERED_OFF

CLOCK_STOPPED -> [WAKE_Q for A55] -> RUN
POWERED_OFF -> WAKE_POWER -> WAKE_RESET -> [WAKE_Q for A55] -> RUN
```

- **Power-up:** Request power on, hold reset and isolation, and keep the domain clock disabled until `power_good`. Then request the clock on and release `reset_hold`; wait for the external reset synchronizer to report `reset_released`. The A55 also waits for its Q-channel to be active before reporting `online`.
- **Sleep / clock stop:** `sleep_req` or `powerdown_req` causes `quiesce_req` to assert. The FSM waits for local `idle` and `axi_quiescent`. The A55 then requests Q-channel stop and waits until all configured channels accept (`QACCEPTn` low) and report inactive (`QACTIVE` low). Only then does it deassert `clk_enable`.
- **Power down:** In addition to the sleep checks, `powerdown_safe` must be true. Once the clock is stopped, the FSM asserts reset hold and isolation; in the next state it requests power off. The external power controller reports completion through `power_good` going low (this module does not wait for `power_good` to fall before entering `POWERED_OFF`).
- **Wake:** A stopped-clock domain enables its clock and, for the A55, deasserts Q-channel stop and waits for Q acceptance before returning to `RUN`. A powered-off domain requests power on, waits for `power_good`, enables the clock, releases reset hold, waits for reset release, removes isolation, and wakes the A55 Q-channel.
- **Deny / timeout:** A Q-channel deny aborts the stop request and sets the domain fault. A Q-channel timeout also aborts the stop request and marks the request rejected until the sleep/powerdown request is withdrawn. Power-good, reset-release, and P/Q handshake waits are bounded by `TIMEOUT_CYCLES`. Fault outputs are sticky until `por_n` resets the module.
- **P-channel:** For each configured P-channel, `a55_pvalid` plus a captured `a55_pstate_req` starts a request while the A55 is online. The PMU holds PSTATE stable, asserts PREQ, and waits for PACCEPT or PDENY. It pulses `a55_pdone` on acceptance, pulses `a55_pdenied` on denial or timeout, and holds the PSTATE output until a later request. `a55_pactive_status` is only a pass-through of the synchronized PACTIVE input; it does not gate sleep or power transitions.

## 4. Signal ownership and recommended connections

All input signals to `a55_ibex_pmu` other than `pmu_clk` and `por_n` are expected to be synchronous to `pmu_clk`. The module contains **no CDC synchronizers**. Signals with `_pmu` in their names are already expected to have crossed into the PMU clock domain through integration logic.

### Common signals

| Signal | Direction | Source / destination |
|---|---|---|
| `pmu_clk` | Input | Always-on PMU clock source. Use the 200 MHz system/control clock if it remains available during CPU-domain clock stop. |
| `por_n` | Input | Always-on power-on reset controller. Active-low asynchronous reset for PMU state. |

### A55 request, status, and P-channel ports

| Signal | Direction | Source / destination |
|---|---|---|
| `a55_sleep_req` | Input | Always-on PMU policy, firmware-controlled register block, or A55 sleep coordinator. Assert for a reversible clock-stop request. Must be PMU-clock synchronous. |
| `a55_powerdown_req` | Input | PMU policy/power controller. Assert only when the A55 island is intended to lose power. Normally accompanies a sleep request. |
| `a55_core_idle[1:0]` | Input | One idle indication per A55 core from the A55 integration/wrapper or a validated cluster-idle coordinator. Synchronize/qualify each indication. Both bits must be high before this RTL considers the A55 island idle. Do not infer idle solely from QACTIVE or PACTIVE. |
| `a55_axi_quiescent` | Input | AXI5 bridge/interconnect quiescence tracker. Assert only when the A55 master has no outstanding reads/writes, buffered transactions, or responses in flight, including transactions through the async bridge. |
| `a55_powerdown_safe` | Input | System-level shutdown/coherency coordinator. Assert only after cache/cluster maintenance, snoop/coherency shutdown, interrupt routing, debug policy, and any shared-resource prerequisites are satisfied. This RTL cannot determine these conditions. |
| `a55_power_good` | Input | Power controller / power-good synchronizer for the shared A55 rail. High means the rail is valid and stable enough for the specified startup sequence. |
| `a55_reset_released` | Input | A55 local reset controller's synchronized status. It should indicate that reset is safely deasserted in the A55 clock/reset domain, accounting for `a55_reset_hold` and clock stability. |
| `a55_qacceptn_pmu` | Input | A55 Q-channel `QACCEPTn` response(s), returned through a proper CDC adapter to `pmu_clk`. Each bit corresponds to one configured Q-channel. |
| `a55_qdeny_pmu` | Input | A55 Q-channel `QDENY` response(s), CDC-adapted to `pmu_clk`. Each bit corresponds to a Q-channel. |
| `a55_qactive_pmu` | Input | A55 Q-channel `QACTIVE` response(s), CDC-adapted to `pmu_clk`. Each bit corresponds to a Q-channel. |
| `a55_qreqn_pmu` | Output | Route each bit through a PMU-to-A55 CDC adapter to the corresponding A55 `QREQn` port. It is active-low: all ones request active operation; all zeros request stop. |
| `a55_pvalid` | Input | Request-valid from the always-on P-channel request source (for example, a PMU register/controller). This is **not** an A55 pin. Hold each bit until `a55_pready` acknowledges it. |
| `a55_pready` | Output | Return to the P-channel request source. A bit is high when that P-channel handler can accept a request and the A55 PMU state is online. |
| `a55_pstate_req` | Input | Requested PSTATE bundle from the PMU policy/register block. Bit slice `i*PSTATE_WIDTH +: PSTATE_WIDTH` belongs to P-channel `i`. Use only encodings supported by the configured A55/connected device. |
| `a55_preq_pmu` | Output | Route through a PMU-to-A55 CDC adapter to the corresponding A55 `PREQ` pin. Hold the synchronized PSTATE stable while the request is outstanding. |
| `a55_pstate_pmu` | Output | Route with the associated PREQ to the corresponding A55 P-channel PSTATE input. Use a bundled-data CDC scheme: stabilize PSTATE before asserting synchronized PREQ and hold it until the response completes. |
| `a55_paccept_pmu` | Input | A55 P-channel `PACCEPT` response(s), synchronized/CDC-adapted into `pmu_clk`. |
| `a55_pdeny_pmu` | Input | A55 P-channel `PDENY` response(s), synchronized/CDC-adapted into `pmu_clk`. |
| `a55_pactive_pmu` | Input | A55 P-channel `PACTIVE` response(s), synchronized/CDC-adapted into `pmu_clk`. |
| `a55_pdone` | Output | One-cycle completion pulse to the PMU PSTATE request source after PACCEPT. |
| `a55_pdenied` | Output | One-cycle failure pulse to the PMU PSTATE request source after PDENY or timeout. |
| `a55_pactive_status` | Output | PMU-clock-domain copy of `a55_pactive_pmu`; route to status/diagnostic logic. It is informational in this RTL. |

### A55 controls and status

| Signal | Direction | Source / destination |
|---|---|---|
| `a55_axi_quiesce_req` | Output | Route to the A55 AXI bridge/interconnect quiesce controller. It requests admission stop and transaction drain. Return the resulting status via `a55_axi_quiescent`. |
| `a55_clk_enable` | Output | Route to an integrated clock-gating cell's enable/control for the A55 clock branch. The clock-gating cell must safely gate the external PLL clock. Do **not** AND this signal directly with a clock. |
| `a55_power_enable` | Output | Route to the external A55 power controller as a power-on request/enable. The external controller controls switches/sequencing and returns `a55_power_good`. Confirm polarity/semantics with the power controller. |
| `a55_isolation_enable` | Output | Route to isolation-cell control at A55 island boundaries. High means isolation asserted in this reference RTL. Validate polarity and clamp values for the actual isolation library. |
| `a55_reset_hold` | Output | Route to the A55 reset controller as a request to hold/assert reset. The reset controller generates per-domain asynchronous assertion/synchronous deassertion and returns `a55_reset_released`. Confirm polarity at the reset-controller interface. |
| `a55_online` | Output | Route to PMU policy/software-visible status and request gating. High only in the A55 `RUN` state. |
| `a55_fault` | Output | Route to always-on interrupt, error/status register, or PMU fault logger. It is sticky until POR; includes domain timeout/deny fault and P-channel timeout fault. |

### Ibex signals

| Signal | Direction | Source / destination |
|---|---|---|
| `ibex_sleep_req` | Input | Always-on PMU policy or Ibex sleep coordinator. Must be synchronous to `pmu_clk`. |
| `ibex_powerdown_req` | Input | Always-on PMU/power controller. Request Ibex rail power-down. |
| `ibex_idle` | Input | Ibex wrapper's qualified idle indication, synchronized to PMU clock. |
| `ibex_axi_quiescent` | Input | AXI5 bridge/interconnect quiescence tracker for Ibex's outstanding requests/responses. |
| `ibex_powerdown_safe` | Input | System-level indication that Ibex state is saved and shared services/coherency/interrupt requirements permit power removal. |
| `ibex_power_good` | Input | Ibex rail power controller's synchronized status. |
| `ibex_reset_released` | Input | Ibex local reset controller's synchronized status. |
| `ibex_axi_quiesce_req` | Output | Route to the Ibex AXI adapter/interconnect's quiesce/drain controller; return completion through `ibex_axi_quiescent`. |
| `ibex_clk_enable` | Output | Route to the Ibex clock branch's integrated clock-gating cell. Not a clock output. |
| `ibex_power_enable` | Output | Route to the external Ibex power controller; confirm active polarity. |
| `ibex_isolation_enable` | Output | Route to Ibex island boundary isolation controls. High means isolation asserted in this RTL. |
| `ibex_reset_hold` | Output | Route as a reset-hold request to the Ibex reset controller. The reset controller returns `ibex_reset_released`. |
| `ibex_online` | Output | Route to PMU/software status. High only while Ibex is in its `RUN` state. |
| `ibex_fault` | Output | Route to always-on error/status logic. Sticky until POR. |

Ibex has no Q-channel in this module; the internal Q-channel inputs to its generic domain FSM are tied to constants. Do not connect those constants to physical Ibex pins.

## 5. Clock and CDC integration

Recommended clock topology:

1. The external PLL generates the 2 GHz A55 clock and 200 MHz system/AXI clock. The PMU uses an always-available management/control clock.
2. An integrated clock-gating cell gates the A55 clock branch using `a55_clk_enable`. Keep the PLL running if required by other consumers. Use the clock-gating cell's supported enable timing and test/scan controls.
3. The A55 AXI master crosses into a 200 MHz AXI5 subsystem through a protocol-correct asynchronous AXI bridge. The bridge must preserve ordering/IDs and safely handle all five AXI channels.
4. `a55_axi_quiesce_req` requests that the bridge stop accepting new work from A55 and drain all in-flight transactions. `a55_axi_quiescent` must be derived from bridge state, not just CPU idle.
5. Transfer each Q/P handshake across the clock boundary with protocol-aware CDC logic. Simple two-flop synchronizers are suitable only for single-bit level signals where the protocol allows them. Use bundled-data capture/handshake for PSTATE and preserve the required response pulse/level behavior. Keep PMU response pins alive from an always-on clock when the A55 clock is stopped.
6. Synchronize `power_good`, idle, quiescence, reset status, and safety status into `pmu_clk`. Synchronize reset deassertion separately in each destination clock domain.

## 6. Parameters and integration assumptions

| Parameter | Meaning |
|---|---|
| `A55_Q_CHANNELS` | Number of Q-channel bundles exposed and managed. Set to the actual A55 integration count. |
| `A55_P_CHANNELS` | Number of P-channel bundles exposed and managed. Set to the actual A55 integration count. |
| `PSTATE_WIDTH` | Width of each PSTATE encoding, per the configured A55/device interface. |
| `TIMEOUT_CYCLES` | Wait timeout in `pmu_clk` cycles. At 200 MHz, the default 100,000 cycles is 500 us. This is a control timeout, not a PLL/rail settling specification. |

Additional assumptions:

- Both A55 cores share one power and clock island. The domain enters idle only when both `a55_core_idle` bits are high. The module does not independently power-gate the two cores.
- `a55_qacceptn_pmu`, `a55_qdeny_pmu`, and `a55_qactive_pmu` are PMU-clock-domain vectors, one bit per channel. The RTL currently waits for all channels to be active for wake and all channels to accept/inactive for stop. Validate this aggregation rule against the exact configured interface.
- P/Q pin directions, legal values, reset values, state encoding, and timing must be confirmed in the licensed Cortex-A55 integration documentation and applicable Arm interface specifications.
- AXI quiescence and `powerdown_safe` are trusted inputs. The PMU cannot prove transaction drain, cache clean/invalidate, snoop shutdown, debug behavior, or safe removal of shared resources by itself.
- `a55_pactive_status` is currently observational only. P-channel activity does not gate sleep or power-down unless additional policy logic is added.
- `power_good` is sampled in `pmu_clk`; its synchronizer and qualification are external.

## 7. Integration and verification checklist

- [ ] Confirm A55 P/Q channel count, direction, active polarity, PSTATE width/encodings, and reset values from the configured A55 documentation.
- [ ] Add and verify all required CDC adapters; do not connect raw 2 GHz-domain responses directly to this PMU.
- [ ] Ensure the PMU clock and POR remain available throughout CPU-domain shutdown.
- [ ] Connect the clock-enable requests to glitch-free integrated clock gates, not combinational clock logic.
- [ ] Connect power, isolation, and reset requests to their dedicated controllers/cells; verify polarities and safe sequencing.
- [ ] Make AXI quiescence include every outstanding address, data, response, bridge FIFO, and relevant shared fabric transaction.
- [ ] Define system-level `powerdown_safe`, including A55 cache/coherency and shared-resource requirements.
- [ ] Verify wakeup sources can reach the always-on PMU while the CPU clocks/rails are stopped.
- [ ] Run CDC/RDC analysis, formal/state-transition checks, and power-aware simulation with the target libraries and actual A55 integration model.
- [ ] Check timeout values against worst-case PLL lock, supply ramp, reset release, and interface response times.

## 8. Reference verification

[`a55_ibex_pmu_tb.sv`](./a55_ibex_pmu_tb.sv) exercises power-up, P-channel acceptance, AXI-drain blocking, A55 Q-channel sleep/wake, power-down/wake, Ibex clock sleep/wake, Q-channel denial, and timeout recovery. It is a functional unit test and does not model real CDC cells, PLL behavior, AXI transactions, power switches, or Cortex-A55 protocol timing.
