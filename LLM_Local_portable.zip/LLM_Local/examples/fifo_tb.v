module tb_fifo_8bit;

    // Parameters
    parameter CLK_PERIOD = 10;  // 100MHz clock period in ns
    parameter DEPTH = 8;      // FIFO depth

    // Signals
    reg clk;
    reg rst_n;
    reg wr_en;
    reg rd_en;
    reg [7:0] data_in;
    wire [7:0] data_out;
    wire full;
    wire empty;

    // Instantiate the FIFO module
    fifo_8bit #(.DEPTH(DEPTH)) uut (
        .clk(clk),
        .rst_n(rst_n),
        .wr_en(wr_en),
        .rd_en(rd_en),
        .data_in(data_in),
        .data_out(data_out),
        .full(full),
        .empty(empty)
    );

    // Clock generation
    initial begin
        clk = 0;
        forever #(CLK_PERIOD / 2) clk = ~clk;
    end

    // Testbench logic
    initial begin
        // Initialize signals
        rst_n = 0;
        wr_en = 0;
        rd_en = 0;
        data_in = 0;

        // Dump waveform
        $dumpfile("dump.vcd");
        $dumpvars(0, tb_fifo_8bit);

        // Reset sequence
        rst_n = 0;
        #10;
        rst_n = 1;

        // Test cases
        // Case 1: Write and read one element
        wr_en = 1;
        data_in = 8'h55;
        #10;
        wr_en = 0;
        rd_en = 1;
        #10;
        rd_en = 0;
        if (data_out !== 8'h55) begin
            $display("Test Case 1 Failed");
            $finish;
        end else begin
            $display("Test Case 1 Passed");
        end

        // Case 2: Write to full and read from empty
        wr_en = 1;
        for (int i = 0; i < DEPTH; i = i + 1) begin
            data_in = i;
            #10;
        end
        wr_en = 0;
        rd_en = 1;
        #10;
        rd_en = 0;
        if (full) begin
            $display("Test Case 2 Passed");
        end else begin
            $display("Test Case 2 Failed");
            $finish;
        end

        // Case 3: Write and read multiple elements
        wr_en = 1;
        for (int i = 0; i < DEPTH; i = i + 1) begin
            data_in = i;
            #10;
        end
        wr_en = 0;
        rd_en = 1;
        for (int i = 0; i < DEPTH; i = i + 1) begin
            #10;
            if (data_out !== i) begin
                $display("Test Case 3 Failed");
                $finish;
            end else begin
                $display("Test Case 3 Passed");
            end
        end
        rd_en = 0;

        // Case 4: Boundary conditions
        wr_en = 1;
        data_in = 8'hFF;
        #10;
        wr_en = 0;
        rd_en = 1;
        #10;
        rd_en = 0;
        if (data_out !== 8'hFF) begin
            $display("Test Case 4 Failed");
            $finish;
        end else begin
            $display("Test Case 4 Passed");
        end

        // Finish simulation
        $finish;
    end

endmodule
