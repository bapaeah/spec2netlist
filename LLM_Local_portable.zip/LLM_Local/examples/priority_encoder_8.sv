module priority_encoder_8 (
    input  logic [7:0] request,
    output logic [2:0] index,
    output logic       valid
);

    integer i;

    always_comb begin
        index = 3'd0;
        valid = 1'b0;

        for (i = 0; i < 8; i = i + 1) begin
            if (request[i]) begin
                index = i[2:0];
                valid = 1'b1;
            end
        end
    end

endmodule
