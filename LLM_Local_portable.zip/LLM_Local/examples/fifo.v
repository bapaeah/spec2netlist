module fifo_8bit #(
    parameter DEPTH = 8  // Depth of the FIFO
) (
    input wire clk,        // Clock signal
    input wire rst_n,      // Active-low asynchronous reset
    input wire wr_en,      // Write enable
    input wire rd_en,      // Read enable
    input wire [7:0] data_in, // Data input
    output reg [7:0] data_out, // Data output
    output reg full,       // Full flag
    output reg empty       // Empty flag
);

    // Internal signals
    reg [7:0] mem [0:DEPTH-1]; // FIFO memory
    reg [DEPTH-1:0] wr_ptr;    // Write pointer
    reg [DEPTH-1:0] rd_ptr;    // Read pointer
    reg [DEPTH-1:0] count;     // Count of valid entries

    // Sequential logic for write pointer
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            wr_ptr <= 0;
        end else if (wr_en && !full) begin
            wr_ptr <= wr_ptr + 1;
        end
    end

    // Sequential logic for read pointer
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rd_ptr <= 0;
        end else if (rd_en && !empty) begin
            rd_ptr <= rd_ptr + 1;
        end
    end

    // Sequential logic for count
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            count <= 0;
        end else if (wr_en && !full) begin
            count <= count + 1;
        end else if (rd_en && !empty) begin
            count <= count - 1;
        end
    end

    // Combinational logic for full flag
    assign full = (count == DEPTH);

    // Combinational logic for empty flag
    assign empty = (count == 0);

    // Combinational logic for data output
    assign data_out = mem[rd_ptr];

    // Combinational logic for memory write
    always_comb begin
        mem[wr_ptr] = data_in;
    end

endmodule
