#!/usr/bin/env bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$DIR"

echo "============================================================"
echo "    Local RTL LLM Setup: 100% Offline & Token-Free"
echo "============================================================"

# 0. Where does Ollama run?  OLLAMA_HOST=http://<ip>:11434 ./<this script>  (or --ollama-host=<url>)
#    If it is another machine, nothing is installed or pulled here; models are chosen from what
#    that machine has, based on its GPU/RAM (see: rtl --models).
for a in "$@"; do case "$a" in --ollama-host=*) export OLLAMA_HOST="${a#*=}";; esac; done
if [ -n "${OLLAMA_HOST:-}" ]; then
    python3 "$DIR/ollama_models.py" --set-host "$OLLAMA_HOST" > /dev/null
fi
OLLAMA_URL="$(python3 -c "import sys;sys.path.insert(0,'$DIR');import ollama_models as m;print(m.ollama_host())")"
if python3 -c "import sys;sys.path.insert(0,'$DIR');import ollama_models as m;sys.exit(0 if m.is_local(m.ollama_host()) else 1)"; then
    REMOTE_OLLAMA=0
else
    REMOTE_OLLAMA=1
    echo "[0] Using remote Ollama at $OLLAMA_URL - skipping local Ollama install and model downloads."
fi

# 1. System Memory Check
TOTAL_MEM_BYTES=$(sysctl -n hw.memsize 2>/dev/null || echo 0)
TOTAL_MEM_GB=$((TOTAL_MEM_BYTES / 1024 / 1024 / 1024))
echo "[1] System check: Apple Silicon detected with ${TOTAL_MEM_GB} GB RAM."

RECOMMENDED_MODEL="qwen2.5-coder:7b"
FAST_MODEL="qwen2.5-coder:3b"

if [ "$TOTAL_MEM_GB" -le 8 ]; then
    echo "    Notice: On 8 GB RAM, ${RECOMMENDED_MODEL} (quantized ~4.7 GB) provides the best accuracy."
    echo "    Alternatively, ${FAST_MODEL} (~2.0 GB) runs blazingly fast with minimal RAM usage."
fi

if [ "$REMOTE_OLLAMA" = "1" ]; then
    echo ""
    echo "[2-6] Ollama runs on $OLLAMA_URL - skipping local install, server start and model downloads."
    echo "    Remote Ollama: selecting from the models installed on $OLLAMA_URL (GPU/RAM based)..."
    python3 "$DIR/ollama_models.py" || echo "    [!] Cannot reach $OLLAMA_URL - on that machine run: OLLAMA_HOST=0.0.0.0 ollama serve"
else
# 2. Check / Install Ollama
echo ""
echo "[2] Checking Ollama..."
if ! command -v ollama &> /dev/null; then
    echo "    Ollama is not installed yet."
    echo "    Installing via Homebrew..."
    if command -v brew &> /dev/null; then
        brew install ollama
    else
        echo "    Homebrew not found! Please download and install Ollama from https://ollama.com/download"
        exit 1
    fi
else
    echo "    ✓ Ollama is already installed at: $(which ollama)"
fi

# 3. Check if Ollama daemon is running
echo ""
echo "[3] Checking Ollama server daemon..."
if ! curl -s http://localhost:11434/api/tags > /dev/null; then
    echo "    Starting Ollama service in background..."
    # Start ollama serve in background if not running
    nohup ollama serve > /dev/null 2>&1 &
    sleep 3
    if ! curl -s http://localhost:11434/api/tags > /dev/null; then
        echo "    Waiting for Ollama to initialize..."
        sleep 3
    fi
fi

if curl -s http://localhost:11434/api/tags > /dev/null; then
    echo "    ✓ Ollama server is actively responding on http://localhost:11434"
else
    echo "    [Warning] Could not reach Ollama server. Please run 'ollama serve' in another terminal."
fi

# 4. Pull base model
echo ""
echo "[4] Downloading base model '${RECOMMENDED_MODEL}'..."
ollama pull "$RECOMMENDED_MODEL"

# 5. Build specialized RTL model
echo ""
echo "[5] Building custom 'rtl-coder' model from Modelfile.rtl..."
ollama create rtl-coder -f Modelfile.rtl

# 6. Optional: Also build fast 3B model
echo ""
echo "[6] Building lightweight 'rtl-coder-fast' (3B)..."
ollama pull "$FAST_MODEL"
ollama create rtl-coder-fast -f Modelfile.rtl-fast

python3 "$DIR/ollama_models.py" || true
fi

# 6b. EDA tools + synthesis environment (previously missing on macOS: no iverilog/verilator/yosys)
echo ""
echo "[6b] EDA tools (Icarus Verilog, Verilator, Yosys) + OpenSTA + Liberty libraries..."
if [ "${SKIP_SYNTH_SETUP:-0}" = "1" ]; then
    echo "    Skipped (SKIP_SYNTH_SETUP=1). Run ./setup_synthesis.sh later."
else
    bash "$DIR/setup_synthesis.sh" || echo "    [!] Synthesis setup incomplete - re-run ./setup_synthesis.sh"
fi

# 7. Install Python Spec Ingestion Packages (PDF, Word, Excel)
echo ""
echo "[7] Installing document parsing packages (PDF, Word, Excel)..."
python3 -m pip install --quiet --break-system-packages pdfplumber python-docx openpyxl 2>/dev/null || \
python3 -m pip install --quiet pdfplumber python-docx openpyxl 2>/dev/null || true

# 8. Check Spec2rtl_upf integration
SPEC2RTL_DIR="$DIR/spec2rtl_upf"
if [ ! -d "$SPEC2RTL_DIR" ]; then
    SPEC2RTL_DIR="$(cd "$DIR/../Spec2rtl_upf" 2>/dev/null && pwd || echo "$HOME/Spec2rtl_upf")"
fi
if [ -d "$SPEC2RTL_DIR" ]; then
    echo "    Found Spec2rtl_upf at: $SPEC2RTL_DIR"
    chmod +x "$SPEC2RTL_DIR/run_local.sh" 2>/dev/null || true
fi

# 9. Configure Continue extension
mkdir -p "$HOME/.continue"
if [ "$REMOTE_OLLAMA" = "1" ]; then
    python3 "$DIR/ollama_models.py" --write-continue "$HOME/.continue/config.json" || true
elif [ -f "continue_config.json" ]; then
    cp -f continue_config.json "$HOME/.continue/config.json"
fi

# 10. Check Memory Compiler
if [ -f "$DIR/memory/memgen.py" ]; then
    echo ""
    echo "[10] Memory Compiler detected. Running test suite..."
    python3 -m unittest discover "$DIR/memory/tests" > /dev/null 2>&1 && echo "     ✓ Memory compiler unit tests passed."
fi

# 11. Install CLI package
echo ""
echo "[11] Registering system-wide CLI tools (rtl-assistant, llm-local, memgen, spec2rtl)..."
python3 -m pip install -e . --no-build-isolation > /dev/null 2>&1 || python3 -m pip install -e . --user > /dev/null 2>&1 || true

# 12. Verification Test
echo ""
echo "[12] Running quick environment health check..."
python3 rtl_assistant.py check

echo ""
echo "============================================================"
echo "    Local RTL & Memory LLM is Ready to Use!"
echo "============================================================"
echo "Quick Commands:"
echo "  • System-Wide CLI:            rtl-assistant --help"
echo "  • Interactive Chat:           rtl-assistant chat  (or: python3 rtl_assistant.py chat)"
echo "  • AI Memory Compiler:         rtl-assistant memory --spec '16KB SDP RAM with Wishbone bus'"
echo "                                (or standalone: memgen --list-presets)"
echo "  • Generate RTL from Spec:     rtl-assistant generate --spec 'Dual-port RAM' -o ram.v"
echo "  • Testbench & Simulation:     rtl-assistant testbench ram.v -o ram_tb.v"
echo "                                rtl-assistant verify ram.v ram_tb.v"
echo "  • Full Spec2RTL + UPF Flow:   rtl-assistant soc --spec my_spec.md --all"
echo "                                (or standalone: spec2rtl --spec my_spec.md --all)"
echo ""
