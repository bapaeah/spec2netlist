# ==============================================================================
#  rtl: 1 Common Unified Command for RTL, VLSI, Memory & SoC Engineering
# ==============================================================================
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
python "$ScriptDir\rtl_assistant.py" @args
