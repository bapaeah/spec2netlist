# ==============================================================================
#  LLM_Local Package Installer (Windows PowerShell)
# ==============================================================================
$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "    Installing LLM_Local System-Wide CLI & Package       " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Error "Python 3 is required but not found in PATH."
    exit 1
}

$PyVer = python --version
Write-Host "$PyVer detected." -ForegroundColor Green

Write-Host "Installing llm-local package via pip (editable mode)..." -ForegroundColor Yellow
python -m pip install -e .

# Link Continue extension configuration
if (Test-Path "continue_config.json") {
    $ContinueDir = Join-Path $env:USERPROFILE ".continue"
    New-Item -ItemType Directory -Force -Path $ContinueDir 2>$null | Out-Null
    Copy-Item .\continue_config.json (Join-Path $ContinueDir "config.json") -Force
    Write-Host "✓ VS Code / Cursor Continue configuration linked." -ForegroundColor Green
}

Write-Host "`n==========================================================" -ForegroundColor Cyan
Write-Host "    Installed CLI Commands & Entry Points                " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  * rtl             : 1 Common Unified Command for all VLSI / RTL tasks!"
Write-Host "  * rtl-assistant   : Primary assistant alias"
Write-Host "  * llm-local       : Environment check and assistant alias"
Write-Host "  * memgen          : Standalone technology-agnostic memory compiler"
Write-Host "  * spec2rtl        : Full SoC CAD, CDC, UPF 2.1 & Gate Netlist pipeline"
Write-Host "`nTry running 1 command with simple switches:"
Write-Host "  rtl --check"
Write-Host "  rtl --chat"
Write-Host "  rtl --rtl --spec '4-bit priority encoder' -o encoder.v"
Write-Host "  rtl --tb encoder.v -o encoder_tb.v"
Write-Host "  rtl --verify encoder.v encoder_tb.v"
Write-Host "  rtl --mem --spec '16KB SDP RAM with Wishbone bus'"
Write-Host "  rtl --soc --spec benchmarks\H264D-U1000_cfg_regs_spec.md --all"
Write-Host "==========================================================" -ForegroundColor Cyan
