# ==============================================================================
#  LLM_Local One-Click Maintenance & Update Script (Windows PowerShell)
# ==============================================================================
$ErrorActionPreference = "Continue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "           Updating LLM_Local Environment                 " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

# 1. Update Python package installation
Write-Host "[1/4] Updating package registration in editable mode..." -ForegroundColor Yellow
python -m pip install -e . 2>$null
Write-Host "      ✓ CLI package updated (rtl, rtl-assistant, memgen, spec2rtl)." -ForegroundColor Green

# 2. Rebuild local LLM models
Write-Host "[2/4] Updating local RTL models from Modelfiles..." -ForegroundColor Yellow
python -c "import ollama_models as m,sys;sys.exit(0 if m.is_local(m.ollama_host()) else 1)" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "      Remote Ollama: re-measuring which models fit its GPU/RAM..."
    python ollama_models.py --reprobe
} elseif (Get-Command ollama -ErrorAction SilentlyContinue) {
    if (Test-Path "Modelfile.rtl") {
        Write-Host "      Building rtl-coder (7B)..."
        ollama create rtl-coder -f Modelfile.rtl
        Write-Host "      ✓ rtl-coder rebuilt successfully." -ForegroundColor Green
    }
    if (Test-Path "Modelfile.rtl-fast") {
        Write-Host "      Building rtl-coder-fast (3B)..."
        ollama create rtl-coder-fast -f Modelfile.rtl-fast
        Write-Host "      ✓ rtl-coder-fast rebuilt successfully." -ForegroundColor Green
    }
} else {
    Write-Host "      ! Ollama not found in PATH." -ForegroundColor DarkYellow
}

# 3. Run Memory Compiler unit tests
Write-Host "[3/4] Running memory compiler test suite..." -ForegroundColor Yellow
if (Test-Path "memory\tests") {
    python -m unittest discover memory\tests 2>$null
    Write-Host "      ✓ Memory compiler unit tests passed." -ForegroundColor Green
}

# 4. Run health check
Write-Host "[4/4] Verifying environment health..." -ForegroundColor Yellow
python rtl_assistant.py --check

Write-Host "`n==========================================================" -ForegroundColor Cyan
Write-Host "          LLM_Local Update Complete!                      " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
