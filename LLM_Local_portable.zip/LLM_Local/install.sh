#!/usr/bin/env bash
# ==============================================================================
#  LLM_Local Package Installer (macOS & Linux)
# ==============================================================================
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================================="
echo "    Installing LLM_Local System-Wide CLI & Package       "
echo "=========================================================="

if ! command -v python3 &>/dev/null; then
    echo "[Error] Python 3 is required but not found in PATH."
    exit 1
fi

echo "Python $(python3 --version) detected."

echo "Installing llm-local package via pip (editable developer mode)..."
if python3 -m pip install -e . --no-build-isolation 2>/dev/null; then
    echo "✓ Package installed successfully!"
elif python3 -m pip install -e . --user 2>/dev/null; then
    echo "✓ Package installed in user directory!"
else
    python3 -m pip install -e .
fi

# Configure Continue extension settings
if [ -f "continue_config.json" ]; then
    mkdir -p "$HOME/.continue" 2>/dev/null || true
    cp -f continue_config.json "$HOME/.continue/config.json" 2>/dev/null || true
    echo "✓ VS Code / Cursor Continue configuration linked (~/.continue/config.json)."
fi

echo ""
echo "=========================================================="
echo "    Installed CLI Commands & Entry Points                "
echo "=========================================================="
echo "  • rtl             : 1 Common Unified Command for all VLSI / RTL tasks!"
echo "  • rtl-assistant   : Primary assistant alias"
echo "  • llm-local       : Environment check and assistant alias"
echo "  • memgen          : Standalone technology-agnostic memory compiler"
echo "  • spec2rtl        : Full SoC CAD, CDC, UPF 2.1 & Gate Netlist pipeline"
echo "  • md-convert      : Universal Markdown Converter (PDF, TXT, HTML, DOCX, RTF, LaTeX)"
echo ""
echo "Try running 1 command with simple switches:"
echo "  rtl --check"
echo "  rtl --chat"
echo "  rtl --rtl --spec '4-bit priority encoder' -o encoder.v"
echo "  rtl --tb encoder.v -o encoder_tb.v"
echo "  rtl --verify encoder.v encoder_tb.v"
echo "  rtl --synth encoder.v --lib nangate45 -o encoder_gate.v"
echo "  rtl --convert spec.md -o spec.pdf"
echo "  rtl --mem --spec '16KB SDP RAM with Wishbone bus'"
echo "  rtl --soc --spec benchmarks/H264D-U1000_cfg_regs_spec.md --all"
echo "=========================================================="
