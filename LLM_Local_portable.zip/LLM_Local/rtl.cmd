@echo off
rem ==============================================================================
rem  rtl: 1 Common Unified Command for RTL, VLSI, Memory & SoC Engineering
rem ==============================================================================
python "%~dp0rtl_assistant.py" %*
