# LLM_Local – RTL generation & verification: how to run

Everything runs from the `LLM_Local` folder. `rtl` is the front-end. If it isn't installed as a command yet, use `./rtl` (macOS/Linux), `rtl.cmd` (Windows) or `python3 rtl_assistant.py`.

**Contents**

1. One-time setup
2. Flow A – generate **only RTL**
3. Flow B – the **full flow** (RTL → checks → UPF/SDC → synthesis → netlist → timing)
4. **Standalone steps** – run just lint, just CDC, just simulation, just synthesis, …
5. Batch runs (all IPs)
6. Reading the results
7. Troubleshooting

---

## 1. One-time setup

### 1.1 The machine that runs Ollama (if it isn't your laptop)

```bash
# models used by the tools (any subset works; the best one that fits is picked automatically)
ollama pull qwen2.5-coder:7b
ollama pull qwen2.5-coder:32b
ollama pull deepseek-coder-v2:16b

# accept connections from the network (open TCP 11434 in that machine's firewall)
OLLAMA_HOST=0.0.0.0 ollama serve
```

### 1.2 Your laptop

| OS | Command |
|---|---|
| macOS | `OLLAMA_HOST=http://<ollama-ip>:11434 ./setup_local_llm.sh` |
| Linux | `OLLAMA_HOST=http://<ollama-ip>:11434 ./setup_linux.sh` |
| Windows | `$env:OLLAMA_HOST="http://<ollama-ip>:11434"; .\setup_windows.ps1` |

Leave out `OLLAMA_HOST=…` if Ollama runs on the laptop itself. The setup scripts also run `./setup_synthesis.sh` (`.ps1` on Windows), which installs:

- Yosys, Icarus Verilog and Verilator.
- OpenSTA, the timing analyser. It is built once, which takes about 5 minutes.
- The NanGate45 and sky130 cell libraries, with timing data.

Use `SKIP_SYNTH_SETUP=1` to skip that part, and run `./setup_synthesis.sh` later.

### 1.3 Check

```bash
rtl --models --set-host http://<ollama-ip>:11434   # only needed once if not set during setup
rtl --check            # Ollama reachable, which model per task, EDA tools, libraries
rtl --models           # why each model was chosen (GPU/RAM of the Ollama machine)
python3 techlib/synth_flow.py --selftest           # synthesis -> gate-level sim -> STA smoke test
```

The model is chosen automatically:

- **qwen2.5-coder:32b**: when it fits in the Ollama machine's GPU memory (about 24 GB).
- **deepseek-coder-v2:16b**: when 12–16 GB is available.
- **qwen2.5-coder:7b**: otherwise.

To force a model, add `--model <name>` or set `RTL_MODEL=<name>`.

---

## 2. Flow A – generate only RTL

### A1. From a text description (LLM)

```bash
rtl --rtl --spec "8-deep 8-bit synchronous FIFO, first-word-fall-through, active-low async reset" -o fifo.sv
rtl --tb fifo.sv -o tb_fifo.sv                 # optional: self-checking testbench
```

### A2. From a specification document (LLM)

```bash
rtl --rtl --file my_spec.pdf -o my_ip.sv                      # .pdf .docx .md .txt .json .yaml
rtl --rtl --file my_spec.docx --section "Register Map" -o regs.sv
```

### A3. From an IP spec with ports and a register-map table (spec2rtl)

This writes the bus interface and register file, the core, the top level, a testbench, `files.f` and `top.txt`.

```bash
cd spec2rtl_upf
python3 spec2rtl/spec2rtl.py run market_specs/uart_16550_spec.md -o out/uart     # RTL only
python3 spec2rtl/spec2rtl.py run my_spec.md -o out/my_ip --llm                     # LLM fills the core
```

or, through the pipeline (RTL plus basic checks, no UPF/SDC/synthesis):

```bash
cd spec2rtl_upf
python3 main.py --spec market_specs/uart_16550_spec.md --rtl-only -o out
python3 main.py --spec market_specs/ --rtl-only -o out          # every spec in a folder
```

**Output** (per IP), in `out/<ip>/`:

- `rtl/<ip>.sv`, `rtl/<ip>_regs.sv`, `rtl/<ip>_core.sv`
- `tb/tb_<ip>.sv`
- `files.f`, `top.txt`, `spec.json`

Note: without `--llm`, cores that have no built-in template are placeholders. Check `rtl/<ip>_core.sv` before relying on the design.

---

## 3. Flow B – full flow

### B1. One command

```bash
cd spec2rtl_upf
python3 main.py --spec market_specs/uart_16550_spec.md \
                --config benchmarks/power_config.json \
                --filelist benchmarks/soc_filelist.f \
                --all -o out_full                # add --llm to fill the core with the LLM
```

This runs, in order:

1. RTL generation
2. CDC constraints
3. Lint, CDC and testbench simulation
4. UPF 2.1 plus the RTL–UPF alignment audit
5. SDC
6. Gate-level synthesis and netlist

Outputs go to `out_full/`: `<ip>/…`, `<top>.upf`, `partitions/*.upf`, `<top>.sdc`, `*_gate_netlist.v` and `upf_rtl_alignment_report.json`.

### B2. Step by step (recommended – stop at the first failing step)

```bash
# 1 Generate RTL                      (Flow A, any variant)
cd spec2rtl_upf && python3 spec2rtl/spec2rtl.py run market_specs/uart_16550_spec.md -o out/uart && cd ..
IP=spec2rtl_upf/out/uart

# 2 Lint                               (fails on errors and warnings)
rtl --lint $IP
# 3 CDC / RDC                          (fails on unsynchronized crossings)
rtl --cdc  $IP
# 4 Simulation                         (fails on any error, a missing PASS, or 0 checks)
python3 rtl_checks.py sim $IP
# 5 Synthesis + gate-level sim + STA   (real libraries with timing, after setup_synthesis.sh)
python3 rtl_checks.py synth $IP --lib nangate45 --period 10 --gls -o $IP/synth
# 6 Power intent (UPF) + SDC for an SoC
cd spec2rtl_upf && python3 main.py --upf-only --config benchmarks/power_config_market_soc.json \
                                   --dir generated_soc -o out_upf
```

Or run steps 2 to 5 in one go:

```bash
python3 rtl_checks.py all $IP --lib nangate45 --period 10 --gls --json $IP/checks.json
```

---

## 4. Standalone steps

All checks accept the same **inputs**, in any mix:

| Input | Example |
|---|---|
| RTL files | `a.sv b.sv c.v` |
| A folder (recursive; `tb/` and `tb_*` are skipped) | `--dir rtl/` |
| An EDA filelist (`+incdir+`, `+define+`, `-f`, `-v`) | `--filelist soc.f` |
| A spec2rtl IP folder (uses `files.f`, `top.txt`, `tb/tb_<top>.sv`) | `spec2rtl_upf/generated_soc/uart_16550` |

Common options:

- `--top <module>`: auto-detected if omitted.
- `-I <incdir>`, `-D <define>`
- `--tb <testbench>`
- `--json report.json`
- `--fail-on error|warning`: the default is `warning` for lint and `error` for CDC.

### 4.1 Lint only

```bash
rtl --lint my_ip.sv                                        # one file
rtl --lint --dir rtl/ --top my_top                         # a folder
rtl --lint --filelist soc.f --waivers lint.waive           # filelist + waivers
python3 rtl_checks.py lint spec2rtl_upf/generated_soc/uart_16550
cd spec2rtl_upf && python3 main.py --lint-only --dir generated_soc/uart_16550/rtl --top uart_16550
```

A waiver file has one waiver per line: `RULE [file-glob[:line]]`. For example:

```
UNUSEDSIGNAL  *_regs.sv
WIDTHEXPAND   dma_axi_sg_core.sv:50
```

The report also counts inline `lint_off` pragmas, because those hide warnings from the report.

### 4.2 CDC / RDC only

```bash
rtl --cdc --dir rtl/ --top my_top
rtl --cdc --dir rtl/ --top my_top --sdc my_top.sdc          # clock names, async groups, input clocks
rtl --cdc --dir rtl/ --sync-clocks clk,clk_div2             # declare synchronous clocks
rtl --cdc --dir rtl/ --async-inputs 'rx|gpio_in|_async$'    # top inputs that are asynchronous
python3 spec2rtl_upf/spec2rtl/spec2rtl.py cdc spec2rtl_upf/generated_soc/uart_16550
cd spec2rtl_upf && python3 main.py --cdc-only --spec market_specs/uart_16550_spec.md -o out
```

### 4.3 Simulation only

```bash
python3 rtl_checks.py sim my_ip.sv --tb tb_my_ip.sv
python3 rtl_checks.py sim spec2rtl_upf/generated_soc/uart_16550          # uses tb/tb_<top>.sv
cd spec2rtl_upf && python3 main.py --sim-only --dir out/uart/rtl --tb out/uart/tb/tb_uart_16550.sv
```

### 4.4 Lint + CDC + simulation (no synthesis, no UPF)

```bash
rtl --checks spec2rtl_upf/generated_soc/uart_16550
cd spec2rtl_upf && python3 main.py --checks-only --spec market_specs/watchdog_wdt_spec.md -o out
```

### 4.5 Synthesis / gate-level simulation / timing only

```bash
rtl --synth top.sv sub1.sv sub2.sv --lib nangate45 --period 5 --tb tb_top.sv -o top_gate.v
python3 rtl_checks.py synth --dir rtl/ --top my_top --lib sky130 --period 8 --gls --tb tb.sv -o synth_out
python3 techlib/synth_flow.py rtl/*.sv --top my_top --lib sky130 --period 8 --sdc my.sdc
cd spec2rtl_upf && python3 main.py --synth-only --dir generated_soc/watchdog_wdt/rtl --top watchdog_wdt --period 5 -o out_syn
```

These print the cell count, area, gate-level simulation result, and setup/hold slack (WNS). The full timing report is written to `<netlist>.sta.rpt`. Without `--sdc`, a basic SDC is generated from the top-level ports.

### 4.6 UPF (power intent) only

```bash
cd spec2rtl_upf
python3 main.py --upf-only --config benchmarks/power_config_market_soc.json --dir generated_soc -o out_upf
python3 main.py --upf-only --config my_power.json --filelist my_soc.f --existing-upf my.upf -o out_upf   # audit an existing UPF
```

### 4.7 Other single tools

| Task | Command |
|---|---|
| Testbench for an RTL file | `rtl --tb my_ip.sv -o tb_my_ip.sv` |
| Simulate + let the LLM repair | `rtl --verify my_ip.sv tb_my_ip.sv --max-retries 3` |
| Memory macro (plain English) | `rtl --mem --spec "16KB dual-port RAM with AXI5"` |
| Memory macro (direct) | `memgen --type sdp --size 2Kx32 --byte-enable --bus axi5 --name fb_ram --out-dir gen/` (or `python3 memory/memgen.py …`) |
| List memory presets | `memgen --list-presets` |
| Chat with the RTL model | `rtl --chat` |
| Markdown → PDF/DOCX | `rtl --convert notes.md --to pdf` |
| Which model is used | `rtl --models` (`--reprobe` after a hardware change) |

---

## 5. Batch runs

```bash
# lint + CDC on every generated IP
for d in spec2rtl_upf/generated_soc/*/; do [ -f "$d/files.f" ] && rtl --lint "$d" && rtl --cdc "$d"; done

# everything on every IP, one JSON report each
for d in spec2rtl_upf/generated_soc/*/; do
  [ -f "$d/files.f" ] && python3 rtl_checks.py all "$d" --json "$d/checks.json" -o "$d/synth"
done

# regenerate all 17 IPs from market_specs/ (RTL + TB + CDC SDC + lint + sim)
cd spec2rtl_upf && python3 src/regenerate_all_ips.py
```

Exit codes for every check: **0** = pass, **1** = check failed, **2** = bad input or missing tool. You can use them directly in CI or `make`.

---

## 6. Reading the results

**Lint**: PASS means no errors and no warnings that aren't waived. Each warning shows its rule, file and line.

**CDC / RDC** (structural, from the Yosys netlist):

| Result | Meaning | Severity |
|---|---|---|
| `SYNC_2FF` | flop-to-flop capture followed by a second flop (1-bit signal or gray code) | OK |
| `QUALIFIED` | data captured with an enable from the destination domain (handshake) | INFO |
| `MULTIBIT_SYNC` | a bus synchronized bit-by-bit – use gray code, a handshake or an async FIFO | WARNING |
| `SINGLE_FLOP` | only one capture flop – metastability risk | ERROR |
| `COMB_BEFORE_SYNC` / `UNSYNC` | crossing through logic, or no synchronizer at all | ERROR |
| `UNSYNC_RESET_DEASSERT` | one raw reset port used in several clock domains – add a reset synchronizer per domain | WARNING |
| `RESET_FROM_OTHER_DOMAIN` | a flop's async reset comes from another clock domain | WARNING |
| `GATED_CLOCK` / `GENERATED_CLOCK` / `LATCH` | clock-structure findings | WARNING / INFO |

**Simulation**: FAIL if the simulator errors, any line starts with `ERROR`/`FAIL`, `TEST FAILED` is printed, the testbench reports `0 checks`, or no PASS is printed.

**Synthesis**:

- Setup WNS < 0 means the design is too slow for `--period`.
- Hold WNS < 0 before clock-tree synthesis usually means input-to-flop paths with a 0 ns input delay.

---

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| `cannot reach Ollama at …` | On the Ollama machine run `OLLAMA_HOST=0.0.0.0 ollama serve` and open port 11434. Then `rtl --models --set-host http://<ip>:11434`. |
| A 32B model runs out of memory | The tool falls back to the next smaller model automatically. To pin one: `RTL_MODEL=qwen2.5-coder:7b`. |
| `CDC: ERROR … Multiple edge sensitive events` | An `always_ff … or negedge rst` block tests `!rst_n \|\| !other`. Use `wire rst_x_n = rst_n & other;` as the reset. (`soc_subsystem_top.sv` currently has this.) |
| `SIM: FAIL 0 checks executed` | The testbench checks nothing (the CPU and H.264 stream IPs today). Add checks to the testbench. |
| `STA: … not installed` / `no timing` | Run `./setup_synthesis.sh`. Without it, synthesis uses the bundled 30-cell libraries, which have no timing data. |
| Lint passes but the review found problems | Look at the "inline lint_off pragmas" count. Those pragmas hide warnings. |

Related files:

- `COMMANDS.md`: all switches.
- `rtl_review/RTL_FLOW_REVIEW.md`: review findings and known issues.
- `SETUP_*.md`: per-OS details.
