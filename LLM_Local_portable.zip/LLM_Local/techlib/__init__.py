"""
Open Standard Cell Libraries for Logic Synthesis and Technology Mapping.
Bundled: 30-cell NanGate45 / sky130 subsets (logic mapping + GLS only, no timing).
Full libraries with timing are downloaded by setup_synthesis.sh into techlib/<lib>/full/.
Flow entry point: techlib.synth_flow (synthesis -> GLS -> OpenSTA).
"""
