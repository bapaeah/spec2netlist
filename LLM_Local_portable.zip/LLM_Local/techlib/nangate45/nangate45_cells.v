// =============================================================================
//  NanGate 45nm Open Cell Library (NangateOpenCellLibrary)
//  Verilog Behavioral Simulation Models for Gate-Level Simulation (GLS)
// =============================================================================
`timescale 1ns/1ps

module INV_X1 (input A, output ZN);
  assign ZN = ~A;
endmodule

module INV_X2 (input A, output ZN);
  assign ZN = ~A;
endmodule

module INV_X4 (input A, output ZN);
  assign ZN = ~A;
endmodule

module BUF_X1 (input A, output Z);
  assign Z = A;
endmodule

module BUF_X2 (input A, output Z);
  assign Z = A;
endmodule

module CLKBUF_X1 (input A, output Z);
  assign Z = A;
endmodule

module CLKBUF_X2 (input A, output Z);
  assign Z = A;
endmodule

module AND2_X1 (input A1, input A2, output ZN);
  assign ZN = A1 & A2;
endmodule

module AND3_X1 (input A1, input A2, input A3, output ZN);
  assign ZN = A1 & A2 & A3;
endmodule

module AND4_X1 (input A1, input A2, input A3, input A4, output ZN);
  assign ZN = A1 & A2 & A3 & A4;
endmodule

module NAND2_X1 (input A1, input A2, output ZN);
  assign ZN = ~(A1 & A2);
endmodule

module NAND3_X1 (input A1, input A2, input A3, output ZN);
  assign ZN = ~(A1 & A2 & A3);
endmodule

module NAND4_X1 (input A1, input A2, input A3, input A4, output ZN);
  assign ZN = ~(A1 & A2 & A3 & A4);
endmodule

module OR2_X1 (input A1, input A2, output ZN);
  assign ZN = A1 | A2;
endmodule

module OR3_X1 (input A1, input A2, input A3, output ZN);
  assign ZN = A1 | A2 | A3;
endmodule

module OR4_X1 (input A1, input A2, input A3, input A4, output ZN);
  assign ZN = A1 | A2 | A3 | A4;
endmodule

module NOR2_X1 (input A1, input A2, output ZN);
  assign ZN = ~(A1 | A2);
endmodule

module NOR3_X1 (input A1, input A2, input A3, output ZN);
  assign ZN = ~(A1 | A2 | A3);
endmodule

module NOR4_X1 (input A1, input A2, input A3, input A4, output ZN);
  assign ZN = ~(A1 | A2 | A3 | A4);
endmodule

module XOR2_X1 (input A1, input A2, output Z);
  assign Z = A1 ^ A2;
endmodule

module XNOR2_X1 (input A1, input A2, output ZN);
  assign ZN = ~(A1 ^ A2);
endmodule

module MUX2_X1 (input I0, input I1, input S, output Z);
  assign Z = S ? I1 : I0;
endmodule

module AOI21_X1 (input A, input B1, input B2, output ZN);
  assign ZN = ~((B1 & B2) | A);
endmodule

module OAI21_X1 (input A, input B1, input B2, output ZN);
  assign ZN = ~((B1 | B2) & A);
endmodule

module AOI22_X1 (input A1, input A2, input B1, input B2, output ZN);
  assign ZN = ~((A1 & A2) | (B1 & B2));
endmodule

module OAI22_X1 (input A1, input A2, input B1, input B2, output ZN);
  assign ZN = ~((A1 | A2) & (B1 | B2));
endmodule

module DFF_X1 (input CK, input D, output reg Q, output QN);
  always @(posedge CK) begin
    Q <= D;
  end
  assign QN = ~Q;
endmodule

module DFF_X2 (input CK, input D, output reg Q, output QN);
  always @(posedge CK) begin
    Q <= D;
  end
  assign QN = ~Q;
endmodule

module DFFR_X1 (input CK, input D, input RN, output reg Q, output QN);
  always @(posedge CK or negedge RN) begin
    if (!RN)
      Q <= 1'b0;
    else
      Q <= D;
  end
  assign QN = ~Q;
endmodule

module DFFS_X1 (input CK, input D, input SN, output reg Q, output QN);
  always @(posedge CK or negedge SN) begin
    if (!SN)
      Q <= 1'b1;
    else
      Q <= D;
  end
  assign QN = ~Q;
endmodule

module DFFRS_X1 (input CK, input D, input RN, input SN, output reg Q, output QN);
  always @(posedge CK or negedge RN or negedge SN) begin
    if (!RN)
      Q <= 1'b0;
    else if (!SN)
      Q <= 1'b1;
    else
      Q <= D;
  end
  assign QN = ~Q;
endmodule

module DLH_X1 (input G, input D, output reg Q, output QN);
  always @(*) begin
    if (G)
      Q = D;
  end
  assign QN = ~Q;
endmodule
