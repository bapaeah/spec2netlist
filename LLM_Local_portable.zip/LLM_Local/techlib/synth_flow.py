#!/usr/bin/env python3
"""
techlib/synth_flow.py - one synthesis / GLS / STA flow shared by `rtl --synth` and spec2rtl.

Library selection (per --lib nangate45|sky130):
  1. techlib/<lib>/full/<real>.lib      real foundry-grade Liberty WITH timing, downloaded by
                                        setup_synthesis.sh (pinned commit + sha256)
  2. techlib/<lib>/<lib>.lib            bundled 30-cell subset: logic mapping + GLS only,
                                        NO timing arcs -> area is indicative, STA impossible

Flow (works on Yosys 0.33 ... 0.6x; no reliance on -dont_use options):
  read_liberty -lib  -> read_verilog -sv -> hierarchy -check -> proc/flatten/opt
  -> latch assert -> synth -> dfflibmap -> abc [-D period] -> hilomap (tie cells)
  -> check -assert -> write_verilog + stat -liberty
Then optional:  GLS models generated from the Liberty itself (read_liberty -> write_verilog)
                STA with OpenSTA (`sta`) using the given SDC or an auto-generated IP SDC.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

HERE = Path(__file__).resolve().parent

LIBS: Dict[str, dict] = {
    "nangate45": {
        "display": "NanGate 45nm Open Cell Library (typical, 1.1 V, 25 C)",
        "full": "NangateOpenCellLibrary_typical.lib",
        "url": "https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/"
               "b50af175fe2ed137353b6e056b91af1f8e8df529/flow/platforms/nangate45/lib/NangateOpenCellLibrary_typical.lib",
        "sha256": "8d540a4d4cf6d09d27c87ad067857a9c0c2eeb023ab7a56e058cd3113db4e9b1",
        "tie": ("LOGIC1_X1", "Z", "LOGIC0_X1", "Z"),
        "bundled_tie": None,
        "drive_cell": "INV_X1",
        # from ORFS platforms/nangate45/config.mk + cells without a usable function
        "dont_use": [r"TAPCELL_.*", r"FILLCELL_.*", r"AOI211_X1", r"OAI211_X1", r"ANTENNA.*",
                     r"CLKGATE.*", r"SDFF.*", r"TLAT.*", r"DLL_.*", r"DLH_.*"],
    },
    "sky130": {
        "display": "SkyWater 130nm sky130_fd_sc_hd (tt, 1.8 V, 25 C)",
        "full": "sky130_fd_sc_hd__tt_025C_1v80.lib",
        "url": "https://raw.githubusercontent.com/The-OpenROAD-Project/OpenROAD-flow-scripts/"
               "b50af175fe2ed137353b6e056b91af1f8e8df529/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib",
        "sha256": "ec0e1067a35c8bf20b11e58d1e8ac53326067e4dac84a125cc1b917a3518d0d9",
        "tie": ("sky130_fd_sc_hd__conb_1", "HI", "sky130_fd_sc_hd__conb_1", "LO"),
        "bundled_tie": None,
        "drive_cell": "sky130_fd_sc_hd__inv_1",
        # from ORFS platforms/sky130hd/config.mk (probe, lpflow, kapwr, fill/tap/decap) + latches/ICG/scan
        "dont_use": [r".*__probe.*", r".*__lpflow_.*", r".*kapwr.*", r".*__decap.*", r".*__fill.*",
                     r".*__tap.*", r".*__diode.*", r".*__dl[x].*", r".*__dlr.*", r".*__dlclkp.*",
                     r".*__sdl.*", r".*__sdf.*", r".*__sedf.*", r".*__macro_sparecell.*", r".*__einv.*",
                     r".*__ebuf.*"],
    },
}


def lib_dir(key: str) -> Path:
    return HERE / key


def full_lib(key: str) -> Optional[Path]:
    p = lib_dir(key) / "full" / LIBS[key]["full"]
    return p if p.is_file() else None


def bundled_lib(key: str) -> Path:
    return lib_dir(key) / f"{key}.lib"


def select_lib(key: str, prefer_full: bool = True):
    """Return (liberty_path, is_full)."""
    if prefer_full and full_lib(key):
        return synth_view(key), True
    return bundled_lib(key), False


# ------------------------------------------------------------------ liberty helpers
def _cell_blocks(text: str):
    """Yield (name, start, end) of every `cell (name) { ... }` block (brace matched)."""
    for m in re.finditer(r'\bcell\s*\(\s*"?([\w$]+)"?\s*\)\s*\{', text):
        depth, i = 1, m.end()
        while depth and i < len(text):
            c = text[i]
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
            i += 1
        yield m.group(1), m.start(), i


def synth_view(key: str) -> Path:
    """Liberty with dont_use cells removed (cached). Portable replacement for
    `abc/dfflibmap -dont_use`, which older Yosys releases (e.g. Ubuntu's 0.33) lack."""
    src = full_lib(key)
    dst = src.with_suffix(".synth.lib")
    if dst.exists() and dst.stat().st_mtime >= src.stat().st_mtime:
        return dst
    text = src.read_text(errors="ignore")
    pats = [re.compile(p) for p in LIBS[key]["dont_use"]]
    out, last, dropped = [], 0, 0
    for name, s, e in _cell_blocks(text):
        if any(p.fullmatch(name) for p in pats):
            out.append(text[last:s])
            last = e
            dropped += 1
    out.append(text[last:])
    dst.write_text("".join(out))
    print(f"[synth_flow] {dst.name}: removed {dropped} dont_use cells")
    return dst


def gls_models(key: str, liberty: Optional[Path] = None) -> Path:
    """Verilog simulation models for gate-level simulation."""
    if liberty is None or "full" not in str(liberty):
        return lib_dir(key) / f"{key}_cells.v"
    out = liberty.with_name(f"{key}_full_models.v")
    if out.exists() and out.stat().st_mtime >= liberty.stat().st_mtime:
        return out
    y = yosys_bin()
    subprocess.run([y, "-q", "-p", f"read_liberty -ignore_miss_func {liberty}; write_verilog -noattr {out}"],
                   capture_output=True, text=True)
    return out


def yosys_bin() -> Optional[str]:
    return shutil.which("yosys") or shutil.which("yowasp-yosys")


def sta_bin() -> Optional[str]:
    return shutil.which("sta") or shutil.which("opensta")


# ------------------------------------------------------------------ synthesis
def synthesize(files: List[str], top: str, key: str = "nangate45", out_netlist: Optional[str] = None,
               period_ns: Optional[float] = None, log: Optional[str] = None, prefer_full: bool = True) -> dict:
    y = yosys_bin()
    if not y:
        return {"ok": False, "error": "yosys not found - run ./setup_synthesis.sh (or pip install yowasp-yosys)"}
    liberty, is_full = select_lib(key, prefer_full)
    out_netlist = out_netlist or f"{top}_{key}_gate.v"
    log = log or str(Path(out_netlist).with_suffix(".synth.log"))
    tie = LIBS[key]["tie"]
    tie_cmd = f"hilomap -hicell {tie[0]} {tie[1]} -locell {tie[2]} {tie[3]}; " if is_full else ""
    abc_d = f"-D {period_ns * 1000:.0f} " if (period_ns and is_full) else ""
    script = (
        f"read_liberty -lib {liberty}; "
        f"read_verilog -sv {' '.join(files)}; "
        f"hierarchy -check -top {top}; proc; flatten; opt_clean; "
        "select -assert-none t:$dlatch t:$adlatch t:$dlatchsr; "
        f"synth -top {top}; "
        f"dfflibmap -liberty {liberty}; "
        f"abc {abc_d}-liberty {liberty}; opt_clean; "
        f"{tie_cmd}setundef -zero; opt_clean; "
        "check -assert; "
        f"write_verilog -noattr -noexpr {out_netlist}; "
        f"tee -q -o {out_netlist}.stat stat -liberty {liberty}"
    )
    r = subprocess.run([y, "-q", "-l", log, "-p", script], capture_output=True, text=True)
    res = {"ok": r.returncode == 0, "liberty": str(liberty), "full_library": is_full,
           "netlist": out_netlist if r.returncode == 0 else None, "log": log, "lib": key}
    if r.returncode != 0:
        res["error"] = "\n".join((r.stderr or r.stdout or Path(log).read_text(errors='ignore')).strip()
                                 .splitlines()[-8:])
        return res
    stat = Path(out_netlist + ".stat").read_text(errors="ignore")
    m = re.search(r"Chip area for (?:top )?module.*?:\s*([0-9.]+)", stat)
    res["area_um2"] = float(m.group(1)) if m else None
    m = re.findall(r"Number of cells:\s+(\d+)", stat)
    res["cells"] = int(m[-1]) if m else None
    res["flops"] = sum(int(n) for c, n in re.findall(r"^\s+(\S*(?:DFF|df[a-z]+p|dfbbp|dfxtp|dfrtp|dfstp)\S*)\s+(\d+)\s*$",
                                                      stat, re.M | re.I))
    if not is_full:
        res["warning"] = ("bundled subset library has NO timing data: area is indicative only and STA is "
                          "not possible. Run ./setup_synthesis.sh to install the real Liberty files.")
    return res


# ------------------------------------------------------------------ STA
def auto_sdc(top: str, files: List[str], clock: str, period_ns: float, reset: Optional[str], key: str,
             out: str) -> str:
    """Minimal IP SDC from the top-level port list (explicit lists; OpenSTA-compatible)."""
    txt = "\n".join(Path(f).read_text(errors="ignore") for f in files)
    txt = re.sub(r"//[^\n]*|/\*[\s\S]*?\*/", "", txt)   # comments contain words like "(active-low)"
    m = re.search(rf"\bmodule\s+{re.escape(top)}\b[\s\S]*?\)\s*;", txt)
    hdr = m.group(0) if m else ""
    ports = re.findall(r"\b(input|output|inout)\b[^,;)]*?(\w+)\s*(?=,|\)|//|$)", hdr, re.M)
    ins = [n for d, n in ports if d == "input" and n not in (clock, reset)]
    outs = [n for d, n in ports if d != "input"]
    io = period_ns * 0.3
    L = [f"create_clock -name {clock} -period {period_ns:.3f} [get_ports {clock}]",
         f"set_clock_uncertainty 0.1 [get_clocks {clock}]"]
    if reset:
        L.append(f"set_false_path -from [get_ports {reset}]")
    if ins:
        L += [f"set_input_delay -clock {clock} {io:.3f} [get_ports {{{' '.join(ins)}}}]",
              f"set_driving_cell -lib_cell {LIBS[key]['drive_cell']} [get_ports {{{' '.join(ins)}}}]"]
    if outs:
        L += [f"set_output_delay -clock {clock} {io:.3f} [get_ports {{{' '.join(outs)}}}]",
              "set_load 0.01 [all_outputs]"]
    Path(out).write_text("\n".join(L) + "\n")
    return out


def _sta_path(path: str, via_wsl: bool) -> str:
    """OpenSTA via the Windows WSL shim needs Linux paths."""
    if not via_wsl:
        return str(path)
    r = subprocess.run(["wsl", "wslpath", "-a", str(Path(path).resolve()).replace("\\", "/")],
                       capture_output=True, text=True)
    return r.stdout.strip() or str(path)


def run_sta(netlist: str, top: str, liberty: str, sdc: str, report: Optional[str] = None) -> dict:
    s = sta_bin()
    via_wsl = os.name == "nt" and bool(s) and s.lower().endswith(".cmd")
    if not s:
        return {"ok": False, "error": "OpenSTA (`sta`) not found - run ./setup_synthesis.sh"}
    report = report or str(Path(netlist).with_suffix(".sta.rpt"))
    tcl = Path(netlist).with_suffix(".sta.tcl")
    P = lambda x: _sta_path(x, via_wsl)  # noqa: E731
    tcl.write_text(f"""read_liberty {P(liberty)}
read_verilog {P(netlist)}
link_design {top}
read_sdc {P(sdc)}
report_checks -path_delay max -digits 3 -group_path_count 3
report_checks -path_delay min -digits 3 -group_path_count 3
report_worst_slack -max -digits 3
report_worst_slack -min -digits 3
report_tns -digits 3
report_check_types -max_slew -max_capacitance -max_fanout -violators
exit
""")
    r = subprocess.run([s, "-no_init", "-exit", P(str(tcl))], capture_output=True, text=True, timeout=1800)
    out = (r.stdout or "") + (r.stderr or "")
    Path(report).write_text(out)
    wmax = re.search(r"worst slack max\s+(-?[0-9.]+)", out)
    wmin = re.search(r"worst slack min\s+(-?[0-9.]+)", out)
    ws = [wmax.group(1) if wmax else None, wmin.group(1) if wmin else None]
    tns = re.search(r"tns\s+(?:max\s+)?(-?[0-9.]+)", out)
    errs = [l for l in out.splitlines() if l.startswith("Error")]
    return {"ok": r.returncode == 0 and not errs, "report": report,
            "wns_setup": float(ws[0]) if ws[0] else None, "wns_hold": float(ws[1]) if ws[1] else None,
            "tns": float(tns.group(1)) if tns else None, "errors": errs[:5]}


def gls(netlist: str, tb: str, key: str, liberty: Optional[str] = None) -> dict:
    models = gls_models(key, Path(liberty) if liberty else None)
    if not shutil.which("iverilog"):
        return {"ok": False, "error": "iverilog not found"}
    vvp = str(Path(netlist).with_suffix(".gls.vvp"))
    r = subprocess.run(["iverilog", "-g2012", "-o", vvp, str(models), netlist, tb], capture_output=True, text=True)
    if r.returncode:
        return {"ok": False, "error": r.stderr[-1500:]}
    r = subprocess.run(["vvp", "-n", vvp], capture_output=True, text=True, timeout=1800)
    out = r.stdout + r.stderr
    passed = bool(re.search(r"TEST(S)? PASSED|ALL TESTS PASSED", out, re.I)) and not re.search(r"\bFAIL", out)
    return {"ok": passed, "tail": out[-800:]}


# ------------------------------------------------------------------ install / self-test
def install_libs(keys=None, force=False) -> bool:
    """Download the real Liberty files (pinned commit), verify sha256, build synth views + GLS models."""
    import hashlib
    import urllib.request
    ok = True
    for k in keys or list(LIBS):
        info = LIBS[k]
        dst = lib_dir(k) / "full" / info["full"]
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and not force and hashlib.sha256(dst.read_bytes()).hexdigest() == info["sha256"]:
            print(f"  ✓ {k}: {dst.name} already installed")
        else:
            print(f"  ↓ {k}: downloading {info['full']} ...")
            tmp = dst.with_suffix(".part")
            try:
                with urllib.request.urlopen(info["url"], timeout=300) as r, open(tmp, "wb") as f:
                    shutil.copyfileobj(r, f)
            except Exception as e:  # noqa: BLE001
                print(f"  ✗ {k}: download failed ({e}). Behind a proxy? set HTTPS_PROXY, or copy the file to {dst}")
                ok = False
                continue
            h = hashlib.sha256(tmp.read_bytes()).hexdigest()
            if h != info["sha256"]:
                print(f"  ✗ {k}: sha256 mismatch ({h}) - file rejected")
                tmp.unlink()
                ok = False
                continue
            tmp.replace(dst)
            print(f"  ✓ {k}: {dst} ({dst.stat().st_size // 1024} KB, sha256 verified)")
        if yosys_bin():
            gls_models(k, synth_view(k))
            print(f"  ✓ {k}: synthesis view + GLS models generated")
        else:
            print(f"  ! {k}: yosys missing - synth view / GLS models will be generated on first use")
    return ok


SELFTEST_RTL = """module st_counter #(parameter W = 8) (input logic clk, input logic rst_n, input logic en,
  output logic [W-1:0] q, output logic wrap);
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) q <= '0; else if (en) q <= q + 1'b1;
  assign wrap = en && (q == '1);
endmodule
"""
SELFTEST_TB = """`timescale 1ns/1ps
module tb_st; logic clk = 0, rst_n = 0, en = 0; logic [7:0] q; logic wrap; int errs = 0, checks = 0;
  st_counter dut(.*); always #5 clk = ~clk;
  initial begin repeat (2) @(posedge clk); rst_n = 1; @(negedge clk); en = 1;
    for (int i = 1; i <= 300; i++) begin @(negedge clk); checks++; if (q !== 8'(i)) errs++; end
    if (errs == 0) $display("TEST PASSED (%0d checks)", checks); else $display("TEST FAILED (%0d errors)", errs);
    $finish; end
endmodule
"""


def selftest() -> bool:
    import tempfile
    td = Path(tempfile.mkdtemp(prefix="synth_selftest_"))
    (td / "st.sv").write_text(SELFTEST_RTL)
    (td / "tb.sv").write_text(SELFTEST_TB)
    all_ok = True
    rows = []
    for k in LIBS:
        r = synthesize([str(td / "st.sv")], "st_counter", k, str(td / f"st_{k}.v"), 2.0)
        g = gls(r["netlist"], str(td / "tb.sv"), k, r["liberty"] if r.get("full_library") else None) if r["ok"] else {"ok": False}
        st = {"ok": None}
        if r["ok"] and r["full_library"] and sta_bin():
            sdc = auto_sdc("st_counter", [str(td / "st.sv")], "clk", 2.0, "rst_n", k, str(td / f"st_{k}.sdc"))
            st = run_sta(r["netlist"], "st_counter", str(full_lib(k)), sdc)
        rows.append((k, "full" if r.get("full_library") else "bundled", r["ok"], g["ok"], st.get("ok"), st.get("wns_setup")))
        all_ok &= bool(r["ok"] and g["ok"] and (st.get("ok") in (True, None)))
    print(f"\n  {'library':10} {'liberty':8} {'synth':6} {'GLS':6} {'STA':6} setup-WNS@500MHz")
    for k, kind, a, b, c, w in rows:
        f = lambda x: "PASS" if x else ("skip" if x is None else "FAIL")  # noqa: E731
        print(f"  {k:10} {kind:8} {f(a):6} {f(b):6} {f(c):6} {w}")
    return all_ok


# ------------------------------------------------------------------ doctor / CLI
def doctor() -> dict:
    rep = {"yosys": yosys_bin(), "sta": sta_bin(), "iverilog": shutil.which("iverilog"),
           "verilator": shutil.which("verilator")}
    for k in LIBS:
        rep[f"{k}_full_lib"] = str(full_lib(k)) if full_lib(k) else None
        rep[f"{k}_bundled_lib"] = str(bundled_lib(k)) if bundled_lib(k).exists() else None
    if rep["yosys"]:
        v = subprocess.run([rep["yosys"], "-V"], capture_output=True, text=True).stdout.strip()
        rep["yosys_version"] = v
    return rep


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description="Synthesis + GLS + STA with open standard-cell libraries")
    ap.add_argument("rtl", nargs="*")
    ap.add_argument("--top")
    ap.add_argument("--lib", choices=list(LIBS), default="nangate45")
    ap.add_argument("--period", type=float, default=10.0, help="clock period in ns (default 10)")
    ap.add_argument("--clock", default="clk")
    ap.add_argument("--reset", default="rst_n")
    ap.add_argument("--sdc")
    ap.add_argument("--tb", help="testbench for gate-level simulation")
    ap.add_argument("-o", "--output")
    ap.add_argument("--bundled", action="store_true", help="force the bundled subset library")
    ap.add_argument("--doctor", action="store_true", help="report what is installed")
    ap.add_argument("--install-libs", action="store_true", help="download + verify the real Liberty files")
    ap.add_argument("--selftest", action="store_true", help="synth + GLS + STA smoke test on every library")
    a = ap.parse_args(argv)
    if a.install_libs:
        return 0 if install_libs() else 1
    if a.selftest:
        return 0 if selftest() else 1
    if a.doctor or not a.rtl:
        print(json.dumps(doctor(), indent=2))
        return 0
    top = a.top or re.search(r"\bmodule\s+(\w+)", Path(a.rtl[-1]).read_text()).group(1)
    r = synthesize(a.rtl, top, a.lib, a.output, a.period, prefer_full=not a.bundled)
    print(json.dumps({k: v for k, v in r.items() if k != "log"}, indent=2))
    if not r["ok"]:
        return 1
    if a.tb:
        g = gls(r["netlist"], a.tb, a.lib, r["liberty"] if r["full_library"] else None)
        print("GLS:", "PASS" if g["ok"] else "FAIL", g.get("error", ""))
    if r["full_library"]:
        sdc = a.sdc or auto_sdc(top, a.rtl, a.clock, a.period, a.reset, a.lib, str(Path(r["netlist"]).with_suffix(".sdc")))
        s = run_sta(r["netlist"], top, str(full_lib(a.lib)), sdc)
        print("STA:", json.dumps(s, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
