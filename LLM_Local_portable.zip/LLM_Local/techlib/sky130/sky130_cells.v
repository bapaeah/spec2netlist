// =============================================================================
//  SkyWater 130nm High-Density Open Cell Library (sky130_fd_sc_hd)
//  Verilog Behavioral Simulation Models for Gate-Level Simulation (GLS)
// =============================================================================
`timescale 1ns/1ps

module sky130_fd_sc_hd__inv_1 (input A, output Y);
  assign Y = ~A;
endmodule

module sky130_fd_sc_hd__inv_2 (input A, output Y);
  assign Y = ~A;
endmodule

module sky130_fd_sc_hd__inv_4 (input A, output Y);
  assign Y = ~A;
endmodule

module sky130_fd_sc_hd__buf_1 (input A, output X);
  assign X = A;
endmodule

module sky130_fd_sc_hd__buf_2 (input A, output X);
  assign X = A;
endmodule

module sky130_fd_sc_hd__clkbuf_1 (input A, output X);
  assign X = A;
endmodule

module sky130_fd_sc_hd__clkbuf_2 (input A, output X);
  assign X = A;
endmodule

module sky130_fd_sc_hd__nand2_1 (input A, input B, output Y);
  assign Y = ~(A & B);
endmodule

module sky130_fd_sc_hd__nand3_1 (input A, input B, input C, output Y);
  assign Y = ~(A & B & C);
endmodule

module sky130_fd_sc_hd__nand4_1 (input A, input B, input C, input D, output Y);
  assign Y = ~(A & B & C & D);
endmodule

module sky130_fd_sc_hd__and2_1 (input A, input B, output X);
  assign X = A & B;
endmodule

module sky130_fd_sc_hd__and3_1 (input A, input B, input C, output X);
  assign X = A & B & C;
endmodule

module sky130_fd_sc_hd__and4_1 (input A, input B, input C, input D, output X);
  assign X = A & B & C & D;
endmodule

module sky130_fd_sc_hd__nor2_1 (input A, input B, output Y);
  assign Y = ~(A | B);
endmodule

module sky130_fd_sc_hd__nor3_1 (input A, input B, input C, output Y);
  assign Y = ~(A | B | C);
endmodule

module sky130_fd_sc_hd__nor4_1 (input A, input B, input C, input D, output Y);
  assign Y = ~(A | B | C | D);
endmodule

module sky130_fd_sc_hd__or2_1 (input A, input B, output X);
  assign X = A | B;
endmodule

module sky130_fd_sc_hd__or3_1 (input A, input B, input C, output X);
  assign X = A | B | C;
endmodule

module sky130_fd_sc_hd__or4_1 (input A, input B, input C, input D, output X);
  assign X = A | B | C | D;
endmodule

module sky130_fd_sc_hd__xor2_1 (input A, input B, output X);
  assign X = A ^ B;
endmodule

module sky130_fd_sc_hd__xnor2_1 (input A, input B, output Y);
  assign Y = ~(A ^ B);
endmodule

module sky130_fd_sc_hd__mux2_1 (input A0, input A1, input S, output X);
  assign X = S ? A1 : A0;
endmodule

module sky130_fd_sc_hd__a21oi_1 (input A1, input A2, input B1, output Y);
  assign Y = ~((A1 & A2) | B1);
endmodule

module sky130_fd_sc_hd__o21ai_1 (input A1, input A2, input B1, output Y);
  assign Y = ~((A1 | A2) & B1);
endmodule

module sky130_fd_sc_hd__a22oi_1 (input A1, input A2, input B1, input B2, output Y);
  assign Y = ~((A1 & A2) | (B1 & B2));
endmodule

module sky130_fd_sc_hd__o22ai_1 (input A1, input A2, input B1, input B2, output Y);
  assign Y = ~((A1 | A2) & (B1 | B2));
endmodule

module sky130_fd_sc_hd__dfxtp_1 (input CLK, input D, output reg Q);
  always @(posedge CLK) begin
    Q <= D;
  end
endmodule

module sky130_fd_sc_hd__dfbbp_1 (input CLK, input D, output reg Q, output Q_N);
  always @(posedge CLK) begin
    Q <= D;
  end
  assign Q_N = ~Q;
endmodule

module sky130_fd_sc_hd__dfrtp_1 (input CLK, input D, input RESET_B, output reg Q);
  always @(posedge CLK or negedge RESET_B) begin
    if (!RESET_B)
      Q <= 1'b0;
    else
      Q <= D;
  end
endmodule

module sky130_fd_sc_hd__dfstp_1 (input CLK, input D, input SET_B, output reg Q);
  always @(posedge CLK or negedge SET_B) begin
    if (!SET_B)
      Q <= 1'b1;
    else
      Q <= D;
  end
endmodule

module sky130_fd_sc_hd__dlxtp_1 (input GATE, input D, output reg Q);
  always @(*) begin
    if (GATE)
      Q = D;
  end
endmodule
