#!/usr/bin/env python3
"""
ollama_models.py - pick the best Ollama model for the hardware that will actually run it.

Where the hardware is measured (RTL_HW_SOURCE, default "auto"):
  auto    Ollama on this laptop  -> detect this laptop's GPU / unified memory / RAM.
          Ollama on another host -> measure that host: load each model once and read
                                    /api/ps (size vs size_vram = how much sits in GPU memory).
                                    Result is cached for 7 days (~/.llm_local/model_fit.json).
  laptop  always size models against THIS laptop's GPU/RAM (even if Ollama runs elsewhere).
  manual  use "host_vram_gb" / "host_ram_gb" from ~/.llm_local/config.json (no probing).

Selection per role (models discovered from /api/tags, so exact tag spelling does not matter):
  quality   generate / testbench / verify-repair / spec2rtl core fill
            -> most capable model that fits COMPLETELY in GPU memory with the context window;
               if none fits, a model that still runs at usable speed (MoE or <=8B) on CPU/RAM.
  balanced  chat -> most capable fully-GPU model up to ~16B parameters.
  fast      JSON extraction (memory compiler) -> smallest capable coder model.
Overrides: --model <name> / RTL_MODEL=<name> (any value other than "auto") always win.

Configure the host once:   rtl --models --set-host http://192.168.1.50:11434
  (on that machine Ollama must listen on the network:  OLLAMA_HOST=0.0.0.0 ollama serve)
Show the decision:         rtl --models          (add --reprobe to re-measure)
"""
from __future__ import annotations

import json
import math
import os
import platform
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Dict, List, Optional, Tuple

CFG_DIR = Path(os.getenv("LLM_LOCAL_HOME", Path.home() / ".llm_local"))
CFG_FILE = CFG_DIR / "config.json"
FIT_CACHE = CFG_DIR / "model_fit.json"
FIT_TTL_S = 7 * 24 * 3600
DEFAULT_CTX = int(os.getenv("RTL_CTX", "8192"))
MAX_CTX = int(os.getenv("RTL_MAX_CTX", "16384"))
GB = 1024 ** 3

# Capability ranking for RTL work (higher = better). Unknown models fall back to parameter count.
CAPABILITY = [
    (r"qwen2\.5-coder:32b", 100), (r"qwen3-coder", 98), (r"deepseek-coder-v2:236b", 99),
    (r"qwen2\.5-coder:14b", 85), (r"deepseek-coder-v2(:16b|:lite|:latest)?$", 80),
    (r"codestral", 78), (r"qwen2\.5-coder:7b", 60), (r"deepseek-coder:6\.7b", 50),
    (r"qwen2\.5-coder:3b", 40), (r"qwen2\.5-coder:1\.5b", 25),
]
NON_CHAT_FAMILIES = {"bert", "nomic-bert", "clip"}


# ------------------------------------------------------------------ config / host
def load_cfg() -> dict:
    try:
        return json.loads(CFG_FILE.read_text())
    except Exception:  # noqa: BLE001
        return {}


def save_cfg(cfg: dict):
    CFG_DIR.mkdir(parents=True, exist_ok=True)
    CFG_FILE.write_text(json.dumps(cfg, indent=2))


def normalize_host(h: str) -> str:
    h = (h or "").strip().rstrip("/")
    if not h:
        return "http://127.0.0.1:11434"
    if not re.match(r"^https?://", h):
        h = "http://" + h
    if not re.search(r":\d+$", h.split("://", 1)[1]):
        h += ":11434"
    return h.replace("://0.0.0.0", "://127.0.0.1")   # server bind address -> local client


def ollama_host() -> str:
    return normalize_host(os.getenv("OLLAMA_HOST") or load_cfg().get("ollama_host") or "")


def is_local(host: str) -> bool:
    return bool(re.match(r"^https?://(127\.\d+\.\d+\.\d+|localhost|\[?::1\]?)(:|$)", host))


def _req(path: str, payload: Optional[dict] = None, timeout: int = 15, host: Optional[str] = None):
    url = f"{host or ollama_host()}{path}"
    data = json.dumps(payload).encode() if payload is not None else None
    r = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(r, timeout=timeout) as resp:
        body = resp.read().decode()
        return json.loads(body) if body.strip() else {}


# ------------------------------------------------------------------ model metadata
def list_models() -> List[dict]:
    out = []
    for m in _req("/api/tags").get("models", []):
        d = m.get("details", {}) or {}
        if (d.get("family") or "").lower() in NON_CHAT_FAMILIES or "embed" in m["name"]:
            continue
        out.append({"name": m["name"], "size": m.get("size", 0), "digest": m.get("digest", "")[:12],
                    "params_b": _param_b(d.get("parameter_size", "")), "family": d.get("family", ""),
                    "quant": d.get("quantization_level", "")})
    return out


def _param_b(s: str) -> float:
    m = re.match(r"([\d.]+)\s*([BbMm])", s or "")
    if not m:
        return 0.0
    return float(m.group(1)) / (1000 if m.group(2).lower() == "m" else 1)


_SHOW: Dict[str, dict] = {}


def arch_info(name: str) -> dict:
    """KV-cache bytes/token and MoE flag from /api/show model_info."""
    if name in _SHOW:
        return _SHOW[name]
    info = {}
    try:
        mi = _req("/api/show", {"model": name}, timeout=30).get("model_info", {}) or {}
        a = mi.get("general.architecture", "")
        g = lambda k, d=None: mi.get(f"{a}.{k}", d)  # noqa: E731
        layers = g("block_count", 0) or 0
        heads = g("attention.head_count", 0) or 0
        kvh = g("attention.head_count_kv", heads) or heads
        emb = g("embedding_length", 0) or 0
        hd = (emb // heads) if heads else 128
        kl, vl = g("attention.key_length", hd) or hd, g("attention.value_length", hd) or hd
        info = {"arch": a, "kv_bytes_per_token": 2 * layers * kvh * (kl + vl),
                "moe": bool(g("expert_count", 0)), "experts_used": g("expert_used_count", 0)}
    except Exception:  # noqa: BLE001
        info = {"arch": "?", "kv_bytes_per_token": 0, "moe": False}
    _SHOW[name] = info
    return info


def capability(m: dict) -> float:
    for pat, score in CAPABILITY:
        if re.search(pat, m["name"]):
            return score
    bonus = 1.15 if "coder" in m["name"] or "code" in m["family"] else 1.0
    return min(95.0, 3.0 * m["params_b"] * bonus)


def need_gb(m: dict, ctx: int) -> float:
    kv = arch_info(m["name"]).get("kv_bytes_per_token") or int(m["params_b"] * 8000)
    return (m["size"] * 1.05 + kv * ctx) / GB + 0.6          # weights + KV cache + compute graph


# ------------------------------------------------------------------ hardware detection (this machine)
def _run(cmd: List[str]) -> str:
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=15).stdout
    except Exception:  # noqa: BLE001
        return ""


def _ram_gb() -> float:
    try:
        if sys.platform == "darwin":
            return int(_run(["sysctl", "-n", "hw.memsize"]).strip()) / GB
        if sys.platform.startswith("linux"):
            kb = int(re.search(r"MemTotal:\s+(\d+)", Path("/proc/meminfo").read_text()).group(1))
            return kb / 1024 ** 2
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("m", ctypes.c_ulong), ("t", ctypes.c_ulonglong),
                            ("a", ctypes.c_ulonglong), ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                            ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("e", ctypes.c_ulonglong)]
            s = MS(); s.l = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
            return s.t / GB
    except Exception:  # noqa: BLE001
        pass
    return 8.0


def detect_local_hw() -> dict:
    ram = _ram_gb()
    hw = {"where": "this machine", "ram_gb": round(ram, 1), "gpu": "none", "vram_gb": 0.0}
    smi = shutil.which("nvidia-smi")
    if smi:
        rows = [r.split(",") for r in _run([smi, "--query-gpu=name,memory.total",
                                            "--format=csv,noheader,nounits"]).strip().splitlines() if r.strip()]
        if rows:
            hw.update(gpu=" + ".join(r[0].strip() for r in rows),
                      vram_gb=round(sum(float(r[1]) for r in rows) / 1024 - 0.5, 1))
            return hw
    if sys.platform == "darwin" and _run(["sysctl", "-n", "hw.optional.arm64"]).strip() == "1":
        frac = 0.67 if ram <= 36 else 0.75                      # macOS default GPU wired-memory limit
        chip = _run(["sysctl", "-n", "machdep.cpu.brand_string"]).strip() or "Apple Silicon"
        hw.update(gpu=f"{chip} (unified memory)", vram_gb=round(ram * frac - 1.5, 1))
        return hw
    if shutil.which("rocm-smi"):
        tot = re.findall(r"Total Memory \(B\)\D+(\d+)", _run(["rocm-smi", "--showmeminfo", "vram"]))
        if tot:
            hw.update(gpu="AMD ROCm", vram_gb=round(sum(int(t) for t in tot) / GB - 0.5, 1))
            return hw
    hw["gpu"] = "none (CPU inference)"
    return hw


# ------------------------------------------------------------------ remote fit probe
def _fit_cache() -> dict:
    try:
        return json.loads(FIT_CACHE.read_text())
    except Exception:  # noqa: BLE001
        return {}


def probe_fit(m: dict, ctx: int, refresh: bool = False) -> dict:
    """Load the model on the Ollama host and read how much of it landed in GPU memory."""
    key = f"{ollama_host()}|{m['name']}|{m['digest']}|{ctx}"
    cache = _fit_cache()
    hit = cache.get(key)
    if hit and not refresh and time.time() - hit.get("t", 0) < FIT_TTL_S:
        return hit
    print(f"  [models] measuring {m['name']} on {ollama_host()} (one-time, cached 7 days)...", file=sys.stderr)
    res = {"t": time.time(), "gpu_frac": 0.0, "loads": False, "error": ""}
    try:
        _req("/api/generate", {"model": m["name"], "prompt": "", "keep_alive": "60s",
                               "options": {"num_ctx": ctx}}, timeout=900)
        for p in _req("/api/ps").get("models", []):
            if p.get("name") == m["name"] or p.get("model") == m["name"]:
                res["loads"] = True
                res["gpu_frac"] = round((p.get("size_vram", 0) or 0) / max(p.get("size", 1), 1), 3)
                res["resident_gb"] = round(p.get("size", 0) / GB, 1)
        _req("/api/generate", {"model": m["name"], "keep_alive": 0}, timeout=60)   # unload
    except urllib.error.HTTPError as e:
        res["error"] = e.read().decode(errors="ignore")[:200]
    except Exception as e:  # noqa: BLE001
        res["error"] = str(e)[:200]
    cache[key] = res
    CFG_DIR.mkdir(parents=True, exist_ok=True)
    FIT_CACHE.write_text(json.dumps(cache, indent=1))
    return res


def invalidate(model: str):
    """Called when a model fails at runtime with an out-of-memory error."""
    cache = _fit_cache()
    for k in list(cache):
        if f"|{model}|" in k:
            cache[k].update(gpu_frac=0.0, loads=False, error="runtime OOM", t=time.time())
    CFG_DIR.mkdir(parents=True, exist_ok=True)
    FIT_CACHE.write_text(json.dumps(cache, indent=1))


# ------------------------------------------------------------------ evaluation & selection
def evaluate(refresh: bool = False) -> Tuple[dict, List[dict]]:
    host = ollama_host()
    source = os.getenv("RTL_HW_SOURCE", load_cfg().get("hw_source", "auto")).lower()
    models = list_models()
    if source == "auto":
        source = "laptop" if is_local(host) else "probe"
    if source == "manual":
        c = load_cfg()
        hw = {"where": f"{host} (manual config)", "vram_gb": float(c.get("host_vram_gb", 0)),
              "ram_gb": float(c.get("host_ram_gb", 16)), "gpu": "manual"}
    elif source == "laptop":
        hw = detect_local_hw()
        if not is_local(host):
            hw["where"] = "this laptop (RTL_HW_SOURCE=laptop) - note: models run on " + host
    else:
        hw = {"where": f"{host} (measured by loading models)", "gpu": "measured", "vram_gb": None, "ram_gb": None}
    hw.update(source=source, host=host)

    # largest first, so probing can stop as soon as one fits completely
    models.sort(key=lambda m: -m["size"])
    full_found = False
    for m in models:
        ai = arch_info(m["name"])
        m.update(capability=capability(m), moe=ai.get("moe", False), need_gb=round(need_gb(m, DEFAULT_CTX), 1))
        if source == "probe":
            if full_found:
                m.update(gpu_frac=1.0, runs=True, how="fits (a larger model already fits)")
                continue
            f = probe_fit(m, DEFAULT_CTX, refresh)
            m.update(gpu_frac=f["gpu_frac"], runs=f["loads"], how=f.get("error") or
                     f"{f['gpu_frac']*100:.0f}% in GPU memory")
            full_found |= f["gpu_frac"] >= 0.95
        else:
            vram, ram = hw["vram_gb"] or 0, hw["ram_gb"] or 0
            m["gpu_frac"] = 1.0 if vram >= m["need_gb"] else round(max(vram, 0) / m["need_gb"], 2)
            m["runs"] = m["need_gb"] <= vram + ram * 0.85      # weights are mmap'ed; OS keeps ~15%
            m["how"] = f"needs ~{m['need_gb']} GB, GPU budget {vram} GB, RAM {ram} GB"
    return hw, models


def _cpu_usable(m: dict) -> bool:
    return m["moe"] or m["params_b"] <= 8.5


def choose(role: str, models: List[dict]) -> Tuple[Optional[dict], str]:
    allow_slow = os.getenv("RTL_ALLOW_SLOW", "0") == "1"
    full = [m for m in models if m.get("gpu_frac", 0) >= 0.95 and m.get("runs", True)]
    runs = [m for m in models if m.get("runs")]
    by_cap = lambda L: sorted(L, key=lambda m: -m["capability"])  # noqa: E731
    if role == "fast":
        pool = [m for m in full if m["params_b"] >= 3] or full or [m for m in runs if _cpu_usable(m)] or runs
        pick = min(pool, key=lambda m: m["size"]) if pool else None
        return pick, "smallest capable model that fits"
    if role == "balanced":
        pool = [m for m in full if m["params_b"] <= 17]
        if pool:
            return by_cap(pool)[0], "most capable model <=16B fully in GPU memory"
    if role in ("quality", "balanced"):
        if full:
            return by_cap(full)[0], "most capable model that fits completely in GPU memory"
        cpu = [m for m in runs if _cpu_usable(m) or allow_slow]
        if cpu:
            return by_cap(cpu)[0], "no model fits fully in GPU memory - best one that runs at usable speed"
        if runs:
            return by_cap(runs)[0], "only partially-offloaded models available (slow)"
    # nothing is known to fit: the smallest model is the only safe choice
    return (min(models, key=lambda m: m["size"]) if models else None), \
        "nothing measured as fitting - using the smallest installed model"


def ctx_for(m: dict, hw: dict) -> int:
    """Context window: as large as the memory budget allows, bounded by RTL_MAX_CTX."""
    vram = hw.get("vram_gb")
    kv = arch_info(m["name"]).get("kv_bytes_per_token") or 0
    if not vram or not kv:
        return DEFAULT_CTX
    free = vram * GB - m["size"] * 1.05 - 0.6 * GB
    ctx = 4096
    while ctx * 2 <= MAX_CTX and kv * ctx * 2 <= free:
        ctx *= 2
    return ctx


_SELECTED: Dict[str, Tuple[str, int]] = {}


def select(role: str = "quality", requested: Optional[str] = None, quiet: bool = False) -> Tuple[str, int]:
    """Return (model_name, num_ctx). An explicit model (not 'auto') always wins."""
    env = os.getenv("RTL_MODEL", "")
    explicit = requested if requested and requested != "auto" else (env if env and env != "auto" else None)
    if explicit:
        return explicit, DEFAULT_CTX
    if role in _SELECTED:
        return _SELECTED[role]
    try:
        hw, models = evaluate()
    except Exception as e:  # noqa: BLE001
        if not quiet:
            print(f"  [models] cannot query {ollama_host()} ({e}); using qwen2.5-coder:7b", file=sys.stderr)
        return "qwen2.5-coder:7b", DEFAULT_CTX
    m, why = choose(role, models)
    if not m:
        return "qwen2.5-coder:7b", DEFAULT_CTX
    res = (m["name"], ctx_for(m, hw))
    _SELECTED[role] = res
    if not quiet:
        print(f"  [models] {role}: {m['name']} (ctx {res[1]}) - {why}", file=sys.stderr)
    return res


def next_smaller(name: str) -> Optional[str]:
    """Runtime fallback after an out-of-memory error."""
    try:
        models = sorted(list_models(), key=lambda m: -m["size"])
    except Exception:  # noqa: BLE001
        return None
    names = [m["name"] for m in models]
    if name in names and names.index(name) + 1 < len(names):
        invalidate(name)
        _SELECTED.clear()
        return names[names.index(name) + 1]
    return None


def rtl_system_prompt() -> str:
    """The SYSTEM block of Modelfile.rtl, sent with every request so base models (which the
    remote host has) get the same RTL rules as the local custom `rtl-coder` model."""
    try:
        txt = (Path(__file__).resolve().parent / "Modelfile.rtl").read_text()
        m = re.search(r'SYSTEM\s+"""([\s\S]*?)"""', txt)
        return m.group(1).strip() if m else ""
    except Exception:  # noqa: BLE001
        return ""


# ------------------------------------------------------------------ report / CLI
def report(refresh: bool = False):
    hw, models = evaluate(refresh)
    print("==================================================")
    print("   Ollama model selection")
    print("==================================================")
    print(f"  Ollama host     : {hw['host']}  ({'this machine' if is_local(hw['host']) else 'remote'})")
    print(f"  Hardware source : {hw['source']}  ->  {hw['where']}")
    if hw.get("vram_gb") is not None:
        print(f"  GPU             : {hw['gpu']}  | usable GPU memory ~{hw['vram_gb']} GB | RAM {hw['ram_gb']} GB")
    print(f"\n  {'model':28} {'size':>7} {'params':>7} {'need@ctx':>9} {'in GPU':>7}  note")
    for m in models:
        print(f"  {m['name']:28} {m['size']/GB:6.1f}G {m['params_b']:6.1f}B {m['need_gb']:8.1f}G "
              f"{m['gpu_frac']*100:6.0f}%  {'MoE ' if m['moe'] else ''}{m['how']}")
    print("\n  Selection:")
    for role, use in (("quality", "rtl --rtl / --tb / --verify, spec2rtl --llm"),
                      ("balanced", "rtl --chat"), ("fast", "rtl --mem (spec -> JSON)")):
        m, why = choose(role, models)
        print(f"   {role:9} -> {m['name'] if m else '-':26} ctx {ctx_for(m, hw) if m else '-':>5}   [{use}]")
        print(f"   {'':9}    {why}")
    print("\n  Override any time with --model <name> or RTL_MODEL=<name>.")


def write_continue(path: str, template: Optional[str] = None):
    """VS Code Continue config pointing at the Ollama host, with the models it actually has
    (best first), the RTL system prompt, and the 'fast' pick for tab-autocomplete."""
    host = ollama_host()
    hw, models = evaluate()
    cfg = {}
    if template and Path(template).exists():
        cfg = json.loads(Path(template).read_text())
    ordered = sorted([m for m in models if m.get("runs", True)], key=lambda m: -m["capability"])
    sysmsg = rtl_system_prompt()
    cfg["models"] = [{"title": f"{m['name']} ({m['gpu_frac']*100:.0f}% GPU)", "provider": "ollama",
                      "model": m["name"], "apiBase": host, "systemMessage": sysmsg,
                      "contextLength": ctx_for(m, hw)} for m in ordered]
    fast, _ = choose("fast", models)
    if fast:
        cfg["tabAutocompleteModel"] = {"title": f"Autocomplete ({fast['name']})", "provider": "ollama",
                                       "model": fast["name"], "apiBase": host}
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(cfg, indent=2))
    print(f"  wrote {path}: {[m['model'] for m in cfg['models']]} @ {host}")


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(prog="rtl --models", description="Show / configure Ollama model selection")
    ap.add_argument("--set-host", help="Ollama URL of the machine running the models, e.g. http://192.168.1.50:11434")
    ap.add_argument("--hw-source", choices=["auto", "laptop", "manual"], help="where to measure hardware (default auto)")
    ap.add_argument("--host-vram-gb", type=float, help="manual mode: usable GPU memory on the Ollama host")
    ap.add_argument("--host-ram-gb", type=float, help="manual mode: RAM on the Ollama host")
    ap.add_argument("--reprobe", action="store_true", help="re-measure model fit on the Ollama host")
    ap.add_argument("--role", choices=["quality", "balanced", "fast"], help="print only the chosen model for a role")
    ap.add_argument("--write-continue", metavar="PATH", help="write a VS Code Continue config.json for this host")
    a = ap.parse_args(argv)
    cfg = load_cfg()
    if a.set_host:
        cfg["ollama_host"] = normalize_host(a.set_host)
    if a.hw_source:
        cfg["hw_source"] = a.hw_source
    if a.host_vram_gb is not None:
        cfg["host_vram_gb"] = a.host_vram_gb
    if a.host_ram_gb is not None:
        cfg["host_ram_gb"] = a.host_ram_gb
    if any([a.set_host, a.hw_source, a.host_vram_gb is not None, a.host_ram_gb is not None]):
        save_cfg(cfg)
        print(f"  saved {CFG_FILE}: {json.dumps(cfg)}")
    if a.role:
        print(select(a.role, quiet=True)[0])
        return 0
    if a.write_continue:
        write_continue(a.write_continue, str(Path(__file__).resolve().parent / "continue_config.json"))
        return 0
    try:
        report(a.reprobe)
    except Exception as e:  # noqa: BLE001
        print(f"[Error] cannot reach Ollama at {ollama_host()}: {e}")
        print("  On the Ollama machine run:  OLLAMA_HOST=0.0.0.0 ollama serve   (and allow port 11434 in its firewall)")
        print("  Then here:                  rtl --models --set-host http://<that-machine-ip>:11434")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
