"""
Spec2RTL + AutoUPF-AI SoC CAD Engine Package
Automated specification to synthesizable RTL, CDC/RDC constraints, IEEE 1801 UPF 2.1 power intent, SDC, and 45nm Gate Netlist synthesis.
"""

from .main import main

__all__ = ["main"]
