# Spec2RTL + AutoUPF-AI: Specification to Synthesizable RTL, CDC, UPF 2.1 & Gate Netlist Engine

`Spec2RTL + AutoUPF-AI` is an autonomous VLSI/SoC CAD framework that translates hardware specifications into synthesizable SystemVerilog RTL, generates Clock Domain Crossing (CDC) and Synopsys Design Constraints (SDC), synthesizes IEEE 1801 UPF 2.1 power intent, performs low-power alignment auditing, and maps designs to technology-mapped gate-level netlists.

---

## Operating Modes Overview

The framework provides two primary operating modes tailored for hardware engineering workflows, plus an audit mode:

| Mode | Command Flag | Workflow & Deliverables Generated |
| :--- | :--- | :--- |
| **1. RTL-Only Mode** | `--rtl-only` or `--mode rtl-only` | **1. Spec Ingestion & Non-Stub RTL:** Synthesizes complete SystemVerilog (`.sv`), register map decoders (`_regs.sv`), core logic (`_core.sv`), self-checking testbenches (`tb_*.sv`), and filelists (`files.f`).<br>**2. CDC & RDC Constraints:** Generates IP-level (`<ip>_cdc.sdc`) and SoC-level (`soc_cdc.sdc`) multi-clock CDC constraints with `set_clock_groups -asynchronous` and `set_property ASYNC_REG true`.<br>**3. Verification Suite:** Executes **Verilator Static Lint** (`-Wall`), **Structural CDC/RDC Check**, and **TB Simulation** (`simv`).<br>*(Skips UPF, SDC, gate synthesis, and netlist)* |
| **2. All Unified Mode** | `--all` or `--mode all` *(Default)* | **Runs All of Mode 1 above (RTL + CDC + Lint + CDC + TB)**<br>**PLUS:**<br>**4. Modular & Master UPF 2.1:** Synthesizes modular IP UPFs (`partitions/<ip>.upf`) and combined master SoC UPF (`soc_top.upf`) with Power State Tables (PST).<br>**5. RTL-UPF Alignment Audit:** Detects unisolated crossings, missing level shifters, and supply mismatches (`upf_rtl_alignment_report.json`).<br>**6. Synthesis SDC Constraints:** Generates comprehensive timing SDC (`soc_top.sdc`) covering clock uncertainties, I/O delays, drive strengths, and PMU false paths.<br>**7. Gate-Level Synthesis & Netlist:** Maps logic to NanGate 45nm standard cells and writes the final gate netlist (`soc_top_gate_netlist.v`) with 0 latches. |
| **3. UPF-Only Mode** | `--upf-only` | Audits existing RTL source trees against power configuration JSONs and outputs UPF 2.1 intent without re-synthesizing RTL. |

---

## Step-by-Step Execution Commands

### **Mode 1: RTL-Only Generation & Verification (`--rtl-only`)**

Use this mode for rapid front-end RTL design, register decoding, and structural verification without power intent or synthesis overhead.

#### 1. Default Benchmark Mode (H.264 Configuration Registers):
```bash
python3 main.py --rtl-only --output-dir output/rtl_run
```

#### 2. Run on a Specific Spec Document:
```bash
# Example: H.264 Configuration Registers Spec
python3 main.py --spec benchmarks/H264D-U1000_cfg_regs_spec.md \
               --name h264d_cfg_regs \
               --output-dir output/rtl_run \
               --rtl-only

# Example: H.264 Stream In Spec
python3 main.py --spec market_specs/H264D-U1000_stream_in_spec.md \
               --name h264d_stream_in \
               --output-dir output/stream_in_run \
               --rtl-only

# Example: Batch Generation across an entire Directory of Specs
python3 main.py --spec market_specs/ \
               --output-dir output/batch_run \
               --rtl-only

# Example: Batch Generation using Wildcard
python3 main.py --spec market_specs/*.md \
               --output-dir output/batch_run \
               --rtl-only
```

#### What Gets Executed & Verified in Mode 1:
```text
==============================================================================
 Spec2RTL + AutoUPF-AI Engine [Operating Mode: RTL-Only]
==============================================================================
[Stage 1: Spec-to-RTL Ingestion & Synthesis]
  ✔ Synthesized IP Module: h264d_cfg_regs (AXI4-Lite, 38 ports, 21 registers)
[Stage 2: CDC & RDC Constraints Generation]
  ✔ Generated IP CDC Constraints : output/rtl_run/generated_ip/h264d_cfg_regs/h264d_cfg_regs_cdc.sdc
  ✔ Generated SoC CDC Constraints: output/rtl_run/soc_cdc.sdc
[Stage 3: RTL Verification Suite (Lint, CDC, TB)]
  • [Verification 1/3] Verilator Static Lint      : LINT: CLEAN (PASS)
  • [Verification 2/3] Structural CDC/RDC Analysis: CDC Status: PASS (0 violations)
  • [Verification 3/3] Self-Checking TB Simulation: TEST PASSED (79 checks, 0 warnings)
==============================================================================
 PIPELINE EXECUTION SUCCESSFUL [Mode: RTL-Only]
  • Synthesized IP RTL     : ['h264d_cfg_regs_core.sv', 'h264d_cfg_regs_regs.sv', 'h264d_cfg_regs.sv']
  • IP CDC Constraints     : h264d_cfg_regs_cdc.sdc
  • SoC CDC Constraints    : soc_cdc.sdc
  • Verification Status    : Lint=PASS | CDC=PASS | TB=PASS
==============================================================================
```

---

### **Mode 2: All Unified Flow (`--all` or Full Default)**

Use this mode for complete end-to-end tapeout signoff from specification to verified 45nm gate-level netlist.

#### 1. Default Benchmark Mode:
```bash
python3 main.py --all --output-dir output/full_run
```

#### 2. Run with Custom Specs, Power Config & Filelist:
```bash
python3 main.py --spec benchmarks/H264D-U1000_cfg_regs_spec.md \
               --config benchmarks/power_config.json \
               --filelist benchmarks/soc_filelist.f \
               --output-dir output/full_run \
               --all
```

#### 3. Run on Multicore Market SoC Subsystem (6 Power Domains, 18 IPs):
```bash
python3 main.py --spec market_specs/H264D-U1000_cfg_regs_spec.md \
               --config benchmarks/power_config_market_soc.json \
               --filelist benchmarks/market_soc_filelist.f \
               --name soc_subsystem_top \
               --output-dir output/market_soc_run \
               --all
```

#### 4. Regenerate All 17 SoC IP Modules & Full Verification Suite:
```bash
python3 src/regenerate_all_ips.py
```
*Synthesizes non-stub functional RTL, generates CDC constraints, and verifies 100% of IPs with Verilator static lint and testbench simulation.*

#### What Gets Executed & Verified in Mode 2:
```text
==============================================================================
 Spec2RTL + AutoUPF-AI Engine [Operating Mode: Unified (All)]
==============================================================================
[Stage 1: Spec-to-RTL Ingestion & Synthesis]
  ✔ Synthesized IP Module: h264d_cfg_regs (AXI4-Lite, 38 ports, 21 registers)
[Stage 2: CDC & RDC Constraints Generation]
  ✔ Generated IP CDC Constraints : output/full_run/generated_ip/h264d_cfg_regs/h264d_cfg_regs_cdc.sdc
  ✔ Generated SoC CDC Constraints: output/full_run/soc_cdc.sdc
[Stage 3: RTL Verification Suite (Lint, CDC, TB)]
  • [Verification 1/3] Verilator Static Lint      : LINT: CLEAN (PASS)
  • [Verification 2/3] Structural CDC/RDC Analysis: CDC Status: PASS (0 violations)
  • [Verification 3/3] Self-Checking TB Simulation: TEST PASSED (79 checks, 0 warnings)
[Stage 4: Low-Power Intent & IEEE 1801 UPF 2.1 Generation]
  ✔ Generated Modular IP UPF: output/full_run/partitions/h264d_cfg_regs.upf
  ✔ Generated Master SoC UPF: output/full_run/soc_top.upf
  ✔ RTL-UPF Alignment Audit : output/full_run/upf_rtl_alignment_report.json
[Stage 5: Synopsys Design Constraints (SDC) Generation]
  ✔ Generated SoC Top-Level SDC: output/full_run/soc_top.sdc
[Stage 6: Gate-Level Synthesis & Netlist Generation]
  • Running Standard-Cell Technology Mapping Synthesis (NanGate45)...
  ✔ Generated Gate-Level Netlist: output/full_run/soc_top_gate_netlist.v
    - Standard Cells Mapped : 7,520 (DFF: 376, Combinational: 7,144)
    - Target Library        : NanGate45
    - Latch Check           : PASS (0 latches, 0 multi-drivers)
==============================================================================
 PIPELINE EXECUTION SUCCESSFUL [Mode: Unified (All)]
  • Synthesized IP RTL     : h264d_cfg_regs_core.sv, h264d_cfg_regs_regs.sv, h264d_cfg_regs.sv
  • IP CDC Constraints     : h264d_cfg_regs_cdc.sdc
  • SoC CDC Constraints    : soc_cdc.sdc
  • Verification Status    : Lint=PASS | CDC=PASS | TB=PASS
  • IP Modular UPF         : partitions/h264d_cfg_regs.upf
  • SoC Master UPF         : soc_top.upf
  • SoC SDC Constraints    : soc_top.sdc
  • Gate-Level Netlist     : soc_top_gate_netlist.v
  • UPF-RTL Audit JSON     : upf_rtl_alignment_report.json
==============================================================================
```

---

## Directory Structure of Generated Deliverables

```text
output/
├── soc_top_gate_netlist.v           # [Mode 2] Synthesized 45nm Gate-Level Structural Netlist
├── soc_top.sdc                     # [Mode 2] Synopsys Design Constraints (Timing, IO, False Paths)
├── soc_top.upf                     # [Mode 2] IEEE 1801 Master SoC UPF 2.1 (Domains, PST, Switches)
├── soc_cdc.sdc                     # [Mode 1 & 2] Top-Level SoC Multi-Clock CDC Constraints
├── upf_rtl_alignment_report.json   # [Mode 2] Automated RTL vs UPF Alignment Bug Audit Report
├── partitions/                     # [Mode 2] Modular Partition UPF Intent Files
│   ├── pd_cpu.upf
│   ├── pd_video.upf
│   ├── pd_aon.upf
│   └── <ip_module>.upf
└── generated_ip/
    └── <ip_module>/
        ├── spec.json               # Parsed Specification JSON Schema
        ├── files.f                 # EDA Tool Filelist
        ├── <ip_module>_cdc.sdc     # [Mode 1 & 2] Dedicated IP Clock Domain Crossing Constraints
        ├── rtl/
        │   ├── <ip_module>.sv      # Top-Level Synthesizable SystemVerilog Wrapper
        │   ├── <ip_module>_core.sv # 100% Non-Stub Functional Core (FSMs, Counters, Handshakes)
        │   └── <ip_module>_regs.sv # Address Decoder & Register Interface Map
        └── tb/
            └── tb_<ip_module>.sv   # Self-Checking Simulation Testbench
```

---

## Detailed Command-Line Options Reference

| Option | Shorthand | Applicable Modes | Description |
| :--- | :--- | :--- | :--- |
| `--rtl-only` | | Mode 1 | Run RTL generation, CDC constraints & Lint/CDC/TB verification ONLY. Skips UPF, SDC, synth & netlist. |
| `--all` | | Mode 2 | Run complete flow: RTL + CDC + Verif + UPF 2.1 + SDC + Gate Synthesis + Netlist. |
| `--mode` | | All | Set execution mode explicitly: `--mode rtl-only` or `--mode all`. |
| `--upf-only`| | Mode 3 | Audit existing RTL against power configs and generate UPF 2.1 without synthesizing new RTL. |
| `--spec` | `-s` | Mode 1 & 2 | Path to input specification document(s) (`.md`, `.pdf`, `.docx`, `.xlsx`, `.csv`). |
| `--config` | `-c` | Mode 2 & 3 | Path to JSON power domain and supply voltage configuration file (`power_config.json`). |
| `--filelist`| `-fl`| Mode 2 & 3 | Path to SoC EDA filelist (`.f`, `.flist`, `.vc`). |
| `--output-dir`| `-o`| All | Target directory where RTL, UPF, SDC, reports, and gate netlists are saved. |
| `--name` | | All | Override the target IP module name. |
| `--llm` | | Mode 1 & 2 | Optional: Use LLM inference to complete custom algorithmic datapath core logic. |
| `--non-interactive` | | All | Run in headless non-interactive mode. |

---

## Presentation & Publication Package Files Included

The repository and master archive (`Spec2RTL_UPF_Framework_and_Docs.zip`) bundle the complete submission assets:
1. **PowerPoint Pitch Deck:** [`presentation_idea_submission.pptx`](presentation_idea_submission.pptx) & [`presentation_idea_submission_clean.pptx`](presentation_idea_submission_clean.pptx) (OpenXML compliant, 7 widescreen slides).
2. **Beamer PDF Presentation:** [`presentation_idea_submission.pdf`](presentation_idea_submission.pdf) (Compiled with LaTeX `pdflatex`).
3. **Interactive Web Presentation:** [`presentation_idea_submission.html`](presentation_idea_submission.html) (Self-contained interactive HTML/Tailwind deck).
4. **Conference Research Paper:** [`paper_soc_spec2rtl_upf.tex`](paper_soc_spec2rtl_upf.tex) (Double-column IEEEtran layout).
5. **Implementation Plan & Architectural Spec:** [`IMPLEMENTATION_PLAN.md`](IMPLEMENTATION_PLAN.md).
