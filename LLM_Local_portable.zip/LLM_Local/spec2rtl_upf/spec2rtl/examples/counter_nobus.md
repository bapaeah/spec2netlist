Module Name: cnt8
| Port | Dir | Width | Description |
|--|--|--|--|
| clk | in | 1 | clock 50 MHz |
| rst | in | 1 | synchronous reset, active high |
| en | in | 1 | enable |
| q | out | 8 | count |
