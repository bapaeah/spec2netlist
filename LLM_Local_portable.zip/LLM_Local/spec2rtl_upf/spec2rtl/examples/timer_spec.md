# Timer IP Specification
Module Name: apb_timer
Target Frequency: 100 MHz (clk)
The reset is asynchronous active-low.

## Ports
| Port Name | Dir | Width | Description |
|---|---|---|---|
| clk | IN | 1 | System clock input (100 MHz) |
| rst_n | IN | 1 | Active-low reset |
| s_paddr | IN | [7:0] | APB address |
| s_psel | IN | 1 | select |
| s_penable | IN | 1 | enable |
| s_pwrite | IN | 1 | write |
| s_pwdata | IN | 32 | write data |
| s_pstrb | IN | 4 | byte strobes |
| s_prdata | OUT | 32 | read data |
| s_pready | OUT | 1 | ready |
| s_pslverr | OUT | 1 | error |
| irq | OUT | 1 | Interrupt |
| ext_evt | IN | 1 | external event |

## Registers
| Offset | Name | Reset | Access | Description |
|---|---|---|---|---|
| 0x00 | CTRL | 0x0 | RW | [0] en, [1] ie, [3:2] mode |
| 0x04 | LOAD | 0xFFFF | RW | [15:0] load |
| 0x08 | COUNT | 0x0 | RO | [15:0] value |
| 0x0C | INTSTAT | 0x0 | W1C | [0] tick, [1] evt |
| 0x10 | CMD | 0x0 | WO | [0] restart |
