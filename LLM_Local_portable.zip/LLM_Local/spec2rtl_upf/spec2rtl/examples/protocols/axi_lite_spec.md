# Timer (axi_lite)

Module Name: tmr_axi_lite

Reset: Active-low reset, synchronous reset.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| s_axil_aclk | in | 1 | AXI clock 250 MHz |
| s_axil_aresetn | in | 1 |  |
| s_axil_awaddr | in | [11:0] |  |
| s_axil_awprot | in | [2:0] |  |
| s_axil_awvalid | in | 1 |  |
| s_axil_awready | out | 1 |  |
| s_axil_wdata | in | [31:0] |  |
| s_axil_wstrb | in | [3:0] |  |
| s_axil_wvalid | in | 1 |  |
| s_axil_wready | out | 1 |  |
| s_axil_bresp | out | [1:0] |  |
| s_axil_bvalid | out | 1 |  |
| s_axil_bready | in | 1 |  |
| s_axil_araddr | in | [11:0] |  |
| s_axil_arprot | in | [2:0] |  |
| s_axil_arvalid | in | 1 |  |
| s_axil_arready | out | 1 |  |
| s_axil_rdata | out | [31:0] |  |
| s_axil_rresp | out | [1:0] |  |
| s_axil_rvalid | out | 1 |  |
| s_axil_rready | in | 1 |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
