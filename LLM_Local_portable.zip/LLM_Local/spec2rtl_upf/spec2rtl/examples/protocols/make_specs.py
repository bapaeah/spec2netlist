#!/usr/bin/env python3
"""Generates one small timer-like spec per bus protocol (used by `make regress`)."""
from pathlib import Path

REGS = """
| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |
"""
# (name, reset-desc, [(port, dir, width, desc)])
X = lambda *a: a  # noqa: E731
P = {
 "apb4": ("Active-low asynchronous reset", [X("pclk","in",1,"APB clock, 100 MHz"), X("presetn","in",1,"Active-low reset"),
   X("paddr","in","[11:0]",""), X("psel","in",1,""), X("penable","in",1,""), X("pwrite","in",1,""), X("pwdata","in","[31:0]",""),
   X("pstrb","in","[3:0]",""), X("pprot","in","[2:0]",""), X("prdata","out","[31:0]",""), X("pready","out",1,""), X("pslverr","out",1,"")]),
 "apb2": ("Active-low asynchronous reset", [X("pclk","in",1,"APB clock, 50 MHz"), X("presetn","in",1,""),
   X("paddr","in","[7:0]",""), X("psel","in",1,""), X("penable","in",1,""), X("pwrite","in",1,""), X("pwdata","in","[31:0]",""),
   X("prdata","out","[31:0]","")]),
 "ahb_lite": ("Active-low asynchronous reset", [X("hclk","in",1,"AHB clock 200 MHz"), X("hresetn","in",1,""),
   X("hsel","in",1,""), X("haddr","in","[15:0]",""), X("htrans","in","[1:0]",""), X("hwrite","in",1,""), X("hsize","in","[2:0]",""),
   X("hburst","in","[2:0]",""), X("hprot","in","[3:0]",""), X("hmastlock","in",1,""), X("hwdata","in","[31:0]",""),
   X("hready","in",1,"HREADY from interconnect"), X("hreadyout","out",1,""), X("hresp","out",1,""), X("hrdata","out","[31:0]","")]),
 "ahb5": ("Active-low asynchronous reset", [X("hclk","in",1,"AHB clock 200 MHz"), X("hresetn","in",1,""),
   X("hselx","in",1,""), X("haddr","in","[15:0]",""), X("htrans","in","[1:0]",""), X("hwrite","in",1,""), X("hsize","in","[2:0]",""),
   X("hwstrb","in","[3:0]",""), X("hnonsec","in",1,""), X("hwdata","in","[31:0]",""),
   X("hreadyout","out",1,""), X("hresp","out",1,""), X("hrdata","out","[31:0]","")]),
 "axi_lite": ("Active-low reset, synchronous reset", [X("s_axil_aclk","in",1,"AXI clock 250 MHz"), X("s_axil_aresetn","in",1,""),
   *[X("s_axil_"+n,d,w,"") for n,d,w in [("awaddr","in","[11:0]"),("awprot","in","[2:0]"),("awvalid","in",1),("awready","out",1),
   ("wdata","in","[31:0]"),("wstrb","in","[3:0]"),("wvalid","in",1),("wready","out",1),("bresp","out","[1:0]"),("bvalid","out",1),
   ("bready","in",1),("araddr","in","[11:0]"),("arprot","in","[2:0]"),("arvalid","in",1),("arready","out",1),("rdata","out","[31:0]"),
   ("rresp","out","[1:0]"),("rvalid","out",1),("rready","in",1)]]]),
}
full = [("awid","in","[3:0]"),("awaddr","in","[15:0]"),("awlen","in","[7:0]"),("awsize","in","[2:0]"),("awburst","in","[1:0]"),
        ("awlock","in",1),("awcache","in","[3:0]"),("awprot","in","[2:0]"),("awqos","in","[3:0]"),("awvalid","in",1),("awready","out",1),
        ("wdata","in","[31:0]"),("wstrb","in","[3:0]"),("wlast","in",1),("wvalid","in",1),("wready","out",1),
        ("bid","out","[3:0]"),("bresp","out","[1:0]"),("bvalid","out",1),("bready","in",1),
        ("arid","in","[3:0]"),("araddr","in","[15:0]"),("arlen","in","[7:0]"),("arsize","in","[2:0]"),("arburst","in","[1:0]"),
        ("arlock","in",1),("arcache","in","[3:0]"),("arprot","in","[2:0]"),("arqos","in","[3:0]"),("arvalid","in",1),("arready","out",1),
        ("rid","out","[3:0]"),("rdata","out","[31:0]"),("rresp","out","[1:0]"),("rlast","out",1),("rvalid","out",1),("rready","in",1)]
clk = [X("aclk","in",1,"AXI clock 400 MHz"), X("aresetn","in",1,"active-low")]
P["axi4"] = ("Active-low asynchronous reset", clk + [X("s_axi_"+n,d,w,"") for n,d,w in full])
axi3 = [(n, d, "[3:0]" if n in ("awlen", "arlen") else w) for n, d, w in full] + [("wid","in","[3:0]")]
P["axi3"] = ("Active-low asynchronous reset", clk + [X("s_axi_"+n,d,w,"") for n,d,w in axi3])
acel = full + [("awdomain","in","[1:0]"),("awsnoop","in","[2:0]"),("awbar","in","[1:0]"),
               ("ardomain","in","[1:0]"),("arsnoop","in","[3:0]"),("arbar","in","[1:0]")]
P["ace_lite"] = ("Active-low asynchronous reset", clk + [X("s_ace_"+n,d,w,"") for n,d,w in acel])
ace = [(n, d, "[3:0]" if n == "rresp" else w) for n, d, w in acel] + [
    ("rack","in",1),("wack","in",1),("acvalid","in",1),("acready","out",1),("acaddr","in","[15:0]"),("acsnoop","in","[3:0]"),
    ("acprot","in","[2:0]"),("crvalid","out",1),("crready","in",1),("crresp","out","[4:0]"),
    ("cdvalid","out",1),("cdready","in",1),("cddata","out","[31:0]"),("cdlast","out",1)]
P["ace"] = ("Active-low asynchronous reset", clk + [X("s_ace_"+n,d,w,"") for n,d,w in ace])
wb = [X("wb_clk_i","in",1,"Wishbone clock 100 MHz"), X("wb_rst_i","in",1,"Active-high reset"),
      X("wb_adr_i","in","[7:0]",""), X("wb_dat_i","in","[31:0]",""), X("wb_dat_o","out","[31:0]",""), X("wb_we_i","in",1,""),
      X("wb_sel_i","in","[3:0]",""), X("wb_stb_i","in",1,""), X("wb_cyc_i","in",1,""), X("wb_ack_o","out",1,""), X("wb_err_o","out",1,""),
      X("wb_rty_o","out",1,""), X("wb_cti_i","in","[2:0]",""), X("wb_bte_i","in","[1:0]","")]
P["wishbone"] = ("Synchronous reset, active-high", wb)
P["wishbone_pipe"] = ("Synchronous reset, active-high", wb + [X("wb_stall_o","out",1,"")])
av = [X("clk","in",1,"Clock 150 MHz"), X("reset","in",1,"Active-high reset"),
      X("avs_address","in","[5:0]","word address"), X("avs_read","in",1,""), X("avs_write","in",1,""), X("avs_writedata","in","[31:0]",""),
      X("avs_byteenable","in","[3:0]",""), X("avs_readdata","out","[31:0]",""), X("avs_waitrequest","out",1,""),
      X("avs_response","out","[1:0]","")]
P["avalon"] = ("Active-high asynchronous reset", av)
P["avalon_pipe"] = ("Active-high asynchronous reset", av + [X("avs_readdatavalid","out",1,""), X("avs_writeresponsevalid","out",1,"")])
P["tilelink"] = ("Active-low asynchronous reset", [X("clk_i","in",1,"Clock 100 MHz"), X("rst_ni","in",1,"active-low")] +
   [X("tl_"+n,d,w,"") for n,d,w in [("a_valid","in",1),("a_ready","out",1),("a_opcode","in","[2:0]"),("a_param","in","[2:0]"),
   ("a_size","in","[1:0]"),("a_source","in","[7:0]"),("a_address","in","[31:0]"),("a_mask","in","[3:0]"),("a_data","in","[31:0]"),
   ("d_valid","out",1),("d_ready","in",1),("d_opcode","out","[2:0]"),("d_param","out","[2:0]"),("d_size","out","[1:0]"),
   ("d_source","out","[7:0]"),("d_sink","out",1),("d_data","out","[31:0]"),("d_error","out",1)]])
P["obi"] = ("Active-low asynchronous reset", [X("clk_i","in",1,"Clock 100 MHz"), X("rst_ni","in",1,"active-low")] +
   [X("obi_"+n,d,w,"") for n,d,w in [("req_i","in",1),("gnt_o","out",1),("addr_i","in","[31:0]"),("we_i","in",1),("be_i","in","[3:0]"),
   ("wdata_i","in","[31:0]"),("rvalid_o","out",1),("rdata_o","out","[31:0]"),("err_o","out",1)]])

out = Path(__file__).parent
for name, (rst, ports) in P.items():
    rows = "\n".join(f"| {p} | {d} | {w} | {ds} |" for p, d, w, ds in ports)
    (out / f"{name}_spec.md").write_text(
        f"# Timer ({name})\n\nModule Name: tmr_{name}\n\nReset: {rst}.\n\n## Ports\n\n"
        f"| Port | Dir | Width | Description |\n|---|---|---|---|\n{rows}\n\n## Registers\n{REGS}\n"
        "## Functional description\nThe timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.\n")
print("specs:", ", ".join(sorted(P)))
