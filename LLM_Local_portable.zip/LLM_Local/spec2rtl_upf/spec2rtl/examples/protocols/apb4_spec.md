# Timer (apb4)

Module Name: tmr_apb4

Reset: Active-low asynchronous reset.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| pclk | in | 1 | APB clock, 100 MHz |
| presetn | in | 1 | Active-low reset |
| paddr | in | [11:0] |  |
| psel | in | 1 |  |
| penable | in | 1 |  |
| pwrite | in | 1 |  |
| pwdata | in | [31:0] |  |
| pstrb | in | [3:0] |  |
| pprot | in | [2:0] |  |
| prdata | out | [31:0] |  |
| pready | out | 1 |  |
| pslverr | out | 1 |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
