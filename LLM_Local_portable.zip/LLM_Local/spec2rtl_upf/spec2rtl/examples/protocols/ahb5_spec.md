# Timer (ahb5)

Module Name: tmr_ahb5

Reset: Active-low asynchronous reset.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| hclk | in | 1 | AHB clock 200 MHz |
| hresetn | in | 1 |  |
| hselx | in | 1 |  |
| haddr | in | [15:0] |  |
| htrans | in | [1:0] |  |
| hwrite | in | 1 |  |
| hsize | in | [2:0] |  |
| hwstrb | in | [3:0] |  |
| hnonsec | in | 1 |  |
| hwdata | in | [31:0] |  |
| hreadyout | out | 1 |  |
| hresp | out | 1 |  |
| hrdata | out | [31:0] |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
