# Timer (axi3)

Module Name: tmr_axi3

Reset: Active-low asynchronous reset.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| aclk | in | 1 | AXI clock 400 MHz |
| aresetn | in | 1 | active-low |
| s_axi_awid | in | [3:0] |  |
| s_axi_awaddr | in | [15:0] |  |
| s_axi_awlen | in | [3:0] |  |
| s_axi_awsize | in | [2:0] |  |
| s_axi_awburst | in | [1:0] |  |
| s_axi_awlock | in | 1 |  |
| s_axi_awcache | in | [3:0] |  |
| s_axi_awprot | in | [2:0] |  |
| s_axi_awqos | in | [3:0] |  |
| s_axi_awvalid | in | 1 |  |
| s_axi_awready | out | 1 |  |
| s_axi_wdata | in | [31:0] |  |
| s_axi_wstrb | in | [3:0] |  |
| s_axi_wlast | in | 1 |  |
| s_axi_wvalid | in | 1 |  |
| s_axi_wready | out | 1 |  |
| s_axi_bid | out | [3:0] |  |
| s_axi_bresp | out | [1:0] |  |
| s_axi_bvalid | out | 1 |  |
| s_axi_bready | in | 1 |  |
| s_axi_arid | in | [3:0] |  |
| s_axi_araddr | in | [15:0] |  |
| s_axi_arlen | in | [3:0] |  |
| s_axi_arsize | in | [2:0] |  |
| s_axi_arburst | in | [1:0] |  |
| s_axi_arlock | in | 1 |  |
| s_axi_arcache | in | [3:0] |  |
| s_axi_arprot | in | [2:0] |  |
| s_axi_arqos | in | [3:0] |  |
| s_axi_arvalid | in | 1 |  |
| s_axi_arready | out | 1 |  |
| s_axi_rid | out | [3:0] |  |
| s_axi_rdata | out | [31:0] |  |
| s_axi_rresp | out | [1:0] |  |
| s_axi_rlast | out | 1 |  |
| s_axi_rvalid | out | 1 |  |
| s_axi_rready | in | 1 |  |
| s_axi_wid | in | [3:0] |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
