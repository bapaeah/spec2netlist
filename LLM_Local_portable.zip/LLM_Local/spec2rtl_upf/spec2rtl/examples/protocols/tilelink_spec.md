# Timer (tilelink)

Module Name: tmr_tilelink

Reset: Active-low asynchronous reset.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| clk_i | in | 1 | Clock 100 MHz |
| rst_ni | in | 1 | active-low |
| tl_a_valid | in | 1 |  |
| tl_a_ready | out | 1 |  |
| tl_a_opcode | in | [2:0] |  |
| tl_a_param | in | [2:0] |  |
| tl_a_size | in | [1:0] |  |
| tl_a_source | in | [7:0] |  |
| tl_a_address | in | [31:0] |  |
| tl_a_mask | in | [3:0] |  |
| tl_a_data | in | [31:0] |  |
| tl_d_valid | out | 1 |  |
| tl_d_ready | in | 1 |  |
| tl_d_opcode | out | [2:0] |  |
| tl_d_param | out | [2:0] |  |
| tl_d_size | out | [1:0] |  |
| tl_d_source | out | [7:0] |  |
| tl_d_sink | out | 1 |  |
| tl_d_data | out | [31:0] |  |
| tl_d_error | out | 1 |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
