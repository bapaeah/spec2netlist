# Timer (wishbone)

Module Name: tmr_wishbone

Reset: Synchronous reset, active-high.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| wb_clk_i | in | 1 | Wishbone clock 100 MHz |
| wb_rst_i | in | 1 | Active-high reset |
| wb_adr_i | in | [7:0] |  |
| wb_dat_i | in | [31:0] |  |
| wb_dat_o | out | [31:0] |  |
| wb_we_i | in | 1 |  |
| wb_sel_i | in | [3:0] |  |
| wb_stb_i | in | 1 |  |
| wb_cyc_i | in | 1 |  |
| wb_ack_o | out | 1 |  |
| wb_err_o | out | 1 |  |
| wb_rty_o | out | 1 |  |
| wb_cti_i | in | [2:0] |  |
| wb_bte_i | in | [1:0] |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
