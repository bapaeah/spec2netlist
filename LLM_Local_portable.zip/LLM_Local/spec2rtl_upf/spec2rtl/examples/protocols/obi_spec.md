# Timer (obi)

Module Name: tmr_obi

Reset: Active-low asynchronous reset.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| clk_i | in | 1 | Clock 100 MHz |
| rst_ni | in | 1 | active-low |
| obi_req_i | in | 1 |  |
| obi_gnt_o | out | 1 |  |
| obi_addr_i | in | [31:0] |  |
| obi_we_i | in | 1 |  |
| obi_be_i | in | [3:0] |  |
| obi_wdata_i | in | [31:0] |  |
| obi_rvalid_o | out | 1 |  |
| obi_rdata_o | out | [31:0] |  |
| obi_err_o | out | 1 |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
