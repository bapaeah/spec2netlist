# Timer (ace_lite)

Module Name: tmr_ace_lite

Reset: Active-low asynchronous reset.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| aclk | in | 1 | AXI clock 400 MHz |
| aresetn | in | 1 | active-low |
| s_ace_awid | in | [3:0] |  |
| s_ace_awaddr | in | [15:0] |  |
| s_ace_awlen | in | [7:0] |  |
| s_ace_awsize | in | [2:0] |  |
| s_ace_awburst | in | [1:0] |  |
| s_ace_awlock | in | 1 |  |
| s_ace_awcache | in | [3:0] |  |
| s_ace_awprot | in | [2:0] |  |
| s_ace_awqos | in | [3:0] |  |
| s_ace_awvalid | in | 1 |  |
| s_ace_awready | out | 1 |  |
| s_ace_wdata | in | [31:0] |  |
| s_ace_wstrb | in | [3:0] |  |
| s_ace_wlast | in | 1 |  |
| s_ace_wvalid | in | 1 |  |
| s_ace_wready | out | 1 |  |
| s_ace_bid | out | [3:0] |  |
| s_ace_bresp | out | [1:0] |  |
| s_ace_bvalid | out | 1 |  |
| s_ace_bready | in | 1 |  |
| s_ace_arid | in | [3:0] |  |
| s_ace_araddr | in | [15:0] |  |
| s_ace_arlen | in | [7:0] |  |
| s_ace_arsize | in | [2:0] |  |
| s_ace_arburst | in | [1:0] |  |
| s_ace_arlock | in | 1 |  |
| s_ace_arcache | in | [3:0] |  |
| s_ace_arprot | in | [2:0] |  |
| s_ace_arqos | in | [3:0] |  |
| s_ace_arvalid | in | 1 |  |
| s_ace_arready | out | 1 |  |
| s_ace_rid | out | [3:0] |  |
| s_ace_rdata | out | [31:0] |  |
| s_ace_rresp | out | [1:0] |  |
| s_ace_rlast | out | 1 |  |
| s_ace_rvalid | out | 1 |  |
| s_ace_rready | in | 1 |  |
| s_ace_awdomain | in | [1:0] |  |
| s_ace_awsnoop | in | [2:0] |  |
| s_ace_awbar | in | [1:0] |  |
| s_ace_ardomain | in | [1:0] |  |
| s_ace_arsnoop | in | [3:0] |  |
| s_ace_arbar | in | [1:0] |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
