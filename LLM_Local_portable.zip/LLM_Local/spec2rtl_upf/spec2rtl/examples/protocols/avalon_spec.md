# Timer (avalon)

Module Name: tmr_avalon

Reset: Active-high asynchronous reset.

## Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| clk | in | 1 | Clock 150 MHz |
| reset | in | 1 | Active-high reset |
| avs_address | in | [5:0] | word address |
| avs_read | in | 1 |  |
| avs_write | in | 1 |  |
| avs_writedata | in | [31:0] |  |
| avs_byteenable | in | [3:0] |  |
| avs_readdata | out | [31:0] |  |
| avs_waitrequest | out | 1 |  |
| avs_response | out | [1:0] |  |

## Registers

| Offset | Name    | Access | Reset      | Description                         |
|--------|---------|--------|------------|-------------------------------------|
| 0x00   | CTRL    | RW     | 0x00000001 | [0] en, [3:1] mode, [15:8] prescale |
| 0x04   | STATUS  | RO     | 0x00000000 | [0] busy, [7:4] level               |
| 0x08   | IRQ     | W1C    | 0x00000000 | [0] done, [1] ovf                   |
| 0x0C   | TXDATA  | WO     | 0x00000000 | [31:0] data                         |
| 0x10   | SCRATCH | RW     | 0x12345678 | Scratch register                    |
| 0x14   | LOAD    | RW     | 0x00000000 | Reload value                        |

## Functional description
The timer counts down from LOAD when CTRL.en is set and raises IRQ.done at zero.
