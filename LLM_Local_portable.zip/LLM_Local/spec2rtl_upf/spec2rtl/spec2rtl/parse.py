"""Heuristic spec parser: text + tables -> normalized spec dict (spec.json).

The spec.json is the contract between parsing and generation. Always review
it (and edit if needed) before generating RTL.
"""
from __future__ import annotations
import re

SV_KEYWORDS = {"input", "output", "inout", "logic", "wire", "reg", "module",
               "begin", "end", "case", "default", "assign", "always", "type",
               "disable", "int", "bit", "byte", "event", "final"}


def ident(s: str) -> str:
    s = re.sub(r"\[.*?\]", "", s or "")
    s = re.sub(r"[^A-Za-z0-9_]", "_", s.strip()).strip("_").lower()
    s = re.sub(r"_+", "_", s)
    if not s or s[0].isdigit():
        s = "f_" + s
    if s in SV_KEYWORDS:
        s = s + "_f"
    return s


def to_int(s, default=0):
    if s is None:
        return default
    s = str(s).strip().replace("_", "")
    m = re.search(r"(?:(\d+)'[hH]([0-9a-fA-F]+))|(0[xX][0-9a-fA-F]+)|(\d+)", s)
    if not m:
        return default
    if m.group(2):
        return int(m.group(2), 16)
    if m.group(3):
        return int(m.group(3), 16)
    return int(m.group(4))


def col(header, *keys):
    for i, h in enumerate(header):
        hl = h.lower()
        if any(k in hl for k in keys):
            return i
    return None


# ---------------------------------------------------------------- ports
def parse_ports(tables):
    ports = []
    for t in tables:
        h = t[0]
        ci_dir = col(h, "dir", "i/o", "type", "domain")
        ci_name = col(h, "port", "signal", "pin", "name", "clock", "reset")
        if ci_name is None:
            continue
        ci_w = col(h, "width", "size", "bits")
        ci_d = col(h, "desc", "function", "comment", "used for", "behavior", "notes")
        for r in t[1:]:
            if len(r) <= ci_name:
                continue
            raw_name = r[ci_name]
            if not raw_name or not re.search(r"[A-Za-z0-9_]", raw_name):
                continue
            direction = None
            if ci_dir is not None and ci_dir < len(r):
                d = r[ci_dir].lower()
                if d.startswith("in") and "out" in d:
                    direction = "inout"
                elif d.startswith("i"):
                    direction = "input"
                elif d.startswith("o"):
                    direction = "output"
            if not direction:
                if re.search(r"clk|clock|rst|reset", raw_name, re.I):
                    direction = "input"
                else:
                    continue
            width = 1
            m = re.search(r"\[(\d+)\s*:\s*(\d+)\]", raw_name)
            if m:
                width = abs(int(m.group(1)) - int(m.group(2))) + 1
            if ci_w is not None and ci_w < len(r) and r[ci_w]:
                m2 = re.search(r"\[(\d+)\s*:\s*(\d+)\]", r[ci_w])
                width = (abs(int(m2.group(1)) - int(m2.group(2))) + 1) if m2 \
                    else to_int(r[ci_w], width) or width
            ports.append({"name": ident(raw_name), "dir": direction,
                          "width": width,
                          "desc": r[ci_d] if ci_d is not None and ci_d < len(r) else ""})
    # de-dup keep first
    seen, out = set(), []
    for p in ports:
        if p["name"] not in seen:
            seen.add(p["name"])
            out.append(p)
    return out



# ---------------------------------------------------------------- registers
ACCESS_MAP = [("core", "CORE"), ("once", "RW"), ("w1c", "W1C"), ("w1s", "W1S"), ("rc", "RC"), ("r/w", "RW"),
              ("rw", "RW"), ("wo", "WO"), ("w/o", "WO"), ("write", "WO"),
              ("ro", "RO"), ("r/o", "RO"), ("read", "RO")]


def norm_access(s: str) -> str:
    s = (s or "").lower().replace(" ", "")
    for k, v in ACCESS_MAP:
        if k in s:
            return v
    return "RW"


FIELD_RE = re.compile(r"(?:\[(\d+)(?:\s*:\s*(\d+))?\]|\bb(\d+)(?::(\d+))?)\s+([A-Za-z_][A-Za-z0-9_]*)")


def parse_fields(desc, reg_name, reg_access, reg_reset, dw):
    fields = []
    for m in FIELD_RE.finditer(desc or ""):
        g1, g2 = (m.group(1), m.group(2)) if m.group(1) is not None else (m.group(3), m.group(4))
        msb = int(g1)
        lsb = int(g2) if g2 is not None else msb
        msb, lsb = max(msb, lsb), min(msb, lsb)
        if msb >= dw:
            continue
        # per-field access override, e.g. "[4] err (W1C)"
        tail = desc[m.end():m.end() + 25]
        acc = reg_access
        mo = re.match(r"\s*\((W1C|W1S|RC|RO|RW|WO|CORE)\)", tail, re.I)
        if mo:
            acc = mo.group(1).upper()
        name = ident(m.group(5))
        # strip trailing index e.g. tx_count[3:0] already handled by regex
        fields.append({"name": name, "msb": msb, "lsb": lsb, "access": acc,
                       "reset": (reg_reset >> lsb) & ((1 << (msb - lsb + 1)) - 1),
                       "desc": ""})
    if not fields:
        fields = [{"name": ident(reg_name), "msb": dw - 1, "lsb": 0,
                   "access": reg_access, "reset": reg_reset, "desc": ""}]
    # drop overlaps (keep first)
    used, out = 0, []
    for f in fields:
        mask = ((1 << (f["msb"] - f["lsb"] + 1)) - 1) << f["lsb"]
        if used & mask:
            continue
        used |= mask
        out.append(f)
    return sorted(out, key=lambda f: f["lsb"])


def parse_registers(tables, dw):
    regs = []
    field_tables = []
    for t in tables:
        h = t[0]
        ci_off = col(h, "offset", "address", "addr")
        ci_name = col(h, "register", "name")
        ci_bits = col(h, "bit")
        if ci_off is None and ci_bits is not None and ci_name is not None:
            field_tables.append(t)
            continue
        if ci_off is None or ci_name is None:
            continue
        ci_rst = col(h, "reset", "default", "init")
        ci_acc = col(h, "access", "type", "attr", "r/w")
        ci_d = col(h, "desc", "function", "field", "note")
        ci_w1c = next((i for i, x in enumerate(h) if x.strip().lower() == "w1c"), None)
        rows = []
        for r in t[1:]:
            if len(r) <= max(ci_off, ci_name) or not re.search(r"\d", r[ci_off]):
                continue
            offs = re.findall(r"0[xX][0-9a-fA-F_]+|\d+'[hH][0-9a-fA-F_]+", r[ci_off])
            nms = [x.strip() for x in re.split(r"\s*/\s*", r[ci_name])]
            if len(offs) > 1 and len(nms) == len(offs):   # "0x00C/0x010 | PTR / CNT"
                base = nms[0].rsplit("_", 1)[0] + "_" if "_" in nms[0] else ""
                for o, n in zip(offs, nms):
                    rr = list(r); rr[ci_off] = o
                    rr[ci_name] = n if ("_" in n or not base or n == nms[0]) else base + n
                    rows.append(rr)
            else:
                rows.append(r)
        for r in rows:
            name = ident(r[ci_name])
            acc = norm_access(r[ci_acc]) if ci_acc is not None and ci_acc < len(r) else "RW"
            if ci_w1c is not None and ci_w1c < len(r) and "w1c" in r[ci_w1c].lower():
                acc = "W1C"
            rst = to_int(r[ci_rst]) if ci_rst is not None and ci_rst < len(r) else 0
            desc = r[ci_d] if ci_d is not None and ci_d < len(r) else ""
            regs.append({"name": name, "offset": to_int(r[ci_off]),
                         "access": acc, "reset": rst, "desc": desc,
                         "fields": parse_fields(desc, name, acc, rst, dw)})
    # optional separate field tables: Register | Bits | Field | Access | Reset
    for t in field_tables:
        h = t[0]
        ci_reg, ci_bits = col(h, "register", "reg"), col(h, "bit")
        ci_f = col(h, "field", "name")
        ci_acc, ci_rst = col(h, "access", "type"), col(h, "reset", "default")
        for r in t[1:]:
            reg = next((x for x in regs if ci_reg is not None and x["name"] == ident(r[ci_reg])), None)
            if not reg:
                continue
            m = re.search(r"(\d+)\s*(?::\s*(\d+))?", r[ci_bits])
            if not m:
                continue
            msb = int(m.group(1)); lsb = int(m.group(2) or msb)
            if reg["fields"] and reg["fields"][0]["name"] == reg["name"]:
                reg["fields"] = []  # replace default whole-register field
            reg["fields"].append({"name": ident(r[ci_f]), "msb": max(msb, lsb),
                                  "lsb": min(msb, lsb),
                                  "access": norm_access(r[ci_acc]) if ci_acc is not None else reg["access"],
                                  "reset": to_int(r[ci_rst]) if ci_rst is not None else 0,
                                  "desc": ""})
    return regs


# ---------------------------------------------------------------- top-level info
def detect_bus(ports):
    from . import buses
    return buses.detect(ports)


def _alias(p):
    m = re.search(r"=\s*`?([A-Za-z_]\w*)", p.get("desc", ""))
    return m.group(1) if m else None


def detect_clock_reset(text, ports, bus=None):
    bus = bus or {}
    P = {p["name"]: p for p in ports}
    clk = [p for p in ports if p["dir"] == "input" and p["width"] == 1 and
           (re.search(r"(^|_)(clk|clock)", p["name"]) or
            re.search(r"clock input|system clock|\bclock\b", p["desc"], re.I))
           and not re.search(r"enable|select", p["desc"], re.I)]
    rst = [p for p in ports if p["dir"] == "input" and p["width"] == 1 and
           re.search(r"rst|reset", p["name"] + " " + p["desc"], re.I)
           and p not in clk]
    if bus.get("clock") in P:
        clk = [P[bus["clock"]]] + [p for p in clk if p["name"] != bus["clock"]]
    if bus.get("reset") in P:
        rst = [P[bus["reset"]]] + [p for p in rst if p["name"] != bus["reset"]]
    freq = None
    names = "|".join(re.escape(x) for x in filter(None, [clk[0]["name"] if clk else None,
                                                         _alias(clk[0]) if clk else None]))
    rng_pats = [r"frequency[^0-9\n]{0,20}([\d.]+)\s*(?:-|–|to)\s*([\d.]+)\s*(g|m|k)?hz"]
    if names:
        rng_pats.insert(0, r"(?:%s)[^\n]{0,60}?([\d.]+)\s*(?:-|–|to)\s*([\d.]+)\s*(g|m|k)?hz" % names)
    for pat in rng_pats:
        m = re.search(pat, text, re.I)
        if m:
            freq = max(float(m.group(1)), float(m.group(2))) * \
                {"g": 1e3, "m": 1, "k": 1e-3}.get((m.group(3) or "").lower(), 1e-6)
            break
    for pat in ([] if freq else [r"target frequency[^0-9]{0,20}([\d.]+)\s*(g|m|k)?hz",
                r"([\d.]+)\s*(g|m|k)?hz[^.\n]{0,30}\(?(?:p?clk|system clock)",
                r"(?:p?clk|system clock)[^.\n]{0,40}?([\d.]+)\s*(g|m|k)?hz"]):
        m = re.search(pat, text, re.I)
        if m:
            mult = {"g": 1e3, "m": 1, "k": 1e-3, None: 1e-6}[(m.group(2) or "").lower() or None]
            freq = float(m.group(1)) * mult
            break
    clock = None
    if clk:
        c = clk[0]
        fm = re.search(r"([\d.]+)\s*(g|m|k)?hz", c["desc"], re.I)
        if fm:
            freq = float(fm.group(1)) * {"g": 1e3, "m": 1, "k": 1e-3}.get((fm.group(2) or "").lower(), 1e-6)
        clock = {"name": c["name"], "freq_mhz": freq or 100.0,
                 "freq_source": "spec" if freq else "DEFAULT (not found in spec)"}
    reset = None
    if rst:
        r = rst[0]
        blob = r["name"] + " " + r["desc"] + " " + text[:3000]
        active_low = bool(re.search(r"(_n|_b|n)$", r["name"])) or \
            bool(re.search(r"active[\s-]*low", r["desc"] + text[:3000], re.I))
        sync = bool(re.search(r"\bsynchronous reset\b", blob, re.I)) and \
            not re.search(r"asynchronous reset", blob, re.I)
        al = _alias(r)
        for nm in filter(None, [r["name"], al]):
            for line in text.splitlines():
                if nm in line and nm != line.strip() and re.search(r"\b(a?sync)", line, re.I) and len(line) < 300:
                    sync = not re.search(r"\basync", line, re.I)
                    break
        if not re.search(r"synchronous|async", blob + (al or ""), re.I) and bus.get("type") == "wishbone":
            sync = True  # Wishbone RST_I is synchronous by definition
        reset = {"name": r["name"], "active_low": active_low,
                 "type": "sync" if sync else "async"}
    return clock, reset


def parse(text, tables, override_name=None):
    ports = parse_ports(tables)
    bus = detect_bus(ports)
    regs = parse_registers(tables, bus["data_width"] or 32) if bus["type"] != "none" else []
    rows = "\n".join("| " + " | ".join(r) + " |" for t in tables for r in t)
    clock, reset = detect_clock_reset(text + "\n" + rows, ports, bus)
    m = re.search(r"module\s*name\s*[*_]*\s*[:=]\s*[*_`]*([A-Za-z_]\w*)", text, re.I)
    if not m:  # fallback: "# h264d_cfg_regs — ..." title line
        m = re.search(r"^#+\s*`?([A-Za-z_]\w*)`?\s*(?:—|–|-|:)", text, re.M)
    name = override_name or (m.group(1) if m else "ip_top")
    # functional description = prose (limited) for documentation / LLM
    func = "\n".join(l for l in text.splitlines() if len(l.split()) > 5)[:6000]
    warnings = []
    if not clock:
        warnings.append("No clock port found")
    if not reset:
        warnings.append("No reset port found")
    if bus["type"] == "none":
        warnings.append("No supported bus slave interface detected -> registers not generated "
                        "(supported: APB, AHB, AXI4-Lite, AXI3/4, ACE-Lite, ACE, Wishbone, Avalon-MM, TileLink-UL, OBI)")
    else:
        if bus.get("other_candidates"):
            warnings.append(f"Several bus interfaces found; using {bus['protocol']} ({bus['prefix'] or 'no prefix'}), "
                            f"others: {bus['other_candidates']}")
        if "burstcount" in bus["signals"]:
            warnings.append("Avalon burstcount present but bursts are not supported (tie burstcount=1)")
    if bus["type"] != "none" and not regs:
        warnings.append("Bus found but no register table parsed")
    return {"module": ident(name), "clock": clock, "reset": reset, "bus": bus,
            "ports": ports, "registers": regs, "functional_description": func,
            "warnings": warnings}
