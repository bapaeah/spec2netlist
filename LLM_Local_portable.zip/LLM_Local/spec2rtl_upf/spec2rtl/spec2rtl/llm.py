"""Optional: fill the functional core with an LLM (OpenAI-compatible API).

Env vars:
  SPEC2RTL_LLM_URL    default <OLLAMA_HOST>/v1/chat/completions (OLLAMA_HOST or ~/.llm_local/config.json)
  SPEC2RTL_LLM_KEY    API key (default "ollama")
  SPEC2RTL_LLM_MODEL  default "auto" = chosen from the GPU/RAM of the Ollama host (see `rtl --models`)
Works with OpenAI, Azure-compatible gateways, Ollama (http://localhost:11434/v1/chat/completions),
vLLM, LM Studio etc. The result is always linted + synthesized; lint errors
are fed back for up to N repair iterations.
"""
from __future__ import annotations
import json
import os
import re
import urllib.error
import urllib.request

RULES = """Hard rules (synthesizable RTL):
- Keep the module name and port list EXACTLY as given. Output the full module.
- SystemVerilog-2012 synthesizable subset only: always_ff / always_comb / assign.
- No initial blocks, no delays (#), no $display, no real, no latches
  (assign every always_comb output on every path), no tri-state except inout ports.
- One clock domain: every always_ff uses the given clock and reset style.
- Derive slower clocks with counters + clock-enable strobes, never gate/derive clocks
  internally; external clock outputs must be registered flops.
- Every output must be driven. Avoid `unique`/`priority` keywords.
- Never use backticks (`) around signal names or comments (backticks denote compiler macro directives in Verilog).
- Reply with ONE ```systemverilog code block and nothing else."""


def _ollama_selector():
    """Repo-root ollama_models.py (GPU/RAM-based model choice, remote OLLAMA_HOST support)."""
    import sys
    from pathlib import Path
    root = Path(__file__).resolve().parents[3]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    try:
        import ollama_models as OM
        return OM
    except Exception:  # noqa: BLE001
        return None


def _call(messages, _model=None):
    OM = _ollama_selector()
    host = OM.ollama_host() if OM else os.environ.get("OLLAMA_HOST", "http://localhost:11434")
    url = os.environ.get("SPEC2RTL_LLM_URL") or f"{host}/v1/chat/completions"
    model = _model or os.environ.get("SPEC2RTL_LLM_MODEL", "auto")
    key = os.environ.get("SPEC2RTL_LLM_KEY", "ollama")
    is_ollama = "11434" in url or (OM is not None and url.startswith(host))
    num_ctx = 8192
    if model == "auto":
        if OM and is_ollama:
            model, num_ctx = OM.select("quality")      # qwen2.5-coder:32b / deepseek-coder-v2:16b / 7b
        else:
            model = "qwen2.5-coder:7b"

    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.1,
        "max_tokens": 4096,
    }
    if is_ollama:
        payload["options"] = {"num_ctx": num_ctx, "num_predict": 4096}

    body = json.dumps(payload).encode()
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"

    req = urllib.request.Request(url, body, headers)
    try:
        with urllib.request.urlopen(req, timeout=900) as r:
            return json.load(r)["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as e:
        msg = e.read().decode(errors="ignore")
        smaller = OM.next_smaller(model) if (OM and is_ollama and
                                              re.search(r"memory|alloc|CUDA", msg, re.I)) else None
        if smaller:
            print(f"[llm] {model} ran out of memory on {host}; retrying with {smaller}")
            return _call(messages, smaller)
        print(f"\n[Error] LLM at {url} returned HTTP {e.code}: {msg[:300]}")
        raise
    except urllib.error.URLError as e:
        print(f"\n[Error] Failed to connect to LLM at {url}: {e}")
        print("Ensure Ollama is running and reachable (remote: `OLLAMA_HOST=0.0.0.0 ollama serve` on that machine,")
        print("then `rtl --models --set-host http://<ip>:11434` here).")
        raise


def _code(txt):
    m = re.search(r"```(?:systemverilog|verilog|sv)?\s*\n(.*?)```", txt, re.S)
    res = (m.group(1) if m else txt).strip() + "\n"
    # Strip backticks in comments which Verilator misinterprets as preprocessor macros
    cleaned_lines = []
    for line in res.splitlines():
        trimmed = line.strip()
        if trimmed.startswith("//") or trimmed.startswith("/*") or trimmed.startswith("*"):
            line = line.replace("`", "")
        cleaned_lines.append(line)
    return "\n".join(cleaned_lines) + "\n"


def fill_core(spec, core_stub: str, lint_fn, iters=3):
    reset = spec["reset"] or {}
    sys = "You are a senior ASIC RTL designer.\n" + RULES
    user = (f"Implement the functional logic of this core module.\n\n"
            f"Clock: {spec['clock']}\nReset: {reset}\n\n"
            f"Register map (the register block already exists; you receive/drive the "
            f"register interface signals listed in the port list):\n"
            f"{json.dumps(spec['registers'], indent=1)[:12000]}\n\n"
            f"Functional description:\n{spec['functional_description']}\n\n"
            f"Module skeleton to complete:\n```systemverilog\n{core_stub}\n```")
    msgs = [{"role": "system", "content": sys}, {"role": "user", "content": user}]
    code = core_stub
    for i in range(iters):
        code = _code(_call(msgs))
        if lint_fn is not None:
            ok, log = lint_fn(code)
            print(f"[llm] iteration {i+1}: lint {'CLEAN' if ok else 'FAILED'}")
            if ok:
                return code
            msgs += [{"role": "assistant", "content": f"```systemverilog\n{code}```"},
                     {"role": "user", "content": f"Lint/synthesis errors:\n{log[:6000]}\nFix and resend the full module."}]
        else:
            return code
    print("[llm] could not reach clean lint; keeping last attempt for manual fix")
    return code
