"""Bus protocol library for spec2rtl.

For every supported memory-mapped protocol this module provides
  * signal roles (with aliases and slave-side direction) for auto-detection,
  * a synthesizable SLAVE front-end that converts the bus into one internal,
    protocol-independent register-access interface,
  * a testbench BFM (bus_wr / bus_rd tasks) used by the generated TB.

Internal register-access interface (all in the clock domain of the bus):
    wr_en   1-cycle write pulse        wr_addr [AW-1:0]  byte address
    wr_data [DW-1:0]                   wr_strb [DW/8-1:0] byte enables
    rd_en   1-cycle read pulse         rd_addr [AW-1:0]  byte address
    rd_data [DW-1:0]  (comb, from register file, 0 when unmapped)
    wr_hit / rd_hit   (comb, address decodes to a register)

Supported protocols (slave side):
    APB2/APB3/APB4/APB5, AHB2/AHB-Lite/AHB5, AXI4-Lite, AXI3, AXI4, AXI5/AXI5-Lite
    (bursts INCR/FIXED/WRAP), ACE-Lite, ACE, ACE5/ACE5-Lite (snoop channel answered as non-caching),
    AMBA CHI Issue E/F (Coherent Hub Interface), Wishbone B3/B4 (classic + pipelined),
    Avalon-MM, TileLink-UL, OBI.
"""
from __future__ import annotations
import re

# ------------------------------------------------------------------ roles
def _r(names, d):
    return {n: ([n], d) for n in names.split()}


AXI_ROLES = {}
AXI_ROLES.update(_r("awaddr awvalid awid awlen awsize awburst awlock awcache awprot awqos "
                    "awregion awuser awdomain awsnoop awbar awunique awatop awtrace awloop "
                    "awnsaid awtagop awtag awmpam awidunq awstashnid awstashniden "
                    "awstashlpid awstashlpiden awmmusecsid awmmusid "
                    "wdata wstrb wlast wvalid wid wuser wpoison wtrace wtag wdatachk "
                    "bready rready araddr arvalid arid arlen arsize arburst arlock arcache "
                    "arprot arqos arregion aruser ardomain arsnoop arbar artrace arloop "
                    "arnsaid artagop armpam aridunq armmusecsid armmusid rack wack", "in"))
AXI_ROLES.update(_r("awready wready bvalid bresp bid buser btrace bidunq btagmatch "
                    "arready rvalid rdata rresp rid rlast ruser rtrace rpoison ridunq rdatachk", "out"))
AXI_ROLES.update(_r("acvalid acready acaddr acsnoop acprot crvalid crready crresp "
                    "cdvalid cdready cddata cdlast", "any"))
AXI_ROLES["_clk"] = (["aclk"], "in")
AXI_ROLES["_rst"] = (["aresetn", "areset_n", "aresetn_i"], "in")

AHB_ROLES = {}
AHB_ROLES.update(_r("haddr htrans hwrite hsize hburst hprot hmastlock hwdata hwstrb hmaster "
                    "hnonsec hexcl hauser hwuser hsplit_in", "in"))
AHB_ROLES.update(_r("hrdata hresp hexokay hruser hbuser hsplit hsplitx", "out"))
AHB_ROLES["hsel"] = (["hsel", "hselx", "hsel_x"], "in")
AHB_ROLES["hready_in"] = (["hready", "hready_in", "hreadyin"], "in")
AHB_ROLES["hreadyout"] = (["hreadyout", "hready_out", "hready"], "out")
AHB_ROLES["_clk"] = (["hclk"], "in")
AHB_ROLES["_rst"] = (["hresetn", "hreset_n", "hrst_n"], "in")

APB_ROLES = {}
APB_ROLES.update(_r("paddr psel penable pwrite pwdata pstrb pprot pwakeup pauser pwuser", "in"))
APB_ROLES.update(_r("prdata pready pslverr pruser pbuser", "out"))
APB_ROLES["psel"] = (["psel", "pselx", "psel_x"], "in")
APB_ROLES["_clk"] = (["pclk"], "in")
APB_ROLES["_rst"] = (["presetn", "preset_n", "prst_n"], "in")

CHI_ROLES = {}
CHI_ROLES.update(_r("txreqflitv txreqflit rxreqlcrdv txrspflitv txrspflit rxrsplcrdv "
                    "txdatflitv txdatflit rxdatlcrdv rxsnpflitv rxsnpflit txsnplcrdv", "in"))
CHI_ROLES.update(_r("rxreqflitv rxreqflit txreqlcrdv rxrspflitv rxrspflit txrsplcrdv "
                    "rxdatflitv rxdatflit txdatlcrdv txsnpflitv txsnpflit rxsnplcrdv", "out"))
CHI_ROLES["_clk"] = (["clk", "chiclk", "chi_clk"], "in")
CHI_ROLES["_rst"] = (["rst_n", "chirst_n", "chi_rst_n"], "in")

WB_ROLES = {
    "adr": (["adr", "addr"], "in"), "dat_w": (["dat", "data", "dat_w", "wdat"], "in"),
    "dat_r": (["dat", "data", "dat_r", "rdat"], "out"), "we": (["we"], "in"),
    "sel": (["sel"], "in"), "stb": (["stb"], "in"), "cyc": (["cyc"], "in"),
    "ack": (["ack"], "out"), "err": (["err"], "out"), "rty": (["rty"], "out"),
    "stall": (["stall"], "out"), "cti": (["cti"], "in"), "bte": (["bte"], "in"),
    "lock": (["lock"], "in"), "tga": (["tga"], "in"), "tgc": (["tgc"], "in"),
    "tgd_w": (["tgd"], "in"), "tgd_r": (["tgd"], "out"),
    "_clk": (["clk"], "in"), "_rst": (["rst"], "in"),
}

AVL_ROLES = {}
AVL_ROLES.update(_r("address read write writedata byteenable chipselect burstcount "
                    "beginbursttransfer lock debugaccess", "in"))
AVL_ROLES.update(_r("readdata waitrequest readdatavalid response writeresponsevalid", "out"))
AVL_ROLES["_clk"] = (["clk"], "in")
AVL_ROLES["_rst"] = (["reset", "reset_n", "rst_n", "rst"], "in")

TL_ROLES = {}
TL_ROLES.update(_r("a_valid a_opcode a_param a_size a_source a_address a_mask a_data "
                   "a_user a_corrupt d_ready", "in"))
TL_ROLES.update(_r("a_ready d_valid d_opcode d_param d_size d_source d_sink d_data "
                   "d_error d_denied d_corrupt d_user", "out"))
TL_ROLES["_clk"] = (["clk"], "in")
TL_ROLES["_rst"] = (["rst_n", "rst", "reset_n"], "in")

OBI_ROLES = {}
OBI_ROLES.update(_r("req addr we be wdata aid rready atop auser wuser", "in"))
OBI_ROLES.update(_r("gnt rvalid rdata err rid ruser exokay", "out"))
OBI_ROLES["_clk"] = (["clk"], "in")
OBI_ROLES["_rst"] = (["rst_n", "rst"], "in")

AXIL_REQ = "awaddr awvalid awready wdata wvalid wready bvalid bready araddr arvalid arready rdata rvalid rready".split()

# order = detection priority
PROTOS = [
    {"key": "chi", "roles": CHI_ROLES, "required": ["txreqflitv", "txreqflit", "txreqlcrdv", "rxrspflitv", "rxrspflit"], "word": False},
    {"key": "axi", "roles": AXI_ROLES, "required": AXIL_REQ, "word": False},
    {"key": "ahb", "roles": AHB_ROLES, "required": ["haddr", "htrans", "hwrite", "hwdata", "hrdata"], "word": False},
    {"key": "apb", "roles": APB_ROLES, "required": ["paddr", "psel", "penable", "pwrite", "pwdata", "prdata"], "word": False},
    {"key": "tilelink", "roles": TL_ROLES, "required": ["a_valid", "a_ready", "a_opcode", "a_address", "a_data", "d_valid", "d_ready", "d_opcode", "d_data"], "word": False},
    {"key": "avalon", "roles": AVL_ROLES, "required": ["address", "read", "write", "writedata", "readdata"], "word": True},
    {"key": "wishbone", "roles": WB_ROLES, "required": ["adr", "dat_w", "dat_r", "we", "stb", "cyc", "ack"], "word": False},
    {"key": "obi", "roles": OBI_ROLES, "required": ["req", "gnt", "addr", "we", "wdata", "rvalid", "rdata"], "word": False},
]
SUPPORTED = ["apb", "ahb", "axi_lite", "axi", "ace_lite", "ace", "chi", "wishbone", "avalon", "tilelink", "obi"]


def _variants(n):
    v = [n]
    for s in ("_i", "_o", "_in", "_out"):
        if n.endswith(s) and len(n) > len(s):
            v.append(n[:-len(s)])
    for p in ("i_", "o_"):
        if n.startswith(p):
            v.append(n[len(p):])
    return v


def _match(name, alias):
    for v in _variants(name):
        if v == alias:
            return ""
        if v.endswith("_" + alias):
            return v[:-len(alias)]
    return None


def detect(ports):
    cands = []
    for pi, proto in enumerate(PROTOS):
        groups = {}
        for p in ports:
            d = {"input": "in", "output": "out"}.get(p["dir"], "any")
            for role, (aliases, rd) in proto["roles"].items():
                if rd != "any" and rd != d:
                    continue
                pre = next((x for x in (_match(p["name"], a) for a in aliases) if x is not None), None)
                if pre is None:
                    continue
                g = groups.setdefault(pre, {})
                if role not in g:
                    g[role] = p["name"]
                    break
        for pre, g in groups.items():
            if all(r in g for r in proto["required"]):
                cands.append((pi, -len(g), pre, proto, g))
    if not cands:
        return {"type": "none", "protocol": "none", "signals": {}, "addr_width": 0,
                "data_width": 32, "word_addr": False, "clock": None, "reset": None}
    cands.sort(key=lambda x: (x[0], x[1]))
    _, _, pre, proto, g = cands[0]
    P = {p["name"]: p for p in ports}
    clk, rst = g.pop("_clk", None), g.pop("_rst", None)
    key, label = classify(proto["key"], g, P)
    dport = g.get("wdata") or g.get("hwdata") or g.get("pwdata") or g.get("dat_w") or \
        g.get("writedata") or g.get("a_data")
    aport = g.get("awaddr") or g.get("haddr") or g.get("paddr") or g.get("adr") or \
        g.get("address") or g.get("a_address") or g.get("addr")
    return {"type": key, "protocol": label, "prefix": pre, "signals": g,
            "addr_width": P[aport]["width"], "data_width": P[dport]["width"],
            "word_addr": proto["word"], "clock": clk, "reset": rst,
            "other_candidates": [f"{c[3]['key']}:{c[2] or '(no prefix)'}" for c in cands[1:]]}


def classify(k, g, P):
    w = lambda r: P[g[r]]["width"] if r in g else 0  # noqa: E731
    if k == "axi":
        ace_snoop = any(r in g for r in ("acvalid", "crvalid", "rack", "wack"))
        ace_lite = any(r in g for r in ("awdomain", "ardomain", "awsnoop", "arsnoop", "awbar", "arbar"))
        full = any(r in g for r in ("awlen", "arlen", "awid", "arid", "wlast", "rlast"))
        axi3 = "wid" in g or (0 < w("awlen") <= 4)
        if ace_snoop:
            return "ace", "ACE"
        if ace_lite:
            return "ace_lite", "ACE-Lite" + (" (ACE5-Lite)" if any(r in g for r in ("awatop", "awstashnid")) else "")
        if full:
            return "axi", "AXI3" if axi3 else ("AXI5" if any(r in g for r in ("awatop", "wpoison", "awtrace")) else "AXI4")
        return "axi_lite", "AXI4-Lite"
    if k == "ahb":
        if "hwstrb" in g or "hnonsec" in g or "hexcl" in g:
            return "ahb", "AHB5"
        if w("hresp") >= 2 or "hsplit" in g or "hmaster" in g:
            return "ahb", "AHB (AMBA 2)"
        return "ahb", "AHB-Lite"
    if k == "apb":
        if "pwakeup" in g or "pauser" in g:
            return "apb", "APB5"
        if "pstrb" in g or "pprot" in g:
            return "apb", "APB4"
        if "pready" in g or "pslverr" in g:
            return "apb", "APB3"
        return "apb", "APB2"
    if k == "chi":
        return "chi", "AMBA CHI Issue E/F"
    if k == "wishbone":
        return "wishbone", "Wishbone B4 pipelined" if "stall" in g else "Wishbone classic"
    if k == "avalon":
        return "avalon", "Avalon-MM" + (" (pipelined)" if "readdatavalid" in g else "")
    if k == "tilelink":
        return "tilelink", "TileLink-UL"
    return "obi", "OBI"


# ------------------------------------------------------------------ helpers
def resp_expr(width, err):
    """2-bit AXI-style response (OKAY / SLVERR) zero-extended to width."""
    core = f"({err} ? 2'b10 : 2'b00)"
    if width <= 2:
        return core if width == 2 else f"{err}"
    return f"{{{width-2}'b0, {core}}}"


def in_addr(c, port):
    """Internal byte address from the bus address port."""
    if c.word and c.lsb:
        return f"{{{port}, {c.lsb}'b0}}"
    return port


def tb_addr(c, var="a"):
    return f"{var}[{c.aw-1}:{c.lsb}]" if (c.word and c.lsb) else var


def size_strb_fn(c):
    """function size_strb(size, addr_lsbs) -> byte-lane mask (AHB-style)."""
    nb, lsb = c.nb, c.lsb
    if lsb == 0:
        return ["  function automatic logic size_strb(input logic [2:0] sz, input logic a);",
                "    size_strb = 1'b1 | ^{sz, a};  // 8-bit bus", "  endfunction"]
    L = [f"  function automatic logic [{nb-1}:0] size_strb(input logic [2:0] sz, input logic [{lsb-1}:0] a);",
         "    case (sz)"]
    for s in range(lsb):
        m = (1 << (1 << s)) - 1
        sh = "a" if s == 0 else (f"{{a[{lsb-1}:{s}], {s}'b0}}" if s < lsb else "")
        L.append(f"      3'd{s}: size_strb = {nb}'('h{m:X}) << {sh};")
    L += ["      default: size_strb = '1;", "    endcase", "  endfunction"]
    return L


# ------------------------------------------------------------------ front-ends
def frontend(c):
    """Returns (lines, used_roles). Unused roles are sunk/tied by the caller."""
    return {"apb": fe_apb, "ahb": fe_ahb, "axi_lite": fe_axil, "axi": fe_axi,
            "ace_lite": fe_axi, "ace": fe_axi, "chi": fe_chi, "wishbone": fe_wb, "avalon": fe_avl,
            "tilelink": fe_tl, "obi": fe_obi}[c.bus["type"]](c)


def fe_apb(c):
    S = c.sig
    acc = f"({S['psel']} & {S['penable']})"
    L = ["  // ---------------- APB slave front-end (zero wait-state)",
         f"  assign wr_en   = {acc} &  {S['pwrite']};",
         f"  assign rd_en   = {acc} & ~{S['pwrite']};",
         f"  assign wr_addr = {in_addr(c, S['paddr'])};",
         f"  assign rd_addr = {in_addr(c, S['paddr'])};",
         f"  assign wr_data = {S['pwdata']};",
         f"  assign wr_strb = {S['pstrb'] if 'pstrb' in S else chr(39) + '1'};",
         f"  assign {S['prdata']} = rd_en ? rd_data : '0;"]
    used = {"paddr", "psel", "penable", "pwrite", "pwdata", "pstrb", "prdata"}
    if "pready" in S:
        L.append(f"  assign {S['pready']} = 1'b1;")
        used.add("pready")
    if "pslverr" in S:
        L.append(f"  assign {S['pslverr']} = {acc} & ({S['pwrite']} ? ~wr_hit : ~rd_hit);  // unmapped")
        used.add("pslverr")
    return L, used


def fe_ahb(c):
    S, P = c.sig, c.P
    ff, rc = c.ff(), c.rst_cond()
    hsel = S.get("hsel", "1'b1")
    hro = S.get("hreadyout")
    hrdy = S["hready_in"] if "hready_in" in S else "hrdy_own"
    L = ["  // ---------------- AHB slave front-end (zero wait-state, 2-cycle ERROR)",
         "  logic dp_act, dp_write, err1, err2, dp_hit, hrdy_own;",
         f"  logic [{c.aw-1}:0] dp_addr;", "  logic [2:0] dp_size;",
         f"  assign dp_hit   = dp_write ? wr_hit : rd_hit;",
         "  assign err1     = dp_act & ~dp_hit;",
         "  assign hrdy_own = ~err1;"]
    if hro:
        L.append(f"  assign {hro} = hrdy_own;")
    if "hresp" in S:
        L.append(f"  assign {S['hresp']} = {c.P[S['hresp']]['width']}'(err1 | err2);  // 1 = ERROR")
    L += [f"  {ff} begin",
          f"    if ({rc}) begin dp_act <= 1'b0; dp_write <= 1'b0; dp_addr <= '0; dp_size <= '0; err2 <= 1'b0; end",
          "    else begin", "      err2 <= err1;",
          f"      if ({hrdy}) begin",
          f"        dp_act   <= {hsel} & {S['htrans']}[1];  // NONSEQ/SEQ",
          f"        dp_write <= {S['hwrite']};",
          f"        dp_addr  <= {in_addr(c, S['haddr'])};",
          f"        dp_size  <= {S['hsize'] if 'hsize' in S else f'3' + chr(39) + f'd{c.lsb}'};",
          "      end else if (err1) dp_act <= 1'b0;", "    end", "  end"]
    L += size_strb_fn(c)
    strb = S["hwstrb"] if "hwstrb" in S else \
        ("size_strb(dp_size, dp_addr[%d:0])" % (c.lsb - 1) if c.lsb else "size_strb(dp_size, 1'b0)")
    L += ["  assign wr_en   = dp_act &  dp_write;", "  assign rd_en   = dp_act & ~dp_write;",
          "  assign wr_addr = dp_addr;", "  assign rd_addr = dp_addr;",
          f"  assign wr_data = {S['hwdata']};", f"  assign wr_strb = {strb};",
          f"  assign {S['hrdata']} = rd_en ? rd_data : '0;"]
    L.append(f"  /* verilator lint_off UNUSEDSIGNAL */ logic unused_htr; assign unused_htr = {S['htrans']}[0]; /* verilator lint_on UNUSEDSIGNAL */")
    if "hsize" not in S or "hwstrb" in S:
        L.append("  /* verilator lint_off UNUSEDSIGNAL */ logic unused_sz; assign unused_sz = ^dp_size; /* verilator lint_on UNUSEDSIGNAL */")
    return L, {"hsel", "hready_in", "hreadyout", "hresp", "htrans", "hwrite", "haddr",
               "hsize", "hwstrb", "hwdata", "hrdata"}


def fe_axil(c):
    S, P = c.sig, c.P
    ff, rc = c.ff(), c.rst_cond()
    sw = c.nb
    L = ["  // ---------------- AXI4-Lite slave front-end (1 outstanding per direction)",
         "  logic aw_full, w_full, bvalid_q, rvalid_q, berr_q, rerr_q;",
         f"  logic [{c.aw-1}:0] aw_q;", f"  logic [{c.dw-1}:0] w_q, rdata_q;", f"  logic [{sw-1}:0] ws_q;",
         f"  assign {S['awready']} = ~aw_full;", f"  assign {S['wready']}  = ~w_full;",
         "  assign wr_en   = aw_full & w_full & ~bvalid_q;",
         "  assign wr_addr = aw_q;", "  assign wr_data = w_q;", "  assign wr_strb = ws_q;",
         f"  assign {S['bvalid']} = bvalid_q;",
         f"  assign {S['arready']} = ~rvalid_q;",
         f"  assign rd_en   = {S['arvalid']} & ~rvalid_q;",
         f"  assign rd_addr = {in_addr(c, S['araddr'])};",
         f"  assign {S['rvalid']} = rvalid_q;", f"  assign {S['rdata']}  = rdata_q;"]
    if "bresp" in S:
        L.append(f"  assign {S['bresp']} = {resp_expr(P[S['bresp']]['width'], 'berr_q')};")
    if "rresp" in S:
        L.append(f"  assign {S['rresp']} = {resp_expr(P[S['rresp']]['width'], 'rerr_q')};")
    strb = S["wstrb"] if "wstrb" in S else "'1"
    L += [f"  {ff} begin",
          f"    if ({rc}) begin",
          "      aw_full <= 1'b0; w_full <= 1'b0; bvalid_q <= 1'b0; rvalid_q <= 1'b0;",
          "      berr_q <= 1'b0; rerr_q <= 1'b0; aw_q <= '0; w_q <= '0; ws_q <= '0; rdata_q <= '0;",
          "    end else begin",
          f"      if ({S['awvalid']} & ~aw_full) begin aw_full <= 1'b1; aw_q <= {in_addr(c, S['awaddr'])}; end",
          f"      if ({S['wvalid']} & ~w_full) begin w_full <= 1'b1; w_q <= {S['wdata']}; ws_q <= {strb}; end",
          "      if (wr_en) begin aw_full <= 1'b0; w_full <= 1'b0; bvalid_q <= 1'b1; berr_q <= ~wr_hit; end",
          f"      else if (bvalid_q & {S['bready']}) bvalid_q <= 1'b0;",
          "      if (rd_en) begin rvalid_q <= 1'b1; rdata_q <= rd_data; rerr_q <= ~rd_hit; end",
          f"      else if (rvalid_q & {S['rready']}) rvalid_q <= 1'b0;",
          "    end", "  end"]
    return L, set(AXIL_REQ) | {"wstrb", "bresp", "rresp"}


def fe_axi(c):
    """AXI3/AXI4/AXI5/ACE-Lite/ACE slave with INCR/FIXED/WRAP bursts."""
    S, P = c.sig, c.P
    ff, rc = c.ff(), c.rst_cond()
    aw = c.aw
    w = lambda r: P[S[r]]["width"]  # noqa: E731
    used = set(AXIL_REQ) | {"wstrb", "bresp", "rresp", "awlen", "arlen", "awsize", "arsize",
                            "awburst", "arburst", "awid", "arid", "bid", "rid", "rlast"}
    def fld(r, width, default):
        if r in S:
            return f"{width}'({S[r]})" if w(r) != width else S[r]
        return default
    idw = max(w("awid") if "awid" in S else 0, w("arid") if "arid" in S else 0, 1)
    L = ["  // ---------------- AXI slave front-end (bursts: FIXED/INCR/WRAP, 1 outstanding/dir)",
         f"  function automatic logic [{aw-1}:0] axi_next(input logic [{aw-1}:0] a, input logic [2:0] sz,",
         "                                                input logic [1:0] bt, input logic [7:0] ln);",
         f"    logic [{aw-1}:0] inc, wm;",
         f"    inc = {aw}'(1) << sz;",
         f"    wm  = (({aw}'(ln) + {aw}'(1)) << sz) - {aw}'(1);",
         "    case (bt)",
         "      2'b00:   axi_next = a;                                  // FIXED",
         "      2'b10:   axi_next = (a & ~wm) | ((a + inc) & wm);       // WRAP",
         "      default: axi_next = (a & ~(inc - " + f"{aw}'(1))) + inc;     // INCR",
         "    endcase", "  endfunction",
         "  localparam logic [1:0] W_IDLE = 2'd0, W_DATA = 2'd1, W_RESP = 2'd2;",
         "  logic [1:0] wst;",
         f"  logic [{aw-1}:0] w_addr, r_addr;", "  logic [7:0] w_left, w_len, r_left, r_len;",
         "  logic [2:0] w_size, r_size;", "  logic [1:0] w_burst, r_burst;",
         f"  logic [{idw-1}:0] w_id, r_id, rid_q;",
         "  logic w_err, r_act, rvalid_q, rlast_q, rerr_q;", f"  logic [{c.dw-1}:0] rdata_q;",
         f"  assign {S['awready']} = (wst == W_IDLE);",
         f"  assign {S['wready']}  = (wst == W_DATA);",
         f"  assign wr_en   = (wst == W_DATA) & {S['wvalid']};",
         "  assign wr_addr = w_addr;", f"  assign wr_data = {S['wdata']};",
         f"  assign wr_strb = {S['wstrb'] if 'wstrb' in S else chr(39) + '1'};",
         f"  assign {S['bvalid']} = (wst == W_RESP);"]
    if "bresp" in S:
        L.append(f"  assign {S['bresp']} = {resp_expr(w('bresp'), 'w_err')};")
    if "bid" in S:
        L.append(f"  assign {S['bid']} = {w('bid')}'(w_id);")
    L += [f"  assign {S['arready']} = ~r_act & ~rvalid_q;",
          f"  assign rd_en   = r_act & (~rvalid_q | {S['rready']});",
          "  assign rd_addr = r_addr;",
          f"  assign {S['rvalid']} = rvalid_q;", f"  assign {S['rdata']} = rdata_q;"]
    if "rresp" in S:
        L.append(f"  assign {S['rresp']} = {resp_expr(w('rresp'), 'rerr_q')};  // ACE: IsShared/PassDirty = 0")
    if "rid" in S:
        L.append(f"  assign {S['rid']} = {w('rid')}'(rid_q);")
    if "rlast" in S:
        L.append(f"  assign {S['rlast']} = rlast_q;")
    L += [f"  {ff} begin",
          f"    if ({rc}) begin",
          "      wst <= W_IDLE; w_addr <= '0; w_left <= '0; w_len <= '0; w_size <= '0; w_burst <= '0;",
          "      w_id <= '0; w_err <= 1'b0;",
          "    end else begin",
          "      case (wst)",
          f"        W_IDLE: if ({S['awvalid']}) begin",
          "          wst     <= W_DATA;",
          f"          w_addr  <= {in_addr(c, S['awaddr'])};",
          f"          w_left  <= {fld('awlen', 8, chr(39) + '0')};",
          f"          w_len   <= {fld('awlen', 8, chr(39) + '0')};",
          f"          w_size  <= {fld('awsize', 3, f'3' + chr(39) + f'd{c.lsb}')};",
          f"          w_burst <= {fld('awburst', 2, chr(50) + chr(39) + 'b01')};",
          f"          w_id    <= {fld('awid', idw, chr(39) + '0')};",
          "          w_err   <= 1'b0;", "        end",
          f"        W_DATA: if ({S['wvalid']}) begin",
          "          w_err  <= w_err | ~wr_hit;",
          "          w_addr <= axi_next(w_addr, w_size, w_burst, w_len);",
          "          if (w_left == 8'd0) wst <= W_RESP;", "          else w_left <= w_left - 8'd1;",
          "        end",
          f"        W_RESP: if ({S['bready']}) wst <= W_IDLE;",
          "        default: wst <= W_IDLE;", "      endcase", "    end", "  end",
          f"  {ff} begin",
          f"    if ({rc}) begin",
          "      r_act <= 1'b0; r_addr <= '0; r_left <= '0; r_len <= '0; r_size <= '0; r_burst <= '0;",
          "      r_id <= '0; rid_q <= '0; rvalid_q <= 1'b0; rlast_q <= 1'b0; rerr_q <= 1'b0; rdata_q <= '0;",
          "    end else begin",
          f"      if ({S['arvalid']} & ~r_act & ~rvalid_q) begin",
          "        r_act   <= 1'b1;",
          f"        r_addr  <= {in_addr(c, S['araddr'])};",
          f"        r_left  <= {fld('arlen', 8, chr(39) + '0')};",
          f"        r_len   <= {fld('arlen', 8, chr(39) + '0')};",
          f"        r_size  <= {fld('arsize', 3, f'3' + chr(39) + f'd{c.lsb}')};",
          f"        r_burst <= {fld('arburst', 2, chr(50) + chr(39) + 'b01')};",
          f"        r_id    <= {fld('arid', idw, chr(39) + '0')};", "      end",
          "      if (rd_en) begin",
          "        rvalid_q <= 1'b1; rdata_q <= rd_data; rerr_q <= ~rd_hit; rid_q <= r_id;",
          "        rlast_q  <= (r_left == 8'd0);",
          "        r_addr   <= axi_next(r_addr, r_size, r_burst, r_len);",
          "        if (r_left == 8'd0) r_act <= 1'b0; else r_left <= r_left - 8'd1;",
          f"      end else if (rvalid_q & {S['rready']}) rvalid_q <= 1'b0;",
          "    end", "  end"]
    # ACE snoop channel: answer every snoop as a non-caching agent (CRRESP = 0, no data)
    if all(r in S for r in ("acvalid", "acready", "crvalid", "crready")) and \
            P[S["acvalid"]]["dir"] == "input" and P[S["acready"]]["dir"] == "output":
        L += ["  // ACE snoop channel: non-caching responder (CRRESP=0 -> no data, not shared)",
              "  logic cr_pend;", f"  assign {S['acready']} = ~cr_pend;",
              f"  assign {S['crvalid']} = cr_pend;"]
        if "crresp" in S:
            L.append(f"  assign {S['crresp']} = '0;")
            used.add("crresp")
        L += [f"  {ff} begin", f"    if ({rc}) cr_pend <= 1'b0;",
              f"    else if ({S['acvalid']} & ~cr_pend) cr_pend <= 1'b1;",
              f"    else if (cr_pend & {S['crready']}) cr_pend <= 1'b0;", "  end"]
        used |= {"acvalid", "acready", "crvalid", "crready"}
    return L, used


def fe_chi(c):
    S = c.sig
    ff, rc = c.ff(), c.rst_cond()
    txreq = S.get("txreqflit", "'0")
    txdat = S.get("txdatflit", "'0")
    rxrspv = S.get("rxrspflitv", "rxrsp_v_unused")
    rxrsp = S.get("rxrspflit", "rxrsp_unused")
    rxdatv = S.get("rxdatflitv", "rxdat_v_unused")
    rxdat = S.get("rxdatflit", "rxdat_unused")
    txreqv = S.get("txreqflitv", "1'b0")
    L = ["  // ---------------- AMBA CHI Issue E/F slave front-end (Coherent Hub Interface)",
         "  logic req_valid_q, req_write_q, req_err_q;",
         f"  logic [{c.aw-1}:0] req_addr_q;",
         f"  logic [{c.dw-1}:0] req_wdata_q;",
         f"  assign {S.get('txreqlcrdv', 'txreqlcrdv_unused')} = 1'b1;  // Link credit issue",
         f"  assign {S.get('txrsplcrdv', 'txrsplcrdv_unused')} = 1'b1;",
         f"  assign {S.get('txdatlcrdv', 'txdatlcrdv_unused')} = 1'b1;",
         "  assign wr_en   = req_valid_q &  req_write_q;",
         "  assign rd_en   = req_valid_q & ~req_write_q;",
         "  assign wr_addr = req_addr_q;",
         "  assign rd_addr = req_addr_q;",
         "  assign wr_data = req_wdata_q;",
         "  assign wr_strb = '1;",
         f"  assign {rxrspv} = req_valid_q;",
         f"  assign {rxrsp}  = {{16'b0, req_err_q ? 2'b10 : 2'b00}};",
         f"  assign {rxdatv} = req_valid_q & ~req_write_q;",
         f"  assign {rxdat}  = {{rd_data, 16'b0}};",
         f"  {ff} begin",
         f"    if ({rc}) begin req_valid_q <= 1'b0; req_write_q <= 1'b0; req_addr_q <= '0; req_wdata_q <= '0; req_err_q <= 1'b0; end",
         "    else begin",
         f"      if ({txreqv}) begin",
         "        req_valid_q <= 1'b1;",
         f"        req_write_q <= {txreq}[0];",
         f"        req_addr_q  <= {in_addr(c, txreq)};",
         f"        req_wdata_q <= {txdat}[{c.dw-1}:0];",
         f"        req_err_q   <= {txreq}[0] ? ~wr_hit : ~rd_hit;",
         "      end else begin req_valid_q <= 1'b0; end",
         "    end",
         "  end"]
    return L, set(S.keys())


def fe_wb(c):
    S = c.sig
    ff, rc = c.ff(), c.rst_cond()
    piped = "stall" in S
    has_err = "err" in S
    hit = f"({S['we']} ? wr_hit : rd_hit)"
    req = f"({S['cyc']} & {S['stb']})"
    L = [f"  // ---------------- Wishbone {'B4 pipelined' if piped else 'classic'} slave front-end",
         "  logic ack_q, err_q, busy;", f"  logic [{c.dw-1}:0] rdat_q;",
         "  assign busy = " + ("1'b0;" if piped else "ack_q | err_q;  // registered feedback"),
         f"  assign wr_en   = {req} &  {S['we']} & ~busy;",
         f"  assign rd_en   = {req} & ~{S['we']} & ~busy;",
         f"  assign wr_addr = {in_addr(c, S['adr'])};", f"  assign rd_addr = {in_addr(c, S['adr'])};",
         f"  assign wr_data = {S['dat_w']};", f"  assign wr_strb = {S['sel'] if 'sel' in S else chr(39) + '1'};",
         f"  assign {S['ack']}   = ack_q;", f"  assign {S['dat_r']} = rdat_q;"]
    if has_err:
        L.append(f"  assign {S['err']} = err_q;")
    if piped:
        L.append(f"  assign {S['stall']} = 1'b0;")
    ok = f" & {hit}" if has_err else ""
    L += [f"  {ff} begin",
          f"    if ({rc}) begin ack_q <= 1'b0; err_q <= 1'b0; rdat_q <= '0; end",
          "    else begin",
          f"      ack_q <= {req} & ~busy{ok};",
          f"      err_q <= {'(' + req + ' & ~busy & ~' + hit + ')' if has_err else chr(49) + chr(39) + 'b0'};",
          "      if (rd_en) rdat_q <= rd_data;", "    end", "  end"]
    return L, {"adr", "dat_w", "dat_r", "we", "sel", "stb", "cyc", "ack", "err", "stall"}


def fe_avl(c):
    S, P = c.sig, c.P
    ff, rc = c.ff(), c.rst_cond()
    cs = f" & {S['chipselect']}" if "chipselect" in S else ""
    L = ["  // ---------------- Avalon-MM slave front-end (no wait states, no bursts)",
         f"  assign wr_en   = {S['write']}{cs};", f"  assign rd_en   = {S['read']}{cs};",
         f"  assign wr_addr = {in_addr(c, S['address'])};", f"  assign rd_addr = {in_addr(c, S['address'])};",
         f"  assign wr_data = {S['writedata']};",
         f"  assign wr_strb = {S['byteenable'] if 'byteenable' in S else chr(39) + '1'};"]
    if "waitrequest" in S:
        L.append(f"  assign {S['waitrequest']} = 1'b0;")
    rw = P[S["response"]]["width"] if "response" in S else 2
    if "readdatavalid" in S:
        L += ["  logic rdv_q, rerr_q;", f"  logic [{c.dw-1}:0] rdat_q;",
              f"  {ff} begin",
              f"    if ({rc}) begin rdv_q <= 1'b0; rerr_q <= 1'b0; rdat_q <= '0; end",
              "    else begin rdv_q <= rd_en; rerr_q <= rd_en & ~rd_hit; if (rd_en) rdat_q <= rd_data; end",
              "  end", f"  assign {S['readdatavalid']} = rdv_q;", f"  assign {S['readdata']} = rdat_q;"]
        rerr = "rerr_q"
    else:
        L.append(f"  assign {S['readdata']} = rd_en ? rd_data : '0;")
        rerr = "(rd_en & ~rd_hit)"
    if "writeresponsevalid" in S:
        L += ["  logic wrv_q, werr_q;", f"  {ff} begin",
              f"    if ({rc}) begin wrv_q <= 1'b0; werr_q <= 1'b0; end",
              "    else begin wrv_q <= wr_en; werr_q <= wr_en & ~wr_hit; end", "  end",
              f"  assign {S['writeresponsevalid']} = wrv_q;"]
        werr = "werr_q"
    else:
        werr = "(wr_en & ~wr_hit)"
    if "response" in S:
        L.append(f"  assign {S['response']} = {resp_expr(rw, f'({rerr} | {werr})')};  // 10 = SLVERR")
    return L, {"address", "read", "write", "writedata", "readdata", "byteenable", "chipselect",
               "waitrequest", "readdatavalid", "writeresponsevalid", "response"}


def fe_tl(c):
    S, P = c.sig, c.P
    ff, rc = c.ff(), c.rst_cond()
    w = lambda r: P[S[r]]["width"]  # noqa: E731
    L = ["  // ---------------- TileLink-UL slave front-end (Get / PutFullData / PutPartialData)",
         "  logic d_valid_q, d_err_q, a_fire, is_get, is_put;", "  logic [2:0] d_op_q;",
         f"  logic [{c.dw-1}:0] d_data_q;",
         f"  assign {S['a_ready']} = ~d_valid_q | {S['d_ready']};",
         f"  assign a_fire  = {S['a_valid']} & {S['a_ready']};",
         f"  assign is_get  = ({S['a_opcode']} == 3'd4);",
         f"  assign is_put  = ({S['a_opcode']} == 3'd0) | ({S['a_opcode']} == 3'd1);",
         "  assign wr_en   = a_fire & is_put;", "  assign rd_en   = a_fire & is_get;",
         f"  assign wr_addr = {in_addr(c, S['a_address'])};", f"  assign rd_addr = {in_addr(c, S['a_address'])};",
         f"  assign wr_data = {S['a_data']};",
         f"  assign wr_strb = {S['a_mask'] if 'a_mask' in S else chr(39) + '1'};",
         f"  assign {S['d_valid']} = d_valid_q;", f"  assign {S['d_opcode']} = d_op_q;",
         f"  assign {S['d_data']} = d_data_q;"]
    regs = []
    for src, dst in (("a_size", "d_size"), ("a_source", "d_source")):
        if src in S and dst in S:
            L.append(f"  logic [{w(dst)-1}:0] {dst}_q; assign {S[dst]} = {dst}_q;")
            regs.append((dst, f"{w(dst)}'({S[src]})"))
    for e in ("d_error", "d_denied"):
        if e in S:
            L.append(f"  assign {S[e]} = d_err_q;")
    L += [f"  {ff} begin",
          f"    if ({rc}) begin d_valid_q <= 1'b0; d_err_q <= 1'b0; d_op_q <= '0; d_data_q <= '0;"
          + "".join(f" {d}_q <= '0;" for d, _ in regs) + " end",
          "    else if (a_fire) begin",
          "      d_valid_q <= 1'b1;",
          "      d_op_q    <= is_get ? 3'd1 : 3'd0;  // AccessAckData : AccessAck",
          "      d_data_q  <= is_get ? rd_data : '0;",
          "      d_err_q   <= is_get ? ~rd_hit : (is_put ? ~wr_hit : 1'b1);"]
    L += [f"      {d}_q <= {v};" for d, v in regs]
    L += [f"    end else if (d_valid_q & {S['d_ready']}) d_valid_q <= 1'b0;", "  end"]
    return L, {"a_valid", "a_ready", "a_opcode", "a_address", "a_data", "a_mask", "d_ready",
               "d_valid", "d_opcode", "d_data", "d_error", "d_denied", "a_size", "d_size",
               "a_source", "d_source"}


def fe_obi(c):
    S, P = c.sig, c.P
    ff, rc = c.ff(), c.rst_cond()
    rr = S.get("rready")
    L = ["  // ---------------- OBI slave front-end (gnt when response slot free)",
         "  logic rvalid_q, err_q, fire;", f"  logic [{c.dw-1}:0] rdata_q;",
         f"  assign {S['gnt']} = ~rvalid_q" + (f" | {rr};" if rr else " | 1'b1;"),
         f"  assign fire    = {S['req']} & {S['gnt']};",
         f"  assign wr_en   = fire &  {S['we']};", f"  assign rd_en   = fire & ~{S['we']};",
         f"  assign wr_addr = {in_addr(c, S['addr'])};", f"  assign rd_addr = {in_addr(c, S['addr'])};",
         f"  assign wr_data = {S['wdata']};", f"  assign wr_strb = {S['be'] if 'be' in S else chr(39) + '1'};",
         f"  assign {S['rvalid']} = rvalid_q;", f"  assign {S['rdata']} = rdata_q;"]
    if "err" in S:
        L.append(f"  assign {S['err']} = err_q;")
    rid = ""
    if "rid" in S and "aid" in S:
        L.append(f"  logic [{P[S['rid']]['width']-1}:0] rid_q; assign {S['rid']} = rid_q;")
        rid = f" rid_q <= {P[S['rid']]['width']}'({S['aid']});"
    L += [f"  {ff} begin",
          f"    if ({rc}) begin rvalid_q <= 1'b0; err_q <= 1'b0; rdata_q <= '0;{' rid_q <= ' + chr(39) + '0;' if rid else ''} end",
          f"    else if (fire) begin rvalid_q <= 1'b1; rdata_q <= {S['we']} ? '0 : rd_data;"
          f" err_q <= {S['we']} ? ~wr_hit : ~rd_hit;{rid} end",
          f"    else if (rvalid_q{(' & ' + rr) if rr else ''}) rvalid_q <= 1'b0;", "  end"]
    return L, {"req", "gnt", "addr", "we", "be", "wdata", "rvalid", "rdata", "err", "rid", "aid", "rready"}


# ------------------------------------------------------------------ testbench BFMs
def has_err(c):
    S = c.sig
    t = c.bus["type"]
    return {"apb": "pslverr" in S, "ahb": "hresp" in S, "axi_lite": "bresp" in S and "rresp" in S,
            "axi": "bresp" in S and "rresp" in S, "ace": "bresp" in S and "rresp" in S,
            "ace_lite": "bresp" in S and "rresp" in S, "chi": "rxrspflit" in S or "rxrspflitv" in S,
            "wishbone": "err" in S, "avalon": "response" in S, "tilelink": "d_error" in S or "d_denied" in S,
            "obi": "err" in S}.get(t, False)


def tb_bfm(c):
    """Returns (task_lines, continuous_assign_lines, ports_not_to_init)."""
    S, clk, aw, dw = c.sig, c.clk, c.aw, c.dw
    t = c.bus["type"]
    hdr_w = f"  task automatic bus_wr(input logic [{aw-1}:0] a, input logic [{dw-1}:0] d, output logic e);"
    hdr_r = f"  task automatic bus_rd(input logic [{aw-1}:0] a, output logic [{dw-1}:0] d, output logic e);"
    N = f"@(negedge {clk}); #0.1;"
    A = tb_addr(c)
    set_ = lambda role, v: f" {S[role]} = {v};" if role in S else ""  # noqa: E731
    if t == "chi":
        txreqv = S.get("txreqflitv", "txreqflitv")
        txreq = S.get("txreqflit", "txreqflit")
        txdatv = S.get("txdatflitv", "txdatflitv")
        txdat = S.get("txdatflit", "txdatflit")
        txreqlcrdv = S.get("txreqlcrdv", "txreqlcrdv")
        rxrspv = S.get("rxrspflitv", "rxrspflitv")
        rxrsp = S.get("rxrspflit", "rxrspflit")
        rxdatv = S.get("rxdatflitv", "rxdatflitv")
        rxdat = S.get("rxdatflit", "rxdatflit")
        return [hdr_w,
                f"    @(negedge {clk}); {txreqv} = 1'b1; {txreq} = {{{A}, 1'b1}}; {txdatv} = 1'b1; {txdat} = d;",
                f"    #0.1; while (!{txreqlcrdv}) begin {N} end",
                f"    @(negedge {clk}); {txreqv} = 1'b0; {txdatv} = 1'b0; #0.1;",
                f"    while (!{rxrspv}) begin {N} end",
                f"    e = {rxrsp}[1];",
                f"    @(negedge {clk});", "  endtask",
                hdr_r,
                f"    @(negedge {clk}); {txreqv} = 1'b1; {txreq} = {{{A}, 1'b0}};",
                f"    #0.1; while (!{txreqlcrdv}) begin {N} end",
                f"    @(negedge {clk}); {txreqv} = 1'b0; #0.1;",
                f"    while (!{rxdatv}) begin {N} end",
                f"    d = {rxdat}[{dw+15}:16]; e = 1'b0;",
                f"    @(negedge {clk});", "  endtask"], [], set()
    if t == "apb":
        err = f"e = {S['pslverr']};" if "pslverr" in S else "e = 1'b0;"
        wait = f"while (!{S['pready']}) begin {N} end" if "pready" in S else ""
        return [hdr_w,
                f"    @(negedge {clk}); {S['paddr']} = {A}; {S['pwdata']} = d; {S['pwrite']} = 1'b1; {S['psel']} = 1'b1; {S['penable']} = 1'b0;{set_('pstrb', chr(39) + '1')}",
                f"    {N} {S['penable']} = 1'b1; #0.1;", f"    {wait}", f"    {err}",
                f"    @(negedge {clk}); {S['psel']} = 1'b0; {S['penable']} = 1'b0;", "  endtask",
                hdr_r,
                f"    @(negedge {clk}); {S['paddr']} = {A}; {S['pwrite']} = 1'b0; {S['psel']} = 1'b1; {S['penable']} = 1'b0;",
                f"    {N} {S['penable']} = 1'b1; #0.1;", f"    {wait}", f"    d = {S['prdata']}; {err}",
                f"    @(negedge {clk}); {S['psel']} = 1'b0; {S['penable']} = 1'b0;", "  endtask"], [], set()
    if t == "ahb":
        rdy = S.get("hreadyout") or "1'b1"
        err = f"if ({S['hresp']} != 0) e = 1'b1;" if "hresp" in S else ""
        assigns, noinit = [], set()
        if "hready_in" in S:
            assigns.append(f"  assign {S['hready_in']} = {rdy};")
            noinit.add(S["hready_in"])
        sz = set_("hsize", f"3'd{c.lsb}")
        def phase(write):
            return [f"    @(negedge {clk});{set_('hsel', chr(49) + chr(39) + 'b1')} {S['haddr']} = {A}; {S['htrans']} = 2'b10; {S['hwrite']} = 1'b{int(write)};{sz}{set_('hwstrb', chr(39) + '1')}",
                    f"    #0.1; while (!{rdy}) begin {N} end",
                    f"    @(negedge {clk});{set_('hsel', chr(49) + chr(39) + 'b0')} {S['htrans']} = 2'b00;" + (f" {S['hwdata']} = d;" if write else ""),
                    f"    #0.1; e = 1'b0; {err}",
                    f"    while (!{rdy}) begin {N} {err} end",
                    "" if write else f"    d = {S['hrdata']};"]
        return [hdr_w] + phase(True) + ["  endtask", hdr_r] + phase(False) + ["  endtask"], assigns, noinit
    if t in ("axi_lite", "axi", "ace", "ace_lite"):
        full = t != "axi_lite"
        ew = f"e = ({S['bresp']}[1:0] != 2'b00);" if "bresp" in S else "e = 1'b0;"
        er = f"e = ({S['rresp']}[1:0] != 2'b00);" if "rresp" in S else "e = 1'b0;"
        aw_extra = (set_("awlen", "'0") + set_("awsize", f"3'd{c.lsb}") + set_("awburst", "2'b01") +
                    set_("wlast", "1'b1")) if full else ""
        ar_extra = (set_("arlen", "'0") + set_("arsize", f"3'd{c.lsb}") + set_("arburst", "2'b01")) if full else ""
        L = [hdr_w,
             f"    @(negedge {clk}); {S['awaddr']} = {A}; {S['awvalid']} = 1'b1; {S['wdata']} = d; {S['wvalid']} = 1'b1;{set_('wstrb', chr(39) + '1')}{aw_extra}",
             f"    #0.1; while ({S['awvalid']} | {S['wvalid']}) begin",
             f"      automatic logic aw_hs = {S['awvalid']} & {S['awready']};",
             f"      automatic logic w_hs  = {S['wvalid']} & {S['wready']};",
             f"      @(negedge {clk}); if (aw_hs) {S['awvalid']} = 1'b0; if (w_hs) {S['wvalid']} = 1'b0; #0.1;",
             "    end",
             f"    {S['bready']} = 1'b1; while (!{S['bvalid']}) begin {N} end",
             f"    {ew}", f"    @(negedge {clk}); {S['bready']} = 1'b0;", "  endtask",
             hdr_r,
             f"    @(negedge {clk}); {S['araddr']} = {A}; {S['arvalid']} = 1'b1; {S['rready']} = 1'b0;{ar_extra}",
             f"    #0.1; while (!{S['arready']}) begin {N} end",
             f"    @(negedge {clk}); {S['arvalid']} = 1'b0; {S['rready']} = 1'b1; #0.1;",
             f"    while (!{S['rvalid']}) begin {N} end",
             f"    d = {S['rdata']}; {er}", f"    @(negedge {clk}); {S['rready']} = 1'b0;", "  endtask"]
        if full and "arlen" in S:
            L += [f"  logic [{dw-1}:0] bd [0:15];",
                  f"  task automatic bus_rd_burst(input logic [{aw-1}:0] a, input int n, input logic [1:0] bt);",
                  f"    @(negedge {clk}); {S['araddr']} = {A}; {S['arvalid']} = 1'b1; {S['arlen']} = {c.P[S['arlen']]['width']}'(n-1);{set_('arsize', f'3' + chr(39) + f'd{c.lsb}')}{set_('arburst', 'bt')}",
                  f"    #0.1; while (!{S['arready']}) begin {N} end",
                  f"    @(negedge {clk}); {S['arvalid']} = 1'b0; {S['rready']} = 1'b1; #0.1;",
                  "    for (int i = 0; i < n; i++) begin",
                  f"      while (!{S['rvalid']}) begin {N} end",
                  f"      bd[i] = {S['rdata']};",
                  (f"      if ((i == n-1) != {S['rlast']}) begin errs++; $display(\"ERROR  rlast wrong at beat %0d\", i); end" if "rlast" in S else ""),
                  f"      {N}", "    end", f"    {S['rready']} = 1'b0;", "  endtask"]
        return L, [], set()
    if t == "wishbone":
        piped = "stall" in S
        err = f"e = {S['err']};" if "err" in S else "e = 1'b0;"
        def cyc(write):
            L = [f"    @(negedge {clk}); {S['cyc']} = 1'b1; {S['stb']} = 1'b1; {S['we']} = 1'b{int(write)}; {S['adr']} = {A};{set_('sel', chr(39) + '1')}" + (f" {S['dat_w']} = d;" if write else "")]
            if piped:
                L += [f"    #0.1; while ({S['stall']}) begin {N} end", f"    @(negedge {clk}); {S['stb']} = 1'b0; #0.1;"]
            else:
                L += ["    #0.1;"]
            cond = f"{S['ack']}" + (f" | {S['err']}" if "err" in S else "")
            L += [f"    while (!({cond})) begin {N} end", f"    {err}" + ("" if write else f" d = {S['dat_r']};"),
                  f"    @(negedge {clk}); {S['cyc']} = 1'b0; {S['stb']} = 1'b0; {S['we']} = 1'b0;"]
            return L
        return [hdr_w] + cyc(True) + ["  endtask", hdr_r] + cyc(False) + ["  endtask"], [], set()
    if t == "avalon":
        wr_ = f"while ({S['waitrequest']}) begin {N} end" if "waitrequest" in S else ""
        resp = f"e = ({S['response']} != 0);" if "response" in S else "e = 1'b0;"
        cs = set_("chipselect", "1'b1")
        L = [hdr_w,
             f"    @(negedge {clk}); {S['address']} = {A}; {S['write']} = 1'b1; {S['writedata']} = d;{set_('byteenable', chr(39) + '1')}{cs}",
             f"    #0.1; {wr_}"]
        if "writeresponsevalid" in S:
            L += [f"    @(negedge {clk}); {S['write']} = 1'b0; #0.1;",
                  f"    while (!{S['writeresponsevalid']}) begin {N} end", f"    {resp}"]
        else:
            L += [f"    {resp}", f"    @(negedge {clk}); {S['write']} = 1'b0;"]
        L += ["  endtask", hdr_r,
              f"    @(negedge {clk}); {S['address']} = {A}; {S['read']} = 1'b1;{cs}", f"    #0.1; {wr_}"]
        if "readdatavalid" in S:
            L += [f"    @(negedge {clk}); {S['read']} = 1'b0; #0.1;",
                  f"    while (!{S['readdatavalid']}) begin {N} end", f"    d = {S['readdata']}; {resp}"]
        else:
            L += [f"    d = {S['readdata']}; {resp}", f"    @(negedge {clk}); {S['read']} = 1'b0;"]
        return L + ["  endtask"], [], set()
    if t == "tilelink":
        err = " | ".join(S[x] for x in ("d_error", "d_denied") if x in S) or "1'b0"
        asz = f" {S['a_size']} = {c.P[S['a_size']]['width']}'d{c.lsb};" if "a_size" in S else ""
        def tx(op, write):
            return [f"    @(negedge {clk}); {S['a_valid']} = 1'b1; {S['a_opcode']} = 3'd{op}; {S['a_address']} = {A}; {S['d_ready']} = 1'b1;"
                    f"{set_('a_mask', chr(39) + '1')}{asz}"
                    + (f" {S['a_data']} = d;" if write else ""),
                    f"    #0.1; while (!{S['a_ready']}) begin {N} end",
                    f"    @(negedge {clk}); {S['a_valid']} = 1'b0; #0.1;",
                    f"    while (!{S['d_valid']}) begin {N} end",
                    f"    e = {err};" + ("" if write else f" d = {S['d_data']};"),
                    f"    @(negedge {clk});"]
        return [hdr_w] + tx(0, True) + ["  endtask", hdr_r] + tx(4, False) + ["  endtask"], [], set()
    if t == "obi":
        err = f"e = {S['err']};" if "err" in S else "e = 1'b0;"
        rr = set_("rready", "1'b1")
        def tx(write):
            return [f"    @(negedge {clk}); {S['req']} = 1'b1; {S['we']} = 1'b{int(write)}; {S['addr']} = {A};{set_('be', chr(39) + '1')}{rr}" + (f" {S['wdata']} = d;" if write else ""),
                    f"    #0.1; while (!{S['gnt']}) begin {N} end",
                    f"    @(negedge {clk}); {S['req']} = 1'b0; #0.1;",
                    f"    while (!{S['rvalid']}) begin {N} end",
                    f"    {err}" + ("" if write else f" d = {S['rdata']};"), f"    @(negedge {clk});"]
        return [hdr_w] + tx(True) + ["  endtask", hdr_r] + tx(False) + ["  endtask"], [], set()
    return [], [], set()
