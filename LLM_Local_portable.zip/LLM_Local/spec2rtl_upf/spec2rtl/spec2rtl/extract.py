"""Spec extraction: PDF / DOCX / XLSX / CSV / MD / TXT -> plain text + tables.

Every reader returns (text: str, tables: list[list[list[str]]]).
"""
from __future__ import annotations
import csv
import re
from pathlib import Path


def _clean(c) -> str:
    return re.sub(r"\s+", " ", str(c if c is not None else "")).strip()


def _merge_continuations(tables):
    """PDF tables split across pages lose their header. If a table's first row
    doesn't look like a header and has the same column count as the previous
    table, append it to the previous table."""
    out = []
    for t in tables:
        t = [[_clean(c) for c in r] for r in t if any(_clean(c) for c in r)]
        if not t:
            continue
        if out and len(t[0]) == len(out[-1][0]) and not _looks_like_header(t[0]):
            out[-1].extend(t)
        else:
            out.append(t)
    return out


HEADER_WORDS = {"name", "port", "signal", "dir", "direction", "width", "offset",
                "address", "addr", "reset", "access", "type", "description",
                "bits", "bit", "field", "register", "default", "attribute", "size"}


def _looks_like_header(row) -> bool:
    words = {w.lower().strip("():") for c in row for w in c.split()}
    return len(words & HEADER_WORDS) >= 2


def read_pdf(p: Path):
    import pdfplumber
    text, tables = [], []
    with pdfplumber.open(str(p)) as pdf:
        for pg in pdf.pages:
            text.append(pg.extract_text() or "")
            tables.extend(pg.extract_tables() or [])
    return "\n".join(text), _merge_continuations(tables)


def read_docx(p: Path):
    import docx
    d = docx.Document(str(p))
    text = "\n".join(par.text for par in d.paragraphs)
    tables = [[[c.text for c in r.cells] for r in t.rows] for t in d.tables]
    return text, _merge_continuations(tables)


def read_xlsx(p: Path):
    import openpyxl
    wb = openpyxl.load_workbook(str(p), data_only=True)
    text, tables = [], []
    for ws in wb.worksheets:
        rows = [[_clean(c) for c in r] for r in ws.iter_rows(values_only=True)]
        rows = [r for r in rows if any(r)]
        if not rows:
            continue
        # Split a sheet into blocks at every header-looking row
        block = []
        for r in rows:
            if _looks_like_header(r) and block:
                tables.append(block)
                block = []
            block.append(r)
        tables.append(block)
        for r in rows:  # key:value style rows also go to text
            text.append(" ".join(c for c in r if c))
    return "\n".join(text), [t for t in tables if len(t) > 1]


def read_csv(p: Path):
    rows = list(csv.reader(p.open(newline="", encoding="utf-8", errors="ignore")))
    return "\n".join(" ".join(r) for r in rows), _merge_continuations([rows])


def read_md(p: Path):
    raw = p.read_text(encoding="utf-8", errors="ignore")
    tables, cur, text = [], [], []
    for line in raw.splitlines():
        s = line.strip()
        if s.startswith("|") and s.count("|") >= 2:
            cells = [c.strip() for c in s.strip("|").split("|")]
            if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
                continue  # separator row
            cur.append(cells)
        else:
            if cur:
                tables.append(cur)
                cur = []
            text.append(line)
    if cur:
        tables.append(cur)
    return "\n".join(text), _merge_continuations(tables)


def read_doc_legacy(p: Path):
    """Old binary .doc: convert via libreoffice/antiword if present."""
    import shutil
    import subprocess
    import tempfile
    if shutil.which("soffice"):
        with tempfile.TemporaryDirectory() as td:
            subprocess.run(["soffice", "--headless", "--convert-to", "docx",
                            "--outdir", td, str(p)], check=True,
                           capture_output=True)
            return read_docx(Path(td) / (p.stem + ".docx"))
    if shutil.which("antiword"):
        out = subprocess.run(["antiword", str(p)], capture_output=True,
                             text=True).stdout
        return out, []
    raise RuntimeError(".doc needs LibreOffice (soffice) or antiword; "
                       "or save it as .docx")


READERS = {".pdf": read_pdf, ".docx": read_docx, ".doc": read_doc_legacy,
           ".xlsx": read_xlsx, ".xlsm": read_xlsx, ".csv": read_csv,
           ".md": read_md, ".markdown": read_md, ".txt": read_md}


def extract(path: str):
    p = Path(path)
    ext = p.suffix.lower()
    if ext not in READERS:
        raise SystemExit(f"Unsupported spec format '{ext}'. "
                         f"Supported: {', '.join(sorted(READERS))}")
    return READERS[ext](p)
