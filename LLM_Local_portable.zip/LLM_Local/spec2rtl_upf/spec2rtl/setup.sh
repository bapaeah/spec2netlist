#!/usr/bin/env bash
# One-time setup (macOS / Linux)
set -e
python3 -m pip install -r "$(dirname "$0")/requirements.txt"
if [[ "$(uname)" == "Darwin" ]]; then
  command -v brew >/dev/null && brew install verilator yosys icarus-verilog || echo "Install Homebrew, then: brew install verilator yosys icarus-verilog"
else
  sudo apt-get install -y verilator yosys iverilog || python3 -m pip install yowasp-yosys
fi
echo "Tools:"; for t in verilator yosys yowasp-yosys iverilog; do command -v $t && $t -V 2>/dev/null | head -1; done
