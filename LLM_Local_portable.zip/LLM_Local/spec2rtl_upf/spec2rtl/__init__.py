"""
Spec2RTL Core Module Package.
"""
