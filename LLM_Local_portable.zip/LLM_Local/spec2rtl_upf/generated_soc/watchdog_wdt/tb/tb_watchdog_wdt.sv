`timescale 1ns/1ps
// Auto-generated self-checking TB for watchdog_wdt (APB3)
module tb_watchdog_wdt;
  localparam real HALF = 5.0000;  // 100.0 MHz
  logic clk = 1'b0;
  always #(HALF) clk = ~clk;
  logic rst_n;
  int errs = 0, warns = 0, checks = 0;
  logic [7:0] paddr;
  logic psel;
  logic penable;
  logic pwrite;
  logic [31:0] pwdata;
  logic pready;
  logic [31:0] prdata;
  logic pslverr;
  logic wd_reset_req;
  logic irq;

  watchdog_wdt dut (.clk(clk), .rst_n(rst_n), .paddr(paddr), .psel(psel), .penable(penable), .pwrite(pwrite), .pwdata(pwdata), .pready(pready), .prdata(prdata), .pslverr(pslverr), .wd_reset_req(wd_reset_req), .irq(irq));

  initial begin
    paddr = '0;
    psel = '0;
    penable = '0;
    pwrite = '0;
    pwdata = '0;
  end
  task automatic bus_wr(input logic [7:0] a, input logic [31:0] d, output logic e);
    @(negedge clk); paddr = a; pwdata = d; pwrite = 1'b1; psel = 1'b1; penable = 1'b0;
    @(negedge clk); #0.1; penable = 1'b1; #0.1;
    while (!pready) begin @(negedge clk); #0.1; end
    e = pslverr;
    @(negedge clk); psel = 1'b0; penable = 1'b0;
  endtask
  task automatic bus_rd(input logic [7:0] a, output logic [31:0] d, output logic e);
    @(negedge clk); paddr = a; pwrite = 1'b0; psel = 1'b1; penable = 1'b0;
    @(negedge clk); #0.1; penable = 1'b1; #0.1;
    while (!pready) begin @(negedge clk); #0.1; end
    d = prdata; e = pslverr;
    @(negedge clk); psel = 1'b0; penable = 1'b0;
  endtask
  task automatic check(input string what, input logic [31:0] got, exp, mask, input bit fatal);
    checks++;
    if ((got & mask) !== (exp & mask)) begin
      if (fatal) begin errs++;  $display("ERROR  %s: got %h exp %h (mask %h)", what, got, exp, mask); end
      else       begin warns++; $display("WARN   %s: got %h exp %h (mask %h) [core-driven]", what, got, exp, mask); end
    end
  endtask

  initial begin
    logic [31:0] d; logic e;
    rst_n = 1'b0;  // assert reset
    repeat (5) @(posedge clk);
    @(negedge clk); rst_n = 1'b1;  // release reset
    repeat (5) @(posedge clk);
    $display("--- Test 1: reset values ---");
    bus_rd(8'h0, d, e);
    check("CTRL reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(8'h4, d, e);
    check("BARK_THOLD reset (RW)", d, 32'hF0000, 32'hFFFFFFFF, 1);
    bus_rd(8'h8, d, e);
    check("BITE_THOLD reset (RW)", d, 32'h1F0000, 32'hFFFFFFFF, 1);
    bus_rd(8'h10, d, e);
    check("COUNT_VAL reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    $display("--- Test 2: RW write/read-back ---");
    bus_wr(8'h0, 32'hFFFFFFFF, e); bus_rd(8'h0, d, e); check("CTRL rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h0, e); bus_rd(8'h0, d, e); check("CTRL rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'hA5A5A5A5, e); bus_rd(8'h0, d, e); check("CTRL rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h5A5A5A5A, e); bus_rd(8'h0, d, e); check("CTRL rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h0, e);  // restore
    bus_wr(8'h4, 32'hFFFFFFFF, e); bus_rd(8'h4, d, e); check("BARK_THOLD rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'h0, e); bus_rd(8'h4, d, e); check("BARK_THOLD rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'hA5A5A5A5, e); bus_rd(8'h4, d, e); check("BARK_THOLD rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'h5A5A5A5A, e); bus_rd(8'h4, d, e); check("BARK_THOLD rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'hF0000, e);  // restore
    bus_wr(8'h8, 32'hFFFFFFFF, e); bus_rd(8'h8, d, e); check("BITE_THOLD rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h8, 32'h0, e); bus_rd(8'h8, d, e); check("BITE_THOLD rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h8, 32'hA5A5A5A5, e); bus_rd(8'h8, d, e); check("BITE_THOLD rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h8, 32'h5A5A5A5A, e); bus_rd(8'h8, d, e); check("BITE_THOLD rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h8, 32'h1F0000, e);  // restore
    $display("--- Test 3: unmapped address -> error response ---");
    bus_rd(8'h14, d, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped read"); end
    bus_wr(8'h14, '0, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped write"); end
    bus_rd(8'h0, d, e); checks++;
    if (e !== 1'b0) begin errs++; $display("ERROR  error response on valid read"); end
    // TODO: add functional tests for the core here
    $display("=====================================================");
    if (errs == 0) $display("TEST PASSED  (%0d checks, %0d warnings)", checks, warns);
    else           $display("TEST FAILED  (%0d errors, %0d warnings)", errs, warns);
    $display("=====================================================");
    $finish;
  end
  initial begin #(10.000 * 200000); $display("TEST FAILED (timeout)"); $finish; end
endmodule
