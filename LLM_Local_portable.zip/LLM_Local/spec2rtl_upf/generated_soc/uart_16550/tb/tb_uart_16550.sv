`timescale 1ns/1ps
// Auto-generated self-checking TB for uart_16550 (APB3)
module tb_uart_16550;
  localparam real HALF = 5.0000;  // 100.0 MHz
  logic clk = 1'b0;
  always #(HALF) clk = ~clk;
  logic rst_n;
  int errs = 0, warns = 0, checks = 0;
  logic [7:0] paddr;
  logic psel;
  logic penable;
  logic pwrite;
  logic [31:0] pwdata;
  logic pready;
  logic [31:0] prdata;
  logic pslverr;
  logic rxd;
  logic txd;
  logic cts_n;
  logic rts_n;
  logic dtr_n;
  logic dsr_n;
  logic irq;

  uart_16550 dut (.clk(clk), .rst_n(rst_n), .paddr(paddr), .psel(psel), .penable(penable), .pwrite(pwrite), .pwdata(pwdata), .pready(pready), .prdata(prdata), .pslverr(pslverr), .rxd(rxd), .txd(txd), .cts_n(cts_n), .rts_n(rts_n), .dtr_n(dtr_n), .dsr_n(dsr_n), .irq(irq));

  initial begin
    paddr = '0;
    psel = '0;
    penable = '0;
    pwrite = '0;
    pwdata = '0;
    rxd = '0;
    cts_n = '0;
    dsr_n = '0;
  end
  task automatic bus_wr(input logic [7:0] a, input logic [31:0] d, output logic e);
    @(negedge clk); paddr = a; pwdata = d; pwrite = 1'b1; psel = 1'b1; penable = 1'b0;
    @(negedge clk); #0.1; penable = 1'b1; #0.1;
    while (!pready) begin @(negedge clk); #0.1; end
    e = pslverr;
    @(negedge clk); psel = 1'b0; penable = 1'b0;
  endtask
  task automatic bus_rd(input logic [7:0] a, output logic [31:0] d, output logic e);
    @(negedge clk); paddr = a; pwrite = 1'b0; psel = 1'b1; penable = 1'b0;
    @(negedge clk); #0.1; penable = 1'b1; #0.1;
    while (!pready) begin @(negedge clk); #0.1; end
    d = prdata; e = pslverr;
    @(negedge clk); psel = 1'b0; penable = 1'b0;
  endtask
  task automatic check(input string what, input logic [31:0] got, exp, mask, input bit fatal);
    checks++;
    if ((got & mask) !== (exp & mask)) begin
      if (fatal) begin errs++;  $display("ERROR  %s: got %h exp %h (mask %h)", what, got, exp, mask); end
      else       begin warns++; $display("WARN   %s: got %h exp %h (mask %h) [core-driven]", what, got, exp, mask); end
    end
  endtask

  initial begin
    logic [31:0] d; logic e;
    rst_n = 1'b0;  // assert reset
    repeat (5) @(posedge clk);
    @(negedge clk); rst_n = 1'b1;  // release reset
    repeat (5) @(posedge clk);
    $display("--- Test 1: reset values ---");
    bus_rd(8'h0, d, e);
    check("RBR_THR_DLL reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(8'h4, d, e);
    check("IER_DLM reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(8'h8, d, e);
    check("IIR_FCR reset (RW)", d, 32'h1, 32'hFFFFFFFF, 1);
    bus_rd(8'hC, d, e);
    check("LCR reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(8'h10, d, e);
    check("MCR reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(8'h14, d, e);
    check("LSR reset (RO)", d, 32'h60, 32'hFFFFFFFF, 0);
    bus_rd(8'h18, d, e);
    check("MSR reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(8'h1C, d, e);
    check("SCR reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    $display("--- Test 2: RW write/read-back ---");
    bus_wr(8'h0, 32'hFFFFFFFF, e); bus_rd(8'h0, d, e); check("RBR_THR_DLL rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h0, e); bus_rd(8'h0, d, e); check("RBR_THR_DLL rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'hA5A5A5A5, e); bus_rd(8'h0, d, e); check("RBR_THR_DLL rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h5A5A5A5A, e); bus_rd(8'h0, d, e); check("RBR_THR_DLL rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h0, e);  // restore
    bus_wr(8'h4, 32'hFFFFFFFF, e); bus_rd(8'h4, d, e); check("IER_DLM rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'h0, e); bus_rd(8'h4, d, e); check("IER_DLM rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'hA5A5A5A5, e); bus_rd(8'h4, d, e); check("IER_DLM rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'h5A5A5A5A, e); bus_rd(8'h4, d, e); check("IER_DLM rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'h0, e);  // restore
    bus_wr(8'h8, 32'hFFFFFFFF, e); bus_rd(8'h8, d, e); check("IIR_FCR rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h8, 32'h0, e); bus_rd(8'h8, d, e); check("IIR_FCR rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h8, 32'hA5A5A5A5, e); bus_rd(8'h8, d, e); check("IIR_FCR rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h8, 32'h5A5A5A5A, e); bus_rd(8'h8, d, e); check("IIR_FCR rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h8, 32'h1, e);  // restore
    bus_wr(8'hC, 32'hFFFFFFFF, e); bus_rd(8'hC, d, e); check("LCR rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'hC, 32'h0, e); bus_rd(8'hC, d, e); check("LCR rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'hC, 32'hA5A5A5A5, e); bus_rd(8'hC, d, e); check("LCR rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'hC, 32'h5A5A5A5A, e); bus_rd(8'hC, d, e); check("LCR rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'hC, 32'h0, e);  // restore
    bus_wr(8'h10, 32'hFFFFFFFF, e); bus_rd(8'h10, d, e); check("MCR rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h10, 32'h0, e); bus_rd(8'h10, d, e); check("MCR rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h10, 32'hA5A5A5A5, e); bus_rd(8'h10, d, e); check("MCR rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h10, 32'h5A5A5A5A, e); bus_rd(8'h10, d, e); check("MCR rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h10, 32'h0, e);  // restore
    bus_wr(8'h1C, 32'hFFFFFFFF, e); bus_rd(8'h1C, d, e); check("SCR rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h1C, 32'h0, e); bus_rd(8'h1C, d, e); check("SCR rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h1C, 32'hA5A5A5A5, e); bus_rd(8'h1C, d, e); check("SCR rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h1C, 32'h5A5A5A5A, e); bus_rd(8'h1C, d, e); check("SCR rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h1C, 32'h0, e);  // restore
    $display("--- Test 3: unmapped address -> error response ---");
    bus_rd(8'h20, d, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped read"); end
    bus_wr(8'h20, '0, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped write"); end
    bus_rd(8'h0, d, e); checks++;
    if (e !== 1'b0) begin errs++; $display("ERROR  error response on valid read"); end
    // TODO: add functional tests for the core here
    $display("=====================================================");
    if (errs == 0) $display("TEST PASSED  (%0d checks, %0d warnings)", checks, warns);
    else           $display("TEST FAILED  (%0d errors, %0d warnings)", errs, warns);
    $display("=====================================================");
    $finish;
  end
  initial begin #(10.000 * 200000); $display("TEST FAILED (timeout)"); $finish; end
endmodule
