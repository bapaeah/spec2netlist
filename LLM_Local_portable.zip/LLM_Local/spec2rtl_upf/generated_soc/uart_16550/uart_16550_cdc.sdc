# ===========================================================================
# CDC / RDC Constraints - IP Core: uart_16550
# Generated autonomously by Spec2RTL CDC Engine
# Target Cell Library: NanGate45
# ===========================================================================

# 1. Primary Clock Definition
create_clock -name clk -period 10.000 [get_ports clk]

# 2. Asynchronous Clock Domain Groups (CDC Isolation)
# Single clock domain detected (clk); external asynchronous inputs require 2-FF synchronizers.

# 3. Reset Domain Crossing (RDC) & Async Reset False Paths
set_false_path -from [get_ports rst_n]

# 4. CDC Synchronizer Flip-Flop Attributes (Prevent shift-register LUT absorption)
set_property ASYNC_REG true [get_cells -hierarchical *sync*]
set_property ASYNC_REG true [get_cells -hierarchical *cdc_ff*]

# 5. Maximum Datapath Delay on Asynchronous Crossings
# Ensures signal transition time is constrained to receiving clock period
set_max_delay -datapath_only 10.000 -from [get_cells -hierarchical *cdc_src*] -to [get_cells -hierarchical *cdc_dest*] 2>/dev/null || true

# End of CDC constraints for uart_16550
