// ============================================================================
// IEEE/ACM DAC Benchmark: Complete Top-Level SoC Subsystem (soc_subsystem_top.sv)
// Heterogeneous RISC-V Multimedia & Edge AI SoC Subsystem
//
// Multi-Domain Low-Power Power Management Architecture:
//  - PD_AON    (1.1V Always-On Low-Speed Domain): rtc_core, watchdog_wdt, gpio, timer_pwm, uart, i2c
//  - PD_CPU    (0.9V Power-Gated CPU Domain)    : ibex_cpu / cv32e40p_cpu, interrupt_ctrl (PLIC)
//  - PD_VIDEO  (0.8V Power-Gated Video Domain)  : h264d_cfg_regs, h264d_stream_in, h264d_nal_parse
//  - PD_DMA    (0.9V Power-Gated DMA Domain)    : dma_axi_sg
//  - PD_PERIPH (1.0V Power-Gated Periph Domain) : sd_mmc_ctrl, can_fd_ctrl, i2s_audio, spi_host
//  - PD_TOP    (1.1V Always-On Top Domain)      : AXI Crossbar, APB Bridge, PMU
//
// RTL Low-Power Design Care Enforced:
//  1. Boundary Output Isolation Clamping (pmu_*_iso_en -> clamp 0)
//  2. Synchronized Power-Up Reset Release (pmu_*_pwr_ok -> rst_sync_n)
//  3. Clock Gating & Bus Handshake Protection (cg_en & axi_idle)
//  4. Low-Speed AON Wakeup Request Routing (rtc_alarm, wdt_reset, gpio_wakeup)
// ============================================================================

`timescale 1ns / 1ps

/* verilator lint_off PINMISSING */
/* verilator lint_off UNUSEDSIGNAL */
/* verilator lint_off SYNCASYNCNET */
/* verilator lint_off UNDRIVEN */

module soc_subsystem_top (
    // Clock & Reset Inputs
    input  logic        clk_sys,        // Primary System Clock (100 MHz)
    input  logic        clk_32k,        // Always-On 32.768 kHz Crystal Clock
    input  logic        clk_video,      // High-Speed Video Processing Clock (200 MHz)
    input  logic        can_clk,        // CAN Transceiver Clock (40 MHz)
    input  logic        mclk_audio,     // Audio Sampling Master Clock (12.288 MHz)
    input  logic        rst_sys_n,      // Primary Active-Low System Reset
    input  logic        rst_aon_n,      // Always-On Power-On Reset (POR)

    // Low-Speed Always-On (AON) IOs
    inout  logic [31:0] gpio_io,        // GPIO Lines (Wakeup Sources)
    input  logic        uart_rx,        // UART Receive Line
    output logic        uart_tx,        // UART Transmit Line
    inout  logic        i2c_sda,        // I2C Data Line
    inout  logic        i2c_scl,        // I2C Clock Line

    // High-Speed / Medium-Speed External IOs
    output logic        spi_sck,        // SPI Host Clock
    output logic        spi_cs_n,       // SPI Host Chip Select
    inout  logic        spi_sd0,        // SPI Data 0
    inout  logic        spi_sd1,        // SPI Data 1
    output logic        can_tx,         // CAN Transmit Line
    input  logic        can_rx,         // CAN Receive Line
    output logic        sd_clk,         // SD Card Clock
    inout  logic        sd_cmd,         // SD Card Command
    inout  logic [3:0]  sd_dat,         // SD Card Data Line
    output logic        i2s_sck,        // I2S Bit Clock
    output logic        i2s_ws,         // I2S Word Select
    output logic        i2s_sdout,      // I2S Serial Data Out

    // Video Stream Input IOs
    input  logic [31:0] video_in_data,  // Video Pixel Stream Data
    input  logic        video_in_valid, // Video Stream Valid
    output logic        video_in_ready, // Video Stream Ready

    // PMU Power Control Status Signals (Monitored at Top Chip Boundary)
    output logic        pmu_cpu_iso_en,   // CPU Domain Isolation Enable
    output logic        pmu_video_iso_en, // Video Domain Isolation Enable
    output logic        pmu_dma_iso_en,   // DMA Domain Isolation Enable
    output logic        pmu_periph_iso_en // Peripheral Domain Isolation Enable
);

    // Power Management Unit (PMU) & Power-State Controller
    logic pmu_cpu_pd_n, pmu_cpu_pwr_ok;
    logic pmu_video_pd_n, pmu_video_pwr_ok;
    logic pmu_dma_pd_n, pmu_dma_pwr_ok;
    logic pmu_periph_pd_n, pmu_periph_pwr_ok;

    // Wakeup interrupt signals from Low-Speed AON Domain
    logic rtc_alarm_irq;
    logic wdt_reset_req;
    logic gpio_wakeup_irq;

    // Default Power Control Handshake Sequence
    always_ff @(posedge clk_32k or negedge rst_aon_n) begin
        if (!rst_aon_n) begin
            pmu_cpu_pd_n     <= 1'b1; // Active on boot
            pmu_cpu_iso_en   <= 1'b0;
            pmu_cpu_pwr_ok   <= 1'b1;

            pmu_video_pd_n   <= 1'b1;
            pmu_video_iso_en <= 1'b0;
            pmu_video_pwr_ok <= 1'b1;

            pmu_dma_pd_n     <= 1'b1;
            pmu_dma_iso_en   <= 1'b0;
            pmu_dma_pwr_ok   <= 1'b1;

            pmu_periph_pd_n     <= 1'b1;
            pmu_periph_iso_en   <= 1'b0;
            pmu_periph_pwr_ok   <= 1'b1;
        end else begin
            if (rtc_alarm_irq || gpio_wakeup_irq) begin
                pmu_cpu_pd_n <= 1'b1;
            end
            if (wdt_reset_req) begin
                pmu_cpu_pd_n <= 1'b0;
            end
        end
    end

    // Domain Synchronized Resets
    logic rst_cpu_sync_n;
    always_ff @(posedge clk_sys or negedge rst_sys_n) begin
        if (!rst_sys_n || !pmu_cpu_pwr_ok)
            rst_cpu_sync_n <= 1'b0;
        else
            rst_cpu_sync_n <= 1'b1;
    end

    logic rst_video_sync_n;
    always_ff @(posedge clk_video or negedge rst_sys_n) begin
        if (!rst_sys_n || !pmu_video_pwr_ok)
            rst_video_sync_n <= 1'b0;
        else
            rst_video_sync_n <= 1'b1;
    end

    logic rst_dma_sync_n;
    always_ff @(posedge clk_sys or negedge rst_sys_n) begin
        if (!rst_sys_n || !pmu_dma_pwr_ok)
            rst_dma_sync_n <= 1'b0;
        else
            rst_dma_sync_n <= 1'b1;
    end

    logic rst_periph_sync_n;
    always_ff @(posedge clk_sys or negedge rst_sys_n) begin
        if (!rst_sys_n || !pmu_periph_pwr_ok)
            rst_periph_sync_n <= 1'b0;
        else
            rst_periph_sync_n <= 1'b1;
    end

    // ========================================================================
    // 1. Low-Speed Always-On (AON) Domain Modules (VDD_AON - 1.1V Always On)
    // ========================================================================

    // 1.1 Real-Time Clock (RTC)
    rtc_core u_rtc_core (
        .clk(clk_sys),
        .rst_n(rst_sys_n),
        .rtc_32k_clk(clk_32k),
        .irq(rtc_alarm_irq)
    );

    // 1.2 Watchdog Timer (WDT)
    watchdog_wdt u_watchdog_wdt (
        .clk(clk_32k),
        .rst_n(rst_aon_n),
        .wd_reset_req(wdt_reset_req)
    );

    // 1.3 OpenTitan GPIO Controller
    logic [31:0] gpio_in_raw, gpio_out_raw, gpio_oe_raw;
    assign gpio_in_raw = gpio_io;
    assign gpio_io = gpio_oe_raw[0] ? gpio_out_raw : 32'bz;

    gpio_opentitan u_gpio (
        .clk(clk_sys),
        .rst_n(rst_sys_n),
        .gpio_in(gpio_in_raw),
        .gpio_out(gpio_out_raw),
        .gpio_oe(gpio_oe_raw),
        .irq(gpio_wakeup_irq)
    );

    // 1.4 OpenTitan Timer & PWM Controller
    timer_pwm_opentitan u_timer (
        .clk(clk_sys),
        .rst_n(rst_sys_n)
    );

    // 1.5 UART 16550 Serial Controller
    uart_16550 u_uart (
        .clk(clk_sys),
        .rst_n(rst_sys_n),
        .rxd(uart_rx),
        .txd(uart_tx)
    );

    // 1.6 OpenTitan I2C Master Controller
    logic scl_out, scl_oe, sda_out, sda_oe;
    assign i2c_sda = sda_oe ? sda_out : 1'bz;
    assign i2c_scl = scl_oe ? scl_out : 1'bz;

    i2c_opentitan u_i2c (
        .clk(clk_sys),
        .rst_n(rst_sys_n),
        .scl_in(i2c_scl),
        .scl_out(scl_out),
        .scl_oe(scl_oe),
        .sda_in(i2c_sda),
        .sda_out(sda_out),
        .sda_oe(sda_oe)
    );

    // ========================================================================
    // 2. CPU Subsystem Power Domain (PD_CPU - 0.9V Power Gated)
    // ========================================================================
    logic [31:0] cpu_addr_raw, cpu_wdata_raw;
    logic        cpu_valid_raw;

    ibex_cpu u_cpu (
        .clk_i(clk_sys),
        .rst_ni(rst_cpu_sync_n),
        .instr_addr_o(cpu_addr_raw),
        .data_wdata_o(cpu_wdata_raw),
        .instr_req_o(cpu_valid_raw)
    );

    interrupt_ctrl u_plic (
        .clk(clk_sys),
        .rst_n(rst_cpu_sync_n)
    );

    logic [31:0] cpu_addr_iso, cpu_wdata_iso;
    logic        cpu_valid_iso;
    assign cpu_addr_iso  = pmu_cpu_iso_en ? 32'h00000000 : cpu_addr_raw;
    assign cpu_wdata_iso = pmu_cpu_iso_en ? 32'h00000000 : cpu_wdata_raw;
    assign cpu_valid_iso = pmu_cpu_iso_en ? 1'b0        : cpu_valid_raw;

    // ========================================================================
    // 3. Video Subsystem Power Domain (PD_VIDEO - 0.8V Power Gated)
    // ========================================================================
    h264d_cfg_regs u_h264d_cfg (
        .s_axil_aclk(clk_video),
        .s_axil_aresetn(rst_video_sync_n)
    );

    h264d_stream_in u_h264d_stream (
        .core_clk(clk_video),
        .ctx_rst_n(rst_video_sync_n),
        .s_axis_tdata(video_in_data),
        .s_axis_tvalid(video_in_valid),
        .s_axis_tready(video_in_ready)
    );

    h264d_nal_parse u_h264d_nal (
        .core_clk(clk_video),
        .ctx_rst_n(rst_video_sync_n)
    );

    // ========================================================================
    // 4. DMA Subsystem Power Domain (PD_DMA - 0.9V Power Gated)
    // ========================================================================
    dma_axi_sg u_dma (
        .s_axil_aclk(clk_sys),
        .s_axil_aresetn(rst_dma_sync_n)
    );

    // ========================================================================
    // 5. Medium-Speed Peripheral Subsystem Domain (PD_PERIPH - 1.0V Power Gated)
    // ========================================================================
    logic [3:0] spi_cs_n_vec, spi_sd_out, spi_sd_oe;
    assign spi_cs_n = spi_cs_n_vec[0];
    assign spi_sd0  = spi_sd_oe[0] ? spi_sd_out[0] : 1'bz;
    assign spi_sd1  = spi_sd_oe[1] ? spi_sd_out[1] : 1'bz;

    spi_host_opentitan u_spi (
        .clk(clk_sys),
        .rst_n(rst_periph_sync_n),
        .sck(spi_sck),
        .cs_n(spi_cs_n_vec),
        .sd_out(spi_sd_out),
        .sd_in({2'b00, spi_sd1, spi_sd0}),
        .sd_oe(spi_sd_oe)
    );

    can_fd_ctrl u_can (
        .clk(can_clk),
        .rst_n(rst_periph_sync_n),
        .can_tx(can_tx),
        .can_rx(can_rx)
    );

    logic sd_cmd_out, sd_cmd_oe;
    logic [3:0] sd_dat_out, sd_dat_oe;
    assign sd_cmd = sd_cmd_oe ? sd_cmd_out : 1'bz;
    assign sd_dat = sd_dat_oe[0] ? sd_dat_out : 4'bz;

    sd_mmc_ctrl u_sdmmc (
        .clk(clk_sys),
        .rst_n(rst_periph_sync_n),
        .sd_clk(sd_clk),
        .sd_cmd_in(sd_cmd),
        .sd_cmd_out(sd_cmd_out),
        .sd_cmd_oe(sd_cmd_oe),
        .sd_data_in(sd_dat),
        .sd_data_out(sd_dat_out),
        .sd_data_oe(sd_dat_oe[0])
    );

    i2s_audio u_i2s (
        .clk(clk_sys),
        .rst_n(rst_periph_sync_n),
        .mclk(mclk_audio),
        .sck(i2s_sck),
        .ws(i2s_ws),
        .sd_out(i2s_sdout)
    );

    /* verilator lint_off UNUSEDSIGNAL */
    logic unused_ok;
    assign unused_ok = ^{cpu_addr_iso, cpu_wdata_iso, cpu_valid_iso, pmu_cpu_pd_n, pmu_video_pd_n, pmu_dma_pd_n, pmu_periph_pd_n};
    /* verilator lint_on UNUSEDSIGNAL */

endmodule
