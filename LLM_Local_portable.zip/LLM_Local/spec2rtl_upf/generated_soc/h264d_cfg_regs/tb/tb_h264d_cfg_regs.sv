`timescale 1ns/1ps
// Auto-generated self-checking TB for h264d_cfg_regs (AXI4-Lite)
module tb_h264d_cfg_regs;
  localparam real HALF = 5.0000;  // 100.0 MHz
  logic s_axil_aclk = 1'b0;
  always #(HALF) s_axil_aclk = ~s_axil_aclk;
  logic s_axil_aresetn;
  int errs = 0, warns = 0, checks = 0;
  logic [11:0] s_axil_awaddr;
  logic s_axil_awvalid;
  logic s_axil_awready;
  logic [31:0] s_axil_wdata;
  logic [3:0] s_axil_wstrb;
  logic s_axil_wvalid;
  logic s_axil_wready;
  logic [1:0] s_axil_bresp;
  logic s_axil_bvalid;
  logic s_axil_bready;
  logic [11:0] s_axil_araddr;
  logic s_axil_arvalid;
  logic s_axil_arready;
  logic [31:0] s_axil_rdata;
  logic [1:0] s_axil_rresp;
  logic s_axil_rvalid;
  logic s_axil_rready;
  logic [31:0] lock_image;
  logic fuse_valid;
  logic fuse_shadow;
  logic [95:0] cfg_snapshot;
  logic snapshot_ack;
  logic irq_req;
  logic irq_en;
  logic irq;
  logic [3:0] rst_state;
  logic sw_reset_req;
  logic flush_req;
  logic rst_ack;
  logic [7:0] err_code;
  logic [3:0] status_bits;
  logic [31:0] perf_bins;
  logic [31:0] perf_mbs;
  logic [15:0] err_conceal_cnt;
  logic rst_cmd;
  logic soft_reset;

  h264d_cfg_regs dut (.s_axil_aclk(s_axil_aclk), .s_axil_aresetn(s_axil_aresetn), .s_axil_awaddr(s_axil_awaddr), .s_axil_awvalid(s_axil_awvalid), .s_axil_awready(s_axil_awready), .s_axil_wdata(s_axil_wdata), .s_axil_wstrb(s_axil_wstrb), .s_axil_wvalid(s_axil_wvalid), .s_axil_wready(s_axil_wready), .s_axil_bresp(s_axil_bresp), .s_axil_bvalid(s_axil_bvalid), .s_axil_bready(s_axil_bready), .s_axil_araddr(s_axil_araddr), .s_axil_arvalid(s_axil_arvalid), .s_axil_arready(s_axil_arready), .s_axil_rdata(s_axil_rdata), .s_axil_rresp(s_axil_rresp), .s_axil_rvalid(s_axil_rvalid), .s_axil_rready(s_axil_rready), .lock_image(lock_image), .fuse_valid(fuse_valid), .fuse_shadow(fuse_shadow), .cfg_snapshot(cfg_snapshot), .snapshot_ack(snapshot_ack), .irq_req(irq_req), .irq_en(irq_en), .irq(irq), .rst_state(rst_state), .sw_reset_req(sw_reset_req), .flush_req(flush_req), .rst_ack(rst_ack), .err_code(err_code), .status_bits(status_bits), .perf_bins(perf_bins), .perf_mbs(perf_mbs), .err_conceal_cnt(err_conceal_cnt), .rst_cmd(rst_cmd), .soft_reset(soft_reset));

  initial begin
    s_axil_awaddr = '0;
    s_axil_awvalid = '0;
    s_axil_wdata = '0;
    s_axil_wstrb = '0;
    s_axil_wvalid = '0;
    s_axil_bready = '0;
    s_axil_araddr = '0;
    s_axil_arvalid = '0;
    s_axil_rready = '0;
    lock_image = '0;
    fuse_valid = '0;
    snapshot_ack = '0;
    irq_req = '0;
    rst_state = '0;
    rst_ack = '0;
    err_code = '0;
    status_bits = '0;
    perf_bins = '0;
    perf_mbs = '0;
    err_conceal_cnt = '0;
    rst_cmd = '0;
    soft_reset = '0;
  end
  task automatic bus_wr(input logic [11:0] a, input logic [31:0] d, output logic e);
    @(negedge s_axil_aclk); s_axil_awaddr = a; s_axil_awvalid = 1'b1; s_axil_wdata = d; s_axil_wvalid = 1'b1; s_axil_wstrb = '1;
    #0.1; while (s_axil_awvalid | s_axil_wvalid) begin
      automatic logic aw_hs = s_axil_awvalid & s_axil_awready;
      automatic logic w_hs  = s_axil_wvalid & s_axil_wready;
      @(negedge s_axil_aclk); if (aw_hs) s_axil_awvalid = 1'b0; if (w_hs) s_axil_wvalid = 1'b0; #0.1;
    end
    s_axil_bready = 1'b1; while (!s_axil_bvalid) begin @(negedge s_axil_aclk); #0.1; end
    e = (s_axil_bresp[1:0] != 2'b00);
    @(negedge s_axil_aclk); s_axil_bready = 1'b0;
  endtask
  task automatic bus_rd(input logic [11:0] a, output logic [31:0] d, output logic e);
    @(negedge s_axil_aclk); s_axil_araddr = a; s_axil_arvalid = 1'b1; s_axil_rready = 1'b0;
    #0.1; while (!s_axil_arready) begin @(negedge s_axil_aclk); #0.1; end
    @(negedge s_axil_aclk); s_axil_arvalid = 1'b0; s_axil_rready = 1'b1; #0.1;
    while (!s_axil_rvalid) begin @(negedge s_axil_aclk); #0.1; end
    d = s_axil_rdata; e = (s_axil_rresp[1:0] != 2'b00);
    @(negedge s_axil_aclk); s_axil_rready = 1'b0;
  endtask
  task automatic check(input string what, input logic [31:0] got, exp, mask, input bit fatal);
    checks++;
    if ((got & mask) !== (exp & mask)) begin
      if (fatal) begin errs++;  $display("ERROR  %s: got %h exp %h (mask %h)", what, got, exp, mask); end
      else       begin warns++; $display("WARN   %s: got %h exp %h (mask %h) [core-driven]", what, got, exp, mask); end
    end
  endtask

  initial begin
    logic [31:0] d; logic e;
    s_axil_aresetn = 1'b0;  // assert reset
    repeat (5) @(posedge s_axil_aclk);
    @(negedge s_axil_aclk); s_axil_aresetn = 1'b1;  // release reset
    repeat (5) @(posedge s_axil_aclk);
    $display("--- Test 1: reset values ---");
    bus_rd(12'h0, d, e);
    check("CTRL reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h4, d, e);
    check("STATUS reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h8, d, e);
    check("STREAM_MODE reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'hC, d, e);
    check("STREAM_DESC_PTR reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h10, d, e);
    check("STREAM_DESC_CNT reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h14, d, e);
    check("OUTBUF_BASE reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h18, d, e);
    check("OUTBUF_STRIDE reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h1C, d, e);
    check("FRAME_W_MB reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h20, d, e);
    check("FRAME_H_MB reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h24, d, e);
    check("REF_CONFIG reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h28, d, e);
    check("PROFILE_LEVEL reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h2C, d, e);
    check("IRQ_STATUS reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h30, d, e);
    check("PERF_BIN_CNT reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h34, d, e);
    check("PERF_MB_CNT reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h38, d, e);
    check("ERR_CONCEAL_CNT reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h3C, d, e);
    check("ERR_CODE reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h40, d, e);
    check("FEATURE_LOCK reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h44, d, e);
    check("LOCK_STATUS reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h4C, d, e);
    check("RST_STATE reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h50, d, e);
    check("VERSION reset (RO)", d, 32'h1000000, 32'hFFFFFFFF, 0);
    $display("--- Test 2: RW write/read-back ---");
    bus_wr(12'h0, 32'hFFFFFFFF, e); bus_rd(12'h0, d, e); check("CTRL rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h0, 32'h0, e); bus_rd(12'h0, d, e); check("CTRL rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h0, 32'hA5A5A5A5, e); bus_rd(12'h0, d, e); check("CTRL rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h0, 32'h5A5A5A5A, e); bus_rd(12'h0, d, e); check("CTRL rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h0, 32'h0, e);  // restore
    bus_wr(12'h8, 32'hFFFFFFFF, e); bus_rd(12'h8, d, e); check("STREAM_MODE rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h8, 32'h0, e); bus_rd(12'h8, d, e); check("STREAM_MODE rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h8, 32'hA5A5A5A5, e); bus_rd(12'h8, d, e); check("STREAM_MODE rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h8, 32'h5A5A5A5A, e); bus_rd(12'h8, d, e); check("STREAM_MODE rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h8, 32'h0, e);  // restore
    bus_wr(12'hC, 32'hFFFFFFFF, e); bus_rd(12'hC, d, e); check("STREAM_DESC_PTR rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'hC, 32'h0, e); bus_rd(12'hC, d, e); check("STREAM_DESC_PTR rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'hC, 32'hA5A5A5A5, e); bus_rd(12'hC, d, e); check("STREAM_DESC_PTR rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'hC, 32'h5A5A5A5A, e); bus_rd(12'hC, d, e); check("STREAM_DESC_PTR rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'hC, 32'h0, e);  // restore
    bus_wr(12'h10, 32'hFFFFFFFF, e); bus_rd(12'h10, d, e); check("STREAM_DESC_CNT rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h10, 32'h0, e); bus_rd(12'h10, d, e); check("STREAM_DESC_CNT rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h10, 32'hA5A5A5A5, e); bus_rd(12'h10, d, e); check("STREAM_DESC_CNT rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h10, 32'h5A5A5A5A, e); bus_rd(12'h10, d, e); check("STREAM_DESC_CNT rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h10, 32'h0, e);  // restore
    bus_wr(12'h14, 32'hFFFFFFFF, e); bus_rd(12'h14, d, e); check("OUTBUF_BASE rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h14, 32'h0, e); bus_rd(12'h14, d, e); check("OUTBUF_BASE rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h14, 32'hA5A5A5A5, e); bus_rd(12'h14, d, e); check("OUTBUF_BASE rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h14, 32'h5A5A5A5A, e); bus_rd(12'h14, d, e); check("OUTBUF_BASE rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h14, 32'h0, e);  // restore
    bus_wr(12'h18, 32'hFFFFFFFF, e); bus_rd(12'h18, d, e); check("OUTBUF_STRIDE rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h18, 32'h0, e); bus_rd(12'h18, d, e); check("OUTBUF_STRIDE rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h18, 32'hA5A5A5A5, e); bus_rd(12'h18, d, e); check("OUTBUF_STRIDE rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h18, 32'h5A5A5A5A, e); bus_rd(12'h18, d, e); check("OUTBUF_STRIDE rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h18, 32'h0, e);  // restore
    bus_wr(12'h1C, 32'hFFFFFFFF, e); bus_rd(12'h1C, d, e); check("FRAME_W_MB rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h1C, 32'h0, e); bus_rd(12'h1C, d, e); check("FRAME_W_MB rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h1C, 32'hA5A5A5A5, e); bus_rd(12'h1C, d, e); check("FRAME_W_MB rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h1C, 32'h5A5A5A5A, e); bus_rd(12'h1C, d, e); check("FRAME_W_MB rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h1C, 32'h0, e);  // restore
    bus_wr(12'h20, 32'hFFFFFFFF, e); bus_rd(12'h20, d, e); check("FRAME_H_MB rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h20, 32'h0, e); bus_rd(12'h20, d, e); check("FRAME_H_MB rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h20, 32'hA5A5A5A5, e); bus_rd(12'h20, d, e); check("FRAME_H_MB rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h20, 32'h5A5A5A5A, e); bus_rd(12'h20, d, e); check("FRAME_H_MB rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h20, 32'h0, e);  // restore
    bus_wr(12'h24, 32'hFFFFFFFF, e); bus_rd(12'h24, d, e); check("REF_CONFIG rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h24, 32'h0, e); bus_rd(12'h24, d, e); check("REF_CONFIG rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h24, 32'hA5A5A5A5, e); bus_rd(12'h24, d, e); check("REF_CONFIG rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h24, 32'h5A5A5A5A, e); bus_rd(12'h24, d, e); check("REF_CONFIG rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h24, 32'h0, e);  // restore
    bus_wr(12'h40, 32'hFFFFFFFF, e); bus_rd(12'h40, d, e); check("FEATURE_LOCK rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h40, 32'h0, e); bus_rd(12'h40, d, e); check("FEATURE_LOCK rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h40, 32'hA5A5A5A5, e); bus_rd(12'h40, d, e); check("FEATURE_LOCK rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h40, 32'h5A5A5A5A, e); bus_rd(12'h40, d, e); check("FEATURE_LOCK rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h40, 32'h0, e);  // restore
    $display("--- Test 3: unmapped address -> error response ---");
    bus_rd(12'h54, d, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped read"); end
    bus_wr(12'h54, '0, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped write"); end
    bus_rd(12'h0, d, e); checks++;
    if (e !== 1'b0) begin errs++; $display("ERROR  error response on valid read"); end
    // TODO: add functional tests for the core here
    $display("=====================================================");
    if (errs == 0) $display("TEST PASSED  (%0d checks, %0d warnings)", checks, warns);
    else           $display("TEST FAILED  (%0d errors, %0d warnings)", errs, warns);
    $display("=====================================================");
    $finish;
  end
  initial begin #(10.000 * 200000); $display("TEST FAILED (timeout)"); $finish; end
endmodule
