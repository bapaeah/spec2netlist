`timescale 1ns/1ps
// Auto-generated self-checking TB for h264d_nal_parse (none)
module tb_h264d_nal_parse;
  localparam real HALF = 5.0000;  // 100.0 MHz
  logic core_clk = 1'b0;
  always #(HALF) core_clk = ~core_clk;
  logic ctx_rst_n;
  int errs = 0, warns = 0, checks = 0;
  logic [7:0] strm_data;
  logic strm_valid;
  logic strm_ready;
  logic [4:0] nal_type;
  logic [1:0] nal_ref_idc;
  logic [7:0] nal_payload;
  logic nal_valid;
  logic nal_ready;
  logic syntax_err;

  h264d_nal_parse dut (.core_clk(core_clk), .ctx_rst_n(ctx_rst_n), .strm_data(strm_data), .strm_valid(strm_valid), .strm_ready(strm_ready), .nal_type(nal_type), .nal_ref_idc(nal_ref_idc), .nal_payload(nal_payload), .nal_valid(nal_valid), .nal_ready(nal_ready), .syntax_err(syntax_err));

  initial begin
    strm_data = '0;
    strm_valid = '0;
    nal_ready = '0;
  end
  task automatic check(input string what, input logic [31:0] got, exp, mask, input bit fatal);
    checks++;
    if ((got & mask) !== (exp & mask)) begin
      if (fatal) begin errs++;  $display("ERROR  %s: got %h exp %h (mask %h)", what, got, exp, mask); end
      else       begin warns++; $display("WARN   %s: got %h exp %h (mask %h) [core-driven]", what, got, exp, mask); end
    end
  endtask

  initial begin
    logic [31:0] d; logic e;
    ctx_rst_n = 1'b0;  // assert reset
    repeat (5) @(posedge core_clk);
    @(negedge core_clk); ctx_rst_n = 1'b1;  // release reset
    repeat (5) @(posedge core_clk);
    // TODO: add functional tests for the core here
    $display("=====================================================");
    if (errs == 0) $display("TEST PASSED  (%0d checks, %0d warnings)", checks, warns);
    else           $display("TEST FAILED  (%0d errors, %0d warnings)", errs, warns);
    $display("=====================================================");
    $finish;
  end
  initial begin #(10.000 * 200000); $display("TEST FAILED (timeout)"); $finish; end
endmodule
