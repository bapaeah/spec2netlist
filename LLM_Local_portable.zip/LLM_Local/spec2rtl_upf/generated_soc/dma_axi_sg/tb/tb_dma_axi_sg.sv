`timescale 1ns/1ps
// Auto-generated self-checking TB for dma_axi_sg (AXI4-Lite)
module tb_dma_axi_sg;
  localparam real HALF = 5.0000;  // 100.0 MHz
  logic s_axil_aclk = 1'b0;
  always #(HALF) s_axil_aclk = ~s_axil_aclk;
  logic s_axil_aresetn;
  int errs = 0, warns = 0, checks = 0;
  logic [11:0] s_axil_awaddr;
  logic s_axil_awvalid;
  logic s_axil_awready;
  logic [31:0] s_axil_wdata;
  logic [3:0] s_axil_wstrb;
  logic s_axil_wvalid;
  logic s_axil_wready;
  logic [1:0] s_axil_bresp;
  logic s_axil_bvalid;
  logic s_axil_bready;
  logic [11:0] s_axil_araddr;
  logic s_axil_arvalid;
  logic s_axil_arready;
  logic [31:0] s_axil_rdata;
  logic [1:0] s_axil_rresp;
  logic s_axil_rvalid;
  logic s_axil_rready;
  logic [3:0] dma_irq;

  dma_axi_sg dut (.s_axil_aclk(s_axil_aclk), .s_axil_aresetn(s_axil_aresetn), .s_axil_awaddr(s_axil_awaddr), .s_axil_awvalid(s_axil_awvalid), .s_axil_awready(s_axil_awready), .s_axil_wdata(s_axil_wdata), .s_axil_wstrb(s_axil_wstrb), .s_axil_wvalid(s_axil_wvalid), .s_axil_wready(s_axil_wready), .s_axil_bresp(s_axil_bresp), .s_axil_bvalid(s_axil_bvalid), .s_axil_bready(s_axil_bready), .s_axil_araddr(s_axil_araddr), .s_axil_arvalid(s_axil_arvalid), .s_axil_arready(s_axil_arready), .s_axil_rdata(s_axil_rdata), .s_axil_rresp(s_axil_rresp), .s_axil_rvalid(s_axil_rvalid), .s_axil_rready(s_axil_rready), .dma_irq(dma_irq));

  initial begin
    s_axil_awaddr = '0;
    s_axil_awvalid = '0;
    s_axil_wdata = '0;
    s_axil_wstrb = '0;
    s_axil_wvalid = '0;
    s_axil_bready = '0;
    s_axil_araddr = '0;
    s_axil_arvalid = '0;
    s_axil_rready = '0;
  end
  task automatic bus_wr(input logic [11:0] a, input logic [31:0] d, output logic e);
    @(negedge s_axil_aclk); s_axil_awaddr = a; s_axil_awvalid = 1'b1; s_axil_wdata = d; s_axil_wvalid = 1'b1; s_axil_wstrb = '1;
    #0.1; while (s_axil_awvalid | s_axil_wvalid) begin
      automatic logic aw_hs = s_axil_awvalid & s_axil_awready;
      automatic logic w_hs  = s_axil_wvalid & s_axil_wready;
      @(negedge s_axil_aclk); if (aw_hs) s_axil_awvalid = 1'b0; if (w_hs) s_axil_wvalid = 1'b0; #0.1;
    end
    s_axil_bready = 1'b1; while (!s_axil_bvalid) begin @(negedge s_axil_aclk); #0.1; end
    e = (s_axil_bresp[1:0] != 2'b00);
    @(negedge s_axil_aclk); s_axil_bready = 1'b0;
  endtask
  task automatic bus_rd(input logic [11:0] a, output logic [31:0] d, output logic e);
    @(negedge s_axil_aclk); s_axil_araddr = a; s_axil_arvalid = 1'b1; s_axil_rready = 1'b0;
    #0.1; while (!s_axil_arready) begin @(negedge s_axil_aclk); #0.1; end
    @(negedge s_axil_aclk); s_axil_arvalid = 1'b0; s_axil_rready = 1'b1; #0.1;
    while (!s_axil_rvalid) begin @(negedge s_axil_aclk); #0.1; end
    d = s_axil_rdata; e = (s_axil_rresp[1:0] != 2'b00);
    @(negedge s_axil_aclk); s_axil_rready = 1'b0;
  endtask
  task automatic check(input string what, input logic [31:0] got, exp, mask, input bit fatal);
    checks++;
    if ((got & mask) !== (exp & mask)) begin
      if (fatal) begin errs++;  $display("ERROR  %s: got %h exp %h (mask %h)", what, got, exp, mask); end
      else       begin warns++; $display("WARN   %s: got %h exp %h (mask %h) [core-driven]", what, got, exp, mask); end
    end
  endtask

  initial begin
    logic [31:0] d; logic e;
    s_axil_aresetn = 1'b0;  // assert reset
    repeat (5) @(posedge s_axil_aclk);
    @(negedge s_axil_aclk); s_axil_aresetn = 1'b1;  // release reset
    repeat (5) @(posedge s_axil_aclk);
    $display("--- Test 1: reset values ---");
    bus_rd(12'h0, d, e);
    check("DMA_CTRL reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h4, d, e);
    check("DMA_STATUS reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h10, d, e);
    check("CH0_CTRL reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h14, d, e);
    check("CH0_DESC_PTR reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h18, d, e);
    check("CH0_BYTES_DONE reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(12'h20, d, e);
    check("CH1_CTRL reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(12'h24, d, e);
    check("CH1_DESC_PTR reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    $display("--- Test 2: RW write/read-back ---");
    bus_wr(12'h0, 32'hFFFFFFFF, e); bus_rd(12'h0, d, e); check("DMA_CTRL rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h0, 32'h0, e); bus_rd(12'h0, d, e); check("DMA_CTRL rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h0, 32'hA5A5A5A5, e); bus_rd(12'h0, d, e); check("DMA_CTRL rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h0, 32'h5A5A5A5A, e); bus_rd(12'h0, d, e); check("DMA_CTRL rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h0, 32'h0, e);  // restore
    bus_wr(12'h10, 32'hFFFFFFFF, e); bus_rd(12'h10, d, e); check("CH0_CTRL rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h10, 32'h0, e); bus_rd(12'h10, d, e); check("CH0_CTRL rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h10, 32'hA5A5A5A5, e); bus_rd(12'h10, d, e); check("CH0_CTRL rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h10, 32'h5A5A5A5A, e); bus_rd(12'h10, d, e); check("CH0_CTRL rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h10, 32'h0, e);  // restore
    bus_wr(12'h14, 32'hFFFFFFFF, e); bus_rd(12'h14, d, e); check("CH0_DESC_PTR rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h14, 32'h0, e); bus_rd(12'h14, d, e); check("CH0_DESC_PTR rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h14, 32'hA5A5A5A5, e); bus_rd(12'h14, d, e); check("CH0_DESC_PTR rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h14, 32'h5A5A5A5A, e); bus_rd(12'h14, d, e); check("CH0_DESC_PTR rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h14, 32'h0, e);  // restore
    bus_wr(12'h20, 32'hFFFFFFFF, e); bus_rd(12'h20, d, e); check("CH1_CTRL rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h20, 32'h0, e); bus_rd(12'h20, d, e); check("CH1_CTRL rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h20, 32'hA5A5A5A5, e); bus_rd(12'h20, d, e); check("CH1_CTRL rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h20, 32'h5A5A5A5A, e); bus_rd(12'h20, d, e); check("CH1_CTRL rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h20, 32'h0, e);  // restore
    bus_wr(12'h24, 32'hFFFFFFFF, e); bus_rd(12'h24, d, e); check("CH1_DESC_PTR rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(12'h24, 32'h0, e); bus_rd(12'h24, d, e); check("CH1_DESC_PTR rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(12'h24, 32'hA5A5A5A5, e); bus_rd(12'h24, d, e); check("CH1_DESC_PTR rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(12'h24, 32'h5A5A5A5A, e); bus_rd(12'h24, d, e); check("CH1_DESC_PTR rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(12'h24, 32'h0, e);  // restore
    $display("--- Test 3: unmapped address -> error response ---");
    bus_rd(12'h28, d, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped read"); end
    bus_wr(12'h28, '0, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped write"); end
    bus_rd(12'h0, d, e); checks++;
    if (e !== 1'b0) begin errs++; $display("ERROR  error response on valid read"); end
    // TODO: add functional tests for the core here
    $display("=====================================================");
    if (errs == 0) $display("TEST PASSED  (%0d checks, %0d warnings)", checks, warns);
    else           $display("TEST FAILED  (%0d errors, %0d warnings)", errs, warns);
    $display("=====================================================");
    $finish;
  end
  initial begin #(10.000 * 200000); $display("TEST FAILED (timeout)"); $finish; end
endmodule
