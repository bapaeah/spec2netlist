`timescale 1ns/1ps
// Auto-generated self-checking TB for h264d_stream_in (none)
module tb_h264d_stream_in;
  localparam real HALF = 5.0000;  // 100.0 MHz
  logic core_clk = 1'b0;
  always #(HALF) core_clk = ~core_clk;
  logic ctx_rst_n;
  int errs = 0, warns = 0, checks = 0;
  logic mem_clk;
  logic s_axis_aclk;
  logic dma_rst_n;
  logic reset_sequencing;
  logic [31:0] s_axis_tdata;
  logic s_axis_tvalid;
  logic s_axis_tready;
  logic s_axis_tlast;
  logic s_axis_tuser;
  logic stream_mode;
  logic [31:0] desc_list_ptr;
  logic [15:0] desc_count;
  logic [31:0] ring_base;
  logic cfg_update;
  logic [7:0] strm_data;
  logic strm_valid;
  logic strm_ready;
  logic strm_underrun;
  logic [31:0] pts_meta;
  logic [31:0] dma_ar_req_ar_addr_ar_len;
  logic dma_r_data_r_valid;
  logic [31:0] dma_aw_req_aw_addr_aw_len;
  logic [1:0] dma_w_data_w_valid_w_last;
  logic [1:0] dma_b_valid_b_resp;
  logic [3:0] dma_qos;
  logic [31:0] ring_rd_req_rd_addr_rd_len;
  logic ring_rd_data_rd_valid;
  logic busy;
  logic underrun_sticky;
  logic desc_err;
  logic [8:0] fifo_level;
  logic [31:0] ring_wptr_ring_rptr;

  h264d_stream_in dut (.core_clk(core_clk), .mem_clk(mem_clk), .s_axis_aclk(s_axis_aclk), .ctx_rst_n(ctx_rst_n), .dma_rst_n(dma_rst_n), .reset_sequencing(reset_sequencing), .s_axis_tdata(s_axis_tdata), .s_axis_tvalid(s_axis_tvalid), .s_axis_tready(s_axis_tready), .s_axis_tlast(s_axis_tlast), .s_axis_tuser(s_axis_tuser), .stream_mode(stream_mode), .desc_list_ptr(desc_list_ptr), .desc_count(desc_count), .ring_base(ring_base), .cfg_update(cfg_update), .strm_data(strm_data), .strm_valid(strm_valid), .strm_ready(strm_ready), .strm_underrun(strm_underrun), .pts_meta(pts_meta), .dma_ar_req_ar_addr_ar_len(dma_ar_req_ar_addr_ar_len), .dma_r_data_r_valid(dma_r_data_r_valid), .dma_aw_req_aw_addr_aw_len(dma_aw_req_aw_addr_aw_len), .dma_w_data_w_valid_w_last(dma_w_data_w_valid_w_last), .dma_b_valid_b_resp(dma_b_valid_b_resp), .dma_qos(dma_qos), .ring_rd_req_rd_addr_rd_len(ring_rd_req_rd_addr_rd_len), .ring_rd_data_rd_valid(ring_rd_data_rd_valid), .busy(busy), .underrun_sticky(underrun_sticky), .desc_err(desc_err), .fifo_level(fifo_level), .ring_wptr_ring_rptr(ring_wptr_ring_rptr));

  initial begin
    mem_clk = '0;
    s_axis_aclk = '0;
    dma_rst_n = '0;
    reset_sequencing = '0;
    s_axis_tdata = '0;
    s_axis_tvalid = '0;
    s_axis_tlast = '0;
    s_axis_tuser = '0;
    stream_mode = '0;
    desc_list_ptr = '0;
    desc_count = '0;
    ring_base = '0;
    cfg_update = '0;
    strm_ready = '0;
    dma_r_data_r_valid = '0;
    dma_b_valid_b_resp = '0;
    ring_rd_data_rd_valid = '0;
  end
  task automatic check(input string what, input logic [31:0] got, exp, mask, input bit fatal);
    checks++;
    if ((got & mask) !== (exp & mask)) begin
      if (fatal) begin errs++;  $display("ERROR  %s: got %h exp %h (mask %h)", what, got, exp, mask); end
      else       begin warns++; $display("WARN   %s: got %h exp %h (mask %h) [core-driven]", what, got, exp, mask); end
    end
  endtask

  initial begin
    logic [31:0] d; logic e;
    ctx_rst_n = 1'b0;  // assert reset
    repeat (5) @(posedge core_clk);
    @(negedge core_clk); ctx_rst_n = 1'b1;  // release reset
    repeat (5) @(posedge core_clk);
    // TODO: add functional tests for the core here
    $display("=====================================================");
    if (errs == 0) $display("TEST PASSED  (%0d checks, %0d warnings)", checks, warns);
    else           $display("TEST FAILED  (%0d errors, %0d warnings)", errs, warns);
    $display("=====================================================");
    $finish;
  end
  initial begin #(10.000 * 200000); $display("TEST FAILED (timeout)"); $finish; end
endmodule
