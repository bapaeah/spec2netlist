rtl/gpio_opentitan_regs.sv
rtl/gpio_opentitan_core.sv
rtl/gpio_opentitan.sv
