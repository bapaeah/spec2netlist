`timescale 1ns/1ps
// Auto-generated self-checking TB for ibex_cpu (none)
module tb_ibex_cpu;
  localparam real HALF = 5.0000;  // 100.0 MHz
  logic clk_i = 1'b0;
  always #(HALF) clk_i = ~clk_i;
  logic rst_ni;
  int errs = 0, warns = 0, checks = 0;
  logic instr_req_o;
  logic instr_gnt_i;
  logic instr_rvalid_i;
  logic [31:0] instr_addr_o;
  logic [31:0] instr_rdata_i;
  logic instr_err_i;
  logic data_req_o;
  logic data_gnt_i;
  logic data_rvalid_i;
  logic data_we_o;
  logic [3:0] data_be_o;
  logic [31:0] data_addr_o;
  logic [31:0] data_wdata_o;
  logic [31:0] data_rdata_i;
  logic data_err_i;
  logic irq_software_i;
  logic irq_timer_i;
  logic irq_external_i;
  logic [14:0] irq_fast_i;

  ibex_cpu dut (.clk_i(clk_i), .rst_ni(rst_ni), .instr_req_o(instr_req_o), .instr_gnt_i(instr_gnt_i), .instr_rvalid_i(instr_rvalid_i), .instr_addr_o(instr_addr_o), .instr_rdata_i(instr_rdata_i), .instr_err_i(instr_err_i), .data_req_o(data_req_o), .data_gnt_i(data_gnt_i), .data_rvalid_i(data_rvalid_i), .data_we_o(data_we_o), .data_be_o(data_be_o), .data_addr_o(data_addr_o), .data_wdata_o(data_wdata_o), .data_rdata_i(data_rdata_i), .data_err_i(data_err_i), .irq_software_i(irq_software_i), .irq_timer_i(irq_timer_i), .irq_external_i(irq_external_i), .irq_fast_i(irq_fast_i));

  initial begin
    instr_gnt_i = '0;
    instr_rvalid_i = '0;
    instr_rdata_i = '0;
    instr_err_i = '0;
    data_gnt_i = '0;
    data_rvalid_i = '0;
    data_rdata_i = '0;
    data_err_i = '0;
    irq_software_i = '0;
    irq_timer_i = '0;
    irq_external_i = '0;
    irq_fast_i = '0;
  end
  task automatic check(input string what, input logic [31:0] got, exp, mask, input bit fatal);
    checks++;
    if ((got & mask) !== (exp & mask)) begin
      if (fatal) begin errs++;  $display("ERROR  %s: got %h exp %h (mask %h)", what, got, exp, mask); end
      else       begin warns++; $display("WARN   %s: got %h exp %h (mask %h) [core-driven]", what, got, exp, mask); end
    end
  endtask

  initial begin
    logic [31:0] d; logic e;
    rst_ni = 1'b0;  // assert reset
    repeat (5) @(posedge clk_i);
    @(negedge clk_i); rst_ni = 1'b1;  // release reset
    repeat (5) @(posedge clk_i);
    // TODO: add functional tests for the core here
    $display("=====================================================");
    if (errs == 0) $display("TEST PASSED  (%0d checks, %0d warnings)", checks, warns);
    else           $display("TEST FAILED  (%0d errors, %0d warnings)", errs, warns);
    $display("=====================================================");
    $finish;
  end
  initial begin #(10.000 * 200000); $display("TEST FAILED (timeout)"); $finish; end
endmodule
