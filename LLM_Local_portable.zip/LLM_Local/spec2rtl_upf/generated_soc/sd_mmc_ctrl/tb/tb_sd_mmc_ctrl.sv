`timescale 1ns/1ps
// Auto-generated self-checking TB for sd_mmc_ctrl (AHB-Lite)
module tb_sd_mmc_ctrl;
  localparam real HALF = 5.0000;  // 100.0 MHz
  logic clk = 1'b0;
  always #(HALF) clk = ~clk;
  logic rst_n;
  int errs = 0, warns = 0, checks = 0;
  logic [7:0] haddr;
  logic hsel;
  logic hwrite;
  logic [1:0] htrans;
  logic [31:0] hwdata;
  logic hreadyout;
  logic [31:0] hrdata;
  logic hresp;
  logic sd_clk;
  logic sd_cmd_in;
  logic sd_cmd_out;
  logic sd_cmd_oe;
  logic [3:0] sd_data_in;
  logic [3:0] sd_data_out;
  logic sd_data_oe;
  logic irq;

  sd_mmc_ctrl dut (.clk(clk), .rst_n(rst_n), .haddr(haddr), .hsel(hsel), .hwrite(hwrite), .htrans(htrans), .hwdata(hwdata), .hreadyout(hreadyout), .hrdata(hrdata), .hresp(hresp), .sd_clk(sd_clk), .sd_cmd_in(sd_cmd_in), .sd_cmd_out(sd_cmd_out), .sd_cmd_oe(sd_cmd_oe), .sd_data_in(sd_data_in), .sd_data_out(sd_data_out), .sd_data_oe(sd_data_oe), .irq(irq));

  initial begin
    haddr = '0;
    hsel = '0;
    hwrite = '0;
    htrans = '0;
    hwdata = '0;
    sd_cmd_in = '0;
    sd_data_in = '0;
  end
  task automatic bus_wr(input logic [7:0] a, input logic [31:0] d, output logic e);
    @(negedge clk); hsel = 1'b1; haddr = a; htrans = 2'b10; hwrite = 1'b1;
    #0.1; while (!hreadyout) begin @(negedge clk); #0.1; end
    @(negedge clk); hsel = 1'b0; htrans = 2'b00; hwdata = d;
    #0.1; e = 1'b0; if (hresp != 0) e = 1'b1;
    while (!hreadyout) begin @(negedge clk); #0.1; if (hresp != 0) e = 1'b1; end

  endtask
  task automatic bus_rd(input logic [7:0] a, output logic [31:0] d, output logic e);
    @(negedge clk); hsel = 1'b1; haddr = a; htrans = 2'b10; hwrite = 1'b0;
    #0.1; while (!hreadyout) begin @(negedge clk); #0.1; end
    @(negedge clk); hsel = 1'b0; htrans = 2'b00;
    #0.1; e = 1'b0; if (hresp != 0) e = 1'b1;
    while (!hreadyout) begin @(negedge clk); #0.1; if (hresp != 0) e = 1'b1; end
    d = hrdata;
  endtask
  task automatic check(input string what, input logic [31:0] got, exp, mask, input bit fatal);
    checks++;
    if ((got & mask) !== (exp & mask)) begin
      if (fatal) begin errs++;  $display("ERROR  %s: got %h exp %h (mask %h)", what, got, exp, mask); end
      else       begin warns++; $display("WARN   %s: got %h exp %h (mask %h) [core-driven]", what, got, exp, mask); end
    end
  endtask

  initial begin
    logic [31:0] d; logic e;
    rst_n = 1'b0;  // assert reset
    repeat (5) @(posedge clk);
    @(negedge clk); rst_n = 1'b1;  // release reset
    repeat (5) @(posedge clk);
    $display("--- Test 1: reset values ---");
    bus_rd(8'h0, d, e);
    check("ARGUMENT reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(8'h4, d, e);
    check("COMMAND reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_rd(8'h8, d, e);
    check("RESP0 reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(8'hC, d, e);
    check("RESP1 reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(8'h10, d, e);
    check("STATUS reset (RO)", d, 32'h0, 32'hFFFFFFFF, 0);
    bus_rd(8'h14, d, e);
    check("INTR_ENABLE reset (RW)", d, 32'h0, 32'hFFFFFFFF, 1);
    $display("--- Test 2: RW write/read-back ---");
    bus_wr(8'h0, 32'hFFFFFFFF, e); bus_rd(8'h0, d, e); check("ARGUMENT rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h0, e); bus_rd(8'h0, d, e); check("ARGUMENT rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'hA5A5A5A5, e); bus_rd(8'h0, d, e); check("ARGUMENT rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h5A5A5A5A, e); bus_rd(8'h0, d, e); check("ARGUMENT rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h0, 32'h0, e);  // restore
    bus_wr(8'h4, 32'hFFFFFFFF, e); bus_rd(8'h4, d, e); check("COMMAND rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'h0, e); bus_rd(8'h4, d, e); check("COMMAND rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'hA5A5A5A5, e); bus_rd(8'h4, d, e); check("COMMAND rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'h5A5A5A5A, e); bus_rd(8'h4, d, e); check("COMMAND rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h4, 32'h0, e);  // restore
    bus_wr(8'h14, 32'hFFFFFFFF, e); bus_rd(8'h14, d, e); check("INTR_ENABLE rw FFFFFFFF", d, 32'hFFFFFFFF, 32'hFFFFFFFF, 1);
    bus_wr(8'h14, 32'h0, e); bus_rd(8'h14, d, e); check("INTR_ENABLE rw 00000000", d, 32'h0, 32'hFFFFFFFF, 1);
    bus_wr(8'h14, 32'hA5A5A5A5, e); bus_rd(8'h14, d, e); check("INTR_ENABLE rw A5A5A5A5", d, 32'hA5A5A5A5, 32'hFFFFFFFF, 1);
    bus_wr(8'h14, 32'h5A5A5A5A, e); bus_rd(8'h14, d, e); check("INTR_ENABLE rw 5A5A5A5A", d, 32'h5A5A5A5A, 32'hFFFFFFFF, 1);
    bus_wr(8'h14, 32'h0, e);  // restore
    $display("--- Test 3: unmapped address -> error response ---");
    bus_rd(8'h18, d, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped read"); end
    bus_wr(8'h18, '0, e); checks++;
    if (e !== 1'b1) begin errs++; $display("ERROR  no error response on unmapped write"); end
    bus_rd(8'h0, d, e); checks++;
    if (e !== 1'b0) begin errs++; $display("ERROR  error response on valid read"); end
    // TODO: add functional tests for the core here
    $display("=====================================================");
    if (errs == 0) $display("TEST PASSED  (%0d checks, %0d warnings)", checks, warns);
    else           $display("TEST FAILED  (%0d errors, %0d warnings)", errs, warns);
    $display("=====================================================");
    $finish;
  end
  initial begin #(10.000 * 200000); $display("TEST FAILED (timeout)"); $finish; end
endmodule
