rtl/spi_host_opentitan_regs.sv
rtl/spi_host_opentitan_core.sv
rtl/spi_host_opentitan.sv
