# PowerShell Launcher for Spec2RTL + AutoUPF with Local LLM (Windows Native)
$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $ScriptDir

# Set local LLM environment variables for Ollama
# Ollama host comes from $env:OLLAMA_HOST or `rtl --models --set-host http://<ip>:11434`
$env:SPEC2RTL_LLM_KEY = "ollama"
if (-not $env:SPEC2RTL_LLM_MODEL) {
    $env:SPEC2RTL_LLM_MODEL = "auto"   # best of qwen2.5-coder:32b / deepseek-coder-v2:16b / 7b for the host GPU/RAM
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " Running Spec2RTL + AutoUPF with Local LLM ($env:SPEC2RTL_LLM_MODEL)" -ForegroundColor Cyan
$endpoint = if ($env:SPEC2RTL_LLM_URL) { $env:SPEC2RTL_LLM_URL } else { python -c "import sys;sys.path.insert(0,'..');import ollama_models as m;print(m.ollama_host())" }
Write-Host " Endpoint: $endpoint" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# Check if --llm is already passed, otherwise append it
$hasLLM = $false
foreach ($arg in $args) {
    if ($arg -eq "--llm") { $hasLLM = $true; break }
}

if ($hasLLM) {
    python main.py @args
} else {
    python main.py --llm @args
}
