import re
from pathlib import Path
from typing import List, Dict, Optional
from dataclasses import dataclass, field

@dataclass
class UPFDomain:
    name: str
    scope: str = "/"
    elements: List[str] = field(default_factory=list)

@dataclass
class UPFIsolation:
    name: str
    domain: str
    isolation_signal: str
    clamp_value: str = "0"
    applies_to: str = "outputs"

@dataclass
class UPFLevelShifter:
    name: str
    domain: str
    rule: str = "both"  # "low_to_high", "high_to_low", "both"

@dataclass
class UPFSpec:
    file_path: str
    version: str = "2.1"
    domains: Dict[str, UPFDomain] = field(default_factory=dict)
    isolations: Dict[str, UPFIsolation] = field(default_factory=dict)
    level_shifters: Dict[str, UPFLevelShifter] = field(default_factory=dict)
    loaded_upfs: List[str] = field(default_factory=list)

class UPFParser:
    """
    Parses IEEE 1801 UPF files (.upf) into structured UPFSpec objects.
    """

    def parse_upf(self, upf_path: str) -> UPFSpec:
        path = Path(upf_path)
        if not path.exists():
            raise FileNotFoundError(f"UPF file not found: {upf_path}")

        content = path.read_text(encoding="utf-8", errors="ignore")

        # Strip comment lines (#)
        lines = [line.split("#")[0].strip() for line in content.splitlines() if line.strip() and not line.strip().startswith("#")]
        full_text = " ".join(lines)

        spec = UPFSpec(file_path=str(path))

        # 1. Match upf_version
        v_match = re.search(r"upf_version\s+([0-9\.]+)", full_text)
        if v_match:
            spec.version = v_match.group(1)

        # 2. Match create_power_domain
        domain_matches = re.findall(r"create_power_domain\s+(\w+)(?:\s+-elements\s*\{([^\}]+)\})?", full_text)
        for dom_name, elements_str in domain_matches:
            elem_list = elements_str.split() if elements_str else []
            spec.domains[dom_name] = UPFDomain(name=dom_name, elements=elem_list)

        # 3. Match set_isolation
        iso_matches = re.findall(
            r"set_isolation\s+(\w+)\s+-domain\s+(\w+).*?-isolation_signal\s*\{([^\}]+)\}.*?-clamp_value\s+(\d+)",
            full_text
        )
        for iso_name, dom_name, iso_sig, clamp_val in iso_matches:
            spec.isolations[iso_name] = UPFIsolation(
                name=iso_name,
                domain=dom_name,
                isolation_signal=iso_sig.strip(),
                clamp_value=clamp_val.strip(),
            )

        # 4. Match set_level_shifter
        els_matches = re.findall(r"set_level_shifter\s+(\w+)\s+-domain\s+(\w+)", full_text)
        for els_name, dom_name in els_matches:
            spec.level_shifters[els_name] = UPFLevelShifter(name=els_name, domain=dom_name)

        # 5. Match load_upf
        load_matches = re.findall(r"load_upf\s+[\"']?([^\"'\s]+)[\"']?", full_text)
        spec.loaded_upfs = load_matches

        return spec
