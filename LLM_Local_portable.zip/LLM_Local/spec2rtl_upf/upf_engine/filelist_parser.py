import re
from pathlib import Path
from typing import List, Dict

class FileListParser:
    """
    Parses SystemVerilog and Verilog EDA filelists (.f, .flist, .vc, .f_list).
    Handles:
    - File extensions: .sv, .svh, .svi, .v, .vh, .V, .SV
    - Options: +incdir+, +define+, -v (library file), -F / -f (nested filelists)
    - Relative path resolution relative to filelist location and current working directory
    """

    def parse_filelist(self, filelist_path: str) -> Dict[str, List[Path]]:
        fl_path = Path(filelist_path).resolve()
        if not fl_path.exists():
            # Fallback to current working directory if relative
            fl_path = Path.cwd() / filelist_path
            if not fl_path.exists():
                raise FileNotFoundError(f"Filelist not found at: {filelist_path}")

        source_files: List[Path] = []
        include_dirs: List[Path] = []
        defines: List[str] = []

        self._parse_recursive(fl_path, source_files, include_dirs, defines, set())

        return {
            "source_files": source_files,
            "include_dirs": include_dirs,
            "defines": defines,
        }

    def _parse_recursive(
        self,
        current_fl: Path,
        source_files: List[Path],
        include_dirs: List[Path],
        defines: List[str],
        visited: set,
    ):
        if current_fl in visited:
            return
        visited.add(current_fl)

        if not current_fl.exists():
            print(f"\033[91mWarning:\033[0m Nested filelist not found: {current_fl}")
            return

        with open(current_fl, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()

        valid_extensions = {".v", ".sv", ".vh", ".svh", ".svi", ".V", ".SV"}

        for line in lines:
            line_str = line.strip()

            # Handle comments
            if line_str.startswith("//") or line_str.startswith("#"):
                continue
            if "//" in line_str:
                line_str = line_str.split("//")[0].strip()

            if not line_str:
                continue

            # Process +incdir+
            if line_str.startswith("+incdir+"):
                inc_str = line_str.replace("+incdir+", "").strip()
                for p in inc_str.split("+"):
                    resolved = (current_fl.parent / p).resolve()
                    if resolved not in include_dirs:
                        include_dirs.append(resolved)

            # Process +define+
            elif line_str.startswith("+define+"):
                def_str = line_str.replace("+define+", "").strip()
                defines.append(def_str)

            # Process nested filelist -f or -F
            elif line_str.startswith("-f ") or line_str.startswith("-F "):
                nested_fl_str = line_str[3:].strip()
                nested_path = (current_fl.parent / nested_fl_str).resolve()
                if not nested_path.exists():
                    nested_path = (Path.cwd() / nested_fl_str).resolve()
                self._parse_recursive(nested_path, source_files, include_dirs, defines, visited)

            # Process -v library file option
            elif line_str.startswith("-v "):
                v_file_str = line_str[3:].strip()
                v_path = (current_fl.parent / v_file_str).resolve()
                if not v_path.exists():
                    v_path = (Path.cwd() / v_file_str).resolve()
                if v_path.exists() and v_path not in source_files:
                    source_files.append(v_path)

            else:
                # Strip leading switch flags if present
                clean_path_str = line_str
                if clean_path_str.startswith("-"):
                    tokens = clean_path_str.split()
                    if len(tokens) > 1:
                        clean_path_str = tokens[-1]

                path_obj = Path(clean_path_str)
                if path_obj.suffix in valid_extensions or clean_path_str.endswith(".sv") or clean_path_str.endswith(".v"):
                    resolved_file = (current_fl.parent / clean_path_str).resolve()
                    if not resolved_file.exists():
                        resolved_file = (Path.cwd() / clean_path_str).resolve()

                    if resolved_file not in source_files:
                        source_files.append(resolved_file)
                else:
                    # Generic path check
                    resolved_file = (current_fl.parent / clean_path_str).resolve()
                    if not resolved_file.exists():
                        resolved_file = (Path.cwd() / clean_path_str).resolve()

                    if resolved_file.exists() and resolved_file.is_file() and resolved_file not in source_files:
                        source_files.append(resolved_file)
