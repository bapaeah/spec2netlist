import re
from pathlib import Path
from typing import List, Dict, Optional, Set
from dataclasses import dataclass, field

@dataclass
class BoundaryPort:
    name: str
    direction: str  # "input", "output", "inout", "ref", "interface"
    width: int = 1
    type_name: str = "logic"
    connected_net: Optional[str] = None

@dataclass
class ModuleInstance:
    instance_name: str
    module_type: str
    port_connections: Dict[str, str] = field(default_factory=dict)

@dataclass
class ModuleNode:
    module_name: str
    file_path: str
    ports: List[BoundaryPort] = field(default_factory=list)
    sub_instances: List[ModuleInstance] = field(default_factory=list)
    power_control_signals: List[str] = field(default_factory=list)

class RTLHierarchyParser:
    """
    Robust SystemVerilog & Verilog RTL Hierarchy Parser.
    Handles SystemVerilog constructs:
    - Parameterized headers with nested parentheses: module foo #(parameter A = (1+2)) (ports...);
    - SystemVerilog types: logic, bit, int, byte, struct, enum, interface modports, ref ports.
    - Attributes (* ... *), macromodule, automatic, static.
    - Robust parenthesis/semicolon scanner that never fails on nested SV expressions.
    """

    def parse_rtl_files(self, file_paths: List[Path]) -> Dict[str, ModuleNode]:
        modules: Dict[str, ModuleNode] = {}

        for path in file_paths:
            if not path.exists():
                print(f"\033[91mWarning:\033[0m Ingested file path does not exist on disk: {path}")
                continue

            content = path.read_text(encoding="utf-8", errors="ignore")
            parsed_modules = self._parse_single_file(content, str(path))

            if not parsed_modules:
                # Debug feedback for empty parse
                lines_count = len(content.splitlines())
                print(f"  [Debug] Scanned '{path.name}' ({lines_count} lines, {len(content)} bytes) -> 0 modules found.")

            for mod in parsed_modules:
                modules[mod.module_name] = mod

        return modules

    def _parse_single_file(self, content: str, file_path: str) -> List[ModuleNode]:
        # 1. Strip comments (single line // and block /* */)
        cleaned = re.sub(r"//.*", "", content)
        cleaned = re.sub(r"/\*.*?\*/", "", cleaned, flags=re.DOTALL)
        # Strip SystemVerilog attributes (* ... *)
        cleaned = re.sub(r"\(\*.*?\*\)", "", cleaned, flags=re.DOTALL)

        nodes = []
        pos = 0
        length = len(cleaned)

        # Regex to find module or interface keyword start
        mod_kw_pattern = re.compile(r"\b(?:macromodule|module|interface)\b", re.IGNORECASE)

        for match in mod_kw_pattern.finditer(cleaned):
            start_pos = match.end()

            # Find module name
            name_match = re.search(r"^(?:\s+(?:automatic|static))?\s+([a-zA-Z_][a-zA-Z0-9_$]*)", cleaned[start_pos:])
            if not name_match:
                continue

            mod_name = name_match.group(1)

            # Skip reserved SV keywords accidentally matched
            if mod_name.lower() in {"automatic", "static", "import", "export", "begin", "end"}:
                continue

            # Find header end (first semicolon ';' at depth 0 of parentheses)
            header_start = start_pos + name_match.end()
            header_end = self._find_header_end(cleaned, header_start)

            header_text = cleaned[header_start:header_end]

            # Find endmodule or endinterface keyword
            end_match = re.search(r"\b(?:endmodule|endinterface)\b", cleaned[header_end:], re.IGNORECASE)
            if end_match:
                body_end = header_end + end_match.start()
                body_text = cleaned[header_end:body_end]
            else:
                body_text = cleaned[header_end:header_end + 10000]

            full_text = header_text + "\n" + body_text
            ports = self._extract_ports(full_text)
            instances = self._extract_instances(body_text)
            pwr_ctrl_signals = self._extract_power_control_signals(full_text)

            nodes.append(
                ModuleNode(
                    module_name=mod_name,
                    file_path=file_path,
                    ports=ports,
                    sub_instances=instances,
                    power_control_signals=pwr_ctrl_signals,
                )
            )

        return nodes

    def _find_header_end(self, text: str, start_idx: int) -> int:
        """
        Finds the semicolon ';' that terminates a SystemVerilog module header,
        properly balancing nested parentheses () and brackets [].
        """
        depth_paren = 0
        depth_bracket = 0
        depth_brace = 0

        for i in range(start_idx, len(text)):
            char = text[i]
            if char == '(':
                depth_paren += 1
            elif char == ')':
                if depth_paren > 0:
                    depth_paren -= 1
            elif char == '[':
                depth_bracket += 1
            elif char == ']':
                if depth_bracket > 0:
                    depth_bracket -= 1
            elif char == '{':
                depth_brace += 1
            elif char == '}':
                if depth_brace > 0:
                    depth_brace -= 1
            elif char == ';' and depth_paren == 0 and depth_bracket == 0 and depth_brace == 0:
                return i + 1

        # Fallback if no semicolon found
        semi_idx = text.find(';', start_idx)
        return semi_idx + 1 if semi_idx != -1 else min(start_idx + 500, len(text))

    def _extract_ports(self, text: str) -> List[BoundaryPort]:
        ports = []
        # Matches SV input/output/inout/ref ports with types: logic, bit, int, wire, reg, etc.
        port_pattern = re.compile(
            r"\b(input|output|inout|ref)\s+"
            r"(?:wire|reg|logic|bit|byte|int|longint|shortint|signed|unsigned|\s+)*"
            r"(?:\[([^\]]+)\])?\s*(\w+)",
            re.IGNORECASE
        )
        for direction, width_spec, port_name in port_pattern.findall(text):
            width = 1
            if width_spec:
                nums = re.findall(r"\d+", width_spec)
                if len(nums) >= 2:
                    width = abs(int(nums[0]) - int(nums[1])) + 1
            ports.append(BoundaryPort(name=port_name, direction=direction.lower(), width=width))
        return ports

    def _extract_instances(self, body: str) -> List[ModuleInstance]:
        instances = []
        # Matches SystemVerilog module/interface instantiations:
        # module_type #(params) inst_name (.port(net), ...);
        inst_pattern = re.compile(
            r"\b([a-zA-Z_][a-zA-Z0-9_]*)\s*"
            r"(?:#\s*\([\s\S]*?\)\s*)?"  # Optional parameter overrides
            r"([a-zA-Z_][a-zA-Z0-9_]*)\s*"
            r"\(([\s\S]*?)\)\s*;",
            re.DOTALL
        )

        reserved_keywords = {
            "always", "always_ff", "always_comb", "always_latch", "initial", "assign",
            "if", "else", "case", "casex", "casez", "endcase", "module", "endmodule",
            "interface", "endinterface", "package", "endpackage", "function", "endfunction",
            "task", "endtask", "generate", "endgenerate", "specify", "endspecify", "covergroup", "endgroup"
        }

        for mod_type, inst_name, conn_block in inst_pattern.findall(body):
            if mod_type.lower() in reserved_keywords or inst_name.lower() in reserved_keywords:
                continue

            conn_map = {}
            connections = re.findall(r"\.\s*(\w+)\s*\(\s*([^\)]*)\s*\)", conn_block)
            for port, net in connections:
                conn_map[port] = net.strip()

            instances.append(
                ModuleInstance(
                    instance_name=inst_name,
                    module_type=mod_type,
                    port_connections=conn_map,
                )
            )
        return instances

    def _extract_power_control_signals(self, text: str) -> List[str]:
        pwr_keywords = [
            r"\w*iso\w*", r"\w*pwr\w*", r"\w*sleep\w*", r"\w*gate\w*", r"\w*ret\w*"
        ]
        signals = set()
        tokens = re.findall(r"\b([a-zA-Z_][a-zA-Z0-9_]*)\b", text)
        for token in tokens:
            for kw in pwr_keywords:
                if re.search(kw, token, re.IGNORECASE):
                    if token.lower() not in {"always", "assign", "begin", "end", "module", "input", "output", "logic"}:
                        signals.add(token)
                        break
        return sorted(list(signals))

    def detect_root_top_module(self, modules_map: Dict[str, ModuleNode]) -> Optional[str]:
        if not modules_map:
            return None

        instantiated_modules: Set[str] = set()
        for mod in modules_map.values():
            for inst in mod.sub_instances:
                instantiated_modules.add(inst.module_type)

        uninstantiated = [name for name in modules_map.keys() if name not in instantiated_modules]
        if uninstantiated:
            return uninstantiated[0]
        else:
            return list(modules_map.keys())[0]
