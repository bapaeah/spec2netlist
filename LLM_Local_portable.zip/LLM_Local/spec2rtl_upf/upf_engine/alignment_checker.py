from typing import List, Dict, Any
from dataclasses import dataclass, field
from .rtl_hierarchy_parser import ModuleNode
from .upf_parser import UPFSpec

@dataclass
class AlignmentIssue:
    issue_type: str  # "MISSING_ISOLATION", "MISSING_LEVEL_SHIFTER", "ORPHANED_RULE", "PST_INCONSISTENCY"
    severity: str    # "ERROR", "WARNING"
    domain: str
    target_signal: str
    description: str

@dataclass
class AlignmentReport:
    total_issues: int = 0
    errors_count: int = 0
    warnings_count: int = 0
    issues: List[AlignmentIssue] = field(default_factory=list)

class AlignmentChecker:
    """
    Cross-checks RTL hierarchy boundaries against UPF specs to catch low-power alignment bugs.
    """

    def check_alignment(
        self,
        top_module: ModuleNode,
        modules_map: Dict[str, ModuleNode],
        power_config: Dict[str, Any],
        existing_upf: UPFSpec = None,
    ) -> AlignmentReport:
        report = AlignmentReport()
        domains = power_config.get("power_domains", {})

        # 1. Check Inter-Domain Boundaries for Missing Isolation & Level Shifters
        for dom_name, dom_info in domains.items():
            if dom_info.get("always_on", False):
                continue  # Always-on domains do not require output isolation

            scope = dom_info.get("scope")
            voltage = dom_info.get("voltage", 1.1)

            # Find matching sub-instance in top module
            matching_inst = None
            for inst in top_module.sub_instances:
                if inst.instance_name == scope:
                    matching_inst = inst
                    break

            if not matching_inst:
                continue

            sub_mod = modules_map.get(matching_inst.module_type)
            if not sub_mod:
                continue

            # Check output ports crossing to other domains
            for port in sub_mod.ports:
                if port.direction == "output":
                    connected_net = matching_inst.port_connections.get(port.name)
                    if not connected_net:
                        continue

                    # Isolation Check
                    has_iso_rule = False
                    if existing_upf:
                        for iso in existing_upf.isolations.values():
                            if iso.domain == dom_name:
                                has_iso_rule = True
                                break

                    if not existing_upf or not has_iso_rule:
                        report.issues.append(
                            AlignmentIssue(
                                issue_type="MISSING_ISOLATION",
                                severity="ERROR",
                                domain=dom_name,
                                target_signal=f"{matching_inst.instance_name}/{port.name}",
                                description=(
                                    f"Power-gated domain '{dom_name}' output port '{port.name}' "
                                    f"crosses to always-on domain but lacks an isolation rule."
                                ),
                            )
                        )

                    # Level Shifter Check (Cross-Voltage)
                    if voltage != 1.1:
                        has_els_rule = False
                        if existing_upf:
                            for els in existing_upf.level_shifters.values():
                                if els.domain == dom_name:
                                    has_els_rule = True
                                    break

                        if not existing_upf or not has_els_rule:
                            report.issues.append(
                                AlignmentIssue(
                                    issue_type="MISSING_LEVEL_SHIFTER",
                                    severity="ERROR",
                                    domain=dom_name,
                                    target_signal=f"{matching_inst.instance_name}/{port.name}",
                                    description=(
                                        f"Signal '{port.name}' crosses between voltage domains ({voltage}V -> 1.1V) "
                                        f"without an explicit level shifter rule."
                                    ),
                                )
                            )

        # 2. Check for Orphaned UPF Rules (if existing UPF supplied)
        if existing_upf:
            all_rtl_signals = set()
            for mod in modules_map.values():
                for p in mod.ports:
                    all_rtl_signals.add(p.name)

            for iso_name, iso in existing_upf.isolations.items():
                if iso.isolation_signal not in all_rtl_signals:
                    report.issues.append(
                        AlignmentIssue(
                            issue_type="ORPHANED_RULE",
                            severity="WARNING",
                            domain=iso.domain,
                            target_signal=iso.isolation_signal,
                            description=(
                                f"UPF isolation rule '{iso_name}' references isolation signal '{iso.isolation_signal}' "
                                f"which was not found in RTL source code."
                            ),
                        )
                    )

        report.total_issues = len(report.issues)
        report.errors_count = sum(1 for i in report.issues if i.severity == "ERROR")
        report.warnings_count = sum(1 for i in report.issues if i.severity == "WARNING")

        return report
