#!/usr/bin/env python3
"""
Automated Synopsys Design Constraints (SDC) Generator for Specification to Netlist Framework.

Generates standard IEEE 1481 / Synopsys Design Constraints (.sdc) files for:
1. IP-Level Synthesis & Timing Analysis (<ip_module>.sdc)
2. SoC Top-Level Multi-Clock & Low-Power Synthesis (soc_subsystem_top.sdc)
"""

import os
from pathlib import Path
from typing import Dict, Any, List, Optional


class SDCGenerator:
    """
    Automated SDC Generator producing timing constraints for:
    - Primary clock definitions (create_clock)
    - Asynchronous clock domain groups (set_clock_groups -asynchronous)
    - Clock uncertainty and transition times
    - Input and output delay constraints (set_input_delay / set_output_delay)
    - False paths for asynchronous resets and PMU low-power isolation controls
    - Standard drive strength and capacitive loads
    """

    def __init__(self, target_library: str = "NanGate45"):
        self.target_library = target_library

    def generate_ip_sdc(
        self,
        module_name: str,
        clock_port: str = "clk",
        clock_period_ns: float = 10.0,
        reset_port: str = "rst_n",
        input_ports: Optional[List[str]] = None,
        output_ports: Optional[List[str]] = None,
        output_file: Optional[str] = None
    ) -> str:
        """
        Generates an IP-level SDC constraint file.
        """
        input_ports = input_ports or []
        output_ports = output_ports or []

        # Filter out clock and reset
        sig_inputs = [p for p in input_ports if p not in (clock_port, reset_port)]
        sig_outputs = [p for p in output_ports if p not in (clock_port, reset_port)]

        lines = [
            f"# ===========================================================================",
            f"# Synopsys Design Constraints (SDC 2.1) - IP Core: {module_name}",
            f"# Generated autonomously by Specification to Netlist CAD Framework",
            f"# Target Cell Library: {self.target_library}",
            f"# ===========================================================================",
            f"",
            f"# 1. Primary Clock Definition",
            f"create_clock -name {clock_port} -period {clock_period_ns:.3f} -waveform {{0.000 {clock_period_ns/2.0:.3f}}} [get_ports {clock_port}]",
            f"",
            f"# 2. Clock Uncertainty & Jitter",
            f"set_clock_uncertainty -setup 0.200 [get_clocks {clock_port}]",
            f"set_clock_uncertainty -hold 0.100 [get_clocks {clock_port}]",
            f"set_clock_transition 0.150 [get_clocks {clock_port}]",
            f"",
            f"# 3. False Paths on Asynchronous Resets",
            f"set_false_path -from [get_ports {reset_port}]",
            f""
        ]

        # Input delays
        if sig_inputs:
            lines.append("# 4. Input Constraints (Relative to Core Clock)")
            in_delay = clock_period_ns * 0.25
            for inp in sig_inputs:
                lines.append(f"set_input_delay -clock {clock_port} -max {in_delay:.3f} [get_ports {inp}]")
                lines.append(f"set_input_delay -clock {clock_port} -min 0.000 [get_ports {inp}]")
            lines.append("")

        # Output delays
        if sig_outputs:
            lines.append("# 5. Output Constraints (Relative to Core Clock)")
            out_delay = clock_period_ns * 0.25
            for outp in sig_outputs:
                lines.append(f"set_output_delay -clock {clock_port} -max {out_delay:.3f} [get_ports {outp}]")
                lines.append(f"set_output_delay -clock {clock_port} -min 0.000 [get_ports {outp}]")
            lines.append("")

        # Driving cell and capacitive loads
        lines.extend([
            f"# 6. Drive Strength & Capacitive Load",
            f"set_driving_cell -lib_cell INVX1 [all_inputs]",
            f"set_load -pin_load 0.010 [all_outputs]",
            f"",
            f"# End of SDC for {module_name}",
            f""
        ])

        sdc_content = "\n".join(lines)
        if output_file:
            out_p = Path(output_file)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            out_p.write_text(sdc_content, encoding="utf-8")
            print(f"  ✔ Generated IP SDC Constraints: \033[92m{out_p}\033[0m")

        return sdc_content

    def generate_soc_sdc(
        self,
        top_module: str = "soc_subsystem_top",
        clocks_config: Optional[Dict[str, Dict[str, Any]]] = None,
        power_config: Optional[Dict[str, Any]] = None,
        output_file: Optional[str] = None
    ) -> str:
        """
        Generates top-level SoC SDC constraint file featuring multi-clock domains,
        asynchronous clock groups, reset trees, and PMU low-power isolation signals.
        """
        clocks_config = clocks_config or {
            "clk_sys": {"port": "clk_sys", "period": 10.0, "desc": "100 MHz Main System & CPU Crossbar"},
            "clk_video": {"port": "clk_video", "period": 5.0, "desc": "200 MHz H.264 Video Decoder Pipeline"},
            "clk_periph": {"port": "clk_periph", "period": 20.0, "desc": "50 MHz APB Peripheral Bus"},
            "clk_aon": {"port": "clk_aon", "period": 30517.58, "desc": "32.768 kHz Always-On RTC Domain"}
        }

        lines = [
            f"# ===========================================================================",
            f"# Synopsys Design Constraints (SDC 2.1) - Top-Level SoC Subsystem: {top_module}",
            f"# Generated autonomously by Specification to Netlist CAD Framework",
            f"# Target Cell Library: {self.target_library}",
            f"# ===========================================================================",
            f"",
            f"# ---------------------------------------------------------------------------",
            f"# 1. Heterogeneous Clock Domain Definitions",
            f"# ---------------------------------------------------------------------------"
        ]

        clk_names = []
        for clk_name, cfg in clocks_config.items():
            port = cfg["port"]
            period = cfg["period"]
            desc = cfg.get("desc", "")
            clk_names.append(clk_name)
            lines.append(f"# {clk_name}: {desc}")
            lines.append(f"create_clock -name {clk_name} -period {period:.3f} -waveform {{0.000 {period/2.0:.3f}}} [get_ports {port}]")
            lines.append(f"set_clock_uncertainty -setup 0.200 [get_clocks {clk_name}]")
            lines.append(f"set_clock_uncertainty -hold 0.100 [get_clocks {clk_name}]")
            lines.append(f"set_clock_transition 0.150 [get_clocks {clk_name}]")
            lines.append("")

        # Asynchronous Clock Groups (CDC Isolation)
        lines.extend([
            f"# ---------------------------------------------------------------------------",
            f"# 2. Asynchronous Clock Domain Groups (CDC Decoupling)",
            f"# Prevents false timing paths across asynchronously synchronized domains",
            f"# ---------------------------------------------------------------------------",
            f"set_clock_groups -asynchronous \\"
        ])
        for idx, clk in enumerate(clk_names):
            term = " \\" if idx < len(clk_names) - 1 else ""
            lines.append(f"    -group [get_clocks {clk}]{term}")
        lines.append("")

        # False paths on resets and low power controls
        lines.extend([
            f"# ---------------------------------------------------------------------------",
            f"# 3. False Paths on Asynchronous Resets & Reset Synchronizers",
            f"# ---------------------------------------------------------------------------",
            f"set_false_path -from [get_ports rst_sys_n]",
            f"set_false_path -from [get_ports rst_aon_n]",
            f"",
            f"# ---------------------------------------------------------------------------",
            f"# 4. False Paths on PMU Low-Power Signals (UPF 2.1 Control Crossings)",
            f"# Quasi-static power management signals do not require single-cycle timing",
            f"# ---------------------------------------------------------------------------",
            f"set_false_path -from [get_ports -filter \"name =~ pmu_*_iso_en\"]",
            f"set_false_path -from [get_ports -filter \"name =~ pmu_*_pwr_ok\"]",
            f"set_false_path -from [get_ports -filter \"name =~ pmu_*_sleep\"]",
            f"",
            f"# ---------------------------------------------------------------------------",
            f"# 5. Primary I/O Port Timing Constraints",
            f"# ---------------------------------------------------------------------------",
            f"# System Bus Inputs & Outputs (Constrained to clk_sys)",
            f"set_input_delay -clock clk_sys -max 3.000 [get_ports -filter \"name =~ axi_*_i || name =~ apb_*_i\"]",
            f"set_input_delay -clock clk_sys -min 0.500 [get_ports -filter \"name =~ axi_*_i || name =~ apb_*_i\"]",
            f"set_output_delay -clock clk_sys -max 3.000 [get_ports -filter \"name =~ axi_*_o || name =~ apb_*_o\"]",
            f"set_output_delay -clock clk_sys -min 0.500 [get_ports -filter \"name =~ axi_*_o || name =~ apb_*_o\"]",
            f"",
            f"# Always-On & Peripheral IO Delays (Constrained to clk_periph & clk_aon)",
            f"set_input_delay -clock clk_periph -max 5.000 [get_ports -filter \"name =~ gpio_*_i || name =~ uart_*_i\"]",
            f"set_output_delay -clock clk_periph -max 5.000 [get_ports -filter \"name =~ gpio_*_o || name =~ uart_*_o\"]",
            f"",
            f"# ---------------------------------------------------------------------------",
            f"# 6. Environmental Constraints (Drive Strength & Capacitive Loading)",
            f"# ---------------------------------------------------------------------------",
            f"set_driving_cell -lib_cell INVX1 [all_inputs]",
            f"set_load -pin_load 0.015 [all_outputs]",
            f"",
            f"# End of Top-Level SoC SDC Constraints",
            f""
        ])

        sdc_content = "\n".join(lines)
        if output_file:
            out_p = Path(output_file)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            out_p.write_text(sdc_content, encoding="utf-8")
            print(f"  ✔ Generated SoC Top-Level SDC Constraints: \033[92m{out_p}\033[0m")

        return sdc_content


if __name__ == "__main__":
    generator = SDCGenerator()
    # Generate benchmark SoC SDC
    soc_sdc = generator.generate_soc_sdc(output_file="output_market_soc/soc_subsystem_top.sdc")
    print(f"Generated SoC SDC:\n{soc_sdc[:350]}...\n")
