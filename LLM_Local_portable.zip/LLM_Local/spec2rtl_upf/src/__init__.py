"""
Spec2RTL + UPF CAD Engine Core Pipeline Modules.
"""
