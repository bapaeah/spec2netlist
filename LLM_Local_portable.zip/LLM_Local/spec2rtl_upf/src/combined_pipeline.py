#!/usr/bin/env python3
"""
Combined Spec2RTL & AutoUPF-AI Pipeline Orchestrator.

Operating Modes:
1. RTL-Only Mode (--rtl-only):
   - Ingests spec documents & generates synthesizable SystemVerilog RTL, testbenches & filelists.
   - Generates formal Clock Domain Crossing (CDC) and RDC constraints (.cdc / .sdc) for IPs and SoC.
   - Verifies the RTL through:
     * Lint: Verilator static lint check (syntax, widths, multi-drivers)
     * CDC: Static structural CDC/RDC analysis (crossings, 2-FF synchronizers, reset trees)
     * TB: Verilator self-checking testbench simulation (registers, resets, assertions)

2. All / Full Unified Mode (--all or default):
   - Executes everything in Mode 1 (RTL + CDC Constraints + Lint + CDC + TB).
   - Generates IEEE 1801 UPF 2.1 intent (modular IP UPFs + Master SoC UPF with PST).
   - Audits RTL hierarchy against power intent and emits alignment JSON report.
   - Generates comprehensive Synopsys Design Constraints (.sdc) for synthesis & STA.
   - Runs gate-level synthesis (NanGate 45nm standard cell mapping, latch checks).
   - Generates and writes the final gate-level netlist file (*_gate_netlist.v).
"""

import os
import sys
import json
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional

# Add spec2rtl and upf_engine paths
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR / "spec2rtl"))
sys.path.insert(0, str(BASE_DIR / "upf_engine"))
sys.path.insert(0, str(BASE_DIR / "src"))

from spec2rtl import extract as X, parse as P, generate as G
from upf_engine.filelist_parser import FileListParser
from upf_engine.rtl_hierarchy_parser import RTLHierarchyParser, ModuleNode
from upf_engine.upf_parser import UPFParser
from upf_engine.alignment_checker import AlignmentChecker, AlignmentReport
from upf_engine.upf_generator import UPFGenerator
from sdc_generator import SDCGenerator
from cdc_engine import CDCEngine
from synth_netlist_engine import SynthNetlistEngine


class CombinedSpec2RTLUPFPipeline:
    """
    Unified Orchestrator supporting:
    - Mode 1: RTL-Only (RTL + CDC Constraints + Lint + CDC + TB)
    - Mode 2: All (RTL + CDC + Lint + CDC + TB + UPF + SDC + Synthesis + Netlist)
    """

    def __init__(self, output_dir: str = "output"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.cdc_engine = CDCEngine()
        self.sdc_generator = SDCGenerator()
        self.synth_engine = SynthNetlistEngine()

    def run(
        self,
        spec_files: Optional[List[str]] = None,
        power_config_file: Optional[str] = None,
        filelist_file: Optional[str] = None,
        rtl_files: Optional[List[str]] = None,
        rtl_dir: Optional[str] = None,
        existing_upf: Optional[str] = None,
        ip_name: Optional[str] = None,
        use_llm: bool = False,
        rtl_only: bool = False,
        upf_only: bool = False,
        run_lint: bool = False,
        run_synth: bool = False,
        run_sim: bool = False,
        run_all: bool = False,
    ) -> Dict[str, Any]:
        """
        Executes the requested operating mode.
        """
        # Determine active mode
        if rtl_only:
            active_mode = "RTL-Only"
        elif upf_only:
            active_mode = "UPF-Only"
        else:
            active_mode = "Unified (All)"

        results = {
            "success": False,
            "mode": active_mode,
            "ip_rtl_files": [],
            "ip_cdc_file": None,
            "soc_cdc_file": None,
            "verification": {
                "lint": "SKIPPED",
                "cdc": "SKIPPED",
                "sim": "SKIPPED"
            },
            "ip_upf_file": None,
            "soc_top_module": None,
            "soc_master_upf": None,
            "partition_upfs": [],
            "soc_sdc_file": None,
            "gate_netlist_file": None,
            "alignment_report": None,
            "alignment_issues": 0,
        }

        print("=" * 78)
        print(f" Spec2RTL + AutoUPF-AI Engine [Operating Mode: {active_mode}]")
        print("=" * 78)

        # ----------------------------------------------------------------------
        # Stage 1: Spec-to-RTL Ingestion & Synthesis
        # ----------------------------------------------------------------------
        generated_ip_rtl_paths: List[Path] = []
        spec_data = None
        module_name = ip_name or "ip_top"
        ip_out_dir = None

        if not upf_only and spec_files:
            print("\n[Stage 1: Spec-to-RTL Ingestion & Synthesis]")
            for s_file in spec_files:
                p = Path(s_file).resolve()
                if not p.exists():
                    p = BASE_DIR / s_file
                print(f"  • Ingesting Specification: {p}")

                # Extract text & tables
                text, tables = X.extract(str(p))
                parsed_spec = P.parse(text, tables, ip_name)
                module_name = parsed_spec.get("module", module_name)
                spec_data = parsed_spec

                # Setup output directory (single directory: self.output_dir / module_name)
                ip_out_dir = self.output_dir / module_name
                for sub in ["rtl", "tb", "sim_build"]:
                    sub_dir = ip_out_dir / sub
                    if sub_dir.exists():
                        shutil.rmtree(sub_dir)
                ip_out_dir.mkdir(parents=True, exist_ok=True)
                spec_json_path = ip_out_dir / "spec.json"
                spec_json_path.write_text(json.dumps(parsed_spec, indent=2), encoding="utf-8")

                # Generate SystemVerilog RTL, Regs, Core, Testbench & filelist
                code = G.write_all(parsed_spec, ip_out_dir)

                # Optional LLM core filling
                if use_llm:
                    try:
                        from spec2rtl import llm
                        stub = G.gen_core_stub(code)
                        G.write_all(parsed_spec, ip_out_dir, core_text=llm.fill_core(parsed_spec, stub, None))
                        print("  ✔ Completed Functional Core with LLM")
                    except Exception as e:
                        print(f"  \033[93mWarning:\033[0m LLM completion skipped ({e})")

                # Collect generated RTL files
                rtl_dir_path = ip_out_dir / "rtl"
                if rtl_dir_path.exists():
                    for sv_file in rtl_dir_path.glob("*.sv"):
                        generated_ip_rtl_paths.append(sv_file)

                clk_info = parsed_spec.get('clock') or {}
                rst_info = parsed_spec.get('reset') or {}
                print(f"  ✔ Synthesized IP Module: \033[92m{module_name}\033[0m")
                print(f"    - Bus Protocol: {parsed_spec.get('bus', {}).get('protocol', 'AXI-Lite')}")
                print(f"    - Ports: {len(parsed_spec.get('ports', []))}")
                print(f"    - Registers: {len(parsed_spec.get('registers', []))}")
                print(f"    - Clock: {clk_info.get('name', 'clk')} ({clk_info.get('freq_mhz', 100.0)} MHz)")
                print(f"    - Reset: {rst_info.get('name', 'rst_n')}")
                print(f"    - Output Directory: {ip_out_dir}")

        results["ip_rtl_files"] = [str(p) for p in generated_ip_rtl_paths]

        # ----------------------------------------------------------------------
        # Stage 2: CDC Constraints Generation (IP & SoC)
        # ----------------------------------------------------------------------
        if not upf_only and ip_out_dir:
            print("\n[Stage 2: CDC & RDC Constraints Generation]")
            clk_name = spec_data.get("clock", {}).get("name", "clk") if spec_data else "clk"
            rst_name = spec_data.get("reset", {}).get("name", "rst_n") if spec_data else "rst_n"
            ip_cdc_file = ip_out_dir / f"{module_name}_cdc.sdc"

            self.cdc_engine.generate_ip_cdc_constraints(
                module_name=module_name,
                clock_port=clk_name,
                reset_port=rst_name,
                output_file=str(ip_cdc_file)
            )
            results["ip_cdc_file"] = str(ip_cdc_file)

            soc_cdc_file = self.output_dir / "soc_cdc.sdc"
            self.cdc_engine.generate_soc_cdc_constraints(
                top_module="soc_subsystem_top",
                output_file=str(soc_cdc_file)
            )
            results["soc_cdc_file"] = str(soc_cdc_file)

        # ----------------------------------------------------------------------
        # Stage 3: Verification Suite (Lint, CDC, TB Simulation)
        # ----------------------------------------------------------------------
        # In RTL-Only Mode or All Mode (or when explicit verification flags requested)
        should_verify = rtl_only or run_all or (run_lint or run_sim) or (not upf_only and not rtl_only)
        if ip_out_dir and should_verify:
            print("\n[Stage 3: RTL Verification Suite (Lint, CDC, TB)]")
            import importlib.util
            s2r_spec = importlib.util.spec_from_file_location("s2r_cli", str(BASE_DIR / "spec2rtl" / "spec2rtl.py"))
            s2r_mod = importlib.util.module_from_spec(s2r_spec)
            s2r_spec.loader.exec_module(s2r_mod)
            do_lint, do_sim = s2r_mod.do_lint, s2r_mod.do_sim

            # 1. Lint Verification (Verilator Static Lint)
            print("  • [Verification 1/3] Running Verilator Static Lint...")
            lint_ok = do_lint(ip_out_dir)
            results["verification"]["lint"] = "PASS" if lint_ok else "FAIL"

            # 2. CDC Structural & RDC Verification
            print("  • [Verification 2/3] Running Structural CDC & RDC Analysis...")
            cdc_report = self.cdc_engine.verify_cdc(
                rtl_files=generated_ip_rtl_paths,
                top_module=module_name,
                cdc_constraints_file=Path(results["ip_cdc_file"]) if results["ip_cdc_file"] else None
            )
            results["verification"]["cdc"] = "PASS" if cdc_report["cdc_clean"] else "WARNING"
            print(f"    - Clock Domains Detected: {', '.join(cdc_report['clock_domains']) or 'Single-Domain'}")
            print(f"    - Reset Domains Detected: {', '.join(cdc_report['resets']) or 'Synchronous'}")
            print(f"    - Synchronized Crossings: {cdc_report['synchronized_crossings']}")
            print(f"    - Reset Trees (RDC)     : {cdc_report['rdc_status']}")
            print(f"    - CDC Status            : \033[92m{results['verification']['cdc']}\033[0m")

            # 3. TB Simulation (Verilator / Icarus Verilog)
            print("  • [Verification 3/3] Running Self-Checking Testbench Simulation...")
            sim_ok = do_sim(ip_out_dir)
            results["verification"]["sim"] = "PASS" if sim_ok else "FAIL"
            print(f"    - TB Simulation Status  : \033[92m{results['verification']['sim']}\033[0m")

        # ----------------------------------------------------------------------
        # Exit early if in RTL-Only Mode
        # ----------------------------------------------------------------------
        if rtl_only:
            print("\n" + "=" * 78)
            print(" RTL-ONLY PIPELINE EXECUTION COMPLETE")
            print("=" * 78)
            print("  Generated RTL Files:")
            for r_file in results["ip_rtl_files"]:
                print(f"    - \033[92m{r_file}\033[0m")
            print("  Generated CDC Constraints:")
            print(f"    - IP CDC Constraints : \033[92m{results.get('ip_cdc_file')}\033[0m")
            print(f"    - SoC CDC Constraints: \033[92m{results.get('soc_cdc_file')}\033[0m")
            print("  Verification Suite Summary:")
            print(f"    - Lint Pass    : \033[92m{results['verification']['lint']}\033[0m")
            print(f"    - CDC / RDC    : \033[92m{results['verification']['cdc']}\033[0m")
            print(f"    - TB Simulation: \033[92m{results['verification']['sim']}\033[0m")
            print("=" * 78 + "\n")
            results["success"] = True
            return results

        # ----------------------------------------------------------------------
        # Stage 4: Modular & Master IEEE 1801 UPF 2.1 Generation & Alignment Audit
        # ----------------------------------------------------------------------
        print("\n[Stage 4: Low-Power Intent & IEEE 1801 UPF 2.1 Generation]")

        # Ingest or build power domain config JSON
        power_config = {}
        if power_config_file:
            cfg_p = Path(power_config_file).resolve()
            if not cfg_p.exists():
                cfg_p = BASE_DIR / power_config_file
            if cfg_p.exists():
                power_config = json.loads(cfg_p.read_text(encoding="utf-8"))
                print(f"  • Ingested Power Config JSON: {cfg_p}")

        if not power_config:
            power_config = {
                "top_module": "soc_subsystem_top",
                "power_domains": {
                    "PD_TOP": {"scope": "/", "voltage": 1.1, "always_on": True, "primary_supply": "VDD_MAIN"},
                    f"PD_{module_name.upper()}": {
                        "scope": f"u_{module_name}",
                        "voltage": 0.9,
                        "always_on": False,
                        "primary_supply": f"VDD_{module_name.upper()}",
                        "isolation_signal": f"pmu_{module_name}_iso_en"
                    }
                },
                "power_state_table": {
                    "states": {
                        "ACTIVE": {"PD_TOP": "ON", f"PD_{module_name.upper()}": "ON"},
                        "SLEEP": {"PD_TOP": "ON", f"PD_{module_name.upper()}": "OFF"}
                    }
                }
            }

        # IP domain registration
        ip_domain_name = f"PD_{module_name.upper()}"
        if ip_domain_name not in power_config.get("power_domains", {}) and module_name != "soc_subsystem_top":
            power_config.setdefault("power_domains", {})[ip_domain_name] = {
                "scope": f"u_{module_name}",
                "voltage": 0.9,
                "always_on": False,
                "primary_supply": f"VDD_{module_name.upper()}",
                "isolation_signal": f"pmu_{module_name}_iso_en"
            }

        # Write modular IP UPF
        ip_upf_lines = [
            f"# =========================================================",
            f"# Modular IEEE 1801 UPF 2.1 for IP Module: {module_name}",
            f"# Domain: {ip_domain_name} | Scope: u_{module_name}",
            f"# Auto-generated by Spec2RTL + AutoUPF-AI Pipeline",
            f"# =========================================================",
            f"upf_version 2.1\n",
            f"create_power_domain {ip_domain_name} -include_scope",
            f"create_supply_net VDD_{module_name.upper()} -domain {ip_domain_name}",
            f"create_supply_net VSS -domain {ip_domain_name}\n",
            f"# Power Gating Switch",
            f"create_power_switch PSW_{module_name.upper()} \\",
            f"    -domain {ip_domain_name} \\",
            f"    -output_supply_port {{vdd_sw VDD_{module_name.upper()}}} \\",
            f"    -input_supply_port  {{vdd_in VDD_MAIN}} \\",
            f"    -control_port       {{pwr_gate_en pwr_ctrl}} \\",
            f"    -on_state           {{pwr_on vdd_in {{!pwr_ctrl}}}}\n",
            f"# Inter-Domain Boundary Isolation",
            f"set_isolation iso_{module_name}_out \\",
            f"    -domain {ip_domain_name} \\",
            f"    -isolation_signal {{pmu_{module_name}_iso_en}} \\",
            f"    -isolation_sense high \\",
            f"    -clamp_value 0 \\",
            f"    -applies_to outputs\n",
        ]

        partitions_dir = self.output_dir / "partitions"
        partitions_dir.mkdir(parents=True, exist_ok=True)
        ip_upf_file = partitions_dir / f"{module_name.lower()}.upf"
        ip_upf_file.write_text("\n".join(ip_upf_lines) + "\n", encoding="utf-8")
        results["ip_upf_file"] = str(ip_upf_file)
        print(f"  ✔ Generated Modular IP UPF: \033[92m{ip_upf_file}\033[0m")

        # Collect all RTL files (Generated IP RTL + SoC sources)
        all_rtl_paths: List[Path] = list(generated_ip_rtl_paths)

        if filelist_file:
            fl_p = Path(filelist_file).resolve()
            if not fl_p.exists():
                fl_p = BASE_DIR / filelist_file
            if fl_p.exists():
                fl_parser = FileListParser()
                parsed_fl = fl_parser.parse_filelist(str(fl_p))
                all_rtl_paths.extend(parsed_fl["source_files"])
                print(f"  • Ingested EDA Filelist: {fl_p} ({len(parsed_fl['source_files'])} source files)")

        if rtl_files:
            for rf in rtl_files:
                rp = Path(rf).resolve()
                if rp.exists():
                    all_rtl_paths.append(rp)

        if rtl_dir:
            rdp = Path(rtl_dir).resolve()
            if rdp.is_dir():
                all_rtl_paths.extend(list(rdp.glob("**/*.v")) + list(rdp.glob("**/*.sv")))

        # Benchmark SoC fallback
        if len(all_rtl_paths) <= len(generated_ip_rtl_paths):
            benchmark_dir = BASE_DIR / "benchmarks"
            if benchmark_dir.exists():
                bm_files = list(benchmark_dir.glob("*.v")) + list(benchmark_dir.glob("*.sv"))
                all_rtl_paths.extend(bm_files)
                print(f"  • Included Benchmark SoC Files: {len(bm_files)} files")

        all_rtl_paths = list(dict.fromkeys(all_rtl_paths))

        # Parse RTL Hierarchy
        rtl_parser = RTLHierarchyParser()
        modules_map = rtl_parser.parse_rtl_files(all_rtl_paths)

        if not modules_map:
            print("  \033[91mError:\033[0m No SystemVerilog module definitions found in RTL sources.")
            return results

        # Determine Root Top Module
        top_module_name = power_config.get("top_module")
        if not top_module_name or top_module_name not in modules_map:
            detected_top = rtl_parser.detect_root_top_module(modules_map)
            if detected_top:
                top_module_name = detected_top

        top_node = modules_map.get(top_module_name)
        if not top_node:
            top_node = list(modules_map.values())[0]
            top_module_name = top_node.module_name

        results["soc_top_module"] = top_module_name
        print(f"  ✔ Root SoC Top Module: \033[93m{top_module_name}\033[0m")

        # Parse existing UPF if provided
        existing_upf_spec = None
        if existing_upf:
            eupf_p = Path(existing_upf).resolve()
            if eupf_p.exists():
                upf_parser = UPFParser()
                existing_upf_spec = upf_parser.parse_upf(str(eupf_p))
                print(f"  • Ingested Existing UPF for Audit: {eupf_p}")

        # Audit RTL vs Power Intent
        alignment_checker = AlignmentChecker()
        audit_report = alignment_checker.check_alignment(
            top_node, modules_map, power_config, existing_upf_spec
        )
        results["alignment_issues"] = audit_report.total_issues

        print("\n" + "=" * 78)
        print(" RTL-UPF ALIGNMENT & LOW-POWER BUG AUDIT")
        print("=" * 78)
        print(f" Total Discovered Issues: {audit_report.total_issues} "
              f"({audit_report.errors_count} Errors, {audit_report.warnings_count} Warnings)")

        for idx, issue in enumerate(audit_report.issues, 1):
            color = "\033[91m" if issue.severity == "ERROR" else "\033[93m"
            print(f" Issue #{idx} [{color}{issue.severity}\033[0m] Domain: \033[96m{issue.domain}\033[0m | Signal: {issue.target_signal}")
            print(f"   -> {issue.description}")

        # Generate Master SoC Top UPF
        upf_gen = UPFGenerator()
        generated_upfs = upf_gen.generate_upf_package(
            top_node, modules_map, power_config, str(self.output_dir)
        )
        master_upf_file = self.output_dir / f"{top_module_name}.upf"
        results["soc_master_upf"] = str(master_upf_file)
        results["partition_upfs"] = [g for g in generated_upfs.keys() if "partitions" in g]

        print("\n" + "=" * 78)
        print(" GENERATED COMBINED IEEE 1801 UPF 2.1 PACKAGE")
        print("=" * 78)
        print(f"  ✔ Master SoC Top UPF: \033[92m{master_upf_file}\033[0m")
        for g_file in generated_upfs.keys():
            if g_file != str(master_upf_file):
                print(f"  ✔ Sub-Partition UPF: \033[92m{g_file}\033[0m")

        # Save audit report JSON
        report_file = self.output_dir / "upf_rtl_alignment_report.json"
        report_file.write_text(
            json.dumps({
                "top_module": top_module_name,
                "total_issues": audit_report.total_issues,
                "errors": audit_report.errors_count,
                "warnings": audit_report.warnings_count,
                "issues": [i.__dict__ for i in audit_report.issues]
            }, indent=2),
            encoding="utf-8"
        )
        results["alignment_report"] = str(report_file)
        print(f"  ✔ Alignment Audit JSON: \033[93m{report_file}\033[0m")

        # ----------------------------------------------------------------------
        # Stage 5: Synthesis SDC Constraints Generation
        # ----------------------------------------------------------------------
        print("\n[Stage 5: Synopsys Design Constraints (SDC) Generation]")
        soc_sdc_file = self.output_dir / f"{top_module_name}.sdc"
        self.sdc_generator.generate_soc_sdc(
            top_module=top_module_name,
            power_config=power_config,
            output_file=str(soc_sdc_file)
        )
        results["soc_sdc_file"] = str(soc_sdc_file)

        # ----------------------------------------------------------------------
        # Stage 6: Gate-Level Synthesis & Netlist Generation
        # ----------------------------------------------------------------------
        print("\n[Stage 6: Gate-Level Synthesis & Netlist Generation]")
        synth_res = self.synth_engine.run_synthesis(
            rtl_files=all_rtl_paths,
            top_module=top_module_name,
            sdc_file=soc_sdc_file,
            output_dir=self.output_dir
        )
        results["gate_netlist_file"] = synth_res.get("netlist_file")
        results["synth_success"] = synth_res.get("success", False)

        results["success"] = True
        return results
