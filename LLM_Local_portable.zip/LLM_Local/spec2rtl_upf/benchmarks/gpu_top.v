// GPU Accelerator Module (Domain: PD_GPU / 0.75V)
module gpu_top (
    input wire clk,
    input wire rst_n,
    input wire gpu_iso_en,         // Low-power isolation enable
    input wire [31:0] cmd_in,
    output reg [63:0] gpu_out_data // Output crossing to PD_AON (1.1V)
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            gpu_out_data <= 64'h0;
        end else begin
            gpu_out_data <= {32'h0, cmd_in} * 64'h2;
        end
    end

endmodule
