// CPU Subsystem Module (Domain: PD_CPU / 0.9V)
module cpu_subsys (
    input wire clk,
    input wire rst_n,
    input wire cpu_iso_en,         // Isolation control signal
    input wire [31:0] sys_in,
    output reg [31:0] cpu_out_data
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cpu_out_data <= 32'h0;
        end else begin
            cpu_out_data <= sys_in + 32'h1;
        end
    end

endmodule
