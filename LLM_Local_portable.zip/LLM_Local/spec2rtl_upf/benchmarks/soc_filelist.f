// Multi-Power Domain SoC Filelist
+incdir+./include
+define+SYNTHESIS=1

aon_periph.v
cpu_subsys.v
gpu_top.v
soc_top.v
