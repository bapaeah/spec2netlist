// Always-On Peripheral Module (Domain: PD_AON / 1.1V)
module aon_periph (
    input wire clk,
    input wire rst_n,
    input wire [31:0] sys_in_data,
    input wire [63:0] gpu_data_in, // Cross-domain input from PD_GPU (0.75V)
    output reg [31:0] sys_out_data
);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sys_out_data <= 32'h0;
        end else begin
            sys_out_data <= sys_in_data ^ gpu_data_in[31:0];
        end
    end

endmodule
