// Top-Level SoC Module (Domain: PD_TOP / Always-On 1.1V)
module soc_top (
    input wire clk,
    input wire rst_n,
    input wire pmu_cpu_iso_en,
    input wire pmu_gpu_iso_en,
    input wire [31:0] ext_data_in,
    output wire [31:0] ext_data_out
);

    wire [63:0] gpu_to_aon_bus;
    wire [31:0] cpu_to_aon_bus;

    // Sub-Partition 1: Always-On Peripherals (PD_AON / 1.1V)
    aon_periph u_aon (
        .clk(clk),
        .rst_n(rst_n),
        .sys_in_data(ext_data_in),
        .gpu_data_in(gpu_to_aon_bus),
        .sys_out_data(ext_data_out)
    );

    // Sub-Partition 2: CPU Subsystem (PD_CPU / 0.9V)
    cpu_subsys u_cpu (
        .clk(clk),
        .rst_n(rst_n),
        .cpu_iso_en(pmu_cpu_iso_en),
        .sys_in(ext_data_in),
        .cpu_out_data(cpu_to_aon_bus)
    );

    // Sub-Partition 3: GPU Accelerator (PD_GPU / 0.75V)
    gpu_top u_gpu (
        .clk(clk),
        .rst_n(rst_n),
        .gpu_iso_en(pmu_gpu_iso_en),
        .cmd_in(ext_data_in),
        .gpu_out_data(gpu_to_aon_bus)
    );

endmodule
