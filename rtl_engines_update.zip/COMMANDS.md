# Complete RTL & VLSI Command Reference Guide

This document is your **single reference** for all commands, switches, and workflows in the `LLM_Local` environment across macOS, Linux, and Windows.

---

## 1. Quick Switch Cheat Sheet: The `rtl` Unified Command

You can perform every task using the single command **`rtl`** (or `./rtl`):

| Switch | Short Flag | Purpose | Quick Example |
| :--- | :--- | :--- | :--- |
| **`--rtl`** | `-r` | Synthesize synthesizable RTL from prompt or document | `rtl --rtl --spec "4-bit priority encoder" -o encoder.v` |
| **`--tb`** | `-t` | Generate self-checking testbench with assertions & VCD | `rtl --tb encoder.v -o encoder_tb.v` |
| **`--verify`** | `-v` | Autonomous simulation & self-healing auto-fix loop | `rtl --verify encoder.v encoder_tb.v` |
| **`--synth`** | *(none)* | Synthesize RTL to open library cells (NanGate45 / Sky130) | `rtl --synth encoder.v --lib nangate45 -o encoder_gate.v` |
| **`--convert`**| `-c` | Convert Markdown (.md) to PDF, TXT, HTML, DOCX, RTF, LaTeX | `rtl --convert spec.md -o spec.pdf` |
| **`--mem`** | `--memory` | Technology-Agnostic Memory Compiler (AI or flags) | `rtl --mem --spec "16KB SDP RAM with Wishbone bus"` |
| **`--soc`** | *(none)* | Full SoC CAD Flow (RTL + CDC + UPF 2.1 + SDC + Netlist) | `rtl --soc --spec benchmarks/soc_spec.md --all` |
| **`--chat`** | *(none)* | Interactive VLSI / RTL Engineer terminal chat session | `rtl --chat` |
| **`--check`** | *(none)* | Verify Ollama daemon, model weights, and EDA tools | `rtl --check` |
| **`--update`** | *(none)* | 1-Click update, re-link package & rebuild local models | `rtl --update` |

> [!TIP]
> **Typing `rtl` with no arguments** or `rtl --help` prints an on-screen cheat sheet directly in your terminal.

---

## 2. Environment Setup & Installation

### First-Time Automated Setup
Configures Ollama, downloads base weights, and builds custom hardware models:

```bash
# macOS (Apple Silicon):
./setup_local_llm.sh

# Linux (Ubuntu, Debian, RHEL, Rocky):
chmod +x setup_linux.sh && ./setup_linux.sh

# Windows (10 / 11 PowerShell):
.\setup_windows.ps1
```

### System-Wide CLI Installation
Registers `rtl`, `rtl-assistant`, `memgen`, and `spec2rtl` globally in your terminal:

```bash
# macOS / Linux:
./install.sh

# Windows PowerShell:
.\install.ps1

# Or standard pip:
pip install -e .
```

---

## 3. RTL Generation (`--rtl` / `-r`)

Synthesize clean, synthesizable Verilog/SystemVerilog (latch-free, ANSI ports, parameterizable).

### A. From Plain-English Prompt
```bash
# Basic module
rtl --rtl --spec "4-bit priority encoder with active-low async reset" -o encoder.v

# Complex sequential logic
rtl --rtl --spec "Round-robin arbiter with 4 request inputs and grant outputs" -o arbiter.v

# Use the lightweight 3B model for instant generation
rtl --rtl --spec "8-bit shift register with parallel load" -o shift_reg.v --model rtl-coder-fast
```

### A2. Without an LLM (deterministic rules engine)
```bash
# Structured spec (ports + register tables) -> regs + core + top + TB, then lint/synth/sim
rtl --rtl --file spec.md --no-llm -o module_rtl

# SoC flow: rules engine is the default; add --llm for the LLM engine
rtl --soc --spec market_specs/gpio_opentitan_spec.md --rtl-only
rtl --soc --spec market_specs/dma_axi_sg_spec.md --rtl-only --llm --model qwen2.5-coder:32b
```
The LLM `rtl --rtl` path now lints the answer with Verilator and feeds errors back (`--repair 3`, `0` = off).

### B. Directly from Specification Documents
Supports `.docx`, `.pdf`, `.md`, `.xlsx`, `.csv`, `.txt`, `.json`, `.yaml`:

```bash
# Word document (.docx)
rtl --rtl --file /path/to/spec.docx -o module.v

# PDF datasheet / document (.pdf)
rtl --rtl --file /path/to/datasheet.pdf -o module.v

# Markdown specification (.md)
rtl --rtl --file /path/to/register_spec.md -o module.v

# Target a specific chapter/section within a large document
rtl --rtl --file /path/to/soc_spec.docx --section "DMA Controller" -o dma.v
```

---

## 4. Testbench Generation (`--tb` / `-t`)

Inspects existing RTL code and automatically generates clock stimulus, active-low reset sequences, corner-case test vectors, GTKWave VCD dump commands (`$dumpfile("dump.vcd");`), and self-checking assertions.

```bash
# Generate testbench for an RTL module:
rtl --tb encoder.v -o encoder_tb.v

# Using the fast model:
rtl --tb fifo.v -o fifo_tb.v --model rtl-coder-fast
```

---

## 5. Autonomous Simulation & Self-Healing Loop (`--verify` / `-v`)

Runs `iverilog` and `vvp` simulation on your RTL + Testbench. If compilation syntax errors or runtime test failures occur, **the local LLM automatically analyzes the error log, fixes the code, and re-runs the simulation until it passes**.

```bash
# Run verification with self-healing (up to 3 retries by default):
rtl --verify encoder.v encoder_tb.v

# Increase maximum self-healing retry iterations:
rtl --verify complex_ip.v complex_ip_tb.v --max-retries 5
```

---

## 6. Logic Synthesis & Open Standard Cell Mapping (`--synth`)

Executes gate-level logic synthesis and technology mapping using **Yosys** and open-source standard cell libraries (`.lib`). It maps high-level Verilog/SystemVerilog constructs into actual standard cells (inverters, NAND, NOR, AOI, DFFs), calculates exact silicon area ($\mu m^2$), and generates gate-level simulation (GLS) netlists.

### Available Open Standard Cell Libraries
- **`nangate45`** *(default)*: NanGate 45nm Open Cell Library (typical 1.10V, 25°C). Fast, high-density academic & research benchmark standard.
- **`sky130`**: SkyWater 130nm Open Source PDK (`sky130_fd_sc_hd`, typical 1.80V, 25°C). Industry-standard Google/SkyWater commercial open-source foundry PDK.

### Commands
```bash
# Synthesize using NanGate 45nm (default):
rtl --synth encoder.v -o encoder_gate.v

# Synthesize using SkyWater 130nm:
rtl --synth encoder.v --lib sky130 -o encoder_sky130_gate.v

# Specify top module explicitly:
rtl --synth soc_subsys.v --top aon_periph --lib nangate45 -o aon_gate.v

# Run Gate-Level Simulation (GLS) with Icarus Verilog and open cell models:
iverilog -g2012 techlib/nangate45/nangate45_cells.v encoder_gate.v encoder_tb.v && vvp a.out
iverilog -g2012 techlib/sky130/sky130_cells.v encoder_sky130_gate.v encoder_tb.v && vvp a.out
```

### Synthesis Output Statistics
Every synthesis run displays:
- **Total Standard Cells** and mapped cell breakdown (`DFFR_X1`, `XOR2_X1`, `NAND2_X1`, `INV_X1`, etc.)
- **Total Silicon Area** ($\mu m^2$) split into sequential area and combinational area
- **Gate-Level Netlist path** ready for Place & Route or Gate-Level Simulation (GLS)

---

## 7. Universal Markdown Document Converter (`--convert` / `-c`)

Built-in, 100% offline document converter (zero mandatory external dependencies). Converts Markdown (`.md`) hardware specifications, datasheets, or documentation notes into any target format:

### Supported Output Formats:
* **PDF (`.pdf`)**: Clean multi-page vector PDF with headings, shaded code blocks, borders, tables, and page numbers.
* **TXT (`.txt`)**: Formatted plain text with ASCII-aligned box-drawing tables and styled headers.
* **HTML (`.html`)**: Standalone styled HTML document with modern responsive CSS (printable layout).
* **Word (`.docx`)**: Microsoft Word OpenXML document (compatible with Word, Apple Pages, Google Docs, LibreOffice).
* **RTF (`.rtf`)**: Rich Text Format for cross-platform document viewers.
* **LaTeX (`.tex`)**: Typeset LaTeX document with listings code blocks and booktabs tables.
* **JSON (`.json`)**: Structured document parse tree (AST).

### Commands & Examples:
```bash
# 1. Convert to PDF:
rtl --convert spec.md -o spec.pdf
rtl --convert spec.md --to pdf

# 2. Convert to Plain Text:
rtl --convert spec.md -o spec.txt
rtl --convert spec.md --to txt

# 3. Convert to Microsoft Word (DOCX):
rtl --convert spec.md -o spec.docx
rtl --convert spec.md --to docx

# 4. Convert to Standalone Styled HTML:
rtl --convert spec.md -o spec.html

# 5. Convert to ALL Formats Simultaneously (PDF + TXT + HTML + DOCX):
rtl --convert spec.md --to all

# 6. Direct Standalone Utility:
python3 md_converter.py spec.md -o spec.pdf
md-convert spec.md -o spec.docx
```

---

## 8. Technology-Agnostic Memory Compiler (`--mem` / `--memory`)

Compiles synthesizable SystemVerilog on-chip memories targeting **Simulation**, **FPGA** (Xilinx XPM primitives), **ASIC** hard macros, and **SoC bus wrappers**.

### A. AI Natural Language Synthesis
Describe your memory in plain English; the local LLM parses parameters and compiles the subsystem:

```bash
# Simple Dual-Port RAM with Wishbone bus
rtl --mem --spec "16KB Simple Dual-Port RAM with 64-bit width and Wishbone bus"

# Single-Port RAM with AMBA AXI5 bus & Byte Enables
rtl --mem --spec "32KB SPRAM with 32-bit width, byte enables, and AXI5 interface"

# Boot ROM with hex initialization file & RISC-V bus
rtl --mem --spec "4KB ROM with init file bootrom.hex and RISC-V Core i-Bus wrapper"
```

### B. Direct Hardware Parameter Compilation
```bash
# 4KB Single-Port RAM with AXI5 wrapper:
rtl --mem --type spram --size 4KB --bus axi5 --name sram_4k -o generated_mem

# 64KB Simple Dual-Port RAM with Wishbone wrapper:
rtl --mem --type sdp --size 2Kx64 --bus wishbone --name sdp_ram_64k -o generated_mem

# 16KB True Dual-Port RAM:
rtl --mem --type tdp --size 16KB --width 32 --name tdp_ram_16k -o generated_mem
```

### C. Inspect Memory Presets
```bash
rtl --mem --list-presets
```
* **Supported Types**: `rom`, `spram` (Single-Port), `sdp` (Simple Dual-Port), `tdp` (True Dual-Port)
* **Supported Buses**: `axi5`, `ahb-lite`, `wishbone`, `riscv-ibus`, `none`
* **Supported Capacities**: `--size 4KB`, `16KB`, `64KB`, `1MB`, `1Kx32`, `2Kx64`, `512x8`

---

## 9. Full SoC Architecture, CDC, UPF 2.1 & Gate Netlist Flow (`--soc`)

Executes the full automated CAD flow: register map synthesis, CDC/RDC constraints, IEEE 1801 UPF 2.1 power intent, SDC timing constraints, and NanGate 45nm standard-cell gate netlist synthesis.

```bash
# RTL-Only Mode (Synthesizes RTL + CDC Constraints + Verilator Lint + TB Simulation):
rtl --soc --spec benchmarks/H264D-U1000_cfg_regs_spec.md --rtl-only

# Complete Unified Tapeout Flow (RTL + CDC + UPF 2.1 + SDC + 45nm Gate Netlist):
rtl --soc --spec benchmarks/H264D-U1000_cfg_regs_spec.md \
          --config benchmarks/power_config.json \
          --filelist benchmarks/soc_filelist.f \
          --all

# Batch Generation across an entire folder of specifications:
rtl --soc --spec market_specs/ --rtl-only
```

---

## 10. Interactive VLSI / RTL Engineer Chat (`--chat`)

Interactive terminal session powered by local `rtl-coder`. The assistant is prompted as a **Principal ASIC/FPGA Hardware Engineer** with multi-turn conversation memory.

```bash
# Start chat with primary 7B model (deep reasoning):
rtl --chat

# Start chat with fast 3B model (instant responses):
rtl --chat --model rtl-coder-fast
```

### In-Chat Commands
* **Ask any question**: Static Timing Analysis (STA), CDC, UPF 2.1, FSM architectures, arbitration, synthesis trade-offs.
* **Paste RTL code**: Ask to find latches, clock domain bugs, or optimize timing.
* **`clear`**: Resets conversation context to begin a new topic.
* **`exit`** or **`quit`**: Exits the chat.

---

## 11. System Maintenance & 1-Click Updates (`--update`)

Run whenever you update design rules, Modelfiles, or python code:

```bash
# 1-Click update:
rtl --update

# Or run the updater script:
./update.sh          # macOS / Linux
.\update.ps1         # Windows PowerShell
```

### What `rtl --update` does:
1. Re-links package entry points in editable mode (`pip install -e .`).
2. Re-compiles both local models (`rtl-coder` 7B and `rtl-coder-fast` 3B) from [`Modelfile.rtl`](file:///Users/bappi/LLM_Local/Modelfile.rtl) and [`Modelfile.rtl-fast`](file:///Users/bappi/LLM_Local/Modelfile.rtl-fast).
3. Runs the memory compiler unit test suite.
4. Performs an environment health check.

---

## 12. Updating Rules, Models & Tools

### A. Add New Hardware Design Rules
1. Edit [`Modelfile.rtl`](file:///Users/bappi/LLM_Local/Modelfile.rtl).
2. Add your rules into the `SYSTEM """ ... """` block.
3. Run `rtl --update`.

### B. Upgrade to Larger / Newer Base Models
If upgrading GPU VRAM (e.g., 16 GB - 24 GB+):
```bash
# 1. Pull new base model
ollama pull qwen2.5-coder:14b

# 2. Update line 3 in Modelfile.rtl:
# FROM qwen2.5-coder:14b

# 3. Rebuild
rtl --update
```

### C. Update Ollama & Local Simulators
```bash
# macOS:
brew upgrade ollama icarus-verilog verilator yosys

# Linux (Ubuntu/Debian):
curl -fsSL https://ollama.com/install.sh | sh
sudo apt update && sudo apt upgrade -y iverilog verilator yosys

# Windows:
winget upgrade Ollama.Ollama
```

---

## 13. Creating Distributable Release Packages

To package your complete environment into universal Python wheels and standalone portable archives for distribution to other machines:

```bash
python3 package_release.py
```

Generated in [`dist/`](file:///Users/bappi/LLM_Local/dist):
* `llm_local-1.0.0-py3-none-any.whl`: Universal Python wheel.
* `llm-local-1.0.0.tar.gz`: Standard source distribution.
* `LLM_Local-1.0.0-portable.zip`: Complete standalone ZIP for Windows/macOS.
* `LLM_Local-1.0.0-portable.tar.gz`: Complete standalone tarball for Linux servers.

---

## 14. VS Code / Cursor Copilot & Standard Cell Library Integration

When opening `LLM_Local` in VS Code / Cursor, all open standard cell libraries (`techlib/nangate45` and `techlib/sky130`) and synthesis tools are automatically available:

### A. Automatic Workspace Features
* **File Explorer**: Browse and search [`techlib/`](file:///Users/bappi/LLM_Local/techlib) directly.
* **Syntax Highlighting**: `.lib` files are automatically formatted with Liberty/Tcl syntax, and `.v` / `.sv` files with Verilog HDL.
* **Pre-configured 1-Click VS Code Tasks** (`Terminal` -> `Run Task...`):
  * `RTL: Synthesize Active Module (NanGate 45nm)`
  * `RTL: Synthesize Active Module (SkyWater 130nm)`
  * `RTL: Run Gate-Level Simulation (GLS)`
  * `RTL: Verify & Auto-Fix Active Module`
  * `RTL: Generate Testbench for Active File`
  * `RTL: Interactive VLSI Chat`

### B. Free In-Editor AI Copilot (Zero Tokens)
1. Install the **Continue** extension from the VS Code Extensions marketplace.
2. Link the pre-configured settings:
   ```bash
   # macOS / Linux:
   mkdir -p ~/.continue && cp continue_config.json ~/.continue/config.json

   # Windows PowerShell:
   Copy-Item .\continue_config.json "$env:USERPROFILE\.continue\config.json" -Force
   ```
3. **Usage**:
   * **Tab**: Zero-latency local autocompletion.
   * **`Cmd + L` (Mac) / `Ctrl + L` (Win/Linux)**: In-editor chat with selected code.
   * **Slash Commands**:
     * `/rtl-synth`: Analyze & synthesize module targeting NanGate 45nm or SkyWater 130nm.
     * `/rtl-testbench`: Generate self-checking testbench.
     * `/rtl-lint`: Lint RTL for latches, CDC hazards, and timing risks.

---

## 15. Samsung Galaxy Tab & Mobile Tablet Setup

Run this toolkit on Samsung Galaxy Tab (with Samsung DeX):

* **Quick Guide**: Refer to [`SETUP_SAMSUNG_TAB.md`](file:///Users/bappi/LLM_Local/SETUP_SAMSUNG_TAB.md).
* **Automated Termux Setup**: Run `./setup_termux.sh` inside Termux on the tablet.
* **Recommended Mode (VS Code Tunnel)**: Run `code tunnel` on your host PC/Mac, and open the URL in Samsung Internet or Chrome inside **Samsung DeX**. You get the complete desktop VS Code interface, terminal, synthesis, and 1-click document conversion with zero tablet battery drain.

