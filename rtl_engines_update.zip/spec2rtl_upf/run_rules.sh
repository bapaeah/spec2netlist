#!/usr/bin/env bash
# Run Spec2RTL + AutoUPF WITHOUT an LLM (deterministic rules engine; no Ollama needed)
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$DIR"
echo "============================================================"
echo " Running Spec2RTL + AutoUPF - rules engine (no LLM)"
echo "============================================================"
args=(); for a in "$@"; do [ "$a" != "--llm" ] && args+=("$a"); done
exec python3 main.py --no-llm "${args[@]}"
