#!/usr/bin/env python3
"""spec2rtl - generate synthesizable SystemVerilog + TB from an IP spec.

Two independent engines write the functional core:
  (default)  rules engine - deterministic, no LLM, no network
  --llm      LLM engine   - local Ollama (or SPEC2RTL_LLM_URL), lint/synth/sim repair loop

  spec2rtl.py extract  <spec.{pdf,docx,doc,xlsx,csv,md,txt}> -o out/spec.json
  spec2rtl.py generate out/spec.json -o out [--llm [--model M] [--iters N]]
  spec2rtl.py run      <spec file> -o out [--llm ...]      (extract + generate)
  spec2rtl.py lint     out        (Verilator -Wall)
  spec2rtl.py constraints out     (tool-neutral JSON + generic SDC + SpyGlass SGDC + Questa CDC files)
  spec2rtl.py cdc      out        (constraints + open structural CDC/RDC check)
  spec2rtl.py synth    out        (Yosys generic synth + latch/comb-loop check)
  spec2rtl.py sim      out        (build + run TB with Verilator, fallback Icarus)
  spec2rtl.py all      <spec file> -o out [--llm ...]      (run + lint + synth + sim)

Shortcuts:  ./spec2rtl_rules.sh <spec> -o out     ./spec2rtl_llm.sh <spec> -o out
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from spec2rtl import extract as X, parse as P, flow as F  # noqa: E402
from spec2rtl.flow import files_of, tool, sh  # noqa: E402,F401  (re-exported for older callers)


def do_extract(spec_file, out_json, name=None):
    text, tables = X.extract(spec_file)
    spec = P.parse(text, tables, name)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(spec, indent=2))
    print(f"[extract] module={spec['module']}  clock={spec['clock']}  reset={spec['reset']}")
    print(f"[extract] bus={spec['bus']['type']}  ports={len(spec['ports'])}  "
          f"registers={len(spec['registers'])}  -> {out_json}")
    for w in spec["warnings"]:
        print(f"[extract] WARNING: {w}")
    return spec


def lint_files(files, top):
    """Kept for older callers."""
    v = tool("verilator", "verilator-cli")
    if not v:
        return None, "verilator not found"
    return sh([v, "--lint-only", "-Wall", "--top-module", top, *files])


def do_generate(spec_json, out, use_llm=False, model=None, iters=4):
    spec = json.loads(Path(spec_json).read_text())
    res = F.generate(spec, Path(out), engine="llm" if use_llm else "rules", model=model, iters=iters)
    print(f"[generate] engine={res['engine']}  RTL + TB written to {out}/rtl, {out}/tb  "
          f"(report: {out}/core_report.md)")
    return res


def do_lint(out):
    ok, log = F.lint(Path(out))
    print(log)
    print("LINT: CLEAN" if ok else "LINT: FAILED")
    return bool(ok)


def do_synth(out):
    ok, log = F.synth_check(Path(out))
    print("\n".join(log.strip().splitlines()[-15:]))
    print("SYNTH: PASS (no latches, no comb loops, no multi-drivers)" if ok else
          f"SYNTH: FAILED (see {out}/synth.log)")
    return bool(ok)


def do_sim(out):
    ok, log = F.sim(Path(out))
    print(log)
    return bool(ok)


def do_constraints(out, quiet=False):
    """Write the tool-neutral constraint set into out/constraints/ (JSON, SDC, SGDC, Questa, filelist)."""
    from spec2rtl import constraints as K
    out = Path(out)
    files, top = files_of(out)
    spec = json.loads((out / "spec.json").read_text()) if (out / "spec.json").exists() else None
    m = K.model_from_spec(spec, [Path(f) for f in files]) if spec else K.model_from_rtl(top, [Path(f) for f in files])
    paths = K.write_all_constraints(m, out / "constraints", files)
    if not quiet:
        print(f"[constraints] {top}: clocks=" + (", ".join(f"{c['name']}@{c['freq_mhz']:g}MHz" for c in m["clocks"]) or "none")
              + f"  resets={', '.join(r['name'] for r in m['resets']) or 'none'}"
              + f"  async_pins={len(m['async_inputs'])}  quasi_static={len(m['quasi_static'])}")
        for k in ("json", "sdc", "sgdc", "questa"):
            print(f"[constraints]   {k:<7} {paths[k]}")
        for w in m["warnings"]:
            print(f"[constraints] WARNING: {w}")
    return m, paths


def do_cdc(out):
    """Open structural CDC/RDC check (no commercial tool) using the generated constraint model."""
    from spec2rtl import constraints as K
    out = Path(out)
    m, paths = do_constraints(out)
    files, top = files_of(out)
    r = K.check_cdc(m, [Path(f) for f in files])
    print(f"[cdc] clock domains used by flops: {', '.join(r['clock_domains']) or 'none'}   "
          f"crossings: {r['crossings_found']} (synchronized {r['synchronized_crossings']})   RDC: {r['rdc_status']}")
    for v in r["violations"]:
        print(f"[cdc] VIOLATION: {v}")
    (out / "constraints" / "cdc_report.json").write_text(json.dumps(r, indent=2))
    single = len(r["clock_domains"]) <= 1
    print(("CDC: CLEAN" + (" (single clock domain)" if single else "")) if r["cdc_clean"] else "CDC: VIOLATIONS")
    return r["cdc_clean"]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["extract", "generate", "run", "lint", "constraints", "cdc", "synth", "sim", "all"])
    ap.add_argument("input", help="spec file, spec.json, or output dir")
    ap.add_argument("-o", "--out", default="out")
    ap.add_argument("--name", help="override module name")
    eng = ap.add_mutually_exclusive_group()
    eng.add_argument("--llm", action="store_true", help="LLM engine writes the functional core")
    eng.add_argument("--no-llm", "--rules", dest="no_llm", action="store_true",
                     help="rules engine, no LLM (default)")
    ap.add_argument("--model", help="LLM model (default auto: best installed for the host GPU/RAM)")
    ap.add_argument("--iters", type=int, default=4, help="LLM repair rounds (default 4)")
    a = ap.parse_args()
    out = Path(a.out)
    if a.cmd == "extract":
        do_extract(a.input, out if out.suffix == ".json" else out / "spec.json", a.name)
    elif a.cmd == "generate":
        res = do_generate(a.input, out, a.llm, a.model, a.iters)
        sys.exit(0 if res["ok"] else 1)
    elif a.cmd in ("run", "all"):
        do_extract(a.input, out / "spec.json", a.name)
        try:
            res = do_generate(out / "spec.json", out, a.llm, a.model, a.iters)
        except Exception as e:  # noqa: BLE001  (LLM unreachable etc.)
            print(f"\n[error] {e}")
            sys.exit(2)
        if a.cmd == "all":
            r = {"lint": do_lint(out), "cdc": do_cdc(out), "synth": do_synth(out), "sim": do_sim(out)}
            print(f"\nSUMMARY: ENGINE={res['engine'].upper()}  "
                  + "  ".join(f"{k.upper()}={'PASS' if v else 'FAIL'}" for k, v in r.items()))
            sys.exit(0 if all(r.values()) and res["ok"] else 1)
        sys.exit(0 if res["ok"] else 1)
    else:
        if a.cmd == "constraints":
            do_constraints(Path(a.input))
            sys.exit(0)
        ok = {"lint": do_lint, "cdc": do_cdc, "synth": do_synth, "sim": do_sim}[a.cmd](out if a.input == "out" else Path(a.input))
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
