# spec2rtl — User Guide

Turn an IP specification (PDF / DOCX / DOC / XLSX / CSV / MD / TXT) into
**synthesizable SystemVerilog**, a **self-checking testbench**, and run
**lint → synthesis check → simulation** in one flow.

```
 spec.pdf ──extract──► spec.json ──generate──► rtl/*.sv + tb/*.sv ──► lint ──► synth ──► sim
            (review/edit here)                 (fill core logic)     Verilator  Yosys    Verilator/iverilog
```

---

## 0. Two independent core engines (with / without LLM)

| | Rules engine (default) | LLM engine |
|---|---|---|
| Command | `./spec2rtl_rules.sh spec.md -o out` or `spec2rtl.py all spec.md -o out --no-llm` | `./spec2rtl_llm.sh spec.md -o out` or `spec2rtl.py all spec.md -o out --llm` |
| Needs | Python + EDA tools only (no Ollama, no network) | Ollama (local or `rtl --models --set-host`) or `SPEC2RTL_LLM_URL` |
| Core logic | Inferred from register/port semantics: timers, GPIO, PWM, counters, pass-throughs, command pulses, W1C event sources, interrupt aggregation. Anything not derivable is tied to 0 and marked `TODO(spec2rtl)` | Model writes the whole core from an empty skeleton + full spec; every answer goes through port check -> Verilator lint -> Yosys latch check -> TB sim, errors fed back (`--iters`, default 4) |
| TB | Register tests + functional checks for every rule-implemented behaviour | Register tests |
| Report | `out/core_report.md`: which rule drives each output, what is TODO | `out/core_report.md` + `out/llm_history.json`: model, rounds, last errors |

Both engines share only the register block, top wrapper, TB and file list. Neither calls the other,
and a failed LLM run never silently falls back to the rules engine.
Options for the LLM engine: `--model qwen2.5-coder:32b`, `--iters 6`.
Makefile: `make all SPEC=...` (rules) / `make all SPEC=... LLM=1` (LLM).

## 0b. Step-by-step with open-source tools (Makefile)

Run from `spec2rtl_upf/spec2rtl`. Every target runs the tool directly; no LLM unless you add `LLM=1`.

| Step | Command | Tool | Output |
|---|---|---|---|
| 1. Generate RTL + TB | `make rtl SPEC=spec.md OUT=out` | spec2rtl (rules engine) | `out/rtl/`, `out/tb/`, `out/core_report.md` |
| 2. Lint | `make lint OUT=out` | `verilator --lint-only -Wall` | `LINT: CLEAN` |
| 2b. Elaboration (alt) | `make lint-iv OUT=out` | `iverilog -g2012 -Wall` | |
| 3a. Constraints | `make constraints OUT=out` | `spec2rtl/constraints.py` | `out/constraints/` (see below) |
| 3b. CDC / RDC | `make cdc OUT=out [CDC_TOOL=open\|spyglass\|questa\|meridian\|jasper]` | open checker or your CDC tool | `out/constraints/cdc_report.json` (open) |
| 4. Compile | `make compile OUT=out` | `verilator --binary --timing` | `out/sim_build/simv` |
| 5. Simulate | `make sim OUT=out` | self-checking TB | `out/sim.log` (`TEST PASSED`) |
| 4b/5b. Icarus (alt) | `make compile-iv` / `make sim-iv OUT=out` | `iverilog` + `vvp` | `out/sim_iv.log` |
| 6. Synthesis check | `make synth OUT=out` | `yosys` generic synth, latch / loop / multi-driver check | `out/synth.log` |
| 7. Cell mapping | `make synth-lib OUT=out LIB=nangate45` (or `sky130`) | Yosys + open Liberty (`techlib/`) | `out/<top>_<lib>_gate.v`, area |
| 8. Gate-level sim | `make gls OUT=out LIB=nangate45` | Icarus + cell models | `GLS: PASS` |
| 9. STA | `make sta OUT=out` | OpenSTA (needs `./setup_synthesis.sh` for full Liberty + timing) | timing report |
| All of 2-8 | `make flow OUT=out [LIB=sky130]` | | |
| Batch | `make all-specs`, `make regress`, `make soc`, `make everything` | | |
| Tool check | `make tools` | | |

### Constraint files (one model, every tool)

`make constraints` builds one tool-neutral model from the spec and the generated RTL
(clocks with spec frequencies, resets, the clock domain of every port, async pins,
quasi-static inputs) and writes every tool file from it, so they never disagree:

| File in `out/constraints/` | Used by |
|---|---|
| `<top>_constraints.json` | the model itself; edit it to correct a clock period or domain |
| `<top>.sdc` | generic SDC, no vendor extensions: Yosys/OpenSTA, DC, Genus, PrimeTime, Tempus, and CDC tools that read SDC |
| `<top>_cdc.sgdc` + `<top>_spyglass.prj` | SpyGlass CDC (`CDC_TOOL=spyglass`) |
| `<top>_cdc_questa.tcl` + `<top>_questa_cdc.do` | Questa CDC (`CDC_TOOL=questa`) |
| `<top>.f` | RTL file list for any tool |

Meridian CDC and JasperGold CDC read the generic SDC and file list: `make cdc CDC_TOOL=meridian CDC_CMD="<your launch command>"`
(the command gets `SDC`, `FILELIST` and `TOP` in its environment). The open checker (`CDC_TOOL=open`) flags async pins
without a synchronizer, unsynchronized flop-to-flop crossings between clocks inside a module, and async resets shared by
several clock domains without a reset synchronizer. It does not trace across module boundaries or through combinational
logic, so use a CDC tool for sign-off. In the SoC flow (`--all`) the same set is written for the real top module in
`<output>/constraints_soc/`.

### Special cells and std-cell replacement

Every IP ships `rtl/<ip>_cells.sv`, a prefixed wrapper library (like a commercial IP delivery) holding
everything that must not be built from random logic. The IP RTL instantiates only these wrappers:

| Wrapper | Purpose | Used by the generated IP |
|---|---|---|
| `<ip>_sync #(WIDTH, STAGES, RESET_VAL)` | 2/3-flop synchronizer (per bit) | every async input pin |
| `<ip>_rst_sync #(STAGES)` | async-assert / sync-deassert reset synchronizer | IP top (async-reset IPs) |
| `<ip>_pulse_sync` | single-cycle pulse crossing | available |
| `<ip>_hs_sync #(WIDTH)` | req/ack handshake for multi-bit data | available |
| `<ip>_clk_gate` | integrated clock gate with test enable | available |
| `<ip>_clk_mux` | glitch-free 2:1 clock mux | available |
| `<ip>_clk_buf` / `<ip>_clk_inv` | clock-tree buffer / inverter | available |

Replace them with your standard cells (the generic file is never modified):

```bash
make techmap OUT=out TECH=mylib STDCELL=/path/to/stdcells [CELLMAP=examples/cellmap_example.json]
make lint sim synth OUT=out TECH=mylib          # same steps, now with the real cells
make tech-specs TECH=mylib STDCELL=/path/to/stdcells   # every IP under specs_out/
```

`STDCELL` is a directory (or files) with the Liberty (`.lib`/`.lib.gz`) and the cells' Verilog models.
Cells are chosen by **function** from the Liberty, so any foundry naming works: a dedicated
synchronizer or ICG cell when the library has one, otherwise plain async-reset flops, latch + AND,
clock buffers/inverters (all `dont_touch`). Scan, enable and `dont_use` cells are skipped.
`techmap_cells.py --stdcell <dir> --list` shows what it would pick.

Output per IP: `tech/<tech>/<ip>_cells_<tech>.sv`, `files_<tech>.f`, `tech/<tech>/models.f` (simulation),
`liberty.f` (synthesis), `cell_stubs.sv` (lint), `dont_touch.tcl`, `techmap_report.md`.
With `TECH=` set, lint uses the port stubs, simulation uses Icarus with the cell models (vendor
models often use UDPs, which Verilator does not support), and synthesis reads the Liberty as black boxes.

## 1. Requirements

| Item | Version / Notes |
|---|---|
| OS | macOS, Linux (Ubuntu/Debian tested). Windows → use WSL2 |
| Python | 3.8+ |
| Python packages | `pdfplumber`, `python-docx`, `openpyxl` (see `requirements.txt`) |
| Lint | Verilator ≥ 5.0 (needs `--binary --timing` for sim) |
| Synth check | Yosys (or `yowasp-yosys` via pip) |
| Simulator | Verilator (preferred) or Icarus Verilog (`iverilog -g2012`) |
| `.doc` input | LibreOffice (`soffice`) for conversion |

## 2. Installation

```bash
unzip spec2rtl-toolkit.zip && cd spec2rtl
chmod +x setup.sh
./setup.sh
```

`setup.sh` installs the Python packages, then:
- macOS: `brew install verilator yosys icarus-verilog`
- Linux: `sudo apt-get install -y verilator yosys iverilog` (falls back to `pip install yowasp-yosys`)

Verify:
```bash
verilator --version && yosys -V && python3 -c "import pdfplumber, docx, openpyxl; print('OK')"
```

> Ubuntu's apt Verilator is often 4.x. If sim fails on `--timing`, build Verilator 5 from source or use iverilog.

## 3. Quick Start

Try the bundled example first:
```bash
make all                                   # uses examples/timer_spec.md → out/
```

Your own spec:
```bash
make all SPEC=/path/to/my_ip_spec.pdf OUT=out_myip
```
Ends with a summary, exit code 0 only if all pass:
```
SUMMARY: LINT=PASS  SYNTH=PASS  SIM=PASS
```

## 4. Recommended Step-by-Step Flow

| Step | Make target | Direct CLI | Result |
|---|---|---|---|
| 1. Extract | `make extract SPEC=spec.pdf OUT=out` | `python3 spec2rtl.py extract spec.pdf -o out` | `out/spec.json` |
| 2. Review | edit `out/spec.json` | — | fix clock/reset/ports/registers |
| 3. Generate | `make gen OUT=out` | `python3 spec2rtl.py generate out/spec.json -o out` | `out/rtl/`, `out/tb/` |
| 4. Implement | edit `out/rtl/<m>_core.sv` | — | functional logic |
| 5. Lint | `make lint OUT=out` | `python3 spec2rtl.py lint out` | Verilator `-Wall`, must be clean |
| 6. Synth | `make synth OUT=out` | `python3 spec2rtl.py synth out` | no latches / comb loops / multi-drivers |
| 7. Sim | `make sim OUT=out` | `python3 spec2rtl.py sim out` | `TEST PASSED` / `TEST FAILED` |
| Clean | `make clean OUT=out` | `rm -rf out` | — |

Always check `spec.json` in step 2 — spec tables vary, and this is the cheapest place to fix mistakes.

## 5. CLI Reference

```
python3 spec2rtl.py <cmd> <input> [-o OUT] [--name NAME] [--llm]
```

| Command | `<input>` | Action |
|---|---|---|
| `extract` | spec file | Parse spec → `OUT/spec.json` |
| `generate` | `spec.json` | Build RTL + TB |
| `run` | spec file | extract + generate |
| `all` | spec file | extract + generate + lint + synth + sim |
| `lint` / `synth` / `sim` | output dir | Run a single check |

| Option | Meaning |
|---|---|
| `-o, --out` | Output directory (default `out`) |
| `--name` | Override module name from spec |
| `--llm` | Fill the functional core with an AI model (see §9) |

Make variables: `SPEC`, `OUT`, `PY` (python binary), `LLM=1`.

## 6. Writing a Spec the Tool Understands

| Item | What the parser looks for |
|---|---|
| Module name | `Module Name: my_ip` in text (or `--name`) |
| Clock + freq | 1-bit input named `*clk*`/`*clock*`; MHz from port description or `Target Frequency: 200 MHz` |
| Reset | 1-bit input with `rst`/`reset`; active-low if name ends in `_n` or text says active-low; synchronous only if text says "synchronous reset" (default async) |
| Ports | Table with `Port`/`Signal` + `Dir` columns; width as `8` or `[7:0]` |
| Bus | Auto-detected from port names (any prefix, `_i/_o` suffixes OK) – see §7a |
| Registers | Table with `Offset`/`Address` + `Name` (+ `Reset`, `Access`, `Description`) |
| Fields | `[msb:lsb] name` inside description, or a separate `Register/Bits/Field` table |
| Access | `RW, RO, WO, W1C, W1S, RC`; per-field override e.g. `[4] err (W1C)` |

Minimal Markdown template:
```markdown
Module Name: my_timer
Target Frequency: 100 MHz
Reset: active-low asynchronous

| Port   | Dir | Width  | Description        |
|--------|-----|--------|--------------------|
| pclk   | in  | 1      | APB clock, 100 MHz |
| presetn| in  | 1      | Active-low reset   |
| paddr  | in  | [11:0] | APB address        |
| ...    |     |        |                    |

| Offset | Name | Access | Reset      | Description                 |
|--------|------|--------|------------|-----------------------------|
| 0x00   | CTRL | RW     | 0x00000000 | [0] en, [3:1] mode          |
| 0x04   | STAT | RO     | 0x00000001 | [0] idle, [4] err (W1C)     |
```
See `examples/` for the same timer spec in MD, DOCX and XLSX.

## 7. Generated Output

```
out/
├── spec.json            normalized, editable spec
├── rtl/
│   ├── <m>.sv           top – exact spec port list
│   ├── <m>_regs.sv      bus slave front-end + decode, reg flops, byte enables, read mux, error resp, _wr/_rd strobes
│   └── <m>_core.sv      functional core shell  ← IMPLEMENT LOGIC HERE
├── tb/tb_<m>.sv         clock @ spec freq, reset per polarity, bus_wr/bus_rd BFM, tests
├── lint.log / synth.log
└── sim_build/           Verilator build
```

CORE access = register owned by the core (clamped, write-once, eFuse mirror...): regs block gives `_wr` strobe + byte-merged `<reg>_<field>_wd`, core returns the readback value.

Register ↔ core signal naming: `<reg>_<field>`. W1C fields add a `<reg>_<field>_set` input to the regs block; W1S fields add `_clr`.

**Hand-edited `_core.sv` files are never overwritten** when you re-run `generate`, so you can iterate on `spec.json` safely.

Built-in testbench checks: reset values, RW walking-1/0 pattern, pslverr on unmapped address. Add functional tests in `tb_<m>.sv`.

## 7a. Supported Bus Protocols (slave side)

| Protocol | Detected when these ports exist | Generated slave behaviour | Error response |
|---|---|---|---|
| APB2 / APB3 / APB4 / APB5 | `paddr psel penable pwrite pwdata prdata` (+ `pready pslverr pstrb pprot pwakeup`) | Zero wait-state, `pready=1` | `pslverr` |
| AHB-Lite / AHB (AMBA 2) / AHB5 | `haddr htrans hwrite hwdata hrdata` (+ `hsel hready hreadyout hresp hsize hwstrb`) | Zero wait-state, byte lanes from `hsize`/`haddr` or `hwstrb` | 2-cycle `hresp=ERROR` |
| AXI4-Lite | `aw* w* b* ar* r*` valid/ready + addr/data | Independent AW/W capture, 1 outstanding per direction, AR→RVALID 1 cycle | `bresp/rresp=SLVERR` |
| AXI3 / AXI4 / AXI5 | AXI4-Lite set + any of `awlen arlen awid wlast rlast` | Bursts FIXED/INCR/WRAP, IDs echoed on `bid/rid`, `rlast` | per-burst `SLVERR` |
| ACE-Lite / ACE5-Lite | AXI + `awdomain/ardomain/awsnoop/arsnoop/awbar/arbar` | As AXI4; domain/snoop/barrier accepted and ignored (non-cached register target) | `SLVERR` |
| ACE | AXI + snoop channel `ac* cr* cd*` or `rack/wack` | As AXI4; snoops answered `CRRESP=0` (no data, not shared); `RRESP[3:2]=0` | `SLVERR` |
| Wishbone B3/B4 classic | `adr dat_i dat_o we stb cyc ack` (+ `sel err rty cti bte`) | Registered ack (2 cycles/access) | `err` (if present) |
| Wishbone B4 pipelined | classic set + `stall` | `stall=0`, 1 access/cycle, ack next cycle | `err` |
| Avalon-MM | `address read write writedata readdata` (+ `byteenable waitrequest readdatavalid response writeresponsevalid chipselect`) | `waitrequest=0`; fixed latency 0, or 1 if `readdatavalid` exists; **word addressing** | `response=SLVERR` |
| TileLink-UL | `a_valid a_ready a_opcode a_address a_data d_valid d_ready d_opcode d_data` | Get / PutFullData / PutPartialData, `d_source/d_size` echoed | `d_error`/`d_denied` |
| OBI | `req gnt addr we wdata rvalid rdata` (+ `be err rready aid/rid`) | `gnt` when response slot free, response next cycle | `err` |

How it works: each protocol has a front-end in `spec2rtl/buses.py` that converts the bus into one
internal interface (`wr_en/wr_addr/wr_data/wr_strb`, `rd_en/rd_addr/rd_data`, `wr_hit/rd_hit`).
The register file is identical for every protocol. Optional bus inputs that the slave doesn't need
(e.g. `awcache`, `hprot`, `cti`) are sunk lint-clean; unused optional outputs (e.g. `buser`, `rty`,
`cdvalid`) are driven to 0.

Clock/reset: the bus clock/reset (`aclk/aresetn`, `hclk/hresetn`, `pclk/presetn`, `wb_clk_i/wb_rst_i`,
`clk/reset`) is used automatically. If a port description says `= cfg_rst_n`, the reset table row for
`cfg_rst_n` decides sync/async. Frequency ranges like `50-100 MHz` use the maximum.

Checking in `spec.json` after extract:
```json
"bus": {"type": "axi_lite", "protocol": "AXI4-Lite", "prefix": "s_axil_",
        "addr_width": 12, "data_width": 32, "word_addr": false, "signals": {"awaddr": "s_axil_awaddr", ...}}
```
- `type` can be forced to one of: `apb ahb axi_lite axi ace_lite ace wishbone avalon tilelink obi`
- `word_addr: true` if the bus address counts words, not bytes (default true only for Avalon)
- `signals` maps each protocol role to your port name; fix it if detection picked the wrong port
- If the spec has several buses (e.g. an AXI master and an APB slave), only a **slave-direction**
  interface is used; others are listed in the warnings.

Testbench: each protocol gets its own `bus_wr/bus_rd` BFM, so reset-value, RW walking-pattern and
unmapped-address error tests run on every bus. AXI3/AXI4/ACE also get INCR and WRAP burst-read checks.

Regression of all protocols:
```bash
make regress          # generates examples/protocols/*_spec.md, runs lint+synth+sim for each -> PASS/FAIL
```

Not supported: AXI4-Stream / other streaming interfaces (no address, so no register block), CHI,
Avalon bursts (`burstcount`), AXI exclusive access (always OKAY, never EXOKAY), multiple outstanding
transactions. The slave is always correct for these buses, just not maximum-throughput.

## 8. Synthesizability Rules Enforced

- Only `always_ff`, `always_comb`, `assign`; no `initial`, `#delay`, `unique`/`priority`
- Single clock domain; async or sync reset per spec
- Yosys fails on any latch, combinational loop or multiple drivers
- Verilator `-Wall` must be clean (unused bits are sunk explicitly)

## 9. Optional: AI-Filled Core Logic

The functional description is free text, so by default the core is a shell with safe tie-offs and the spec description as a comment. `--llm` sends the shell + register map + description to any OpenAI-compatible endpoint and retries up to 3 times on lint errors.

```bash
export SPEC2RTL_LLM_KEY=...                                        # required (any string for Ollama)
export SPEC2RTL_LLM_URL=http://localhost:11434/v1/chat/completions # optional, e.g. local Ollama
export SPEC2RTL_LLM_MODEL=qwen2.5-coder:32b                        # optional
make all SPEC=spec.pdf OUT=out LLM=1
```
Always review AI-generated RTL and extend the testbench before trusting it.

## 10. Troubleshooting

| Symptom | Fix |
|---|---|
| Clock/reset not found or wrong | Edit `clock`/`reset` in `spec.json`, re-run `make gen` |
| No registers extracted | Table header must contain `Offset`/`Address` and `Name`; or add them to `spec.json` |
| Ports missing | Need a table with `Port`/`Signal` and `Dir` columns |
| Empty text from PDF | Scanned PDF → run OCR first (e.g. `ocrmypdf in.pdf out.pdf`) |
| `.doc` fails | Install LibreOffice, or save as `.docx` |
| Lint `UNUSED`/`WIDTH` warnings | Fix in `_core.sv`; sink unused bits explicitly |
| Synth: latch found | Assign every output in all `always_comb` branches (default at top) |
| Sim: `--timing` unknown | Verilator < 5; upgrade or install iverilog |
| `yosys: command not found` | `pip install yowasp-yosys` |

## 11. Limitations

- Bus: see §7a for supported protocols; unsupported buses → ports passed straight to core, no register block
- Multi-word registers, register arrays, banked registers → edit `spec.json` by hand
- Single clock domain only; no CDC logic generated
- Scanned PDFs need OCR

## 12. Toolkit Layout

```
spec2rtl/
├── spec2rtl.py          CLI entry (extract/generate/lint/synth/sim/all)
├── spec2rtl/
│   ├── extract.py       PDF/DOCX/XLSX/MD → text + tables
│   ├── parse.py         tables/text → normalized spec.json
│   ├── generate.py      SystemVerilog + TB emitters
│   ├── buses.py         bus detection, slave front-ends, TB BFMs
│   └── llm.py           optional AI core fill
├── examples/            timer (md/docx/xlsx), counter without bus
│   └── protocols/       make_specs.py -> one test spec per protocol (make regress)
├── Makefile  setup.sh  requirements.txt
```
