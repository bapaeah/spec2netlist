"""Tool-neutral clock / reset / CDC constraint model and per-tool writers.

One model (built from the spec and the generated RTL) is the single source of truth.
Every tool file is written from it, so the files can never disagree with each other:

  <top>_constraints.json   generic model: clocks, resets, port domains, async pins, quasi-static
  <top>.sdc                generic SDC (Tcl) - synthesis, STA and every CDC tool that reads SDC
                           (Yosys/OpenSTA, DC/Genus, PrimeTime/Tempus, SpyGlass, Questa CDC,
                           Meridian CDC, JasperGold CDC)
  <top>_cdc.sgdc           SpyGlass CDC constraints      + <top>_spyglass.prj  project
  <top>_cdc_questa.tcl     Questa CDC directives         + <top>_questa_cdc.do run script
  <top>.f                  file list (absolute paths) for any tool
  README.txt               which file each tool reads

SDC has no command for quasi-static signals or virtual async domains, so those live in the
tool files (and in the JSON). Everything else is plain SDC with no vendor extensions.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Dict, List, Optional

CLK_RE = re.compile(r"(^|_)(clk|clock|aclk|hclk|pclk|mclk|fclk|sclk|ck)(_?i|_in)?$|^clk_|_clk_|^mclk|_clk$", re.I)
NOT_CLK = re.compile(r"div|_en$|_en_|gate|sel|req|ack|_out|cnt|count|stop|mux|_o$|_oe$", re.I)
RST_RE = re.compile(r"(^|_)(rst|reset|areset|arst)(_?n|_ni|_i|n)?$", re.I)
FREQ_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(GHz|MHz|kHz|Hz)\b", re.I)
SYNC_LHS = re.compile(r"\b(\w*(?:meta|sync|_ff1|_s1|cdc)\w*)\s*(?:\[[^\]]*\])?\s*<=\s*(\w+)\s*;")
PAD_IN = re.compile(r"(^|_)(rx|rxd|scl_in|sda_in|cts_n|dsr_n|dcd_n|ri_n|in|din_pad|evt|event|trig|wake|wakeup|irq_sources)$"
                    r"|^(rxd|scl_in|sda_in|cts_n|dsr_n|dcd_n|ri_n|ext_evt)$|(^|_)(sd|sd_cmd|sd_data|gpio|can|scl|sda)_(in|rx)$",
                    re.I)
QS_NAME = re.compile(r"(^|_)(mode|cfg|config|base|ptr|div|clkdiv|stride|size|len|threshold|count|lock_image)$", re.I)
UNIT = {"ghz": 1000.0, "mhz": 1.0, "khz": 1e-3, "hz": 1e-6}
SYNC_INST = re.compile(r"\b\w+_sync\s*(?:#\s*\((?:[^()]|\([^()]*\))*\))?\s*\w+\s*\(([^;]*?)\)\s*;", re.S)
CELLS_FILE = re.compile(r"_cells(_\w+)?\.s?v$")


def design_files(files):
    """Drop the special-cell wrapper library (verified separately; its internal clocks are generic)."""
    return [Path(f) for f in files if not CELLS_FILE.search(str(f))]


def synced_inputs(rtl: str) -> set:
    """Signals feeding a synchronizer: inline 2-FF chains or <ip>_sync wrapper instances (.d(x))."""
    out = {src for _, src in SYNC_LHS.findall(rtl)}
    for conns in SYNC_INST.findall(rtl):
        out |= set(re.findall(r"\.d\s*\(\s*(\w+)\s*\)", conns))
    return out


# ----------------------------------------------------------------- ports
def parse_rtl_ports(text: str, module: Optional[str] = None) -> List[dict]:
    """ANSI port list of `module` (or the first module) -> [{name, dir, width, desc}]."""
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    pat = rf"\bmodule\s+{re.escape(module)}\b" if module else r"\bmodule\s+\w+"
    m = re.search(pat, text)
    if not m:
        return []
    i = m.end()
    if re.match(r"\s*#", text[i:]):                     # skip parameter list
        j = text.index("(", i)
        depth = 0
        for k in range(j, len(text)):
            depth += {"(": 1, ")": -1}.get(text[k], 0)
            if depth == 0:
                i = k + 1
                break
    j = text.index("(", i)
    depth, k = 0, j
    for k in range(j, len(text)):
        depth += {"(": 1, ")": -1}.get(text[k], 0)
        if depth == 0:
            break
    body = text[j + 1:k]
    ports, cur = [], None
    for line in body.splitlines():
        desc = line.split("//", 1)[1].strip() if "//" in line else ""
        code = line.split("//", 1)[0]
        for chunk in code.split(","):
            chunk = chunk.strip()
            if not chunk:
                continue
            mm = re.match(r"(input|output|inout)\s+(?:wire\s+|logic\s+|reg\s+|var\s+)*(?:signed\s+)?"
                          r"(?:\[\s*(\d+)\s*:\s*(\d+)\s*\]\s*)?(\w+)", chunk)
            if mm:
                w = abs(int(mm.group(2)) - int(mm.group(3))) + 1 if mm.group(2) else 1
                cur = {"dir": mm.group(1), "width": w}
                ports.append({"name": mm.group(4), "dir": cur["dir"], "width": w, "desc": desc})
            elif cur and re.fullmatch(r"\w+", chunk):
                ports.append({"name": chunk, "dir": cur["dir"], "width": cur["width"], "desc": desc})
    return ports


def _freq_mhz(port: dict) -> Optional[float]:
    m = FREQ_RE.search(port.get("desc", ""))
    if m:
        return float(m.group(1)) * UNIT[m.group(2).lower()]
    n = port["name"].lower()
    if re.search(r"32k|32_768|32768", n):
        return 0.032768
    m = re.search(r"(\d+)m(hz)?(_|$)", n)
    return float(m.group(1)) if m else None


def _prefix(clock: str) -> List[str]:
    toks = [t for t in clock.lower().split("_") if t]
    return [t for t in toks if not re.fullmatch(r"clk|clock|aclk|hclk|pclk|mclk|fclk|ck|i|in|\d+k|\d+m", t)]


# ----------------------------------------------------------------- model
def _rtl_domains(rtl: str):
    """owner: signal -> clock of the always_ff that writes it; readers: signal -> clocks of always_ff that read it;
    comb: signal -> identifiers on the RHS of its continuous assign; used: identifiers used as logic inputs."""
    rtl = re.sub(r"//.*", "", rtl)
    owner, readers, comb, used = {}, {}, {}, set()
    for clk, body in re.findall(r"always_ff\s*@\s*\(\s*posedge\s+(\w+)[^)]*\)(.*?)(?=\balways_ff\b|\balways_comb\b|\bassign\b|\bendmodule\b|$)",
                                rtl, re.S):
        for lhs in re.findall(r"\b(\w+)\s*(?:\[[^\]]*\])?\s*<=", body):
            owner.setdefault(lhs, clk)
        for ident in set(re.findall(r"\b[A-Za-z_]\w*\b", re.sub(r"\b\w+\s*(?:\[[^\]]*\])?\s*<=", "", body))):
            readers.setdefault(ident, set()).add(clk)
            used.add(ident)
    for lhs, rhs in re.findall(r"\bassign\s+(\w+)\s*(?:\[[^\]]*\])?\s*=\s*([^;]+);", rtl):
        ids = set(re.findall(r"\b[A-Za-z_]\w*\b", re.sub(r"\d+'[hdbo][0-9a-fA-F_xz]+", "", rhs)))
        if lhs == "unused_ok":
            continue
        comb.setdefault(lhs, set()).update(ids)
        used.update(ids)
    for body in re.findall(r"always_comb(.*?)(?=\balways_ff\b|\balways_comb\b|\bassign\b|\bendmodule\b|$)", rtl, re.S):
        used.update(re.findall(r"\b[A-Za-z_]\w*\b", body))
    return owner, readers, comb, used


def _drive_domain(sig, owner, comb, depth=0):
    """Clock domains feeding `sig` through continuous assigns (to flops)."""
    if sig in owner:
        return {owner[sig]}
    if depth > 8 or sig not in comb:
        return set()
    out = set()
    for i in comb[sig]:
        out |= _drive_domain(i, owner, comb, depth + 1)
    return out


def build_model(top: str, ports: List[dict], main_clock: Optional[dict] = None,
                main_reset: Optional[dict] = None, rtl_texts: Optional[List[str]] = None,
                bus_ports: Optional[set] = None, default_period_ns: float = 10.0) -> dict:
    rtl = "\n".join(rtl_texts or [])
    bus_ports = bus_ports or set()
    names = {p["name"] for p in ports}
    ins = [p for p in ports if p["dir"] == "input"]
    warnings: List[str] = []

    # clocks
    clocks: List[dict] = []
    main_name = (main_clock or {}).get("name")
    for p in ins:
        if p["width"] != 1:
            continue
        if p["name"] == main_name or (CLK_RE.search(p["name"]) and not NOT_CLK.search(p["name"])):
            f = (main_clock or {}).get("freq_mhz") if p["name"] == main_name else _freq_mhz(p)
            src = "spec" if f else "default"
            if not f:
                f = 1000.0 / default_period_ns
                warnings.append(f"clock {p['name']}: no frequency in spec - assumed {f:g} MHz (edit the JSON/SDC)")
            clocks.append({"name": p["name"], "port": p["name"], "freq_mhz": round(f, 6),
                           "period_ns": round(1000.0 / f, 3), "source": src})
    if main_name and main_name not in names:
        warnings.append(f"spec clock {main_name} is not a port of {top}")
    clocks.sort(key=lambda c: (c["name"] != main_name, c["name"]))
    primary = clocks[0]["name"] if clocks else None

    owner, readers, comb, used = _rtl_domains(rtl)
    clk_names = {c["name"] for c in clocks}

    def domain_of(pname: str) -> Optional[str]:
        if len(clocks) <= 1:
            return primary
        ev = (_drive_domain(pname, owner, comb) | readers.get(pname, set())) & clk_names
        if len(ev) == 1:
            return ev.pop()
        pt = pname.lower().split("_")
        best, blen = None, 0
        for c in clocks:
            pre = _prefix(c["name"])
            if pre and pt[:len(pre)] == pre and len(pre) > blen:
                best, blen = c["name"], len(pre)
        return best or primary

    # resets
    resets: List[dict] = []
    rmain = (main_reset or {}).get("name")
    for p in ins:
        if p["width"] != 1 or p["name"] in {c["name"] for c in clocks}:
            continue
        if p["name"] == rmain or RST_RE.search(p["name"]):
            low = (main_reset or {}).get("active_low", True) if p["name"] == rmain else \
                bool(re.search(r"n$|_n$|_ni$", p["name"]))
            asyn = ((main_reset or {}).get("type", "async") == "async") if p["name"] == rmain else True
            resets.append({"name": p["name"], "active_low": low, "async": asyn, "clock": domain_of(p["name"]),
                           "source": "spec" if p["name"] == rmain else "name"})

    # RTL evidence of synchronizers
    synced = {src for src in synced_inputs(rtl) if src in names}

    clk_set = {c["name"] for c in clocks}
    rst_set = {r["name"] for r in resets}
    port_dom, async_in, unsync = [], [], []
    for p in ports:
        n = p["name"]
        if n in clk_set or n in rst_set:
            continue
        if p["dir"] == "input" and n in synced:
            async_in.append(n)
            port_dom.append({"port": n, "dir": p["dir"], "clock": None, "async": True, "synchronized": True})
            continue
        if p["dir"] == "input" and n not in bus_ports and (PAD_IN.search(n) or re.search(r"\basync", p.get("desc", ""), re.I)):
            async_in.append(n)
            if rtl and n not in used:
                port_dom.append({"port": n, "dir": p["dir"], "clock": None, "async": True, "synchronized": False,
                                 "unused": True})
                warnings.append(f"input {n} is asynchronous but not used by the RTL yet - add a 2-FF synchronizer when it is")
                continue
            unsync.append(n)
            port_dom.append({"port": n, "dir": p["dir"], "clock": None, "async": True, "synchronized": False})
            continue
        if len(clocks) > 1 and p["dir"] == "input":
            rd = readers.get(n, set()) & clk_names
            if len(rd) > 1:
                warnings.append(f"input {n} is sampled in several clock domains {sorted(rd)} - one of them is a crossing")
        port_dom.append({"port": n, "dir": p["dir"], "clock": domain_of(n), "async": False})

    qs = []
    if len(clocks) > 1:
        for p in ins:
            if p["name"] in clk_set | rst_set | set(async_in) or p["name"] in bus_ports:
                continue
            if QS_NAME.search(p["name"]) or re.search(r"static|configur|programm|quasi", p.get("desc", ""), re.I):
                qs.append(p["name"])
    for n in unsync:
        warnings.append(f"input {n} looks asynchronous but no 2-FF synchronizer was found in the RTL")

    return {"top": top, "primary_clock": primary, "clocks": clocks, "resets": resets,
            "ports": port_dom, "async_inputs": async_in, "unsynchronized_async_inputs": unsync,
            "quasi_static": qs, "warnings": warnings,
            "io_delay_fraction": 0.3}


def model_from_spec(spec: dict, rtl_files: List[Path]) -> dict:
    """IP-level model: ports/clock/reset from the parsed spec, synchronizer evidence from the RTL."""
    texts = [Path(f).read_text(errors="ignore") for f in design_files(rtl_files) if Path(f).exists()]
    bus = set((spec.get("bus") or {}).get("signals", {}).values())
    return build_model(spec["module"], spec["ports"], spec.get("clock"), spec.get("reset"), texts, bus)


def model_from_rtl(top: str, rtl_files: List[Path], clock_hints: Optional[Dict[str, float]] = None) -> dict:
    """SoC/top-level model from RTL only (no spec): ports of `top`, synchronizers across all files."""
    texts, ports = [], []
    for f in design_files(rtl_files):
        t = Path(f).read_text(errors="ignore") if Path(f).exists() else ""
        texts.append(t)
        if not ports and re.search(rf"\bmodule\s+{re.escape(top)}\b", t):
            ports = parse_rtl_ports(t, top)
    for p in ports:
        if clock_hints and p["name"] in clock_hints and not FREQ_RE.search(p.get("desc", "")):
            p["desc"] = f"{clock_hints[p['name']]} MHz " + p.get("desc", "")
    return build_model(top, ports, None, None, texts)


# ----------------------------------------------------------------- writers
def _plist(names: List[str]) -> str:
    return "{" + " ".join(names) + "}"


def _wrap(cmd: str, names: List[str], suffix: str = "", per_line: int = 6) -> List[str]:
    """`cmd [get_ports {a b ...}] suffix` with long lists wrapped Tcl-safely."""
    if len(names) <= per_line:
        return [f"{cmd} [get_ports {_plist(names)}]{suffix}"]
    rows = [names[i:i + per_line] for i in range(0, len(names), per_line)]
    out = [f"{cmd} [get_ports {{{' '.join(rows[0])} \\"]
    out += [f"    {' '.join(r)} \\" for r in rows[1:-1]]
    out.append(f"    {' '.join(rows[-1])}}}]{suffix}")
    return out


def write_sdc(m: dict) -> str:
    L = [f"# Generic SDC for {m['top']} - generated by spec2rtl (tool-neutral, no vendor extensions)",
         "# Read by: Yosys/OpenSTA, Design Compiler, Genus, PrimeTime, Tempus,",
         "#          SpyGlass CDC, Questa CDC, Meridian CDC, JasperGold CDC.",
         "# Quasi-static signals and async-pin domains are in the tool files (SDC cannot express them).", ""]
    if not m["clocks"]:
        L.append("# No clock ports found - combinational block, nothing to constrain.")
        return "\n".join(L) + "\n"
    L.append("# ---- clocks")
    for c in m["clocks"]:
        L.append(f"create_clock -name {c['name']} -period {c['period_ns']:.3f} "
                 f"-waveform {{0 {c['period_ns'] / 2:.3f}}} [get_ports {{{c['port']}}}]"
                 + ("" if c["source"] == "spec" else "  ;# period assumed - check"))
    for c in m["clocks"]:
        L.append(f"set_clock_uncertainty {max(0.02, round(c['period_ns'] * 0.05, 3))} [get_clocks {{{c['name']}}}]")
    if len(m["clocks"]) > 1:
        L += ["", "# ---- asynchronous clock domains (no timing between groups; CDC tools check the crossings)",
              "set_clock_groups -asynchronous \\"]
        L += [f"    -group [get_clocks {{{c['name']}}}]" + (" \\" if i < len(m["clocks"]) - 1 else "")
              for i, c in enumerate(m["clocks"])]
    L += ["", f"# ---- synchronous I/O ({int(m['io_delay_fraction'] * 100)}% of the period budgeted outside the block)"]
    by = {}
    for p in m["ports"]:
        if not p["async"] and p["clock"]:
            by.setdefault((p["clock"], p["dir"]), []).append(p["port"])
    per = {c["name"]: c["period_ns"] for c in m["clocks"]}
    for (clk, d), names in sorted(by.items()):
        dly = round(per[clk] * m["io_delay_fraction"], 3)
        cmd = "set_input_delay" if d == "input" else "set_output_delay"
        if d == "inout":
            L += _wrap(f"set_input_delay -clock {clk} -max {dly}", names)
            cmd = "set_output_delay"
        L += _wrap(f"{cmd} -clock {clk} -max {dly}", names)
        L += _wrap(f"{cmd} -clock {clk} -min 0", names)
    if m["async_inputs"]:
        L += ["", "# ---- asynchronous input pins (synchronized inside the block): no timing relationship"]
        L += _wrap("set_false_path -from", m["async_inputs"])
    if m["resets"]:
        L += ["", "# ---- resets: async assertion; de-assertion is synchronized by the SoC reset synchronizer"]
        for r in m["resets"]:
            if r["async"]:
                L.append(f"set_false_path -from [get_ports {{{r['name']}}}]")
            else:
                L.append(f"set_input_delay -clock {r['clock']} -max "
                         f"{round(per[r['clock']] * m['io_delay_fraction'], 3)} [get_ports {{{r['name']}}}]")
    if m["quasi_static"]:
        L += ["", "# ---- quasi-static configuration inputs (declared in the tool files): "
              + " ".join(m["quasi_static"])]
    return "\n".join(L) + "\n"


def write_sgdc(m: dict) -> str:
    L = [f"# SpyGlass CDC constraints for {m['top']} - generated by spec2rtl from {m['top']}_constraints.json",
         f"current_design {m['top']}", ""]
    for c in m["clocks"]:
        L.append(f"clock -name {c['name']} -domain D_{c['name']} -period {c['period_ns']:.3f} "
                 f"-edge {{0 {c['period_ns'] / 2:.3f}}}")
    if m["async_inputs"]:
        L.append("clock -tag ASYNC_VCLK -domain D_ASYNC   # virtual clock for asynchronous pins")
    for r in m["resets"]:
        L.append(f"reset -name {r['name']} -value {0 if r['active_low'] else 1} {'-async' if r['async'] else '-sync'}")
    L.append("")
    for p in m["ports"]:
        kw = "input" if p["dir"] == "input" else "output"
        if p["dir"] == "inout":
            kw = "input"
        clk = "ASYNC_VCLK" if p["async"] else p["clock"]
        if clk:
            L.append(f"{kw} -name {p['port']} -clock {clk}")
    if m["quasi_static"]:
        L.append("")
        L += [f"quasi_static -name {m['top']}.{n}" for n in m["quasi_static"]]
    return "\n".join(L) + "\n"


def write_questa(m: dict) -> str:
    L = [f"# Questa CDC directives for {m['top']} - generated by spec2rtl from {m['top']}_constraints.json", ""]
    for c in m["clocks"]:
        L.append(f"netlist clock {c['name']} -period {c['period_ns']:.3f} -group G_{c['name']}")
    for r in m["resets"]:
        L.append(f"netlist reset {r['name']} {'-active_low' if r['active_low'] else '-active_high'} "
                 f"{'-async' if r['async'] else '-sync'}")
    L.append("")
    for p in m["ports"]:
        if p["async"]:
            L.append(f"netlist port domain {p['port']} -async")
        elif p["clock"]:
            L.append(f"netlist port domain {p['port']} -clock {p['clock']}")
    if m["quasi_static"]:
        L.append("")
        L += [f"cdc signal {n} -stable" for n in m["quasi_static"]]
    return "\n".join(L) + "\n"


def write_all_constraints(m: dict, out_dir: Path, files: List[str]) -> Dict[str, Path]:
    """Write every constraint file for model m into out_dir. Returns {kind: path}."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    t = m["top"]
    absf = [str(Path(f).resolve()) for f in files]
    P = {"json": out_dir / f"{t}_constraints.json", "sdc": out_dir / f"{t}.sdc",
         "sgdc": out_dir / f"{t}_cdc.sgdc", "spyglass_prj": out_dir / f"{t}_spyglass.prj",
         "questa": out_dir / f"{t}_cdc_questa.tcl", "questa_do": out_dir / f"{t}_questa_cdc.do",
         "filelist": out_dir / f"{t}.f", "readme": out_dir / "README.txt"}
    P["json"].write_text(json.dumps(m, indent=2) + "\n")
    P["sdc"].write_text(write_sdc(m))
    P["sgdc"].write_text(write_sgdc(m))
    P["questa"].write_text(write_questa(m))
    P["filelist"].write_text("\n".join(absf) + "\n")
    P["spyglass_prj"].write_text(
        f"# SpyGlass CDC project for {t} (run: spyglass -project {P['spyglass_prj'].name} -batch -goal cdc/cdc_verify_struct)\n"
        + "".join(f"read_file -type verilog {f}\n" for f in absf)
        + f"read_file -type sgdc {P['sgdc'].resolve()}\n"
        + f"read_file -type sdc {P['sdc'].resolve()}\n"
        + f"set_option top {t}\nset_option enableSV yes\nset_option projectwdir spyglass_{t}\n"
        + "current_methodology $SPYGLASS_HOME/GuideWare/latest/block/rtl_handoff\n")
    P["questa_do"].write_text(
        f"# Questa CDC run for {t} (run: qverify -c -od questa_cdc_{t} -do {P['questa_do'].name})\n"
        "onerror {exit 1}\n"
        "vlib work\n"
        f"vlog -sv -f {P['filelist'].resolve()}\n"
        f"do {P['questa'].resolve()}\n"
        f"sdc load {P['sdc'].resolve()}\n"
        f"cdc run -d {t}\n"
        "cdc generate report cdc_detail.rpt\n"
        "exit 0\n")
    P["readme"].write_text(
        f"Constraint set for {t} (all generated from {P['json'].name}; edit the JSON, then `make constraints`)\n\n"
        f"  {P['sdc'].name:<28} generic SDC: synthesis, STA, and any CDC tool that reads SDC\n"
        f"  {P['sgdc'].name:<28} SpyGlass CDC (+ {P['spyglass_prj'].name})\n"
        f"  {P['questa'].name:<28} Questa CDC directives (+ {P['questa_do'].name})\n"
        f"  {P['filelist'].name:<28} RTL file list\n\n"
        "  Meridian CDC / JasperGold CDC: read the generic SDC plus the file list; quasi-static\n"
        "  signals and async pins are listed in the JSON for your site's tool setup script.\n\n"
        + ("Warnings:\n" + "\n".join(f"  - {w}" for w in m["warnings"]) + "\n" if m["warnings"] else ""))
    return P


# ----------------------------------------------------------------- open structural CDC check
def check_cdc(m: dict, rtl_files: List[Path]) -> dict:
    """Structural check with no commercial tool:
      1. async input pins without a synchronizer
      2. flop-to-flop crossings between clock domains inside a module (written in an always_ff of
         clock A, read in an always_ff of clock B) that do not land on a synchronizer flop
      3. async resets used in more than one clock domain without a reset synchronizer
    Limits: no cross-module tracing, no combinational path tracing - use a CDC tool for sign-off."""
    viol, crossings, synced_x = [], [], 0
    domains_used = set()
    all_rtl = ""
    for f in design_files(rtl_files):
        txt = re.sub(r"//.*", "", Path(f).read_text(errors="ignore")) if Path(f).exists() else ""
        all_rtl += txt + "\n"
        for mod in re.split(r"\bendmodule\b", txt):
            blocks = re.findall(r"always_ff\s*@\s*\(\s*posedge\s+(\w+)[^)]*\)(.*?)(?=\balways_ff\b|\balways_comb\b|\bassign\b|$)",
                                mod, re.S)
            owner = {}
            for clk, body in blocks:
                domains_used.add(clk)
                for lhs in re.findall(r"\b(\w+)\s*(?:\[[^\]]*\])?\s*<=", body):
                    owner.setdefault(lhs, clk)
            for clk, body in blocks:
                for lhs, rhs in re.findall(r"\b(\w+)\s*(?:\[[^\]]*\])?\s*<=\s*([^;]+);", body):
                    for ident in set(re.findall(r"\b[A-Za-z_]\w*\b", rhs)):
                        src = owner.get(ident)
                        if src and src != clk:
                            is_sync = bool(re.search(r"meta|sync|_ff1|_s1|cdc", lhs, re.I))
                            crossings.append({"from": src, "to": clk, "signal": ident, "dest": lhs, "synchronized": is_sync})
                            if is_sync:
                                synced_x += 1
                            else:
                                viol.append(f"unsynchronized crossing {ident} ({src}) -> {lhs} ({clk})")
    for n in m.get("unsynchronized_async_inputs", []):
        viol.append(f"async input {n} reaches logic without a 2-FF synchronizer")
    rdc = "PASS"
    multi = len(domains_used) > 1
    if multi:
        rsync = re.search(r"\w*rst\w*sync\w*|\w*sync\w*rst\w*", all_rtl, re.I)
        for r in m.get("resets", []):
            used_in = {clk for clk, body in re.findall(r"always_ff\s*@\s*\(\s*posedge\s+(\w+)\s+or\s+\w+\s+(\w+)\s*\)", all_rtl)
                       if body == r["name"]}
            if r["async"] and len(used_in) > 1 and not rsync:
                rdc = "WARNING"
                viol.append(f"async reset {r['name']} used in domains {sorted(used_in)} without a reset synchronizer")
    return {"top_module": m["top"], "clock_domains": sorted(domains_used) or [c["name"] for c in m["clocks"]],
            "resets": [r["name"] for r in m["resets"]], "crossings_found": len(crossings),
            "synchronized_crossings": synced_x + len([1 for x in re.findall(r"\b(\w+_sync)\s*(?:#|\w+\s*\()", all_rtl)
                                                      if not x.endswith("rst_sync")]),
            "unclocked_crossings": len([v for v in viol if v.startswith("unsynchronized")]),
            "rdc_status": rdc, "glitch_hazards": 0, "violations": viol, "crossings": crossings,
            "cdc_clean": not viol, "warnings": m.get("warnings", [])}
