"""Shared flow: EDA tool runners + engine dispatch.

  generate(spec, out, engine="rules")  -> no LLM, deterministic (core_rules.py)
  generate(spec, out, engine="llm")    -> LLM writes the core (llm.py), verified + repaired

The two engines share only the register block / top / TB / file list (generate.py);
neither calls the other, and a failed LLM run never silently falls back to rules.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from pathlib import Path

from . import generate as G


def tool(*names):
    for n in names:
        if shutil.which(n):
            return n
    return None


def sh(cmd, cwd=None, echo=True):
    if echo:
        print("$ " + " ".join(str(x) for x in cmd))
    r = subprocess.run([str(x) for x in cmd], cwd=cwd, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def files_of(out: Path):
    out = Path(out)
    return [str(out / f) for f in (out / "files.f").read_text().split()], (out / "top.txt").read_text().strip()


def lint(out, echo=True):
    """(ok | None if no tool, log)"""
    v = tool("verilator", "verilator-cli")
    if not v:
        return None, "verilator not found"
    files, top = files_of(out)
    rc, log = sh([v, "--lint-only", "-Wall", "--top-module", top, *files], echo=echo)
    return rc == 0, log


def synth_check(out, echo=True):
    y = tool("yosys", "yowasp-yosys")
    if not y:
        return None, "yosys not found (pip install yowasp-yosys)"
    out = Path(out)
    files, top = files_of(out)
    rel = [str(Path(f).relative_to(out)) for f in files]   # run inside out/ (yowasp sandbox)
    script = (f"read_verilog -sv {' '.join(rel)}; hierarchy -check -top {top}; proc; flatten; opt; "
              f"select -assert-none t:$dlatch t:$adlatch t:$dlatchsr; "
              f"synth -top {top}; check -assert; stat")
    rc, log = sh([y, "-q", "-p", script, "-l", "synth.log"], cwd=str(out), echo=echo)
    if rc and "assert" in log.lower() and "dlatch" in log.lower():
        log += "\nA latch was inferred: give every always_comb output a default assignment."
    return rc == 0, log


def sim(out, echo=True):
    out = Path(out)
    files, top = files_of(out)
    tb = str(out / "tb" / f"tb_{top}.sv")
    v = tool("verilator", "verilator-cli")
    if v:
        build = out / "sim_build"
        rc, log = sh([v, "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style",
                      "--top-module", f"tb_{top}", "-Mdir", str(build), "-o", "simv", *files, tb], echo=echo)
        if rc:
            return False, log
        rc, log = sh([str(build / "simv")], echo=echo)
    elif tool("iverilog"):
        rc, log = sh(["iverilog", "-g2012", "-o", str(out / "simv"), "-s", f"tb_{top}", *files, tb], echo=echo)
        if rc:
            return False, log
        rc, log = sh(["vvp", str(out / "simv")], echo=echo)
    else:
        return None, "No simulator (verilator/iverilog) found"
    return "TEST PASSED" in log, log


def verify_core(out, core_path: Path, code: str):
    """Write a candidate core and run lint -> synth -> sim. Returns (ok, error_log)."""
    core_path.write_text(code)
    for name, fn in (("Verilator lint", lint), ("Yosys synthesis check", synth_check), ("TB simulation", sim)):
        ok, log = fn(out, echo=False)
        if ok is None:          # tool missing: skip this gate
            continue
        if not ok:
            keep = [ln for ln in log.splitlines() if ln.startswith(("%Error", "%Warning", "ERROR", "Error", "TEST FAILED"))
                    or "error" in ln.lower()]
            return False, f"[{name} failed]\n" + ("\n".join(keep[:80]) or log[-4000:])
    return True, "clean"


# ------------------------------------------------------------------ engines
def generate(spec, out, engine="rules", model=None, iters=4):
    """Generate RTL + TB for one IP. Returns a result dict; never mixes engines."""
    out = Path(out)
    if engine == "rules":
        c = G.write_all(spec, out)
        rep = (out / "core_report.md").read_text() if (out / "core_report.md").exists() else ""
        m = re.search(r"implemented by rules: \*\*(\d+) / (\d+)\*\*", rep)
        res = {"engine": "rules", "ok": True, "module": c.m,
               "implemented": f"{m.group(1)}/{m.group(2)}" if m else "template"}
        print(f"[rules] {c.m}_core: outputs implemented {res['implemented']} (details: {out/'core_report.md'})")
        return res

    if engine != "llm":
        raise ValueError(f"unknown engine {engine!r}")
    from . import llm
    c = G.write_infra(spec, out)            # regs + top + TB + filelist only (no rules core)
    core = out / "rtl" / f"{c.m}_core.sv"
    core.write_text(llm.skeleton(c))
    r = llm.generate_core(c, spec, lambda code: verify_core(out, core, code), iters=iters, model=model)
    core.write_text(r["code"])
    lines = [f"# Core generation report: `{c.m}_core` (LLM engine)", "",
             f"- Model: `{r['model']}`", f"- Result: **{'CLEAN (lint + synth + sim)' if r['ok'] else 'NOT CLEAN - needs manual fix'}**",
             f"- Rounds: {r['iterations']}", "", "| Round | Result | Time (s) |", "|---|---|---|"]
    lines += [f"| {h['iteration']} | {'clean' if h['ok'] else 'errors'} | {h['seconds']} |" for h in r["history"]]
    if not r["ok"] and r["history"]:
        lines += ["", "Last tool errors:", "```", r["history"][-1]["log"], "```"]
    (out / "core_report.md").write_text("\n".join(lines) + "\n")
    (out / "llm_history.json").write_text(json.dumps(r["history"], indent=2))
    return {"engine": "llm", "ok": r["ok"], "module": c.m, "model": r["model"], "rounds": r["iterations"]}
