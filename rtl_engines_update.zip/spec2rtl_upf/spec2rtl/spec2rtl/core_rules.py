"""Deterministic (no-LLM) functional-core generator.

Infers real behaviour from the register map and the port list instead of emitting
placeholder logic.  Every rule claims the core outputs it drives; anything that no
rule can infer from the spec is tied to a reset-safe 0 and listed as a TODO in
core_report.md, so the generated core never pretends to implement something it
does not.

Rules (applied in this order; first rule to claim an output wins):
  gpio        <x>_in / <x>_out / <x>_oe pins + data_in / direct_out / direct_oe /
              masked_* / intr_en_{rise,fall,high,low} registers
  timer       RO counter field + enable field + load/period field (+ mode, prescaler,
              restart command, tick status bit)
  pwm         pwm<N>[_out] outputs + pwm<N>_duty / duty<N> registers (+ period)
  port_counter output described as a count + optional en / clr / load+d inputs
  passthru    RW field -> same-named output port, input port -> same-named RO field
  cmd_pulse   WO command field + write strobe -> single-cycle pulse on matching output
  status_set  W1C status bit <- matching input (edge-detected for event inputs)
  irq         irq/interrupt outputs <- |(W1C status & enable)
  const_ro    RO field with a non-zero reset value in the spec (version/ID) -> constant
  core_reg    CORE field read-back <- byte-merged write data captured on write
  sync_async  async input pins no rule used -> 2-FF synchronizer (<pin>_sync_q) for later logic
  tie_off     everything else -> 0, reported as TODO

The rules engine never calls an LLM; see llm.py for the independent LLM engine.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field as dfield
from typing import Dict, List, Optional


# --------------------------------------------------------------------- model
@dataclass
class Sig:
    name: str
    width: int
    dir: str            # core view: "in" | "out" | "inout"
    kind: str           # ext | cfg | wo | wr | rd | w1c | w1c_set | w1s | w1s_clr | ro | core_wd | core_rb
    reg: Optional[dict] = None
    fld: Optional[dict] = None
    desc: str = ""


def _fw(f):
    return f["msb"] - f["lsb"] + 1


def build_sigs(c) -> List[Sig]:
    """Core-side signal list with register semantics attached."""
    out: List[Sig] = []
    bus = c.bus_ports
    for p in c.spec["ports"]:
        if p["name"] in bus or p["name"] in (c.clk, c.rst):
            continue
        d = {"input": "in", "output": "out"}.get(p["dir"], "inout")
        out.append(Sig(p["name"], p["width"], d, "ext", desc=p.get("desc", "")))
    for r in c.regs:
        accs = {f["access"] for f in r["fields"]}
        if accs & {"WO", "CORE"}:
            out.append(Sig(f"{r['name']}_wr", 1, "in", "wr", r))
        if accs & {"RO", "RC"}:
            out.append(Sig(f"{r['name']}_rd", 1, "in", "rd", r))
        for f in r["fields"]:
            n, w, a = f"{r['name']}_{f['name']}", _fw(f), f["access"]
            if a == "RW":
                out.append(Sig(n, w, "in", "cfg", r, f))
            elif a == "WO":
                out.append(Sig(n, w, "in", "wo", r, f))
            elif a in ("RO", "RC"):
                out.append(Sig(n, w, "out", "ro", r, f))
            elif a == "CORE":
                out.append(Sig(n + "_wd", w, "in", "core_wd", r, f))
                out.append(Sig(n, w, "out", "core_rb", r, f))
            elif a == "W1C":
                out.append(Sig(n, w, "in", "w1c", r, f))
                out.append(Sig(n + "_set", w, "out", "w1c_set", r, f))
            elif a == "W1S":
                out.append(Sig(n, w, "in", "w1s", r, f))
                out.append(Sig(n + "_clr", w, "out", "w1s_clr", r, f))
    return out


# --------------------------------------------------------------- name tools
FILLER = {"reg", "val", "value", "data", "bits", "bit", "cnt", "count", "req", "o", "i",
          "q", "d", "status", "stat", "sts", "state", "cmd", "pulse", "sig", "out", "in"}


def _tok(name: str) -> List[str]:
    t = [x for x in re.split(r"[_\W]+", name.lower()) if x]
    # singularise simple plurals (bins -> bin, mbs -> mb)
    return [x[:-1] if len(x) >= 3 and x.endswith("s") and not x.endswith(("ss", "us", "is", "os")) else x
            for x in t]


def _core(name: str) -> frozenset:
    t = set(_tok(name))
    core = t - FILLER
    return frozenset(core or t)


def _strip_dir(name: str) -> str:
    return re.sub(r"_(o|i)$", "", name.lower())


def names_equal(port: str, s: Sig) -> bool:
    p = _strip_dir(port)
    cands = {s.name.lower()}
    if s.fld is not None:
        cands |= {s.fld["name"].lower(), s.reg["name"].lower()} if len(s.reg["fields"]) == 1 \
            else {s.fld["name"].lower()}
    return p in cands


def names_similar(port: str, s: Sig) -> bool:
    if names_equal(port, s):
        return True
    a = _core(_strip_dir(port))
    b = _core(s.fld["name"]) if s.fld else _core(s.name)
    if s.reg is not None and len(s.reg["fields"]) > 1:
        b = b | _core(s.reg["name"])
    if bool(a) and a == b:
        return True
    soft = {"bits", "bit", "cnt", "count", "value", "val", "data", "reg", "o", "i"}
    sa = frozenset(_tok(_strip_dir(port))) - soft
    sb = frozenset(_tok(s.fld["name"] if s.fld else s.name)) - soft
    return bool(sa) and sa == sb


def has_tok(name: str, *words) -> bool:
    t = set(_tok(name))
    return any(w in t for w in words)


def cast(w_dst: int, expr: str, w_src: int) -> str:
    if w_dst == w_src:
        return expr
    return f"{w_dst}'({expr})"


# ------------------------------------------------------------------ builder
@dataclass
class Builder:
    c: object
    sigs: List[Sig]
    decl: List[str] = dfield(default_factory=list)
    body: List[str] = dfield(default_factory=list)
    claimed: Dict[str, str] = dfield(default_factory=dict)   # out name -> rule
    notes: List[str] = dfield(default_factory=list)            # report lines
    tb: List[str] = dfield(default_factory=list)               # extra TB statements
    tb_irq: List[str] = dfield(default_factory=list)
    info: Dict[str, object] = dfield(default_factory=dict)

    def __post_init__(self):
        self.S = {s.name: s for s in self.sigs}

    # ---- queries
    def outs(self, kind=None):
        return [s for s in self.sigs if s.dir == "out" and s.name not in self.claimed
                and (kind is None or s.kind == kind)]

    def ins(self, kind=None):
        return [s for s in self.sigs if s.dir == "in" and (kind is None or s.kind == kind)]

    def free(self, name):
        return name in self.S and name not in self.claimed

    # ---- emit
    def claim(self, name, rule, why=""):
        self.claimed[name] = rule
        if why:
            self.notes.append(f"| `{name}` | {rule} | {why} |")

    def assign(self, name, expr, rule, why=""):
        self.body.append(f"  assign {name} = {expr};")
        self.claim(name, rule, why)

    def ff(self):
        return self.c.ff()

    def rc(self):
        return self.c.rst_cond()

    def sync(self, src: Sig, tag: str) -> str:
        """2-FF synchronizer for an asynchronous input pin; returns synced signal name."""
        w = src.width
        r = f"[{w-1}:0] " if w > 1 else ""
        n2 = f"{tag}_sync_q"
        rst_n = self.c.rst if self.c.rst_low else f"~{self.c.rst}"
        self.decl.append(f"  logic {r}{n2};  // {src.name} after 2-FF synchronizer ({self.c.m}_sync, cells file)")
        self.body.append(f"  {self.c.m}_sync #(.WIDTH({w}), .STAGES(2)) u_{tag}_sync "
                         f"(.clk({self.c.clk}), .rst_n({rst_n}), .d({src.name}), .q({n2}));")
        return n2


# -------------------------------------------------------------- TB helpers
def _A(c, off):
    return f"{c.aw}'h{off:X}"


def _D(c, v):
    return f"{c.dw}'h{v & ((1 << c.dw) - 1):X}"


def _fmask(f):
    return ((1 << _fw(f)) - 1) << f["lsb"]


def _pat(w, k=0):
    base = [0xA5A5A5A5A5A5A5A5, 0x5A5A5A5A5A5A5A5A, 0x0123456789ABCDEF][k % 3]
    v = base & ((1 << w) - 1)
    return v or 1


def _reg_reset(r):
    return sum(f["reset"] << f["lsb"] for f in r["fields"])


# ===================================================================== rules
def rule_gpio(b: Builder):
    c = b.c
    ins = [s for s in b.ins("ext") if re.search(r"(^|_)(in|i)$", s.name) and s.width > 1]
    outs_ = [s for s in b.outs("ext") if re.search(r"(^|_)out$", s.name)]
    oes = [s for s in b.outs("ext") if re.search(r"(^|_)oe$", s.name)]
    din = next((s for s in b.outs("ro") if has_tok(s.name, "in") and has_tok(s.name, "data")), None)
    dout = next((s for s in b.ins("cfg") if s.name.startswith("direct_out")), None)
    if not (ins and outs_ and din and dout):
        return
    pin, pout = ins[0], outs_[0]
    w = pout.width
    hw = w // 2
    syn = b.sync(pin, "gpio_in")
    b.assign(din.name, cast(din.width, syn, pin.width), "gpio",
             f"2-FF synchronized `{pin.name}`")

    def find(kind, pref):
        return next((s for s in b.ins(kind) if s.name.startswith(pref)), None)

    def outreg(tag, direct, port, low, high):
        q, prev = f"{tag}_q", f"{tag}_direct_prev_q"
        b.decl.append(f"  logic [{w-1}:0] {q}, {prev};")
        L = [f"  {b.ff()} begin",
             f"    if ({b.rc()}) begin {q} <= '0; {prev} <= '0; end",
             "    else begin",
             f"      {prev} <= {cast(w, direct.name, direct.width)};",
             f"      if ({cast(w, direct.name, direct.width)} != {prev}) {q} <= {cast(w, direct.name, direct.width)};"]
        for half, s in (("low", low), ("high", high)):
            if s is None:
                continue
            wr = f"{s.reg['name']}_wr"
            sl = f"[{hw-1}:0]" if half == "low" else f"[{w-1}:{hw}]"
            L.append(f"      if ({wr}) {q}{sl} <= ({q}{sl} & ~{s.name}[{s.width-1}:{hw}]) | "
                     f"({s.name}[{hw-1}:0] & {s.name}[{s.width-1}:{hw}]);  // upper half = mask, lower = data")
        L += ["    end", "  end"]
        b.body += L
        b.assign(port.name, q, "gpio",
                 f"`{direct.name}` (last write wins) + masked writes" if (low or high) else f"`{direct.name}`")

    ml, mh = find("wo", "masked_out_l"), find("wo", "masked_out_h")
    if hw and ml and mh and ml.width == w and mh.width == w:
        outreg("gpio_out", dout, pout, ml, mh)
    else:
        b.assign(pout.name, cast(w, dout.name, dout.width), "gpio", f"`{dout.name}`")
    doe = find("cfg", "direct_oe")
    if oes and doe:
        oel, oeh = find("wo", "masked_oe_l"), find("wo", "masked_oe_h")
        if hw and oel and oeh and oel.width == w and oeh.width == w:
            outreg("gpio_oe", doe, oes[0], oel, oeh)
        else:
            b.assign(oes[0].name, cast(w, doe.name, doe.width), "gpio", f"`{doe.name}`")

    # interrupts
    st = next((s for s in b.outs("w1c_set")), None)
    en = {k: find("cfg", f"intr_en_{k}") or find("cfg", f"intr_ctrl_en_{k}")
          for k in ("rise", "fall", "high", "low")}
    if st and any(en.values()):
        prev = "gpio_in_prev_q"
        b.decl.append(f"  logic [{pin.width-1}:0] {prev};")
        b.body += [f"  {b.ff()} begin", f"    if ({b.rc()}) {prev} <= '0;",
                   f"    else {prev} <= {syn};", "  end"]
        ev = {"rise": f"({syn} & ~{prev})", "fall": f"(~{syn} & {prev})",
              "high": f"{syn}", "low": f"(~{syn})"}
        terms = [f"({cast(pin.width, en[k].name, en[k].width)} & {ev[k]})" for k in en if en[k]]
        b.assign(st.name, cast(st.width, " | ".join(terms), pin.width), "gpio",
                 "rise/fall/high/low events qualified by intr_en_* registers")
        b.info["gpio"] = dict(pin=pin, din=din, dout=dout, pout=pout, st=st, en=en, oe=(oes[0] if oes else None), doe=doe)
        for s in b.outs("ext"):
            if s.width == 1 and is_irq_name(s.name):
                stv = next(x for x in b.ins("w1c") if x.name == st.name[:-4])
                b.assign(s.name, f"|{stv.name}", "gpio", f"OR of `{stv.name}`")
                b.info["gpio_irq"] = s
                break

    # TB
    g = b.info.get("gpio")
    t = b.tb
    t.append('    $display("--- Functional: GPIO ---");')
    pv = _pat(pin.width)
    t += [f"    {pin.name} = {pin.width}'h{pv:X}; repeat (4) @(posedge {c.clk});",
          f"    bus_rd({_A(c, din.reg['offset'])}, d, e); "
          f"check(\"GPIO data_in follows {pin.name}\", d, {_D(c, (pv & ((1 << din.width)-1)) << din.fld['lsb'])}, "
          f"{_D(c, _fmask(din.fld))}, 1);",
          f"    {pin.name} = '0;"]
    ov = _pat(dout.width, 1)
    t += [f"    bus_wr({_A(c, dout.reg['offset'])}, {_D(c, ov << dout.fld['lsb'])}, e); repeat (2) @(posedge {c.clk});",
          f"    check(\"GPIO {pout.name} follows direct_out\", {c.dw}'({pout.name}), {_D(c, ov)}, {_D(c, (1 << min(w, c.dw)) - 1)}, 1);"]
    if g and g["en"].get("rise"):
        enr = g["en"]["rise"]
        stv = g["st"]
        t += [f"    bus_wr({_A(c, enr.reg['offset'])}, {_D(c, 1 << enr.fld['lsb'])}, e);",
              f"    {pin.name} = {pin.width}'h1; repeat (4) @(posedge {c.clk});",
              f"    bus_rd({_A(c, stv.reg['offset'])}, d, e); "
              f"check(\"GPIO rising-edge interrupt bit 0\", d, {_D(c, 1 << stv.fld['lsb'])}, {_D(c, 1 << stv.fld['lsb'])}, 1);"]
        if "gpio_irq" in b.info:
            t.append(f"    check(\"GPIO {b.info['gpio_irq'].name} asserted\", {c.dw}'({b.info['gpio_irq'].name}), {_D(c, 1)}, {_D(c, 1)}, 1);")
        t += [f"    bus_wr({_A(c, enr.reg['offset'])}, '0, e); {pin.name} = '0;",
              f"    bus_wr({_A(c, stv.reg['offset'])}, '1, e); repeat (2) @(posedge {c.clk});",
              f"    bus_rd({_A(c, stv.reg['offset'])}, d, e); "
              f"check(\"GPIO interrupt W1C clear\", d, '0, {_D(c, _fmask(stv.fld))}, 1);"]


def rule_timer(b: Builder):
    c = b.c
    cnt = next((s for s in b.outs("ro")
                if has_tok(s.fld["name"], "count", "cnt", "value", "counter", "timer")
                and not has_tok(s.reg["name"], "perf", "err", "error", "fifo", "byte", "bytes")
                and s.width >= 4), None)
    en = next((s for s in b.ins("cfg") if s.width == 1 and
               (s.fld["name"] in ("en", "enable", "start", "run") or
                re.search(r"(^|_)(en|enable|tmr_en|timer_en|cnt_en)$", s.fld["name"]))), None)
    load = next((s for s in b.ins("cfg") if has_tok(s.fld["name"], "load", "reload", "period",
                                                     "top", "limit", "max", "compare", "cmp")
                 and s.width >= 4), None)
    if not (cnt and en and load):
        return
    W = cnt.width
    mode = next((s for s in b.ins("cfg") if s.fld["name"] in ("mode", "oneshot", "one_shot")
                 and s.reg is en.reg), None)
    psc = next((s for s in b.ins("cfg") if has_tok(s.fld["name"], "prescale", "prescaler", "psc", "div", "prediv")), None)
    rst_cmd = next((s for s in b.ins("wo") if has_tok(s.fld["name"], "restart", "reload", "start", "clear", "clr")), None)
    tick_st = next((s for s in b.outs("w1c_set") if has_tok(s.fld["name"], "tick", "timeout", "expire",
                                                            "expired", "wrap", "ovf", "overflow", "zero",
                                                            "match", "tmr", "timer", "uf", "underflow")), None)
    oneshot = "1'b0"
    if mode is not None:
        oneshot = f"({mode.name} == {mode.width}'d1)" if mode.fld["name"] == "mode" else mode.name
    restart = f"({rst_cmd.reg['name']}_wr & {rst_cmd.name}{'[0]' if rst_cmd.width > 1 else ''})" if rst_cmd else "1'b0"
    ld = cast(W, load.name, load.width)
    b.decl += [f"  logic [{W-1}:0] tmr_cnt_q;  // down-counter", "  logic        tmr_done_q;  // one-shot expired",
               "  logic        tmr_step;    // count enable (after prescaler)", "  logic        tmr_tick;"]
    if psc is not None:
        b.decl.append(f"  logic [{psc.width-1}:0] tmr_psc_q;")
        b.body += [f"  {b.ff()} begin",
                   f"    if ({b.rc()}) tmr_psc_q <= '0;",
                   f"    else if (!{en.name} || {restart} || tmr_psc_q == {psc.name}) tmr_psc_q <= '0;",
                   "    else tmr_psc_q <= tmr_psc_q + 1'b1;", "  end",
                   f"  assign tmr_step = {en.name} && (tmr_psc_q == {psc.name});"]
    else:
        b.body.append(f"  assign tmr_step = {en.name};")
    b.decl.append("  logic        tmr_en_q;    // enable, delayed (rising-edge detect)")
    b.body += [f"  assign tmr_tick = tmr_step && tmr_en_q && (tmr_cnt_q == '0) && !tmr_done_q && !{restart};",
               f"  {b.ff()} begin",
               f"    if ({b.rc()}) begin tmr_cnt_q <= {W}'h{cnt.fld['reset']:X}; tmr_done_q <= 1'b0; tmr_en_q <= 1'b0; end",
               "    else begin",
               f"      tmr_en_q <= {en.name};",
               f"      if ({restart} || ({en.name} && !tmr_en_q)) begin tmr_cnt_q <= {ld}; tmr_done_q <= 1'b0; end",
               "      else if (tmr_step) begin",
               "        if (tmr_cnt_q == '0) begin",
               f"          if ({oneshot}) tmr_done_q <= 1'b1;",
               f"          else           tmr_cnt_q  <= {ld};",
               "        end else tmr_cnt_q <= tmr_cnt_q - 1'b1;",
               "      end",
               "    end", "  end"]
    b.assign(cnt.name, "tmr_cnt_q", "timer",
             f"down-counter: loads `{load.name}` when `{en.name}` rises or on restart, holds while disabled, counts to 0"
             + (f", prescaled by `{psc.name}`+1" if psc else "")
             + (f"; `{mode.name}`==1 one-shot, else periodic auto-reload" if mode else "; periodic auto-reload"))
    if tick_st is not None:
        b.assign(tick_st.name, cast(tick_st.width, "tmr_tick", 1), "timer", "pulses when counter reaches 0")
    b.info["timer"] = dict(cnt=cnt, en=en, load=load, mode=mode, psc=psc, tick=tick_st)


def rule_pwm(b: Builder):
    pairs = []
    for o in b.outs("ext"):
        m = re.match(r"^pwm(?:_out)?_?(\d+)(?:_o)?$", o.name) or re.match(r"^pwm(\d+)_out(?:_o)?$", o.name)
        if not m or o.width != 1:
            continue
        idx = m.group(1)
        duty = next((s for s in b.ins("cfg") if re.match(rf"^(pwm_?{idx}_duty.*|duty_?{idx})$", s.name)
                     or (s.reg["name"] in (f"pwm{idx}_duty", f"pwm_{idx}_duty", f"duty{idx}"))), None)
        if duty:
            pairs.append((o, duty))
    if not pairs:
        return
    W = min(max(d.width for _, d in pairs), 32)
    period = next((s for s in b.ins("cfg") if has_tok(s.name, "period") and has_tok(s.name, "pwm")), None)
    b.decl.append(f"  logic [{W-1}:0] pwm_cnt_q;  // shared PWM period counter")
    wrap = f"(pwm_cnt_q >= {cast(W, period.name, period.width)})" if period else "1'b0"
    b.body += [f"  {b.ff()} begin", f"    if ({b.rc()}) pwm_cnt_q <= '0;",
               f"    else if ({wrap}) pwm_cnt_q <= '0;", "    else pwm_cnt_q <= pwm_cnt_q + 1'b1;", "  end"]
    for o, d in pairs:
        q = f"{o.name}_q"
        b.decl.append(f"  logic {q};")
        b.body += [f"  {b.ff()} begin", f"    if ({b.rc()}) {q} <= 1'b0;",
                   f"    else {q} <= (pwm_cnt_q < {cast(W, d.name, d.width)});", "  end"]
        b.assign(o.name, q, "pwm", f"registered compare `pwm_cnt_q < {d.name}`"
                 + (f", period `{period.name}`" if period else f", free-running {W}-bit period"))


def rule_port_counter(b: Builder):
    """Port-level counter (no register map): output described as a count + optional en/clr/load."""
    for o in b.outs("ext"):
        if o.width < 2 or not (has_tok(o.name, "count", "cnt", "counter") or
                               has_tok(o.desc, "count", "counter", "cnt")):
            continue
        ins = b.ins("ext")
        en = next((s for s in ins if s.width == 1 and s.name.lower() in ("en", "enable", "ce", "cnt_en", "count_en")), None)
        clr = next((s for s in ins if s.width == 1 and has_tok(s.name, "clr", "clear")), None)
        load = next((s for s in ins if s.width == 1 and has_tok(s.name, "load", "ld")), None)
        din = next((s for s in ins if s.width == o.width and (s.name.lower() in ("d", "din", "data_in", "load_val", "load_value")
                                                               or has_tok(s.name, "din"))), None)
        down = has_tok(o.desc, "down") and not has_tok(o.desc, "up")
        q = f"{o.name}_cnt_q"
        b.decl.append(f"  logic [{o.width-1}:0] {q};")
        L = [f"  {b.ff()} begin", f"    if ({b.rc()}) {q} <= '0;"]
        if clr:
            L.append(f"    else if ({clr.name}) {q} <= '0;")
        if load and din:
            L.append(f"    else if ({load.name}) {q} <= {din.name};")
        step = f"{q} {'-' if down else '+'} 1'b1"
        L.append(f"    else if ({en.name}) {q} <= {step};" if en else f"    else {q} <= {step};")
        L.append("  end")
        b.body += L
        b.assign(o.name, q, "port_counter",
                 f"{o.width}-bit {'down' if down else 'up'}-counter"
                 + (f", enable `{en.name}`" if en else "") + (f", clear `{clr.name}`" if clr else "")
                 + (f", load `{load.name}`/`{din.name}`" if load and din else ""))


def rule_passthru(b: Builder):
    c = b.c
    # RW config -> output port (exact name match, equal width)
    for o in b.outs("ext"):
        src = next((s for s in b.ins("cfg") if names_equal(o.name, s) and s.width == o.width), None) or \
              next((s for s in b.ins("cfg") if names_similar(o.name, s) and s.width == o.width), None)
        if src:
            b.assign(o.name, src.name, "passthru", f"RW register field `{src.name}`")
            if o.width <= c.dw:
                pv = _pat(o.width)
                b.tb += [f"    bus_wr({_A(c, src.reg['offset'])}, {_D(c, pv << src.fld['lsb'])}, e); "
                         f"repeat (2) @(posedge {c.clk});",
                         f"    check(\"{o.name} follows {src.name}\", {c.dw}'({o.name}), {_D(c, pv)}, "
                         f"{_D(c, (1 << o.width) - 1)}, 1);",
                         f"    bus_wr({_A(c, src.reg['offset'])}, {_D(c, _reg_reset(src.reg))}, e);"]
    # input port -> RO field
    for ro in b.outs("ro"):
        src = next((s for s in b.ins("ext") if names_equal(s.name, ro)), None) or \
              next((s for s in b.ins("ext") if names_similar(s.name, ro)), None)
        if src:
            b.assign(ro.name, cast(ro.width, src.name, src.width), "passthru", f"input port `{src.name}`")
            w = min(src.width, ro.width)
            if w <= c.dw:
                pv = _pat(w, 2)
                b.tb += [f"    {src.name} = {src.width}'h{pv:X}; repeat (3) @(posedge {c.clk});",
                         f"    bus_rd({_A(c, ro.reg['offset'])}, d, e); "
                         f"check(\"{ro.reg['name'].upper()}.{ro.fld['name']} reflects {src.name}\", d, "
                         f"{_D(c, pv << ro.fld['lsb'])}, {_D(c, ((1 << w) - 1) << ro.fld['lsb'])}, 1);",
                         f"    {src.name} = '0;"]


def rule_cmd_pulse(b: Builder):
    c = b.c
    for o in b.outs("ext"):
        if o.width != 1:
            continue
        oc = _core(_strip_dir(o.name))
        src = next((s for s in b.ins("wo") if oc and (oc <= _core(s.fld["name"]) or _core(s.fld["name"]) <= oc)), None)
        if not src:
            continue
        q = f"{o.name}_q"
        bit = f"{src.name}[0]" if src.width > 1 else src.name
        b.decl.append(f"  logic {q};")
        b.body += [f"  {b.ff()} begin", f"    if ({b.rc()}) {q} <= 1'b0;",
                   f"    else {q} <= {src.reg['name']}_wr & {bit};", "  end"]
        b.assign(o.name, q, "cmd_pulse", f"1-cycle pulse on write of 1 to `{src.name}`")
        b.tb += [f"    bus_wr({_A(c, src.reg['offset'])}, {_D(c, 1 << src.fld['lsb'])}, e);",
                 f"    // {o.name} pulses for one cycle after the write (not sampled here)"]


EVENT_WORDS = ("evt", "event", "trig", "trigger", "capture", "edge", "wake", "wakeup")


def rule_status_set(b: Builder):
    for st in b.outs("w1c_set"):
        cands = [s for s in b.ins("ext") if (s.width == 1 or s.width == st.width) and names_similar(s.name, st)]
        if not cands:
            # event-like 1-bit input -> event-like status bit
            if has_tok(st.fld["name"], *EVENT_WORDS) or has_tok(st.fld["name"], "ext"):
                cands = [s for s in b.ins("ext") if s.width == 1 and has_tok(s.name, *EVENT_WORDS)]
        if not cands:
            continue
        src = cands[0]
        if has_tok(src.name, *EVENT_WORDS):
            syn = b.sync(src, f"{src.name}")
            prev = f"{src.name}_prev_q"
            b.decl.append(f"  logic {prev};")
            b.body += [f"  {b.ff()} begin", f"    if ({b.rc()}) {prev} <= 1'b0;",
                       f"    else {prev} <= {syn};", "  end"]
            b.assign(st.name, cast(st.width, f"({syn} & ~{prev})", 1), "status_set",
                     f"rising edge of synchronized `{src.name}`")
            b.info.setdefault("events", []).append((src, st))
        else:
            b.assign(st.name, cast(st.width, src.name, src.width), "status_set", f"level of input `{src.name}`")


def is_irq_name(n: str) -> bool:
    n = n.lower()
    if re.search(r"_(en|enable|ack|id|mask|clr|clear|i)$", n):
        return False
    return bool(re.search(r"(^|_)(irq|interrupt|intr|int)(_o|_n|_req)?$", n)) or n.endswith("_irq") or n.startswith("irq_o")


def rule_irq(b: Builder):
    c = b.c
    w1c = b.ins("w1c")
    for o in b.outs("ext"):
        if not is_irq_name(o.name):
            continue
        if not w1c:
            continue
        en_regs = [s for s in b.ins("cfg") if (has_tok(s.name, "intr", "irq", "int", "interrupt")
                                               and has_tok(s.name, "enable", "en", "ena", "mask"))
                   or s.fld["name"] in ("ier",)]
        ie = next((s for s in b.ins("cfg") if s.width == 1 and s.fld["name"] in ("ie", "irq_en", "intr_en", "int_en", "irqen")), None)
        st = w1c[0]
        active_low = o.name.lower().endswith("_n")
        if o.width == 1:
            if len(w1c) == 1 and en_regs and en_regs[0].width == st.width:
                expr, form = f"|({st.name} & {en_regs[0].name})", ("enreg", en_regs[0])
            elif ie is not None:
                expr, form = f"{ie.name} & |{{{', '.join(s.name for s in w1c)}}}", ("ie", ie)
            else:
                expr, form = f"|{{{', '.join(s.name for s in w1c)}}}", ("plain", None)
            if active_low:
                expr = f"~({expr})"
        elif len(w1c) == 1 and st.width == o.width:
            en = en_regs[0] if en_regs and en_regs[0].width == o.width else None
            expr = f"{st.name} & {en.name}" if en else st.name
            form = ("vector", en)
        else:
            continue
        b.assign(o.name, expr, "irq", f"`{expr}`")
        b.info.setdefault("irq", []).append((o, form))
        b.tb_irq.append(f"    check(\"{o.name} idle after reset\", {c.dw}'({o.name}), "
                        f"{_D(c, ((1 << o.width) - 1) if active_low else 0)}, {_D(c, (1 << min(o.width, c.dw)) - 1)}, 1);")


def rule_const_ro(b: Builder):
    for ro in b.outs("ro"):
        if ro.fld["reset"]:
            b.assign(ro.name, f"{ro.width}'h{ro.fld['reset']:X}", "const_ro",
                     "constant = reset value given in the spec (version/ID/capability)")


def rule_core_reg(b: Builder):
    for rb in b.outs("core_rb"):
        wd = rb.name + "_wd"
        wr = f"{rb.reg['name']}_wr"
        q = f"{rb.name}_q"
        b.decl.append(f"  logic {'[%d:0] ' % (rb.width-1) if rb.width > 1 else ''}{q};")
        b.body += [f"  {b.ff()} begin", f"    if ({b.rc()}) {q} <= {rb.width}'h{rb.fld['reset']:X};",
                   f"    else if ({wr}) {q} <= {wd};", "  end"]
        b.assign(rb.name, q, "core_reg", "holds last written value")


def timer_tb(b: Builder):
    t = b.info.get("timer")
    if not t:
        return
    c = b.c
    en, load, cnt, tick, mode = t["en"], t["load"], t["cnt"], t["tick"], t["mode"]
    L = ['    $display("--- Functional: timer ---");']
    ctrl_v = 1 << en.fld["lsb"]
    ie_irq = None
    for o, form in b.info.get("irq", []):
        kind, s = form
        if kind == "ie" and s.reg is en.reg:
            ctrl_v |= 1 << s.fld["lsb"]
            ie_irq = o
        elif kind == "plain":
            ie_irq = o
        elif kind == "enreg" and tick is not None:
            L.append(f"    bus_wr({_A(c, s.reg['offset'])}, {_D(c, _fmask(s.fld))}, e);")
            ie_irq = o
    L += [f"    bus_wr({_A(c, en.reg['offset'])}, '0, e);",
          f"    bus_wr({_A(c, load.reg['offset'])}, {_D(c, 6 << load.fld['lsb'])}, e);",
          f"    repeat (3) @(posedge {c.clk});"]
    if tick is not None:
        L += [f"    bus_wr({_A(c, tick.reg['offset'])}, '1, e);",
              f"    bus_rd({_A(c, tick.reg['offset'])}, d, e); "
              f"check(\"tick status clear while disabled\", d, '0, {_D(c, _fmask(tick.fld))}, 1);"]
    psc_wait = 1
    L += [f"    bus_wr({_A(c, en.reg['offset'])}, {_D(c, ctrl_v)}, e);",
          f"    repeat ({40 * psc_wait}) @(posedge {c.clk});"]
    if tick is not None:
        L.append(f"    bus_rd({_A(c, tick.reg['offset'])}, d, e); "
                 f"check(\"timer expiry sets tick status\", d, {_D(c, 1 << tick.fld['lsb'])}, "
                 f"{_D(c, 1 << tick.fld['lsb'])}, 1);")
        if ie_irq is not None:
            L.append(f"    check(\"{ie_irq.name} asserted on timer expiry\", {c.dw}'({ie_irq.name}), {_D(c, 1)}, {_D(c, 1)}, 1);")
        L += [f"    bus_wr({_A(c, en.reg['offset'])}, '0, e);",
              f"    bus_wr({_A(c, tick.reg['offset'])}, '1, e); repeat (2) @(posedge {c.clk});",
              f"    bus_rd({_A(c, tick.reg['offset'])}, d, e); "
              f"check(\"tick status W1C clear\", d, '0, {_D(c, _fmask(tick.fld))}, 1);"]
        if ie_irq is not None:
            L.append(f"    check(\"{ie_irq.name} deasserted after clear\", {c.dw}'({ie_irq.name}), '0, {_D(c, 1)}, 1);")
    else:
        L.append(f"    bus_wr({_A(c, en.reg['offset'])}, '0, e);")
    if mode is not None:
        L.append(f"    // mode: {mode.name}==1 -> one-shot, otherwise periodic auto-reload")
    b.tb[:0] = L


def events_tb(b: Builder):
    c = b.c
    for src, st in b.info.get("events", []):
        b.tb += [f'    $display("--- Functional: event input {src.name} ---");',
                 f"    bus_wr({_A(c, st.reg['offset'])}, '1, e);",
                 f"    {src.name} = 1'b1; repeat (5) @(posedge {c.clk}); {src.name} = 1'b0;",
                 f"    bus_rd({_A(c, st.reg['offset'])}, d, e); "
                 f"check(\"rising edge of {src.name} sets {st.reg['name'].upper()}.{st.fld['name']}\", d, "
                 f"{_D(c, 1 << st.fld['lsb'])}, {_D(c, 1 << st.fld['lsb'])}, 1);",
                 f"    bus_wr({_A(c, st.reg['offset'])}, '1, e);"]


def rule_sync_unused_async(b: Builder) -> List[str]:
    """Async input pins that no rule consumed still get a 2-FF synchronizer, so the RTL is CDC-clean
    and the functional logic (hand edit or LLM) has a safe, synchronized copy to use.
    Returns the synchronized signal names (not consumed yet -> lint sink)."""
    from .constraints import PAD_IN
    body = "\n".join(b.body)
    spare = []
    for s in b.ins("ext"):
        if re.search(rf"\b{re.escape(s.name)}\b", body):
            continue
        if not (PAD_IN.search(s.name) or re.search(r"\basync", s.desc or "", re.I)):
            continue
        q = b.sync(s, s.name)
        spare.append(q)
        per_bit = " (per-bit: independent pad lines)" if s.width > 1 else ""
        b.notes.append(f"| `{s.name}` | sync_async | 2-FF synchronizer -> `{q}`{per_bit}; "
                       f"no behaviour derived yet - use `{q}`, never the raw pin |")
    return spare


# ===================================================================== entry
RULES = [rule_gpio, rule_timer, rule_pwm, rule_passthru, rule_port_counter, rule_cmd_pulse,
         rule_status_set, rule_irq, rule_const_ro, rule_core_reg]


def generate_core(c):
    """Return (core_sv_text, tb_extra_lines, report_markdown)."""
    from .generate import core_header
    head, _, _ = core_header(c)
    sigs = build_sigs(c)
    b = Builder(c, sigs)
    for r in RULES:
        r(b)
    timer_tb(b)
    events_tb(b)
    synced_spare = rule_sync_unused_async(b)

    todo = []
    tie = []
    for s in sigs:
        if s.dir == "out" and s.name not in b.claimed:
            why = {"ro": "RO status - spec gives no source", "w1c_set": "W1C status - no event source found",
                   "w1s_clr": "W1S hardware clear - none", "ext": "output port - behaviour not derivable"}.get(s.kind, s.kind)
            tie.append(f"  assign {s.name} = '0;  // TODO(spec2rtl): {why}")
            todo.append(f"| `{s.name}` | tie_off | {why} |")
        if s.dir == "inout":
            tie.append(f"  assign {s.name} = 'z;  // TODO(spec2rtl): bidirectional pad, drive enable not derivable")
            todo.append(f"| `{s.name}` | tie_off | inout released (high-Z) |")

    body = "\n".join(b.body)
    used_txt = body
    ins = [s.name for s in sigs if s.dir == "in"]
    unused = [n for n in ins if not re.search(rf"\b{re.escape(n)}\b", used_txt)] + synced_spare
    clk_used = re.search(rf"\b{re.escape(c.clk)}\b", body) is not None
    if not clk_used:
        unused += [c.clk, c.rst]

    L = [head, "",
         f"  // Functional core for {c.m} - generated by the spec2rtl rules engine (no LLM).",
         "  // Each output below is driven by a named rule; see core_report.md.",
         "  // Outputs the spec does not define are tied to 0 and marked TODO(spec2rtl).", ""]
    if b.decl:
        L += b.decl + [""]
    if b.body:
        L += b.body + [""]
    if tie:
        L += ["  // ---- not derivable from the spec: reset-safe defaults ----"] + tie + [""]
    if unused:
        L += ["  /* verilator lint_off UNUSEDSIGNAL */",
              "  logic unused_ok;",
              "  assign unused_ok = ^{" + ", ".join(unused) + "};",
              "  /* verilator lint_on UNUSEDSIGNAL */", ""]
    L.append("endmodule\n")
    core = "\n".join(L)

    outs_total = sum(1 for s in sigs if s.dir == "out")
    impl = len(b.claimed)
    rep = [f"# Core generation report: `{c.m}_core` (rules engine, no LLM)", "",
           f"- Outputs implemented by rules: **{impl} / {outs_total}**",
           f"- Outputs tied off (TODO): **{len(todo)}**",
           f"- Functional TB checks added: **{sum(1 for x in b.tb + b.tb_irq if 'check(' in x)}**", "",
           "| Signal | Rule | Behaviour |", "|---|---|---|"] + b.notes + todo
    if todo:
        rep += ["", "Tied-off signals need either a richer spec (name the port/field after its source, ",
                "or add a functional description) or the LLM engine (`--llm`), or a hand edit of the core."]
    tb = (["    $display(\"--- Functional: restore config, clear sticky status ---\");"]
          + [f"    bus_wr({_A(c, r['offset'])}, {_D(c, _reg_reset(r))}, e);" for r in c.regs
             if any(f["access"] == "RW" for f in r["fields"])]
          + [f"    repeat (2) @(posedge {c.clk});"]
          + [f"    bus_wr({_A(c, r['offset'])}, '1, e);" for r in c.regs
             if any(f["access"] == "W1C" for f in r["fields"])]
          + [f"    repeat (2) @(posedge {c.clk});"]
          + b.tb_irq + b.tb) if (b.tb or b.tb_irq) and c.bus["type"] != "none" else []
    return core, tb, "\n".join(rep) + "\n"
