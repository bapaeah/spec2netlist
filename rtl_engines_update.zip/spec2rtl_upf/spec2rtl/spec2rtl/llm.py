"""LLM engine: write the functional core with a local/remote LLM.

Independent of the rules engine (core_rules.py): the model gets an EMPTY skeleton
(port list only) plus the full spec, never the rules-engine core.  Every answer is
checked (port list -> Verilator lint -> Yosys latch/loop check -> TB simulation) and
the exact errors are fed back for repair, up to `iters` rounds.

Endpoint selection
  Ollama (default)   native /api/chat so num_ctx is honoured (the OpenAI-compatible
                     /v1 endpoint silently ignores it and truncates long specs)
                     host: OLLAMA_HOST or `rtl --models --set-host http://<ip>:11434`
  Other servers      SPEC2RTL_LLM_URL=<.../v1/chat/completions>  (OpenAI, vLLM, LM Studio...)
                     SPEC2RTL_LLM_KEY=<api key>
Model                --model / SPEC2RTL_LLM_MODEL / RTL_MODEL; "auto" picks the best
                     installed coder model for the host GPU/RAM (ollama_models.py)
"""
from __future__ import annotations

import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

RULES = """Hard rules (synthesizable RTL, checked by Verilator -Wall and Yosys):
- Keep the module name and the port list EXACTLY as given (names, directions, widths, order).
- SystemVerilog-2012 synthesizable subset: always_ff, always_comb, assign, localparam, typedef enum.
- No initial blocks, no # delays, no $display/$finish, no real, no tri-state except inout ports.
- No latches: in always_comb give every assigned signal a default at the top.
- One clock domain: every always_ff uses the given clock and the given reset style exactly.
- Never gate or derive clocks; make slower rates with counters + clock-enable strobes.
- Synchronize asynchronous input pins with a 2-flop synchronizer before use.
- Drive every output. Use every input, or sink unused ones in:
    /* verilator lint_off UNUSEDSIGNAL */ logic unused_ok; assign unused_ok = ^{a, b}; /* verilator lint_on UNUSEDSIGNAL */
- Match widths explicitly (sized literals, explicit casts like 8'(x)); no implicit truncation.
- If the spec does not define the behaviour of an output, drive it to 0 and add a // TODO comment.
- Do not use backticks anywhere except `timescale.
- Reply with ONE ```systemverilog code block containing only the module, nothing else."""

PORT_ROLES = """How the core connects to the register block (already written, do not re-implement it):
- <reg>_<field>            input   current value of an RW field written by software
- <reg>_wr                 input   1-cycle strobe when software writes <reg>; WO data inputs are valid in that cycle
- <reg>_rd                 input   1-cycle strobe when software reads <reg> (use for pop / read-to-clear)
- RO field                 output  value software reads from the register
- W1C field  <name>        input   current sticky bit (software clears by writing 1)
             <name>_set    output  drive 1 for one cycle to set the sticky bit on a hardware event
- W1S field  <name>_clr    output  drive 1 to clear the bit from hardware
- CORE field <name>_wd     input   byte-merged write data, valid with <reg>_wr; <name> output = value read back
All other ports are the external pins of the IP."""


# ----------------------------------------------------------------- endpoint
def _ollama_models():
    """Repo-root ollama_models.py (GPU/RAM-based model choice, remote OLLAMA_HOST)."""
    root = Path(__file__).resolve().parents[3]
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    try:
        import ollama_models as OM  # noqa: WPS433
        return OM
    except Exception:  # noqa: BLE001
        return None


class LLMUnavailable(RuntimeError):
    pass


def _endpoint():
    OM = _ollama_models()
    url = os.environ.get("SPEC2RTL_LLM_URL", "").strip()
    host = (OM.ollama_host() if OM else os.environ.get("OLLAMA_HOST", "")) or "http://localhost:11434"
    if not host.startswith("http"):
        host = "http://" + host
    if url and "11434" not in url:
        return "openai", url, OM, host
    return "ollama", host.rstrip("/"), OM, host


def check_available(timeout=5):
    """Fail fast with a clear message instead of a 15-minute hang."""
    kind, url, _, host = _endpoint()
    probe = f"{url}/api/tags" if kind == "ollama" else url.rsplit("/chat/completions", 1)[0] + "/models"
    try:
        req = urllib.request.Request(probe)
        if kind == "openai" and os.environ.get("SPEC2RTL_LLM_KEY"):
            req.add_header("Authorization", f"Bearer {os.environ['SPEC2RTL_LLM_KEY']}")
        urllib.request.urlopen(req, timeout=timeout).read()
    except Exception as e:  # noqa: BLE001
        raise LLMUnavailable(
            f"LLM endpoint not reachable ({probe}): {e}\n"
            "  Start Ollama (`ollama serve`), or point to a remote one with\n"
            "  `rtl --models --set-host http://<ip>:11434`, or set SPEC2RTL_LLM_URL.\n"
            "  To generate without an LLM, run the same command without --llm.") from None


def _pick_model(requested, prompt_chars):
    kind, _, OM, _ = _endpoint()
    req = requested or os.environ.get("SPEC2RTL_LLM_MODEL") or "auto"
    need = int(prompt_chars / 3.2) + 6144          # prompt tokens + answer + repair history
    if kind != "ollama":
        return (req if req != "auto" else "qwen2.5-coder:7b"), need
    if OM:
        model, ctx = OM.select("quality", req, quiet=False)
    else:
        model, ctx = (req if req != "auto" else "qwen2.5-coder:7b"), 8192
    return model, min(max(ctx, need), 32768)


def chat(messages, model, num_ctx, temperature=0.1, max_tokens=6144):
    kind, url, OM, host = _endpoint()
    if kind == "ollama":
        payload = {"model": model, "messages": messages, "stream": False,
                   "options": {"temperature": temperature, "num_ctx": num_ctx, "num_predict": max_tokens,
                               "repeat_penalty": 1.15, "repeat_last_n": 256}}
        target = f"{url}/api/chat"
    else:
        payload = {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
        target = url
    headers = {"Content-Type": "application/json"}
    key = os.environ.get("SPEC2RTL_LLM_KEY", "")
    if kind == "openai" and key:
        headers["Authorization"] = f"Bearer {key}"
    req = urllib.request.Request(target, json.dumps(payload).encode(), headers)
    try:
        with urllib.request.urlopen(req, timeout=int(os.environ.get("SPEC2RTL_LLM_TIMEOUT", "900"))) as r:
            data = json.load(r)
    except urllib.error.HTTPError as e:
        msg = e.read().decode(errors="ignore")
        smaller = OM.next_smaller(model) if (OM and kind == "ollama" and
                                              re.search(r"memory|alloc|CUDA|OOM", msg, re.I)) else None
        if smaller:
            print(f"[llm] {model} ran out of memory on {host}; retrying with {smaller}")
            return chat(messages, smaller, min(num_ctx, 16384), temperature, max_tokens)
        if e.code == 404 or "not found" in msg:
            raise LLMUnavailable(f"model '{model}' is not installed on {host} (see `rtl --models`)") from None
        raise LLMUnavailable(f"LLM HTTP {e.code}: {msg[:300]}") from None
    except (TimeoutError, OSError) as e:
        if isinstance(e, urllib.error.URLError) and not isinstance(getattr(e, "reason", None), TimeoutError):
            raise LLMUnavailable(f"cannot reach LLM at {target}: {e}") from None
        raise LLMUnavailable(
            f"'{model}' did not answer within {os.environ.get('SPEC2RTL_LLM_TIMEOUT', '900')}s on {host}.\n"
            "  The model is probably too large for this machine's GPU memory (running on CPU).\n"
            "  Options: a smaller --model, a GPU host via `rtl --models --set-host http://<ip>:11434`,\n"
            "  SPEC2RTL_LLM_TIMEOUT=3600, or the rules engine (drop --llm).") from None
    if kind == "ollama":
        txt, truncated = data["message"]["content"], data.get("done_reason") == "length"
    else:
        ch = data["choices"][0]
        txt, truncated = ch["message"]["content"], ch.get("finish_reason") == "length"
    return (txt + "\n<<TRUNCATED>>") if truncated else txt


# ----------------------------------------------------------------- prompt
def skeleton(c) -> str:
    """Empty core: exact port list, no behaviour. Never the rules-engine output."""
    from .generate import core_header
    head, _, _ = core_header(c)
    return head + "\n\n  // TODO: implement the functional behaviour described in the specification.\n\nendmodule\n"


def _regmap_text(c) -> str:
    L = []
    for r in c.regs:
        L.append(f"{r['name'].upper()} @0x{r['offset']:X} ({r['access']}, reset 0x{r['reset']:X}) {r.get('desc', '')[:160]}")
        for f in r["fields"]:
            rng = f"[{f['msb']}:{f['lsb']}]" if f["msb"] != f["lsb"] else f"[{f['lsb']}]"
            L.append(f"    {f['name']}{rng} {f['access']} reset=0x{f['reset']:X} {f.get('desc', '')[:160]}")
    return "\n".join(L) or "(no register map)"


def _ports_text(c) -> str:
    return "\n".join(f"  {p['dir']:6} [{p['width']}] {p['name']:24} {p.get('desc', '')[:120]}"
                     for p in c.spec["ports"]) or "(none)"


def build_messages(c, spec):
    reset = spec.get("reset") or {}
    clk = spec.get("clock") or {}
    desc = (spec.get("functional_description") or "").strip()
    if len(desc) > 16000:
        desc = desc[:16000] + "\n...(truncated)"
    user = (f"Write the functional core `{c.m}_core` for the IP `{c.m}`.\n\n"
            f"Clock: {c.clk} ({clk.get('freq_mhz', '?')} MHz)\n"
            f"Reset: {c.rst}, active-{'low' if c.rst_low else 'high'}, {'asynchronous' if c.rst_async else 'synchronous'}"
            f"  -> use exactly: {c.ff()} with reset condition ({c.rst_cond()})\n\n"
            f"IP top-level pins (from the spec):\n{_ports_text(c)}\n\n"
            f"Register map:\n{_regmap_text(c)}\n\n"
            f"{PORT_ROLES}\n\n"
            f"Special cells (already provided in {c.m}_cells.sv - instantiate them, never write your own):\n"
            f"{__import__('spec2rtl.cells', fromlist=['llm_reference']).llm_reference(c.m)}\n"
            f"- Every asynchronous input pin goes through {c.m}_sync before use, e.g.\n"
            f"    logic rx_s; {c.m}_sync #(.WIDTH(1), .STAGES(2)) u_rx_sync (.clk({c.clk}), .rst_n({c.rst if c.rst_low else '~' + c.rst}), .d(rx), .q(rx_s));\n"
            f"- The reset input is already synchronized in the top level; do not add a reset synchronizer.\n"
            f"- Clock gating / clock muxing only through {c.m}_clk_gate / {c.m}_clk_mux.\n\n"
            f"Functional description from the specification:\n{desc or '(none given - infer from names)'}\n\n"
            f"Complete this module (keep the header exactly):\n```systemverilog\n{skeleton(c)}```")
    return [{"role": "system", "content": "You are a senior ASIC RTL design engineer.\n" + RULES},
            {"role": "user", "content": user}]


def extract_code(txt: str) -> str:
    txt = re.sub(r"<think>.*?</think>", "", txt.replace("<<TRUNCATED>>", ""), flags=re.S)
    blocks = re.findall(r"```(?:systemverilog|verilog|sv|v)?[ \t]*\n(.*?)```", txt, re.S | re.I)
    if blocks:
        code = max(blocks, key=len)
    else:   # unclosed fence (answer cut off) or no fence at all
        m = re.search(r"```[a-zA-Z]*[ \t]*\n(.*)", txt, re.S)
        code = m.group(1) if m else txt
    code = "\n".join(ln for ln in code.splitlines() if not ln.strip().startswith("```"))
    out = []
    for line in code.strip().splitlines():
        s = line.strip()
        if s.startswith(("//", "/*", "*")) or ("//" in line and "`" in line.split("//", 1)[1]):
            head, sep, cm = line.partition("//")
            line = head + sep + cm.replace("`", "'") if sep else line.replace("`", "'")
        out.append(line)
    code = "\n".join(out) + "\n"
    if "`timescale" not in code:
        code = "`timescale 1ns/1ps\n" + code
    return code


def port_check(c, code: str):
    """Static check before running tools: module name + exact port names."""
    from .generate import core_ports
    m = re.search(rf"\bmodule\s+{re.escape(c.m)}_core\b(.*?)\);", code, re.S)
    if not m:
        return False, f"module `{c.m}_core` not found - keep the module name exactly."
    hdr = re.sub(r"//.*", "", m.group(1))
    got = set(re.findall(r"\b(?:input|output|inout)\s+(?:wire\s+|logic\s+|reg\s+)?(?:signed\s+)?(?:\[[^\]]+\]\s*)?(\w+)", hdr))
    ext, ri = core_ports(c)
    want = {c.clk, c.rst} | {p["name"] for p in ext} | {n for _, _, n, _ in ri}
    miss, extra = sorted(want - got), sorted(got - want)
    if miss or extra:
        return False, ("Port list changed. Keep the header exactly as given.\n"
                       + (f"Missing ports: {', '.join(miss)}\n" if miss else "")
                       + (f"Unexpected ports: {', '.join(extra)}\n" if extra else ""))
    return True, ""


def _degenerate(code: str) -> bool:
    """Repetition loop (small models): many near-identical lines or no endmodule."""
    if "endmodule" not in code:
        return True
    stems = [re.sub(r"\d+|_next|_reg|\s+", "", ln) for ln in code.splitlines() if ln.strip()]
    return bool(stems) and max(stems.count(x) for x in set(stems)) > 25


def wrapper_check(c, code: str):
    """Reject hand-written synchronizer flops on input pins: they must use the <ip>_sync wrapper."""
    from .constraints import SYNC_LHS
    from .generate import core_ports
    ext, _ = core_ports(c)
    pins = {p["name"] for p in ext if p["dir"] == "input"}
    raw = sorted({src for _, src in SYNC_LHS.findall(code) if src in pins})
    if raw:
        return False, (f"Hand-written synchronizer flops found for: {', '.join(raw)}. Replace them with "
                       f"{c.m}_sync instances (see the special cells list) so they can be mapped to library cells.")
    return True, ""


def generate_core(c, spec, verify_fn, iters=4, model=None):
    """Returns dict(code, ok, iterations, model, history). verify_fn(code) -> (ok, log)."""
    check_available()
    msgs = build_messages(c, spec)
    model, num_ctx = _pick_model(model, sum(len(m["content"]) for m in msgs))
    print(f"[llm] model={model} num_ctx={num_ctx} max_repair_rounds={iters}")
    code, history = skeleton(c), []
    for i in range(1, iters + 1):
        t0 = time.time()
        raw = chat(msgs, model, num_ctx)
        code = extract_code(raw)
        if raw.endswith("<<TRUNCATED>>") or _degenerate(code):
            ok, log = False, ("Your answer was cut off / repeated the same lines over and over. "
                              "Write a SHORT module: only the registers you need, no repeated declarations, "
                              "and end with endmodule.")
        else:
            ok, log = port_check(c, code)
            if ok:
                ok, log = wrapper_check(c, code)
        if ok:
            ok, log = verify_fn(code)
        dt = time.time() - t0
        history.append({"iteration": i, "ok": ok, "seconds": round(dt, 1), "log": log[-3000:]})
        print(f"[llm] round {i}: {'CLEAN (lint+synth+sim)' if ok else 'FAILED - feeding errors back'} ({dt:.0f}s)")
        if ok:
            return {"code": code, "ok": True, "iterations": i, "model": model, "history": history}
        # keep the conversation short: original task + latest attempt + its errors
        msgs = msgs[:2] + [{"role": "assistant", "content": f"```systemverilog\n{code}```"},
                           {"role": "user", "content": f"The tools reported these errors:\n{log[-6000:]}\n\n"
                                                       "Fix every error and resend the complete module."}]
    print("[llm] did not reach a clean result; last attempt kept for manual fixing")
    return {"code": code, "ok": False, "iterations": iters, "model": model, "history": history}
