"""Map the special-cell wrappers (<ip>_cells.sv) onto a real standard-cell library.

Input : a std-cell path (directory or files) containing Liberty (.lib / .lib.gz) and, for
        simulation, the cells' Verilog models (.v / .sv).
Output: <ip>/tech/<tech>/<ip>_cells_<tech>.sv  same module names/ports, bodies = library cells
        <ip>/files_<tech>.f                    file list with the tech cells file swapped in
        <ip>/tech/<tech>/models.f               Verilog models of the used cells (simulation / GLS)
        <ip>/tech/<tech>/liberty.f              Liberty files of the used cells (synthesis / STA)
        <ip>/tech/<tech>/cell_stubs.sv          port-only stubs (lint without vendor models)
        <ip>/tech/<tech>/dont_touch.tcl         set_dont_touch on every mapped cell instance
        <ip>/tech/<tech>/techmap_report.md      what was picked, from where, and what is missing

Cell choice is by FUNCTION read from Liberty (not by name), so it works for any foundry library:
  sync2/sync3   dedicated synchronizer cells (name contains "sync" + clock/data/reset/output pins)
  icg           cells with clock_gating_integrated_cell (posedge types)
  flop_r/flop_s plain D flops with async clear / preset (no scan, no enable), posedge
  flop_r_neg    same, negative-edge clock
  latch_low/hi  D latches (ICG fallback)
  clkbuf/clkinv buffers/inverters ("clk"/"ck" in the name preferred), and2/or2 gates
Smallest-area cell wins in each class; dont_use cells are skipped. A JSON override file can
force any choice:  {"flop_r": {"cell": "DFFRQ_X2", "pins": {"clk": "CK", "d": "D", "rst": "RN", "q": "Q"}}}
"""
from __future__ import annotations

import gzip
import itertools
import json
import re
from pathlib import Path
from typing import Dict, List, Optional

from .cells import common_modules, header, generic_tech_modules

KEEP = '(* keep = 1, dont_touch = "true" *)'


# ======================================================================= Liberty
def _read(p: Path) -> str:
    raw = gzip.open(p, "rt", errors="ignore").read() if p.suffix == ".gz" else p.read_text(errors="ignore")
    raw = re.sub(r"/\*.*?\*/", "", raw, flags=re.S)
    return raw.replace("\\\n", " ")


def _match_brace(text: str, i: int) -> int:
    """index of the '}' matching the '{' at text[i]"""
    depth = 0
    for m in re.compile(r"[{}]").finditer(text, i):
        depth += 1 if m.group() == "{" else -1
        if depth == 0:
            return m.start()
    return len(text) - 1


STMT = re.compile(r'\s*([A-Za-z_][\w.]*)\s*(?:\(\s*([^)]*?)\s*\))?\s*([:{;])', re.S)


def _children(body: str, keep_groups=("pin", "ff", "latch", "statetable", "ff_bank", "bus", "bundle")):
    """Top-level statements of a Liberty group body -> (attrs dict, [(group, args, body)])."""
    attrs, groups, i, n = {}, [], 0, len(body)
    while i < n:
        m = STMT.match(body, i)
        if not m:
            j = body.find(";", i)
            if j < 0:
                break
            i = j + 1
            continue
        name, args, tok = m.group(1), m.group(2), m.group(3)
        if tok == ":":
            j = body.find(";", m.end())
            j = n if j < 0 else j
            attrs[name] = body[m.end():j].strip().strip('"')
            i = j + 1
        elif tok == "{":
            k = _match_brace(body, m.end() - 1)
            if name in keep_groups:
                groups.append((name, (args or "").strip().strip('"'), body[m.end():k]))
            i = k + 1
        else:                                   # complex attribute name(args);
            attrs.setdefault(name, args)
            i = m.end()
    return attrs, groups


def parse_liberty(path: Path) -> Dict[str, dict]:
    text = _read(path)
    cells = {}
    for m in re.finditer(r'\bcell\s*\(\s*"?([\w$\[\]]+)"?\s*\)\s*\{', text):
        k = _match_brace(text, m.end() - 1)
        attrs, groups = _children(text[m.end():k])
        cell = {"name": m.group(1), "lib": str(path), "area": float(attrs.get("area", "0") or 0),
                "dont_use": attrs.get("dont_use", "false").lower() == "true",
                "icg": attrs.get("clock_gating_integrated_cell"), "pins": {}, "ff": None, "latch": None,
                "seq_other": False}
        for g, args, body in groups:
            a, _ = _children(body, ())
            if g == "pin":
                for pn in [x.strip().strip('"') for x in args.split(",")]:
                    cell["pins"][pn] = a
            elif g == "ff":
                cell["ff"] = {"vars": [x.strip() for x in args.split(",")], **a}
            elif g == "latch":
                cell["latch"] = {"vars": [x.strip() for x in args.split(",")], **a}
            else:
                cell["seq_other"] = True
        cells[cell["name"]] = cell
    return cells


# ======================================================================= boolean functions
def _tokens(expr: str):
    return re.findall(r"[A-Za-z_][\w\[\]]*|[01]|[!'*&+|^()]", expr)


def eval_func(expr: str, env: Dict[str, int]) -> int:
    toks, pos = _tokens(expr), [0]

    def peek():
        return toks[pos[0]] if pos[0] < len(toks) else None

    def take():
        pos[0] += 1
        return toks[pos[0] - 1]

    def primary():
        t = take()
        if t == "(":
            v = orx()
            take()
        elif t == "!":
            v = 1 - primary()
        elif t in ("0", "1"):
            v = int(t)
        else:
            v = env[t]
        while peek() == "'":
            take()
            v = 1 - v
        return v

    def andx():
        v = primary()
        while peek() is not None and (peek() in ("*", "&") or re.match(r"[A-Za-z_(!01]", peek())):
            if peek() in ("*", "&"):
                take()
            v &= primary()
        return v

    def xorx():
        v = andx()
        while peek() == "^":
            take()
            v ^= andx()
        return v

    def orx():
        v = xorx()
        while peek() in ("+", "|"):
            take()
            v |= xorx()
        return v

    return orx()


def _truth(expr, ins):
    return tuple(eval_func(expr, dict(zip(ins, bits))) for bits in itertools.product((0, 1), repeat=len(ins)))


def _single_pin(expr: str):
    """'CK' -> ('CK', False);  '!RN' / "RN'" -> ('RN', True); anything else -> None"""
    e = (expr or "").strip().strip('"').replace(" ", "")
    m = re.fullmatch(r"!?\(?([A-Za-z_]\w*)\)?'?", e)
    if not m:
        return None
    return m.group(1), e.startswith("!") or e.endswith("'")


# ======================================================================= classification
def classify(cells: Dict[str, dict]) -> Dict[str, List[dict]]:
    out: Dict[str, List[dict]] = {}

    def add(kind, cell, pins, note=""):
        out.setdefault(kind, []).append({"cell": cell["name"], "pins": pins, "area": cell["area"],
                                         "lib": cell["lib"], "note": note})

    for c in cells.values():
        if c["dont_use"]:
            continue
        P = c["pins"]
        ins = [p for p, a in P.items() if a.get("direction") == "input"]
        outs = [p for p, a in P.items() if a.get("direction") == "output"]
        name = c["name"].lower()
        # --- integrated clock gate
        if c["icg"] and "posedge" in c["icg"]:
            role = {k: next((p for p, a in P.items() if a.get(f"clock_gate_{k}_pin", "").lower() == "true"), None)
                    for k in ("clock", "enable", "test", "out")}
            if role["clock"] and role["enable"] and role["out"]:
                add("icg", c, {"clk": role["clock"], "en": role["enable"], "te": role["test"], "gclk": role["out"]},
                    c["icg"])
            continue
        # --- dedicated synchronizer
        if "sync" in name and len(outs) >= 1:
            clk = next((p for p, a in P.items() if a.get("clock", "").lower() == "true"), None)
            rst = next((p for p in ins if re.search(r"^(rn|rb|r_n|rst_?n|reset_?b|resetn|cdn|clrn|clr_n)$", p, re.I)), None)
            data = [p for p in ins if p not in (clk, rst) and not re.search(r"^(s[ie]|te|scan|se)", p, re.I)]
            if clk and len(data) == 1 and len([p for p in ins if p not in (clk, rst)]) == 1:
                q = next((p for p in outs if re.fullmatch(r"q|z|o|y", p, re.I)), outs[0])
                st = 3 if re.search(r"sync_?3|3_?sync|sync.*x3", name) else 2
                rpol = True if rst else None
                if c["ff"] and c["ff"].get("clear"):
                    sp = _single_pin(c["ff"]["clear"])
                    if sp:
                        rst, rpol = sp[0], sp[1]
                add(f"sync{st}", c, {"clk": clk, "d": data[0], "rst": rst, "rst_low": rpol, "q": q},
                    "dedicated synchronizer (stage count from name - verify)")
            continue
        # --- flops
        if c["ff"]:
            ff = c["ff"]
            ns, ck = _single_pin(ff.get("next_state")), _single_pin(ff.get("clocked_on"))
            if not ns or ns[1] or not ck:
                continue
            clr = _single_pin(ff.get("clear")) if ff.get("clear") else None
            pre = _single_pin(ff.get("preset")) if ff.get("preset") else None
            if (ff.get("clear") and not clr) or (ff.get("preset") and not pre) or (clr and pre):
                continue
            used = {ns[0], ck[0]} | ({clr[0]} if clr else set()) | ({pre[0]} if pre else set())
            if set(ins) != used:
                continue                        # scan / enable / extra pins
            iq = ff["vars"][0]
            q = next((p for p in outs if P[p].get("function", "").replace(" ", "") in (iq, f"({iq})")), None)
            if not q:
                continue
            pins = {"clk": ck[0], "d": ns[0], "q": q, "other_outs": [p for p in outs if p != q]}
            edge = "_neg" if ck[1] else ""
            if clr:
                add(f"flop_r{edge}", c, {**pins, "rst": clr[0], "rst_low": clr[1]})
            elif pre:
                add(f"flop_s{edge}", c, {**pins, "rst": pre[0], "rst_low": pre[1]})
            continue
        if c["latch"]:
            la = c["latch"]
            en, di = _single_pin(la.get("enable")), _single_pin(la.get("data_in"))
            if en and di and not di[1] and set(ins) == {en[0], di[0]} and not la.get("clear") and not la.get("preset"):
                iq = la["vars"][0]
                q = next((p for p in outs if P[p].get("function", "").replace(" ", "") in (iq, f"({iq})")), None)
                if q:
                    add("latch_low" if en[1] else "latch_high", c,
                        {"en": en[0], "d": di[0], "q": q, "other_outs": [p for p in outs if p != q]})
            continue
        if c["seq_other"] or len(outs) != 1 or "function" not in P[outs[0]]:
            continue
        # --- combinational
        f, o = P[outs[0]]["function"], outs[0]
        try:
            if len(ins) == 1:
                tt = _truth(f, ins)
                isclk = bool(re.search(r"clk|ck", name))
                if tt == (0, 1):
                    add("clkbuf" if isclk else "buf", c, {"a": ins[0], "y": o})
                elif tt == (1, 0):
                    add("clkinv" if isclk else "inv", c, {"a": ins[0], "y": o})
            elif len(ins) == 2:
                tt = _truth(f, ins)
                if tt == (0, 0, 0, 1):
                    add("and2", c, {"a": ins[0], "b": ins[1], "y": o})
                elif tt == (0, 1, 1, 1):
                    add("or2", c, {"a": ins[0], "b": ins[1], "y": o})
        except (KeyError, IndexError):
            continue
    for k in out:
        out[k].sort(key=lambda x: (x["area"] if x["area"] > 0 else 1e9,
                                   0 if re.search(r"(_x1|_1|x1)$", x["cell"], re.I) else 1, x["cell"]))
    return out


def select(classes: Dict[str, List[dict]], override: Optional[dict], cells: Dict[str, dict]):
    sel, src, warn = {}, {}, []
    for k, v in classes.items():
        sel[k], src[k] = v[0], "auto"
    for alias, fallback in (("clkbuf", "buf"), ("clkinv", "inv")):
        if alias not in sel and fallback in sel:
            sel[alias], src[alias] = sel[fallback], f"auto ({fallback}: no clock-specific cell)"
    for k, v in (override or {}).items():
        if k.startswith("_"):
            continue
        if v.get("cell") not in cells:
            warn.append(f"override {k}: cell {v.get('cell')} not found in the given Liberty - ignored")
            continue
        base = classes.get(k, [{}])[0] if k in classes else {}
        pins = {**base.get("pins", {}), **v.get("pins", {})}
        sel[k] = {"cell": v["cell"], "pins": pins, "area": cells[v["cell"]]["area"], "lib": cells[v["cell"]]["lib"],
                  "note": "override"}
        src[k] = "override"
    return sel, src, warn


# ======================================================================= tech file writer
def _conn(pins: Dict[str, Optional[str]], extra_out=()) -> str:
    items = [f".{p}({s})" for p, s in pins.items() if p]
    items += [f".{p}()" for p in extra_out]
    return ", ".join(items)


def _ff(sel, kind, clk, d, rst_n, q, name):
    c = sel[kind]
    P = c["pins"]
    rst = rst_n if P.get("rst_low", True) else f"~{rst_n}"
    return (f"{KEEP} {c['cell']} {name} ("
            + _conn({P["clk"]: clk, P["d"]: d, P["rst"]: rst, P["q"]: q}, P.get("other_outs", [])) + ");")


def _gate(sel, kind, ins: Dict[str, str], y: str, name: str):
    c = sel[kind]
    P = c["pins"]
    m = {P[k]: v for k, v in ins.items()}
    m[P["y"]] = y
    return f"{KEEP} {c['cell']} {name} (" + _conn(m) + ");"


def tech_cells_text(p: str, tech: str, sel: dict) -> (str, List[str], List[str]):
    """Returns (sv_text, used_cells, notes)."""
    used, notes = [], []
    if "flop_r" not in sel:
        raise SystemExit("No plain async-clear D flop found in the library (needed for synchronizers). "
                         "Give one with an override: {\"flop_r\": {\"cell\": ..., \"pins\": {...}}}")
    used.append(sel["flop_r"]["cell"])
    gen = generic_tech_modules(p)

    def generic_body(mod):
        m = re.search(rf"\nmodule {p}_{mod}\b.*?\nendmodule\n", gen, re.S)
        return m.group(0)

    L = [header(p, f"standard cells: {tech}"), "/* verilator lint_off PINCONNECTEMPTY */",
         f"// Generated by techmap_cells.py - cells chosen from the Liberty by function. See techmap_report.md.", ""]

    # ---- sync
    s2 = sel.get("sync2")
    s3 = sel.get("sync3")
    fs = sel.get("flop_s")
    L += [f"module {p}_sync #(", "  parameter int             WIDTH     = 1,", "  parameter int             STAGES    = 2,",
          "  parameter logic [WIDTH-1:0] RESET_VAL = '0", ") (", "  input  logic             clk,",
          "  input  logic             rst_n,", "  input  logic [WIDTH-1:0] d,", "  output logic [WIDTH-1:0] q", ");",
          "  for (genvar b = 0; b < WIDTH; b++) begin : g_bit"]
    branch = "if"
    for st, sc in ((2, s2), (3, s3)):
        if sc:
            used.append(sc["cell"])
            P = sc["pins"]
            rst = "rst_n" if P.get("rst_low", True) else "~rst_n"
            conn = {P["clk"]: "clk", P["d"]: "d[b]", P["q"]: "q[b]"}
            if P.get("rst"):
                conn[P["rst"]] = rst
            L += [f"    {branch} (STAGES == {st} && RESET_VAL[b] == 1'b0) begin : g_sync{st}",
                  f"      {KEEP} {sc['cell']} u_cell_sync (" + _conn(conn) + ");", "    end"]
            branch = "else if"
            notes.append(f"{p}_sync STAGES={st}, reset 0: dedicated synchronizer {sc['cell']}")
    wrap = branch != "if"            # an if/else-if chain exists -> need an else block
    L += (["    else begin : g_ff"] if wrap else []) + [
          "      logic [STAGES:0] s;",
          "      for (genvar i = 0; i < STAGES; i++) begin : g_stage"]
    if fs:
        used.append(fs["cell"])
        L += ["        if (RESET_VAL[b]) begin : g_set",
              "          " + _ff(sel, "flop_s", "clk", "s[i]", "rst_n", "s[i+1]", "u_cell_ff"),
              "        end else begin : g_clr",
              "          " + _ff(sel, "flop_r", "clk", "s[i]", "rst_n", "s[i+1]", "u_cell_ff"),
              "        end"]
        L += ["      end", "      assign s[0] = d[b];", "      assign q[b] = s[STAGES];"]
    else:
        notes.append("no async-preset flop: reset-to-1 synchronizer bits store inverted data in clear flops")
        L += ["        " + _ff(sel, "flop_r", "clk", "s[i]", "rst_n", "s[i+1]", "u_cell_ff"),
              "      end",
              "      assign s[0] = RESET_VAL[b] ? ~d[b] : d[b];   // stored inverted when the reset value is 1",
              "      assign q[b] = RESET_VAL[b] ? ~s[STAGES] : s[STAGES];"]
    L += (["    end"] if wrap else []) + ["  end", "endmodule", ""]
    if not (s2 or s3):
        notes.append(f"{p}_sync: no dedicated synchronizer cell - built from {sel['flop_r']['cell']} flops (dont_touch)")

    # ---- rst_sync
    L += [f"module {p}_rst_sync #(", "  parameter int STAGES = 2", ") (", "  input  logic clk,",
          "  input  logic rst_n_in,", "  output logic rst_n_out", ");"]
    if s2 and s2["pins"].get("rst"):
        P = s2["pins"]
        L += ["  if (STAGES == 2) begin : g_sync2",
              f"    {KEEP} {s2['cell']} u_cell_sync (" + _conn({P['clk']: 'clk', P['d']: "1'b1",
                                                                P['rst']: 'rst_n_in' if P.get('rst_low', True) else '~rst_n_in',
                                                                P['q']: 'rst_n_out'}) + ");",
              "  end else begin : g_ff"]
        ind = "    "
    else:
        ind = "  "
    L += [f"{ind}logic [STAGES:0] s;", f"{ind}assign s[0] = 1'b1;",
          f"{ind}for (genvar i = 0; i < STAGES; i++) begin : g_stage",
          f"{ind}  " + _ff(sel, "flop_r", "clk", "s[i]", "rst_n_in", "s[i+1]", "u_cell_ff"),
          f"{ind}end", f"{ind}assign rst_n_out = s[STAGES];"]
    if ind == "    ":
        L.append("  end")
    L += ["endmodule", ""]

    # ---- clk_gate
    L += [f"module {p}_clk_gate (", "  input  logic clk,", "  input  logic en,", "  input  logic test_en,",
          "  output logic gclk", ");"]
    icg = sel.get("icg")
    if icg:
        used.append(icg["cell"])
        P = icg["pins"]
        conn = {P["clk"]: "clk", P["gclk"]: "gclk"}
        if P.get("te"):
            conn[P["en"]], conn[P["te"]] = "en", "test_en"
        else:
            L.append("  logic en_or_te;  assign en_or_te = en | test_en;")
            conn[P["en"]] = "en_or_te"
        L.append(f"  {KEEP} {icg['cell']} u_cell_icg (" + _conn(conn) + ");")
        notes.append(f"{p}_clk_gate: integrated clock gate {icg['cell']} ({icg.get('note')})")
    elif ("latch_low" in sel or ("latch_high" in sel and "clkinv" in sel)) and "and2" in sel:
        L.append("  logic en_l, en_or_te;  assign en_or_te = en | test_en;")
        if "latch_low" in sel:
            la = sel["latch_low"]
            g = "clk"
        else:
            la = sel["latch_high"]
            L += ["  logic clk_n;", "  " + _gate(sel, "clkinv", {"a": "clk"}, "clk_n", "u_cell_ckinv")]
            used.append(sel["clkinv"]["cell"])
            g = "clk_n"
        P = la["pins"]
        used += [la["cell"], sel["and2"]["cell"]]
        L += [f"  {KEEP} {la['cell']} u_cell_latch (" + _conn({P['en']: g, P['d']: 'en_or_te', P['q']: 'en_l'},
                                                             P.get("other_outs", [])) + ");",
              "  " + _gate(sel, "and2", {"a": "clk", "b": "en_l"}, "gclk", "u_cell_and")]
        notes.append(f"{p}_clk_gate: NO integrated clock gate in library - built from latch {la['cell']} + "
                     f"{sel['and2']['cell']} (dont_touch). Prefer a real ICG cell (override 'icg').")
    else:
        L += [generic_body("clk_gate").split(");", 1)[1].rsplit("endmodule", 1)[0].rstrip()]
        notes.append(f"{p}_clk_gate: no ICG / latch+AND cells found - generic latch model kept (needs manual mapping)")
    L += ["endmodule", ""]

    # ---- clk_mux
    L += [f"module {p}_clk_mux (", "  input  logic clk0,", "  input  logic clk1,", "  input  logic rst_n,",
          "  input  logic sel,", "  output logic clk_out", ");",
          "  logic s0_meta_q, s0_q, s1_meta_q, s1_q, d0, d1, g0, g1;",
          "  assign d0 = ~sel & ~s1_q;", "  assign d1 =  sel & ~s0_q;",
          "  " + _ff(sel, "flop_r", "clk0", "d0", "rst_n", "s0_meta_q", "u_cell_s0m"),
          "  " + _ff(sel, "flop_r", "clk1", "d1", "rst_n", "s1_meta_q", "u_cell_s1m")]
    if "flop_r_neg" in sel:
        used.append(sel["flop_r_neg"]["cell"])
        L += ["  " + _ff(sel, "flop_r_neg", "clk0", "s0_meta_q", "rst_n", "s0_q", "u_cell_s0"),
              "  " + _ff(sel, "flop_r_neg", "clk1", "s1_meta_q", "rst_n", "s1_q", "u_cell_s1")]
    elif "clkinv" in sel:
        used.append(sel["clkinv"]["cell"])
        L += ["  logic clk0_n, clk1_n;",
              "  " + _gate(sel, "clkinv", {"a": "clk0"}, "clk0_n", "u_cell_ckinv0"),
              "  " + _gate(sel, "clkinv", {"a": "clk1"}, "clk1_n", "u_cell_ckinv1"),
              "  " + _ff(sel, "flop_r", "clk0_n", "s0_meta_q", "rst_n", "s0_q", "u_cell_s0"),
              "  " + _ff(sel, "flop_r", "clk1_n", "s1_meta_q", "rst_n", "s1_q", "u_cell_s1")]
        notes.append(f"{p}_clk_mux: no negative-edge flop - posedge flop on an inverted clock ({sel['clkinv']['cell']})")
    if "and2" in sel and "or2" in sel:
        used += [sel["and2"]["cell"], sel["or2"]["cell"]]
        L += ["  " + _gate(sel, "and2", {"a": "clk0", "b": "s0_q"}, "g0", "u_cell_and0"),
              "  " + _gate(sel, "and2", {"a": "clk1", "b": "s1_q"}, "g1", "u_cell_and1"),
              "  " + _gate(sel, "or2", {"a": "g0", "b": "g1"}, "clk_out", "u_cell_or")]
    else:
        L += ["  assign g0 = clk0 & s0_q;", "  assign g1 = clk1 & s1_q;", "  assign clk_out = g0 | g1;"]
        notes.append(f"{p}_clk_mux: AND2/OR2 cells not found - output gating left to synthesis (check glitch safety)")
    L += ["endmodule", ""]

    # ---- clk_buf / clk_inv
    for mod, kind in (("clk_buf", "clkbuf"), ("clk_inv", "clkinv")):
        L += [f"module {p}_{mod} (input logic clk_in, output logic clk_out);"]
        if kind in sel:
            used.append(sel[kind]["cell"])
            L.append("  " + _gate(sel, kind, {"a": "clk_in"}, "clk_out", "u_cell"))
        else:
            L.append("  assign clk_out = " + ("clk_in;" if kind == "clkbuf" else "~clk_in;"))
            notes.append(f"{p}_{mod}: no {kind} cell found - generic assign kept")
        L += ["endmodule", ""]

    L.append(common_modules(p))
    L += ["/* verilator lint_on PINCONNECTEMPTY */", "/* verilator lint_on DECLFILENAME */", ""]
    return "\n".join(L), sorted(set(used)), notes


def stubs_text(cells: Dict[str, dict], used: List[str]) -> str:
    L = ["`timescale 1ns/1ps", "// Port-only stubs of the mapped library cells - for lint only (simulation uses models.f)",
         "/* verilator lint_off UNUSEDSIGNAL */", "/* verilator lint_off DECLFILENAME */"]
    for n in used:
        c = cells[n]
        ports = [f"  {'input ' if a.get('direction') == 'input' else 'output'} logic {p}"
                 for p, a in c["pins"].items() if a.get("direction") in ("input", "output")]
        L += [f"module {n} (", ",\n".join(ports), ");"]
        L += [f"  assign {p} = 1'b0;" for p, a in c["pins"].items() if a.get("direction") == "output"]
        L.append("endmodule")
    L += ["/* verilator lint_on DECLFILENAME */", "/* verilator lint_on UNUSEDSIGNAL */", ""]
    return "\n".join(L)


# ======================================================================= driver
def find_files(stdcell: List[str]):
    libs, models = [], []
    for s in stdcell:
        p = Path(s).expanduser()
        cand = [p] if p.is_file() else sorted(x for x in p.rglob("*") if x.is_file())
        for f in cand:
            n = f.name.lower()
            if n.endswith((".lib", ".lib.gz")):
                libs.append(f.resolve())
            elif n.endswith((".v", ".sv", ".vlib")):
                models.append(f.resolve())
    return libs, models


def load_library(stdcell: List[str]):
    libs, models = find_files(stdcell)
    if not libs:
        raise SystemExit(f"No Liberty (.lib/.lib.gz) files found under: {' '.join(stdcell)}")
    cells = {}
    for f in libs:
        for k, v in parse_liberty(f).items():
            cells.setdefault(k, v)                # first corner wins
    return cells, libs, models


def techmap_ip(ip_dir: Path, tech: str, cells, models, override=None) -> dict:
    ip_dir = Path(ip_dir)
    top = (ip_dir / "top.txt").read_text().strip()
    flist = (ip_dir / "files.f").read_text().split()
    generic = f"rtl/{top}_cells.sv"
    if generic not in flist:
        raise SystemExit(f"{ip_dir}: no {generic} in files.f - regenerate the IP with the current spec2rtl")
    classes = classify(cells)
    sel, src, warn = select(classes, override, cells)
    text, used, notes = tech_cells_text(top, tech, sel)
    td = ip_dir / "tech" / tech
    td.mkdir(parents=True, exist_ok=True)
    tf = td / f"{top}_cells_{tech}.sv"
    tf.write_text(text)
    rel = str(tf.relative_to(ip_dir))
    (ip_dir / f"files_{tech}.f").write_text("\n".join(rel if f == generic else f for f in flist) + "\n")
    (td / "cell_stubs.sv").write_text(stubs_text(cells, used))
    mfiles = []
    for m in models:
        try:
            t = m.read_text(errors="ignore")
        except OSError:
            continue
        if any(re.search(rf"\bmodule\s+{re.escape(u)}\b", t) for u in used):
            mfiles.append(str(m))
    (td / "models.f").write_text("\n".join(mfiles) + ("\n" if mfiles else ""))
    libs_used = sorted({cells[u]["lib"] for u in used})
    (td / "liberty.f").write_text("\n".join(libs_used) + "\n")
    (td / "dont_touch.tcl").write_text(
        f"# Keep the mapped special cells of {top} through synthesis / P&R optimisation\n"
        "set_dont_touch [get_cells -hierarchical u_cell*]\n")
    missing_models = [u for u in used if not any(re.search(rf"\bmodule\s+{re.escape(u)}\b", Path(m).read_text(errors='ignore'))
                                                 for m in mfiles)]
    if missing_models:
        warn.append("no Verilog model found for: " + ", ".join(missing_models) + " (simulation with TECH will fail)")
    rows = [f"| {k} | `{v['cell']}` | {src[k]} | {v['area']:g} | {', '.join(f'{a}={b}' for a, b in v['pins'].items() if a != 'other_outs' and b is not None)} |"
            for k, v in sorted(sel.items())]
    rep = [f"# Special-cell mapping: `{top}` -> {tech}", "",
           f"- Tech cells file: `{rel}`  (generic: `{generic}`)", f"- File list: `files_{tech}.f`",
           f"- Liberty: {', '.join(Path(x).name for x in libs_used)}",
           f"- Verilog models: {', '.join(Path(x).name for x in mfiles) or 'NONE FOUND'}",
           f"- Cells used: {', '.join(used)}", "", "## Decisions", ""] + [f"- {n}" for n in notes] + \
          ["", "## Selected cell per class", "", "| Class | Cell | Source | Area | Pins |", "|---|---|---|---|---|"] + rows
    if warn:
        rep += ["", "## Warnings", ""] + [f"- {w}" for w in warn]
    rep += ["", "Override any class with `--map override.json`, e.g.",
            '`{"flop_r": {"cell": "DFFRQ_X1", "pins": {"clk": "CK", "d": "D", "rst": "RN", "rst_low": true, "q": "Q"}}}`'
            ' (classes: sync2, sync3, icg, flop_r, flop_s, flop_r_neg, latch_low, latch_high, clkbuf, clkinv, and2, or2).']
    (td / "techmap_report.md").write_text("\n".join(rep) + "\n")
    return {"top": top, "file": str(tf), "used": used, "notes": notes, "warnings": warn,
            "models": mfiles, "liberty": libs_used}
