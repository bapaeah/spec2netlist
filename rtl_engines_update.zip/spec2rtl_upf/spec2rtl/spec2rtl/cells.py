"""Per-IP special-cell wrapper library (<ip>_cells.sv).

Every component that must NOT be built from random logic by synthesis lives here, behind a
prefixed wrapper, the way commercial IP is delivered: customers (or techmap_cells.py) swap the
bodies for their standard cells without touching the IP RTL.

  <p>_sync        #(WIDTH, STAGES>=2, RESET_VAL)  multi-flop bit synchronizer (per-bit, async reset)
  <p>_rst_sync    #(STAGES>=2)                    reset synchronizer: async assert, sync de-assert
  <p>_pulse_sync                                  single-cycle pulse crossing (toggle + <p>_sync)
  <p>_hs_sync     #(WIDTH)                        req/ack handshake for multi-bit data (uses <p>_sync)
  <p>_clk_gate                                    integrated clock gate (latch-based, test enable)
  <p>_clk_mux                                     glitch-free 2:1 clock mux
  <p>_clk_buf / <p>_clk_inv                       clock-tree buffer / inverter (keep, never optimise)

Only <p>_sync, <p>_rst_sync, <p>_clk_gate, <p>_clk_mux, <p>_clk_buf and <p>_clk_inv contain
technology-dependent bodies; <p>_pulse_sync and <p>_hs_sync are built from <p>_sync, so mapping
the synchronizer maps them too.  All resets are active-low and asynchronous (rst_n).
"""
from __future__ import annotations

TECH_MODULES = ("sync", "rst_sync", "clk_gate", "clk_mux", "clk_buf", "clk_inv")

# Port lists (for documentation, the LLM prompt and the techmap script)
INTERFACES = {
    "sync": "#(parameter int WIDTH = 1, parameter int STAGES = 2, parameter logic [WIDTH-1:0] RESET_VAL = '0)\n"
            "  (input logic clk, input logic rst_n, input logic [WIDTH-1:0] d, output logic [WIDTH-1:0] q)",
    "rst_sync": "#(parameter int STAGES = 2) (input logic clk, input logic rst_n_in, output logic rst_n_out)",
    "pulse_sync": "(input logic src_clk, input logic src_rst_n, input logic src_pulse,\n"
                  "   input logic dst_clk, input logic dst_rst_n, output logic dst_pulse)",
    "hs_sync": "#(parameter int WIDTH = 8) (input logic src_clk, input logic src_rst_n, input logic src_valid,\n"
               "   input logic [WIDTH-1:0] src_data, output logic src_ready, input logic dst_clk, input logic dst_rst_n,\n"
               "   output logic dst_valid, output logic [WIDTH-1:0] dst_data)",
    "clk_gate": "(input logic clk, input logic en, input logic test_en, output logic gclk)",
    "clk_mux": "(input logic clk0, input logic clk1, input logic rst_n, input logic sel, output logic clk_out)",
    "clk_buf": "(input logic clk_in, output logic clk_out)",
    "clk_inv": "(input logic clk_in, output logic clk_out)",
}


def header(p: str, title: str) -> str:
    return (f"`timescale 1ns/1ps\n"
            f"// =============================================================================\n"
            f"//  {p}_cells - special-cell wrapper library for IP `{p}` ({title})\n"
            f"//  Synchronizers, reset synchronizer and clock cells. The IP instantiates ONLY these\n"
            f"//  wrappers; replace the bodies with standard cells (techmap_cells.py) without editing\n"
            f"//  the IP RTL. Module names and ports must stay unchanged.\n"
            f"// =============================================================================\n"
            f"/* verilator lint_off DECLFILENAME */\n")


def common_modules(p: str) -> str:
    """Technology-independent wrappers built on top of <p>_sync (identical in generic and tech files)."""
    return f"""
// -----------------------------------------------------------------------------
// {p}_pulse_sync: single-cycle pulse from src_clk to dst_clk (pulses >= 2 dst cycles apart)
// -----------------------------------------------------------------------------
module {p}_pulse_sync (
  input  logic src_clk,
  input  logic src_rst_n,
  input  logic src_pulse,
  input  logic dst_clk,
  input  logic dst_rst_n,
  output logic dst_pulse
);
  logic src_tgl_q, dst_tgl, dst_tgl_q;
  always_ff @(posedge src_clk or negedge src_rst_n)
    if (!src_rst_n) src_tgl_q <= 1'b0;
    else            src_tgl_q <= src_tgl_q ^ src_pulse;
  {p}_sync #(.WIDTH(1), .STAGES(2)) u_sync (.clk(dst_clk), .rst_n(dst_rst_n), .d(src_tgl_q), .q(dst_tgl));
  always_ff @(posedge dst_clk or negedge dst_rst_n)
    if (!dst_rst_n) dst_tgl_q <= 1'b0;
    else            dst_tgl_q <= dst_tgl;
  assign dst_pulse = dst_tgl ^ dst_tgl_q;
endmodule

// -----------------------------------------------------------------------------
// {p}_hs_sync: multi-bit transfer with a toggle req/ack handshake. src_data is captured
// on src_valid & src_ready and held stable until the destination acknowledges.
// -----------------------------------------------------------------------------
module {p}_hs_sync #(
  parameter int WIDTH = 8
) (
  input  logic             src_clk,
  input  logic             src_rst_n,
  input  logic             src_valid,
  input  logic [WIDTH-1:0] src_data,
  output logic             src_ready,
  input  logic             dst_clk,
  input  logic             dst_rst_n,
  output logic             dst_valid,
  output logic [WIDTH-1:0] dst_data
);
  logic             req_q, ack_s, ack_q, req_s, req_seen_q;
  logic [WIDTH-1:0] hold_q;
  assign src_ready = (req_q == ack_s);
  always_ff @(posedge src_clk or negedge src_rst_n)
    if (!src_rst_n) begin req_q <= 1'b0; hold_q <= '0; end
    else if (src_valid && src_ready) begin req_q <= ~req_q; hold_q <= src_data; end
  {p}_sync #(.WIDTH(1), .STAGES(2)) u_req_sync (.clk(dst_clk), .rst_n(dst_rst_n), .d(req_q), .q(req_s));
  // dst_data and dst_valid are registered together: dst_valid is a 1-cycle pulse with dst_data valid
  always_ff @(posedge dst_clk or negedge dst_rst_n)
    if (!dst_rst_n) begin req_seen_q <= 1'b0; ack_q <= 1'b0; dst_data <= '0; dst_valid <= 1'b0; end
    else begin
      dst_valid <= 1'b0;
      if (req_s != req_seen_q) begin
        req_seen_q <= req_s; ack_q <= req_s; dst_data <= hold_q; dst_valid <= 1'b1;
      end
    end
  {p}_sync #(.WIDTH(1), .STAGES(2)) u_ack_sync (.clk(src_clk), .rst_n(src_rst_n), .d(ack_q), .q(ack_s));
endmodule
"""


def generic_tech_modules(p: str) -> str:
    """Behavioural (technology-independent) bodies of the tech-dependent wrappers."""
    return f"""
// -----------------------------------------------------------------------------
// {p}_sync: STAGES-flop synchronizer, per bit. Use for single-bit signals or independent
// pad lines only; multi-bit values need {p}_hs_sync (or a gray-coded / FIFO scheme).
// -----------------------------------------------------------------------------
module {p}_sync #(
  parameter int             WIDTH     = 1,
  parameter int             STAGES    = 2,
  parameter logic [WIDTH-1:0] RESET_VAL = '0
) (
  input  logic             clk,
  input  logic             rst_n,
  input  logic [WIDTH-1:0] d,
  output logic [WIDTH-1:0] q
);
  (* async_reg = "true" *) logic [STAGES*WIDTH-1:0] chain_q;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) chain_q <= {{STAGES{{RESET_VAL}}}};
    else        chain_q <= {{chain_q[(STAGES-1)*WIDTH-1:0], d}};
  assign q = chain_q[STAGES*WIDTH-1 -: WIDTH];
endmodule

// -----------------------------------------------------------------------------
// {p}_rst_sync: asynchronous assertion, synchronous de-assertion
// -----------------------------------------------------------------------------
module {p}_rst_sync #(
  parameter int STAGES = 2
) (
  input  logic clk,
  input  logic rst_n_in,
  output logic rst_n_out
);
  // Waiver: the synchronized reset is a flop output that drives async resets (intended).
  /* verilator lint_off SYNCASYNCNET */
  (* async_reg = "true" *) logic [STAGES-1:0] chain_q;
  always_ff @(posedge clk or negedge rst_n_in)
    if (!rst_n_in) chain_q <= '0;
    else           chain_q <= {{chain_q[STAGES-2:0], 1'b1}};
  assign rst_n_out = chain_q[STAGES-1];
  /* verilator lint_on SYNCASYNCNET */
endmodule

// -----------------------------------------------------------------------------
// {p}_clk_gate: latch-based integrated clock gate (enable latched while clk is low)
// -----------------------------------------------------------------------------
module {p}_clk_gate (
  input  logic clk,
  input  logic en,
  input  logic test_en,
  output logic gclk
);
  logic en_l;
  /* verilator lint_off LATCH */
  always_latch if (!clk) en_l = en | test_en;
  /* verilator lint_on LATCH */
  assign gclk = clk & en_l;
endmodule

// -----------------------------------------------------------------------------
// {p}_clk_mux: glitch-free 2:1 clock mux (sel may change at any time; clocks may be async)
// -----------------------------------------------------------------------------
module {p}_clk_mux (
  input  logic clk0,
  input  logic clk1,
  input  logic rst_n,
  input  logic sel,
  output logic clk_out
);
  logic s0_meta_q, s0_q, s1_meta_q, s1_q;
  always_ff @(posedge clk0 or negedge rst_n) if (!rst_n) s0_meta_q <= 1'b0; else s0_meta_q <= ~sel & ~s1_q;
  always_ff @(negedge clk0 or negedge rst_n) if (!rst_n) s0_q      <= 1'b0; else s0_q      <= s0_meta_q;
  always_ff @(posedge clk1 or negedge rst_n) if (!rst_n) s1_meta_q <= 1'b0; else s1_meta_q <=  sel & ~s0_q;
  always_ff @(negedge clk1 or negedge rst_n) if (!rst_n) s1_q      <= 1'b0; else s1_q      <= s1_meta_q;
  assign clk_out = (clk0 & s0_q) | (clk1 & s1_q);
endmodule

// -----------------------------------------------------------------------------
// {p}_clk_buf / {p}_clk_inv: clock-tree cells (map to CLKBUF / CLKINV, keep)
// -----------------------------------------------------------------------------
module {p}_clk_buf (input logic clk_in, output logic clk_out);
  assign clk_out = clk_in;
endmodule

module {p}_clk_inv (input logic clk_in, output logic clk_out);
  assign clk_out = ~clk_in;
endmodule
"""


def gen_cells(p: str) -> str:
    return header(p, "generic behavioural models") + generic_tech_modules(p) + common_modules(p) + \
        "/* verilator lint_on DECLFILENAME */\n"


def llm_reference(p: str) -> str:
    """Short interface list for the LLM prompt."""
    return "\n".join(f"  {p}_{k} {v}" for k, v in INTERFACES.items())
