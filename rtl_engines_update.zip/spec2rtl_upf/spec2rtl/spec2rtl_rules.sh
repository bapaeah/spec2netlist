#!/usr/bin/env bash
# RTL generation WITHOUT an LLM (deterministic rules engine; no Ollama, no network).
#   ./spec2rtl_rules.sh <spec file> [-o out_dir]            -> extract + generate + lint + synth + sim
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SPEC="$1"; shift || true
[ -z "$SPEC" ] && { echo "usage: $0 <spec file> [-o out_dir]"; exit 1; }
args=(); for a in "$@"; do [ "$a" != "--llm" ] && args+=("$a"); done
exec python3 "$DIR/spec2rtl.py" all "$SPEC" --no-llm "${args[@]}"
