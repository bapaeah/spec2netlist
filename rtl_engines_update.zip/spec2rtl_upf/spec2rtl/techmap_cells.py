#!/usr/bin/env python3
"""techmap_cells.py - replace the generic special-cell wrappers with your standard cells.

  python3 techmap_cells.py --stdcell <dir-or-files...> --tech <name> --ip <ip_out_dir> [<ip_out_dir> ...]
  python3 techmap_cells.py --stdcell <dir> --tech <name> --ip-root specs_out      (every IP below it)
  python3 techmap_cells.py --stdcell <dir> --list                                 (show what it would pick)

  --stdcell  directory or files with the Liberty (.lib/.lib.gz) and Verilog models (.v) of the library
  --tech     short name used in file names: tech/<tech>/, files_<tech>.f, <ip>_cells_<tech>.sv
  --map      optional JSON override, e.g. {"icg": {"cell": "CKLNQD1", "pins": {"clk": "CP", "en": "E",
             "te": "TE", "gclk": "Q"}}}

Then run any Makefile step on the mapped design with TECH=<tech>, e.g. `make lint sim synth OUT=out TECH=<tech>`.
The generic rtl/<ip>_cells.sv is never modified, so `make ... ` without TECH keeps working.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from spec2rtl import techmap as T  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--stdcell", nargs="+", required=True)
    ap.add_argument("--tech")
    ap.add_argument("--ip", nargs="*", default=[])
    ap.add_argument("--ip-root")
    ap.add_argument("--map")
    ap.add_argument("--list", action="store_true", help="only print the cell classification")
    a = ap.parse_args()

    cells, libs, models = T.load_library(a.stdcell)
    print(f"[techmap] {len(cells)} cells from {len(libs)} Liberty file(s); {len(models)} Verilog model file(s)")
    override = json.loads(Path(a.map).read_text()) if a.map else None
    if a.list:
        for k, v in sorted(T.classify(cells).items()):
            print(f"  {k:<11} " + ", ".join(f"{x['cell']}({x['area']:g})" for x in v[:6]) + (" ..." if len(v) > 6 else ""))
        return 0
    if not a.tech:
        ap.error("--tech is required (unless --list)")
    ips = [Path(x) for x in a.ip]
    if a.ip_root:
        ips += sorted(p.parent for p in Path(a.ip_root).glob("*/files.f"))
    if not ips:
        ap.error("give --ip <dir> or --ip-root <dir>")
    rc = 0
    for ip in ips:
        try:
            r = T.techmap_ip(ip, a.tech, cells, models, override)
        except SystemExit as e:
            print(f"[techmap] {ip}: FAILED - {e}")
            rc = 1
            continue
        print(f"[techmap] {r['top']}: {Path(r['file']).relative_to(ip)}  cells: {', '.join(r['used'])}")
        for n in r["notes"]:
            print(f"[techmap]   - {n}")
        for w in r["warnings"]:
            print(f"[techmap]   ! {w}")
        print(f"[techmap]   report: {ip}/tech/{a.tech}/techmap_report.md   file list: {ip}/files_{a.tech}.f")
    return rc


if __name__ == "__main__":
    sys.exit(main())
