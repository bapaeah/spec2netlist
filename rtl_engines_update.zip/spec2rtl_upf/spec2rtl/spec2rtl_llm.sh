#!/usr/bin/env bash
# RTL generation WITH an LLM (local Ollama by default; lint/synth/sim repair loop).
#   ./spec2rtl_llm.sh <spec file> [-o out_dir] [--model qwen2.5-coder:32b] [--iters 4]
# Endpoint: OLLAMA_HOST, `rtl --models --set-host http://<ip>:11434`, or SPEC2RTL_LLM_URL.
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SPEC="$1"; shift || true
[ -z "$SPEC" ] && { echo "usage: $0 <spec file> [-o out_dir] [--model M] [--iters N]"; exit 1; }
args=(); for a in "$@"; do [ "$a" != "--no-llm" ] && [ "$a" != "--llm" ] && args+=("$a"); done
exec python3 "$DIR/spec2rtl.py" all "$SPEC" --llm "${args[@]}"
