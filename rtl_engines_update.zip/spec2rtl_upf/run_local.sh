#!/usr/bin/env bash
# Run Spec2RTL + AutoUPF WITH the LLM engine (local Ollama, token-free & offline)
# Without an LLM use ./run_rules.sh
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$DIR"

# Configure local LLM environment variables
# Ollama host: OLLAMA_HOST, or `rtl --models --set-host http://<ip>:11434` (saved in ~/.llm_local/config.json)
export SPEC2RTL_LLM_KEY="ollama"
export SPEC2RTL_LLM_MODEL="${SPEC2RTL_LLM_MODEL:-auto}"   # auto = best model for the host GPU/RAM

echo "============================================================"
echo " Running Spec2RTL + AutoUPF with Local LLM (${SPEC2RTL_LLM_MODEL})"
echo " Endpoint: ${SPEC2RTL_LLM_URL:-$(python3 -c "import sys;sys.path.insert(0,'..');import ollama_models as m;print(m.ollama_host())" 2>/dev/null)}"
echo "============================================================"

# Always the LLM engine (drop any --llm / --no-llm the caller passed)
args=(); for a in "$@"; do [ "$a" != "--llm" ] && [ "$a" != "--no-llm" ] && args+=("$a"); done
exec python3 main.py --llm "${args[@]}"
