#!/usr/bin/env python3
"""
Automated Clock Domain Crossing (CDC) & Reset Domain Crossing (RDC) Engine.

Responsibilities:
1. Generate CDC Constraints (.cdc / .sdc) for IPs and SoC Top.
   - Multi-clock definitions
   - Asynchronous clock group declarations
   - False paths on asynchronous resets & quasi-static signals
   - Datapath-only max delay constraints for CDC paths
   - Synchronizer cell recognition attributes (ASYNC_REG)

2. Structural & Rule-Based CDC / RDC Verification Checker:
   - Clock domain identification from RTL AST & port declarations
   - Detection of asynchronous clock domain crossings
   - Verification of synchronizer structures (2-FF, FIFO, handshakes)
   - Glitch prevention check (no combinational logic driving synchronizer inputs)
   - Reset Domain Crossing (RDC) verification (synchronized de-assertion)
"""

import re
import json
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple


import sys as _sys
_sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "spec2rtl"))
from spec2rtl import constraints as K  # noqa: E402


class CDCEngine:
    """CDC/RDC constraints + open structural check.

    Thin wrapper over spec2rtl/constraints.py (one tool-neutral model -> generic SDC,
    SpyGlass SGDC, Questa CDC directives). Kept for existing callers; same method names.
    """

    def __init__(self, target_library: str = "NanGate45"):
        self.target_library = target_library
        self.last_model = None

    def generate_ip_cdc_constraints(self, module_name: str, clock_port: str = "clk",
                                    clock_period_ns: float = 10.0, reset_port: str = "rst_n",
                                    aux_clocks=None, cdc_signals=None, output_file: Optional[str] = None,
                                    spec: Optional[dict] = None, rtl_files: Optional[List[Path]] = None) -> str:
        """IP constraint set. output_file = the generic SDC path; the other tool files are written next to it.
        spec / rtl_files default to <dir of output_file>/spec.json and files.f (spec2rtl output layout)."""
        out_dir = Path(output_file).parent if output_file else Path(".")
        if spec is None and (out_dir / "spec.json").exists():
            spec = json.loads((out_dir / "spec.json").read_text())
        if rtl_files is None and (out_dir / "files.f").exists():
            rtl_files = [out_dir / f for f in (out_dir / "files.f").read_text().split()]
        rtl_files = rtl_files or []
        if spec:
            m = K.model_from_spec(spec, rtl_files)
        else:
            ports = [{"name": clock_port, "dir": "input", "width": 1, "desc": f"{1000.0 / clock_period_ns} MHz"},
                     {"name": reset_port, "dir": "input", "width": 1, "desc": ""}]
            m = K.build_model(module_name, ports, {"name": clock_port, "freq_mhz": 1000.0 / clock_period_ns},
                              {"name": reset_port, "active_low": True, "type": "async"})
        self.last_model = m
        paths = K.write_all_constraints(m, out_dir / "constraints", [str(f) for f in rtl_files])
        sdc = K.write_sdc(m)
        if output_file:
            Path(output_file).write_text(sdc, encoding="utf-8")
            print(f"  ✔ Generated IP constraints: \033[92m{output_file}\033[0m (+ SGDC / Questa / JSON in {paths['sdc'].parent})")
        return sdc

    def generate_soc_cdc_constraints(self, top_module: str = "soc_subsystem_top", clocks_config=None,
                                     output_file: Optional[str] = None,
                                     rtl_files: Optional[List[Path]] = None) -> str:
        """SoC constraint set from the real top-level RTL ports (no hard-coded clock names).
        clocks_config: optional {port: {"period": ns}} to supply frequencies the RTL comments lack."""
        if not rtl_files:
            print(f"  • SoC CDC constraints skipped: top-level RTL for {top_module} not available yet")
            return ""
        hints = {k: 1000.0 / v["period"] for k, v in (clocks_config or {}).items() if v.get("period")}
        m = K.model_from_rtl(top_module, rtl_files, hints)
        self.last_model = m
        out_dir = Path(output_file).parent if output_file else Path(".")
        paths = K.write_all_constraints(m, out_dir / "constraints_soc", [str(f) for f in rtl_files])
        sdc = K.write_sdc(m)
        if output_file:
            Path(output_file).write_text(sdc, encoding="utf-8")
            print(f"  ✔ Generated SoC constraints: \033[92m{output_file}\033[0m "
                  f"({len(m['clocks'])} clocks; + SGDC / Questa / JSON in {paths['sdc'].parent})")
        for w in m["warnings"]:
            print(f"    ! {w}")
        return sdc

    def verify_cdc(self, rtl_files: List[Path], top_module: str,
                   cdc_constraints_file: Optional[Path] = None) -> Dict[str, Any]:
        """Open structural CDC/RDC check (see constraints.check_cdc for what it covers)."""
        m = self.last_model if (self.last_model and self.last_model["top"] == top_module) \
            else K.model_from_rtl(top_module, rtl_files)
        r = K.check_cdc(m, [Path(f) for f in rtl_files])
        r["rdc_status"] = "PASS (no multi-domain reset hazards found)" if r["rdc_status"] == "PASS" else \
            "WARNING: async reset used in several domains without a reset synchronizer"
        return r
