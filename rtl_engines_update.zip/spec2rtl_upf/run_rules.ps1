# Run Spec2RTL + AutoUPF WITHOUT an LLM (deterministic rules engine; no Ollama needed)
$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $MyInvocation.MyCommand.Definition)
Write-Host " Running Spec2RTL + AutoUPF - rules engine (no LLM)" -ForegroundColor Cyan
$rest = @($args | Where-Object { $_ -ne "--llm" })
python main.py --no-llm @rest
