# gpio_opentitan — Complete Industry-Standard GPIO Controller Specification

**Document Version**: 2.0  
**Compliance Standard**: OpenTitan / ARM APB Peripheral Architecture  
**Module Name**: `gpio_opentitan`  

---

## 1. Overview & Theory of Operation

`gpio_opentitan` is a 32-channel General Purpose Input/Output (GPIO) peripheral designed for high-reliability SoC designs. It provides direct pin manipulation, masked bitwise atomic writes (eliminating read-modify-write software race conditions), configurable input debouncing, and per-pin edge/level interrupt generation.

### 1.1 Key Architecture Features
- **32 Independent Bi-directional Pins**: Individual input read, output drive, and output enable controls.
- **Thread-Safe Masked Writes**: Upper 16 bits select the bitmask while lower 16 bits specify values, enabling concurrent atomic software modifications.
- **Hardware Debouncing Engine**: Filter logic suppressing glitches shorter than the programmed clock cycles.
- **Flexible Interrupt Matrix**: Configurable per-pin triggers:
  - Rising Edge
  - Falling Edge
  - High Level
  - Low Level

---

## 2. Ports

### 2.1 Bus Interface (APB Slave) & System Signals

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | System clock (50–100 MHz nominal) |
| `rst_n` | in | 1 | Active-low asynchronous reset |
| `paddr[7:0]` | in | 8 | APB address bus |
| `psel` | in | 1 | APB select signal |
| `penable` | in | 1 | APB strobe enable |
| `pwrite` | in | 1 | APB write control (1=Write, 0=Read) |
| `pwdata[31:0]` | in | 32 | APB write data bus |
| `pready` | out | 1 | APB slave ready output |
| `prdata[31:0]` | out | 32 | APB read data bus |
| `pslverr` | out | 1 | APB slave error response |

### 2.2 GPIO Pin & Interrupt Signals

| Port | Dir | Width | Description |
|---|---|---|---|
| `gpio_in[31:0]` | in | 32 | Raw input pin state from I/O pads |
| `gpio_out[31:0]` | out | 32 | Output pin drive value to I/O pads |
| `gpio_oe[31:0]` | out | 32 | Output enable control (1=Drive output, 0=Hi-Z input) |
| `irq` | out | 1 | Aggregated level interrupt output to CPU/PLIC |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `DATA_IN` | RO | `0x00000000` | Synchronized GPIO pin input readback |
| `0x04` | `DIRECT_OUT` | RW | `0x00000000` | Direct write to all 32 GPIO output bits |
| `0x08` | `MASKED_OUT_L` | WO | `0x00000000` | Masked write for GPIO bits [15:0] (bits [31:16]=mask, [15:0]=data) |
| `0x0C` | `MASKED_OUT_H` | WO | `0x00000000` | Masked write for GPIO bits [31:16] (bits [31:16]=mask, [15:0]=data) |
| `0x10` | `DIRECT_OE` | RW | `0x00000000` | Direct Output Enable control for bits [31:0] |
| `0x14` | `MASKED_OE_L` | WO | `0x00000000` | Masked Output Enable for bits [15:0] |
| `0x18` | `MASKED_OE_H` | WO | `0x00000000` | Masked Output Enable for bits [31:16] |
| `0x1C` | `INTR_EN_RISE` | RW | `0x00000000` | Enable interrupt on rising edge |
| `0x20` | `INTR_EN_FALL` | RW | `0x00000000` | Enable interrupt on falling edge |
| `0x24` | `INTR_EN_HIGH` | RW | `0x00000000` | Enable interrupt on high level |
| `0x28` | `INTR_EN_LOW` | RW | `0x00000000` | Enable interrupt on low level |
| `0x2C` | `INTR_STATE` | W1C | `0x00000000` | Pending interrupt status (Write-1-to-Clear) |
| `0x30` | `CTRL_DEBOUNCE`| RW | `0x00000000` | Debounce filter clock divider and enable |

---

## 4. Detailed Functional Operation & State Behavior

### 4.1 Input Synchronization & Debouncing Logic
1. `gpio_in` signals pass through a 2-stage flip-flop synchronizer (`sync_in_0`, `sync_in_1`) to eliminate metastability from asynchronous external pin events.
2. If `CTRL_DEBOUNCE.enable` is set, a 16-bit counter counts `clk` cycles up to `CTRL_DEBOUNCE.div`. Only inputs remaining stable for the full duration update the internal `DATA_IN` register.

### 4.2 Masked Atomic Write Mechanism
- Writing to `MASKED_OUT_L`:
  $$\text{DIRECT\_OUT}[15:0] \leftarrow (\text{DIRECT\_OUT}[15:0] \ \& \ \sim\text{pwdata}[31:16]) \ | \ (\text{pwdata}[15:0] \ \& \ \text{pwdata}[31:16])$$
- Writing to `MASKED_OUT_H`:
  $$\text{DIRECT\_OUT}[31:16] \leftarrow (\text{DIRECT\_OUT}[31:16] \ \& \ \sim\text{pwdata}[31:16]) \ | \ (\text{pwdata}[15:0] \ \& \ \text{pwdata}[31:16])$$

### 4.3 Interrupt Generation Matrix
At every clock cycle, edge-detection comparators evaluate:
- `rise_edge = DATA_IN & ~DATA_IN_prev`
- `fall_edge = ~DATA_IN & DATA_IN_prev`
- `high_lvl   = DATA_IN`
- `low_lvl    = ~DATA_IN`

The combined interrupt trigger sets the corresponding bit in `INTR_STATE`:
$$\text{INTR\_STATE\_SET} = (\text{rise\_edge} \ \& \ \text{INTR\_EN\_RISE}) \ | \ (\text{fall\_edge} \ \& \ \text{INTR\_EN\_FALL}) \ | \ (\text{high\_lvl} \ \& \ \text{INTR\_EN\_HIGH}) \ | \ (\text{low\_lvl} \ \& \ \text{INTR\_EN\_LOW})$$

The output `irq` stays driven HIGH as long as `|INTR_STATE != 0`. Software clears individual interrupts by writing `1` to `INTR_STATE`.
