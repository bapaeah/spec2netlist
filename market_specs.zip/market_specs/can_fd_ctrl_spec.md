# can_fd_ctrl — ISO 11898-1 CAN-FD Bus Controller Specification

**Document Version**: 2.0  
**Compliance Standard**: ISO 11898-1:2015 CAN Flexible Datarate Standard  
**Module Name**: `can_fd_ctrl`  

---

## 1. Overview & Theory of Operation

`can_fd_ctrl` is an automotive-grade Controller Area Network with Flexible Datarate (CAN-FD) protocol engine supporting arbitration bitrates up to 1 Mbps and data bitrates up to 5 Mbps. It features dual bit-rate prescalers, 16 acceptance filter masks, 64-entry RX FIFO, and Error State Indicator (ESI) tracking.

---

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | System clock |
| `rst_n` | in | 1 | Active-low reset |
| `can_clk` | in | 1 | Dedicated CAN transceiver clock (40 MHz) |
| `paddr[7:0]` | in | 8 | APB address |
| `psel` | in | 1 | APB select |
| `penable` | in | 1 | APB enable |
| `pwrite` | in | 1 | APB write strobe |
| `pwdata[31:0]` | in | 32 | APB write data |
| `pready` | out | 1 | APB ready |
| `prdata[31:0]` | out | 32 | APB read data |
| `pslverr` | out | 1 | APB error |
| `can_rx` | in | 1 | CAN transceiver RX input pin |
| `can_tx` | out | 1 | CAN transceiver TX output pin |
| `irq` | out | 1 | CAN interrupt output |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `MODE` | RW | `0x00000001` | Reset mode, CAN-FD mode enable, Listen-only mode |
| `0x04` | `COMMAND` | WO | `0x00000000` | Transmit request, Abort request, Clear overrun |
| `0x08` | `STATUS` | RO | `0x0000000C` | Node status, Error Warning, Bus Off, Transmit Busy |
| `0x0C` | `INTR_STATE`| W1C | `0x00000000` | RX Interrupt, TX Interrupt, Error Interrupt |
| `0x10` | `BIT_TIMING_NOM`| RW | `0x00000000` | Nominal bitrate timing prescaler and TSEG1/TSEG2 |
| `0x14` | `BIT_TIMING_DATA`| RW | `0x00000000` | Data bitrate timing prescaler and TSEG1/TSEG2 |
| `0x18` | `ACCEPT_FILTER`| RW | `0x00000000` | ID Acceptance Mask Filter |
