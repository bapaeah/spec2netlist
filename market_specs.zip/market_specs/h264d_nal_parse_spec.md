# h264d_nal_parse — Complete Video Bitstream NAL Unit Parser Specification

**Document Version**: 1.0  
**Compliance Standard**: ITU-T H.264 / ISO/IEC 14496-10 Annex-B Specification  
**Module Name**: `h264d_nal_parse`  

---

## 1. Overview & Theory of Operation

`h264d_nal_parse` receives an 8-bit RBSP byte stream from `h264d_stream_in`, detects 3-byte and 4-byte Annex-B start codes (`0x000001` and `0x00000001`), strips emulation prevention bytes (`0x000003`), extracts NAL unit headers (`nal_unit_type`, `nal_ref_idc`), and forwards stripped slice payloads to the downstream CABAC/cavlc decoder core.

---

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `core_clk` | in | 1 | Core clock domain |
| `ctx_rst_n` | in | 1 | Active-low context reset |
| `strm_data[7:0]` | in | 8 | Input byte stream from `h264d_stream_in` |
| `strm_valid` | in | 1 | Stream valid |
| `strm_ready` | out | 1 | Stream ready back-pressure |
| `nal_type[4:0]` | out | 5 | Parsed NAL unit type |
| `nal_ref_idc[1:0]`| out | 2 | Parsed NAL reference indicator |
| `nal_payload[7:0]`| out | 8 | Stripped RBSP payload byte |
| `nal_valid` | out | 1 | Payload valid |
| `nal_ready` | in | 1 | Downstream decoder ready |
| `syntax_err` | out | 1 | Pulse: Start-code / emulation syntax error |

---

## 3. Theory of Operation & FSM

1. **SEARCH_START_CODE**: Shifts incoming bytes into a 3-byte sliding window. Detects `0x000001` or `0x00000001`.
2. **PARSE_HEADER**: Extracts first byte following start code: `forbidden_zero_bit` (bit 7), `nal_ref_idc` (bits 6:5), `nal_unit_type` (bits 4:0).
3. **STRIP_EMULATION**: Detects `0x000003` sequence and strips the `0x03` emulation byte before delivering payload to `nal_payload`.
