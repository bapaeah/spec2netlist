# rtc_core — Complete Real-Time Clock Subsystem Specification

**Document Version**: 2.0  
**Compliance Standard**: Industry Low-Power RTC Standard  
**Module Name**: `rtc_core`  

---

## 1. Overview & Theory of Operation

`rtc_core` is a low-power Real-Time Clock module operating from a 32.768 kHz crystal oscillator domain. It tracks seconds, minutes, hours, days, and year count, and provides an alarm interrupt comparator.

---

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | System clock (50–100 MHz) |
| `rst_n` | in | 1 | Active-low system reset |
| `rtc_32k_clk` | in | 1 | 32.768 kHz ultra-low-power crystal clock |
| `paddr[7:0]` | in | 8 | APB address |
| `psel` | in | 1 | APB select |
| `penable` | in | 1 | APB enable |
| `pwrite` | in | 1 | APB write strobe |
| `pwdata[31:0]` | in | 32 | APB write data |
| `pready` | out | 1 | APB ready |
| `prdata[31:0]` | out | 32 | APB read data |
| `pslverr` | out | 1 | APB error |
| `irq` | out | 1 | RTC Alarm interrupt output |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `CTRL` | RW | `0x00000000` | RTC Enable, Alarm Enable |
| `0x04` | `TIME_SEC` | RW | `0x00000000` | Seconds (0-59) |
| `0x08` | `TIME_MIN` | RW | `0x00000000` | Minutes (0-59) |
| `0x0C` | `TIME_HOUR`| RW | `0x00000000` | Hours (0-23) |
| `0x10` | `ALARM_VAL` | RW | `0x00000000` | Target Alarm Time match value |
| `0x14` | `INTR_STATE`| W1C | `0x00000000` | Alarm Interrupt pending status |
