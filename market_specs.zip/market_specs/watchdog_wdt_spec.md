# watchdog_wdt — Complete Industry-Standard Watchdog Safety Timer Specification

**Document Version**: 2.0  
**Compliance Standard**: OpenTitan AON_WDT / ARM Watchdog Architecture  
**Module Name**: `watchdog_wdt`  

---

## 1. Overview & Theory of Operation

`watchdog_wdt` is an Always-On (AON) hardware watchdog safety timer. It provides a two-stage warning and reset mechanism: stage 1 issues an interrupt to allow software to log state, and stage 2 triggers an unmaskable system reset if the watchdog is not refreshed with a valid unlock key before the deadline.

### 1.1 Key Architecture Features
- **Two-Stage Countdown Timer**: Bark (interrupt) threshold followed by Bite (system reset) threshold.
- **Service Unlock Key Register**: Requires writing secret key `0x76543210` to prevent unintended code execution from clearing the timer.
- **Write-Once Lock Protection**: Configuration registers can be locked until power-on reset.

---

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | Clock |
| `rst_n` | in | 1 | Reset |
| `paddr[7:0]` | in | 8 | APB address |
| `psel` | in | 1 | APB select |
| `penable` | in | 1 | APB enable |
| `pwrite` | in | 1 | APB write strobe |
| `pwdata[31:0]` | in | 32 | APB write data |
| `pready` | out | 1 | APB ready |
| `prdata[31:0]` | out | 32 | APB read data |
| `pslverr` | out | 1 | APB error |
| `wd_reset_req` | out | 1 | Hardware System Reset request output |
| `irq` | out | 1 | Watchdog warning interrupt (Bark) |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `CTRL` | RW | `0x00000000` | Enable WDT, Enable Reset, Lock bit |
| `0x04` | `BARK_THOLD` | RW | `0x000F0000` | Stage 1 Warning Interrupt threshold |
| `0x08` | `BITE_THOLD` | RW | `0x001F0000` | Stage 2 System Reset threshold |
| `0x0C` | `SERVICE_KEY`| WO | `0x00000000` | Write `0x76543210` to refresh countdown |
| `0x10` | `COUNT_VAL` | RO | `0x00000000` | Current watchdog counter value |
