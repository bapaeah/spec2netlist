# spi_host_opentitan — Complete Industry-Standard Quad-SPI Controller Specification

**Document Version**: 2.2  
**Compliance Standard**: OpenTitan SPI Host Architecture / Serial Flash Interface Standard  
**Module Name**: `spi_host_opentitan`  

---

## 1. Overview & Theory of Operation

`spi_host_opentitan` is a high-performance Quad-SPI host controller designed to interface with external SPI NOR Flash, SPI SRAM, and serial peripheral ICs. It supports Standard SPI (1-bit), Dual-SPI (2-bit), and Quad-SPI (4-bit) data transfer modes with hardware command queuing and DMA prefetch.

### 1.1 Key Architecture Features
- **Multi-IO Support**: Single (1-bit), Dual (2-bit), and Quad (4-bit) I/O modes for Command, Address, Dummy, and Data phases.
- **Hardware Command Segment Queue**: 8-entry Segment Queue (`COMMAND`) allowing automated multi-phase SPI transactions.
- **Transmit & Receive FIFOs**: 64-word (256-byte) TX and RX data FIFOs.
- **Programmable Clock Divisor & Chip Select**: Configurable SPI clock division ($f_{\text{sck}} = \frac{f_{\text{clk}}}{2 \times (1 + \text{CLKDIV})}$) and up to 4 Chip Select lines (`cs_n`).

---

## 2. Ports

### 2.1 Bus Interface (AXI4-Lite / APB Slave) & System Signals

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | System clock (50–100 MHz) |
| `rst_n` | in | 1 | Active-low asynchronous reset |
| `paddr[7:0]` | in | 8 | APB address bus |
| `psel` | in | 1 | APB select signal |
| `penable` | in | 1 | APB strobe enable |
| `pwrite` | in | 1 | APB write control |
| `pwdata[31:0]` | in | 32 | APB write data bus |
| `pready` | out | 1 | APB ready output |
| `prdata[31:0]` | out | 32 | APB read data bus |
| `pslverr` | out | 1 | APB slave error response |

### 2.2 SPI Serial Interface Signals

| Port | Dir | Width | Description |
|---|---|---|---|
| `sck` | out | 1 | Serial Clock to SPI peripherals |
| `cs_n[3:0]` | out | 4 | Chip Select lines (active-low) |
| `sd_out[3:0]` | out | 4 | Quad SPI Data Output lines [3:0] |
| `sd_in[3:0]` | in | 4 | Quad SPI Data Input lines [3:0] |
| `sd_oe[3:0]` | out | 4 | Quad SPI Output Enable control [3:0] |
| `irq` | out | 1 | Aggregated level interrupt output |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `INTR_STATE` | W1C | `0x00000000` | Pending SPI interrupt status |
| `0x04` | `INTR_ENABLE` | RW | `0x00000000` | Interrupt enable mask |
| `0x08` | `CONTROL` | RW | `0x00000000` | SPI Enable, CPOL, CPHA, Clock Divisor |
| `0x0C` | `STATUS` | RO | `0x00000000` | Busy, Ready, TX/RX FIFO occupancy and full/empty flags |
| `0x10` | `CONFIGOP` | RW | `0x00000000` | Target Chip Select index and CS Hold/Setup delays |
| `0x14` | `COMMAND` | WO | `0x00000000` | Command Segment: Direction (TX/RX), Mode (Single/Dual/Quad), Length |
| `0x18` | `RXDATA` | RO | `0x00000000` | Receive Data FIFO pop |
| `0x1C` | `TXDATA` | WO | `0x00000000` | Transmit Data FIFO push |

---

## 4. Detailed Functional Operation & Segment Queue FSM

### 4.1 Transaction Phase Execution
A complete SPI Flash Read transaction consists of 4 segments written to `COMMAND`:
1. **Command Segment**: Single-bit mode, TX 1 byte (e.g., `0xEB` Quad Read opcode).
2. **Address Segment**: Quad-bit mode, TX 3 or 4 bytes (target flash address).
3. **Dummy Segment**: Quad-bit mode, 6 dummy clock cycles.
4. **Data Segment**: Quad-bit mode, RX $N$ bytes into `RXDATA` FIFO.

```
IDLE ──(CMD Queue Not Empty)──► ASSERT_CS ──► SHIFT_SEGMENT ──► NEXT_SEGMENT?
  ▲                                                                 │
  │                                           (No more segments)    │
  └─────────────────────────── DEASSERT_CS ◄────────────────────────┘
```
