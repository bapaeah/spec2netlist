# Specification Provenance, Standards, and Academic Citations Catalog

**Document Purpose**: Official provenance catalog and reference citations for the top-level SoC subsystem, 15 benchmark IP specifications, and 2 CPU core specifications used in the `spec2rtl` DAC 2027 paper submission.

---

## 1. Specification Provenance & Industry Standards Matrix

| # | Module Name | Open-Source Organization / Source Repo | Industry / Standard Specification | Reference Repository / Spec File |
|---|---|---|---|---|
| **Top** | `soc_subsystem_top` | **SoC Integration Architecture** | Top-Level RISC-V SoC Architecture & Memory Map | [`soc_subsystem_top_spec.md`](soc_subsystem_top_spec.md) |
| **1** | `gpio_opentitan` | **lowRISC / OpenTitan** | OpenTitan Comportability GPIO Specification v2.0 | `https://github.com/lowRISC/opentitan/tree/master/hw/ip/gpio` |
| **2** | `uart_16550` | **PULP Platform / OpenCores** | National Semiconductor PC16550D UART Specification | `https://github.com/pulp-platform/apb_uart` |
| **3** | `i2c_opentitan` | **lowRISC / NXP Semiconductors** | NXP UM10204 I2C-Bus Specification v6.0 | `https://github.com/lowRISC/opentitan/tree/master/hw/ip/i2c` |
| **4** | `spi_host_opentitan` | **lowRISC / JEDEC** | JEDEC JESD216 Serial Flash Discoverable Parameters (SFDP) | `https://github.com/lowRISC/opentitan/tree/master/hw/ip/spi_host` |
| **5** | `dma_axi_sg` | **ARM / OpenHW Group** | ARM IHI 0022E AMBA AXI4 Protocol Specification | `https://github.com/openhwgroup/core-v-verif` |
| **6** | `timer_pwm_opentitan`| **lowRISC / RISC-V International** | RISC-V Privileged Architecture `mtime` / `mtimecmp` | `https://github.com/lowRISC/opentitan/tree/master/hw/ip/rv_timer` |
| **7** | `watchdog_wdt` | **lowRISC / ARM Ltd.** | ARM DEN 0029A Server Base System Watchdog | `https://github.com/lowRISC/opentitan/tree/master/hw/ip/aon_timer` |
| **8** | `rtc_core` | **OpenCores** | 32.768 kHz Low-Power Real-Time Clock Standard | `https://opencores.org/projects/rtc` |
| **9** | `can_fd_ctrl` | **ISO / CTU CAN FD** | ISO 11898-1:2015 CAN-FD Data Link Layer Standard | `https://github.com/ctu-can-fd/ctu-can-fd` |
| **10** | `sd_mmc_ctrl` | **SD Association / OpenCores** | SD Specifications Part 1 Physical Layer Version 3.01 | `https://opencores.org/projects/sdc_controller` |
| **11** | `i2s_audio` | **Philips / PULP Platform** | Philips I2S Bus Specification (1996 Revision) | `https://github.com/pulp-platform/apb_i2s` |
| **12** | `interrupt_ctrl` | **RISC-V International / PULP** | RISC-V Platform-Level Interrupt Controller (PLIC) v1.0 | `https://github.com/riscv/riscv-plic-spec` |
| **13** | `h264d_nal_parse` | **ITU-T / ISO/IEC** | ITU-T Recommendation H.264 Annex-B Byte Stream | `https://www.itu.int/rec/T-REC-H.264` |
| **14** | `H264D-U1000_cfg_regs` | **H264D Architecture** | H264D Video Decoder Register Specification | `H264D-U1000_cfg_regs_spec.md` |
| **15** | `H264D-U1000_stream_in`| **H264D Architecture** | H264D Video Stream Input Front-End Specification | `H264D-U1000_stream_in_spec.md` |
| **16** | `ibex_cpu` | **lowRISC / OpenTitan** | lowRISC Ibex RV32IMC 2-Stage Core Specification | [`ibex_cpu_spec.md`](ibex_cpu_spec.md) (`https://github.com/lowRISC/ibex`) |
| **17** | `cv32e40p_cpu` | **OpenHW Group / PULP Platform** | OpenHW Group CV32E40P RV32IMFC Core Specification | [`cv32e40p_cpu_spec.md`](cv32e40p_cpu_spec.md) (`https://github.com/openhwgroup/cv32e40p`) |

---

## 2. Formal Academic Citations (BibTeX Format for Paper)

```bibtex
@online{lowrisc_gpio_2024,
  author       = {{lowRISC OpenTitan Team}},
  title        = {{OpenTitan Hardware IP Specifications: GPIO Peripheral}},
  year         = {2024},
  url          = {https://opentitan.org/book/hw/ip/gpio/},
  note         = {Accessed: 2026-10-01}
}

@techreport{natsemi_uart_16550,
  author       = {{National Semiconductor Corporation}},
  title        = {{PC16550D Universal Asynchronous Receiver/Transmitter with FIFOs Datasheet}},
  institution  = {National Semiconductor},
  year         = {2015}
}

@manual{nxp_i2c_2014,
  organization = {{NXP Semiconductors}},
  title        = {{UM10204 I2C-bus Specification and User Manual}},
  number       = {Rev. 6.0},
  year         = {2014}
}

@standard{jedec_sfdp_2019,
  organization = {{JEDEC Solid State Technology Association}},
  title        = {{Serial Flash Discoverable Parameters (SFDP)}},
  number       = {JESD216D},
  year         = {2019}
}

@manual{arm_axi4_2021,
  organization = {{ARM Ltd.}},
  title        = {{AMBA AXI and ACE Protocol Specification AXI3, AXI4, and AXI4-Lite}},
  number       = {ARM IHI 0022E},
  year         = {2021}
}

@standard{riscv_timer_2021,
  organization = {{RISC-V International}},
  title        = {{The RISC-V Instruction Set Manual, Volume II: Privileged Architecture}},
  number       = {Version 1.12},
  year         = {2021}
}

@standard{iso_canfd_2015,
  organization = {{International Organization for Standardization}},
  title        = {{Road Vehicles --- Controller Area Network (CAN) --- Part 1: Data Link Layer and Physical Signalling}},
  number       = {ISO 11898-1:2015},
  year         = {2015}
}

@standard{sd_association_2010,
  organization = {{SD Association}},
  title        = {{SD Specifications Part 1 Physical Layer Simplified Specification}},
  number       = {Version 3.01},
  year         = {2010}
}

@manual{philips_i2s_1996,
  organization = {{Philips Semiconductors}},
  title        = {{I2S Bus Specification}},
  year         = {1996}
}

@standard{riscv_plic_2020,
  organization = {{RISC-V International}},
  title        = {{RISC-V Platform-Level Interrupt Controller (PLIC) Specification}},
  number       = {Version 1.0.0},
  year         = {2020}
}

@standard{itut_h264_2021,
  organization = {{International Telecommunication Union}},
  title        = {{Advanced Video Coding for Generic Audiovisual Services}},
  number       = {Recommendation ITU-T H.264},
  year         = {2021}
}

@online{lowrisc_ibex_2024,
  author       = {{lowRISC Team}},
  title        = {{Ibex RISC-V Core Specification}},
  year         = {2024},
  url          = {https://github.com/lowRISC/ibex},
  note         = {Accessed: 2026-10-01}
}

@online{openhw_cv32e40p_2024,
  author       = {{OpenHW Group}},
  title        = {{CV32E40P User Manual}},
  year         = {2024},
  url          = {https://github.com/openhwgroup/cv32e40p},
  note         = {Accessed: 2026-10-01}
}
```
