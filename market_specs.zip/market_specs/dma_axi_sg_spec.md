# dma_axi_sg — Complete Industry-Standard AXI4 Scatter-Gather DMA Controller Specification

**Document Version**: 3.0  
**Compliance Standard**: ARM AMBA AXI4 / OpenHW Group Subsystem DMA Specification  
**Module Name**: `dma_axi_sg`  

---

## 1. Overview & Theory of Operation

`dma_axi_sg` is a high-performance 4-channel Scatter-Gather Direct Memory Access (DMA) controller. It autonomously fetches 32-byte descriptor data structures from DRAM via AXI4 master burst reads, executes memory-to-memory, memory-to-peripheral, or peripheral-to-memory transfers, and reports progress/completion via interrupts and status registers.

### 1.1 Key Architecture Features
- **4 Independent Channels**: Priority-based round-robin or fixed-priority channel arbitration.
- **Scatter-Gather Descriptor Engine**: Automatically traverses linked-list descriptors stored in DRAM.
- **AXI4 Master Interfaces**: Separate 64-bit Read (`AR`/`R`) and Write (`AW`/`W`/`B`) master channels supporting bursts up to 256 beats.
- **Internal Data FIFO**: 1 KB per-channel data buffering to hide DRAM access latencies.

---

## 2. Ports

### 2.1 Control Bus Interface (AXI4-Lite Slave)

| Port | Dir | Width | Description |
|---|---|---|---|
| `s_axil_aclk` | in | 1 | Clock domain for register access |
| `s_axil_aresetn` | in | 1 | Active-low reset |
| `s_axil_awaddr[11:0]` | in | 12 | Write address |
| `s_axil_awvalid` | in | 1 | Write address valid |
| `s_axil_awready` | out | 1 | Write address ready |
| `s_axil_wdata[31:0]` | in | 32 | Write data |
| `s_axil_wstrb[3:0]` | in | 4 | Write strobe byte enable |
| `s_axil_wvalid` | in | 1 | Write data valid |
| `s_axil_wready` | out | 1 | Write data ready |
| `s_axil_bresp[1:0]` | out | 2 | Write response |
| `s_axil_bvalid` | out | 1 | Write response valid |
| `s_axil_bready` | in | 1 | Write response ready |
| `s_axil_araddr[11:0]` | in | 12 | Read address |
| `s_axil_arvalid` | in | 1 | Read address valid |
| `s_axil_arready` | out | 1 | Read address ready |
| `s_axil_rdata[31:0]` | out | 32 | Read data |
| `s_axil_rresp[1:0]` | out | 2 | Read response |
| `s_axil_rvalid` | out | 1 | Read data valid |
| `s_axil_rready` | in | 1 | Read data ready |

### 2.2 System & Interrupt Signals

| Port | Dir | Width | Description |
|---|---|---|---|
| `dma_irq[3:0]` | out | 4 | Per-channel completion / error interrupts |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `DMA_CTRL` | RW | `0x00000000` | Global Enable and Channel Priority Config |
| `0x04` | `DMA_STATUS` | RO | `0x00000000` | Active channel status and error summary |
| `0x10` | `CH0_CTRL` | RW | `0x00000000` | Channel 0 Enable, Start, Mode, IRQ Enable |
| `0x14` | `CH0_DESC_PTR` | RW | `0x00000000` | Channel 0 Descriptor DRAM Address Pointer |
| `0x18` | `CH0_BYTES_DONE`| RO | `0x00000000` | Channel 0 Transferred byte count |
| `0x20` | `CH1_CTRL` | RW | `0x00000000` | Channel 1 Enable, Start, Mode, IRQ Enable |
| `0x24` | `CH1_DESC_PTR` | RW | `0x00000000` | Channel 1 Descriptor DRAM Address Pointer |

---

## 4. Scatter-Gather Descriptor Architecture & FSM

### 4.1 Descriptor Format (Stored in 32-Byte DRAM Layout)
- **Word 0**: `next_desc_ptr[31:0]` — Address of next descriptor (0 = End of chain).
- **Word 1**: `src_addr[31:0]` — Source DRAM/Peripheral address.
- **Word 2**: `dst_addr[31:0]` — Destination DRAM/Peripheral address.
- **Word 3**: `transfer_len[31:0]` — Total transfer size in bytes.
- **Word 4**: `control_flags[31:0]` — Bit 0: Interrupt on completion, Bit 1: Last descriptor, Bit 7:4: Burst size.

### 4.2 Channel DMA FSM State Machine
```
IDLE ──(CH_START & DESC_PTR != 0)──► FETCH_DESC ──► DECODE_DESC ──► BURST_READ_WRITE ──┐
  ▲                                                                                      │
  │                                                                                      │
  └───────────── COMPLETE ◄──────────────── CHECK_NEXT ◄────────────────────────────────┘
```
1. **FETCH_DESC**: Issues AXI4 `AR` burst to `CHx_DESC_PTR` to read 32 bytes into internal descriptor registers.
2. **BURST_READ_WRITE**: Issues AXI4 `AR` reads to `src_addr` and streams returned data into internal channel FIFO; issues AXI4 `AW`/`W` writes to `dst_addr`.
3. **CHECK_NEXT**: If `control_flags[1] == 0` and `next_desc_ptr != 0`, updates `CHx_DESC_PTR = next_desc_ptr` and loops back to `FETCH_DESC`.
