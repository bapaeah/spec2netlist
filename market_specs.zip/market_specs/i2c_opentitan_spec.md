# i2c_opentitan — Complete Industry-Standard I2C Host & Target Specification

**Document Version**: 2.1  
**Compliance Standard**: NXP I2C Bus Specification v6.0 / OpenTitan Architecture  
**Module Name**: `i2c_opentitan`  

---

## 1. Overview & Theory of Operation

`i2c_opentitan` is a full-featured I2C protocol controller supporting Host (Master) and Target (Slave) modes across Standard-mode (100 kbps), Fast-mode (400 kbps), and Fast-mode Plus (1 Mbps) bitrates. It includes SCL clock stretching, arbitration loss detection, 10-bit address support, and hardware Command/Data FIFOs.

### 1.1 Key Architecture Features
- **Dual Host & Target Operation**: Configurable as I2C bus master or slave device.
- **Hardware Command & Data FIFOs**: 64-entry Command FIFO (`FDATA`), 64-entry RX FIFO (`RDATA`), and 64-entry Format FIFO.
- **SCL Clock Stretch Handling**: SCL low-timeout detector preventing bus lockups when slave holds SCL low.
- **Arbitration Loss Detection**: Monitors SDA while driving; yields bus immediately on multi-master contention.

---

## 2. Ports

### 2.1 Bus Interface (APB Slave) & System Signals

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | System clock (50–100 MHz) |
| `rst_n` | in | 1 | Active-low asynchronous reset |
| `paddr[7:0]` | in | 8 | APB address bus |
| `psel` | in | 1 | APB select signal |
| `penable` | in | 1 | APB strobe enable |
| `pwrite` | in | 1 | APB write control |
| `pwdata[31:0]` | in | 32 | APB write data bus |
| `pready` | out | 1 | APB ready output |
| `prdata[31:0]` | out | 32 | APB read data bus |
| `pslverr` | out | 1 | APB slave error response |

### 2.2 I2C Open-Drain Bus Pins

| Port | Dir | Width | Description |
|---|---|---|---|
| `scl_in` | in | 1 | SCL pin input value |
| `scl_out` | out | 1 | SCL pin output drive (0=Drive Low, 1=Release) |
| `scl_oe` | out | 1 | SCL output enable (1=Open drain low drive) |
| `sda_in` | in | 1 | SDA pin input value |
| `sda_out` | out | 1 | SDA pin output drive (0=Drive Low, 1=Release) |
| `sda_oe` | out | 1 | SDA output enable (1=Open drain low drive) |
| `irq` | out | 1 | Aggregated level interrupt output |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `INTR_STATE` | W1C | `0x00000000` | Interrupt status register |
| `0x04` | `INTR_ENABLE` | RW | `0x00000000` | Interrupt enable mask |
| `0x08` | `CTRL` | RW | `0x00000000` | Enable Host mode, Target mode, and System Reset |
| `0x0C` | `STATUS` | RO | `0x00000000` | Bus busy, FIFO levels, SCL/SDA raw state |
| `0x10` | `FDATA` | WO | `0x00000000` | Command & Data Format FIFO (bits [7:0]=byte, bit 8=START, bit 9=STOP, bit 10=READ) |
| `0x14` | `RDATA` | RO | `0x00000000` | Receive Data FIFO readback |
| `0x18` | `FIFO_CTRL` | RW | `0x00000000` | FIFO reset strobes and interrupt watermark thresholds |
| `0x1C` | `SCL_TIME_HIGH`| RW | `0x00000100` | SCL High time counter cycles |
| `0x20` | `SCL_TIME_LOW` | RW | `0x00000100` | SCL Low time counter cycles |
| `0x24` | `TIMEOUT_CTRL` | RW | `0x00000000` | SCL Clock Stretch Timeout limit |

---

## 4. Detailed Functional Operation & Protocol FSM

### 4.1 Host Protocol State Machine
```
IDLE ──(FDATA read & START)──► START_GEN ──► ADDR_BYTE ──► ACK_CHECK
  ▲                                                             │
  │               ┌─────────────── READ/WRITE ──────────────────┘
  │               ▼
  │          DATA_BYTE ──► ACK_SEND/CHECK ──► STOP_GEN ──┐
  │               ▲                               │      │
  │               └───────────── (More Bytes) ────┘      │
  └──────────────────────────────────────────────────────┘
```

1. **START_GEN**: Pulls SDA low while SCL is high.
2. **ADDR_BYTE / DATA_BYTE**: Shifts out 8 bits on SDA during SCL low period. Releases SDA during SCL high to sample ACK/NACK.
3. **SCL STRETCHING**: When SCL is driven high, the FSM waits until `scl_in == 1` before starting high-count. If `scl_in` remains 0 beyond `TIMEOUT_CTRL`, flags `SCL_TIMEOUT` interrupt.
4. **STOP_GEN**: Pulls SDA high while SCL is high.
