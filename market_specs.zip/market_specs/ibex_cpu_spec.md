# Ibex CPU Core Specification

**Module Name**: `ibex_cpu`  
**Architecture**: RISC-V RV32IMC / RV32EC 32-bit Core  
**Provenance**: lowRISC / OpenTitan Project  
**Repository**: `https://github.com/lowRISC/ibex`  
**License**: Apache-2.0  
**Specification Version**: v2.1.0  

---

## 1. Functional Description

`ibex_cpu` is a production-grade, silicon-proven 32-bit RISC-V core designed for embedded control and security applications. It features an in-order 2-stage (or 3-stage) pipeline, hardware multiplier/divider, compressed instruction decoding, Physical Memory Protection (PMP), and full compliance with the RISC-V Machine Mode Privilege Specification v1.11.

In the target SoC subsystem, `ibex_cpu` serves as the primary system management and peripheral host controller, issuing memory-mapped read and write transactions over its bus interface to configure peripherals (GPIO, UART, I2C, SPI Host, Timers) and handle system interrupts via the RISC-V PLIC.

---

## 2. Key Features

- **Instruction Set Architecture (ISA)**: RV32I / RV32E base with extensions:
  - **M**: Hardware Multiplier (1-cycle or 3-cycle configurable) and Divider.
  - **C**: Compressed 16-bit instructions for high code density.
  - **B**: Bit Manipulation extension support (Zba, Zbb, Zbc, Zbs).
- **Pipeline Architecture**: 2-stage (Instruction Fetch, Execute/Writeback) or optional 3-stage (Fetch, Read/Execute, Writeback).
- **Memory Protection**: Configurable 16-region Physical Memory Protection (PMP).
- **Control & Status Registers (CSRs)**: Complete Machine-Mode (`M-mode`) CSR implementation (`mstatus`, `mie`, `mtvec`, `mepc`, `mcause`, `mtval`, `mip`, `mcycle`, `minstret`).
- **Interrupt Handling**: Fast interrupt interface + standard RISC-V PLIC external, timer, and software interrupt inputs with low interrupt latency.
- **Bus Interface**: Independent Instruction and Data memory ports adhering to standard handshake protocols (TileLink-UL / AXI4-Lite / APB bridgeable).

---

## 3. Clock & Reset Architecture

| Port Name | Type | Width | Description |
|---|---|---|---|
| `clk_i` | Input | 1 | Primary CPU clock (Nominal 50–100 MHz, fully static up to ASIC max) |
| `rst_ni` | Input | 1 | Asynchronous active-low reset signal |

---

## 4. Signal Interface Specification

### 4.1 Bus Interfaces (Instruction & Data Ports)

#### Instruction Fetch Port (`instr_*`)
| Signal | Direction | Width | Description |
|---|---|---|---|
| `instr_req_o` | Output | 1 | Instruction memory request enable |
| `instr_gnt_i` | Input | 1 | Instruction memory grant signal |
| `instr_rvalid_i` | Input | 1 | Instruction memory read data valid |
| `instr_addr_o` | Output | 32 | Instruction memory byte address |
| `instr_rdata_i` | Input | 32 | Fetched 32-bit instruction data |
| `instr_err_i` | Input | 1 | Instruction bus error indicator |

#### Data Load/Store Port (`data_*`)
| Signal | Direction | Width | Description |
|---|---|---|---|
| `data_req_o` | Output | 1 | Data memory access request enable |
| `data_gnt_i` | Input | 1 | Data memory grant signal |
| `data_rvalid_i` | Input | 1 | Data memory read/write transaction complete valid |
| `data_we_o` | Output | 1 | Data write enable (1 = Write, 0 = Read) |
| `data_be_o` | Output | 4 | Data byte enable mask for 32-bit words |
| `data_addr_o` | Output | 32 | Data memory target byte address |
| `data_wdata_o` | Output | 32 | 32-bit write data payload |
| `data_rdata_i` | Input | 32 | 32-bit read data payload |
| `data_err_i` | Input | 1 | Data bus error indicator |

### 4.2 Interrupt Interface
| Signal | Direction | Width | Description |
|---|---|---|---|
| `irq_software_i` | Input | 1 | Machine Software Interrupt input (`msip`) |
| `irq_timer_i` | Input | 1 | Machine Timer Interrupt input (`mtip`) |
| `irq_external_i` | Input | 1 | Machine External Interrupt input (`meip`) from PLIC |
| `irq_fast_i` | Input | 15 | Direct fast interrupt vector inputs |

---

## 5. Control & Status Register (CSR) Map

| Address | Name | Access | Description |
|---|---|---|---|
| `0x300` | `mstatus` | RW | Machine Status Register (Interrupt Enable `MIE`, Previous Enable `MPIE`) |
| `0x304` | `mie` | RW | Machine Interrupt Enable Register (`MEIE`, `MTIE`, `MSIE`) |
| `0x305` | `mtvec` | RW | Machine Trap-Vector Base Address (Direct or Vectored mode) |
| `0x340` | `mscratch` | RW | Machine Scratch Register |
| `0x341` | `mepc` | RW | Machine Exception Program Counter |
| `0x342` | `mcause` | RW | Machine Trap Cause Register (Interrupt flag + Exception code) |
| `0x343` | `mtval` | RW | Machine Trap Value Register |
| `0x344` | `mip` | RO | Machine Interrupt Pending Register |
| `0xB00` | `mcycle` | RO | 64-bit Cycle Counter (lower 32-bit) |
| `0xB02` | `minstret` | RO | 64-bit Instructions Retired Counter (lower 32-bit) |

---

## 6. Functional Execution Modes & Operation

1. **Reset Sequence**: Upon assertion of `rst_ni = 0`, the internal PC is cleared to the boot vector address (`0x80000000` or programmable `boot_addr_i`).
2. **Instruction Fetch**: The core asserts `instr_req_o` and drives `instr_addr_o`. Once `instr_gnt_i` and `instr_rvalid_i` are high, instructions enter the 2-stage pipeline decoder.
3. **Load/Store Execution**: Memory operations stall the execute stage until `data_gnt_i` and `data_rvalid_i` respond.
4. **Trap Handling**: When an exception (e.g., illegal instruction, misaligned access) or interrupt occurs, `mepc` latches the current PC, `mcause` latches the cause code, interrupts are disabled (`mstatus.MIE <= 0`), and PC jumps to `mtvec`. Returning via `mret` restores `mstatus.MIE <= mstatus.MPIE` and sets PC to `mepc`.
