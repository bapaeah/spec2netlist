# CV32E40P CPU Core Specification

**Module Name**: `cv32e40p_cpu`  
**Architecture**: RISC-V RV32IMFC / RV32F 32-bit Core  
**Provenance**: OpenHW Group / PULP Platform  
**Repository**: `https://github.com/openhwgroup/cv32e40p`  
**License**: Apache-2.0 / Solderpad Hardware License v0.51  
**Specification Version**: v1.8.0  

---

## 1. Functional Description

`cv32e40p_cpu` (formerly RI5CY) is a high-performance 4-stage in-order 32-bit RISC-V processor core designed by the PULP Platform team and standardized by the OpenHW Group. It supports the RV32IMFC instruction set along with custom PULP extension ISA enhancements including hardware loops, post-increment load/store operations, vector operations, and bit manipulation.

In modern SoC benchmark architectures, `cv32e40p_cpu` acts as an embedded application processor or DSP accelerator capable of executing floating-point math, high-throughput DSP loops, and controlling high-speed peripherals via its standardized Open Bus Interface (OBI).

---

## 2. Key Features

- **Instruction Set Architecture (ISA)**: RV32I base with:
  - **M**: 1-cycle integer multiplier and iterative divider.
  - **F**: IEEE 754-2008 single-precision Floating Point Unit (FPU).
  - **C**: Compressed 16-bit instructions.
  - **PULP Extensions**: Hardware loops (`lp.setup`), post-incrementing load/stores, MAC instructions, and SIMD 8/16-bit vector operations.
- **Pipeline Architecture**: 4-stage in-order pipeline:
  1. **IF**: Instruction Fetch stage.
  2. **ID**: Instruction Decode & Register File Read stage.
  3. **EX**: Execute stage (ALU, FPU, Multiplier, Branch Target calculation).
  4. **WB**: Writeback stage.
- **Bus Interface**: Dual Open Bus Interface (OBI) ports (Instruction OBI and Data OBI) featuring decoupling request/grant/valid handshakes compatible with AXI-Lite and AHB adapters.
- **Debug Module**: Native RISC-V External Debug Specification v0.13 compliance with JTAG interface support.

---

## 3. Clock & Reset Architecture

| Port Name | Type | Width | Description |
|---|---|---|---|
| `clk_i` | Input | 1 | CPU system clock (50 MHz – 250 MHz nominal) |
| `rst_ni` | Input | 1 | Asynchronous active-low master reset |

---

## 4. Signal Interface Specification

### 4.1 Bus Interfaces (OBI Instruction & Data Ports)

#### OBI Instruction Fetch Interface (`instr_obi_*`)
| Signal | Direction | Width | Description |
|---|---|---|---|
| `instr_req_o` | Output | 1 | OBI transaction request |
| `instr_gnt_i` | Input | 1 | OBI bus grant acknowledgement |
| `instr_rvalid_i` | Input | 1 | OBI read data valid |
| `instr_addr_o` | Output | 32 | Instruction fetch address |
| `instr_rdata_i` | Input | 32 | Fetched 32-bit instruction word |
| `instr_err_i` | Input | 1 | Instruction fetch bus error |

#### OBI Data Interface (`data_obi_*`)
| Signal | Direction | Width | Description |
|---|---|---|---|
| `data_req_o` | Output | 1 | OBI transaction request |
| `data_gnt_i` | Input | 1 | OBI bus grant acknowledgement |
| `data_rvalid_i` | Input | 1 | OBI read/write transaction complete valid |
| `data_we_o` | Output | 1 | Write enable (1 = Write, 0 = Read) |
| `data_be_o` | Output | 4 | Byte enable mask for 32-bit access |
| `data_addr_o` | Output | 32 | Target data address |
| `data_wdata_o` | Output | 32 | Write data payload |
| `data_rdata_i` | Input | 32 | Read data response payload |
| `data_err_i` | Input | 1 | Data bus error indicator |

### 4.2 Interrupt Interface
| Signal | Direction | Width | Description |
|---|---|---|---|
| `irq_i` | Input | 32 | 32-line vectored interrupt input bus (direct connection to PLIC / NVIC) |
| `irq_ack_o` | Output | 1 | Interrupt acknowledge signal |
| `irq_id_o` | Output | 5 | Vector ID of acknowledged interrupt |

---

## 5. Control & Status Register (CSR) Map

| Address | Name | Access | Description |
|---|---|---|---|
| `0x300` | `mstatus` | RW | Machine Status Register |
| `0x304` | `mie` | RW | Machine Interrupt Enable Register |
| `0x305` | `mtvec` | RW | Machine Trap Vector Base Address |
| `0x341` | `mepc` | RW | Machine Exception Program Counter |
| `0x342` | `mcause` | RW | Machine Trap Cause Register |
| `0x7C0` | `lpstart0` | RW | Hardware Loop 0 Start Address (PULP Extension) |
| `0x7C1` | `lpend0` | RW | Hardware Loop 0 End Address (PULP Extension) |
| `0x7C2` | `lpcount0` | RW | Hardware Loop 0 Iteration Counter (PULP Extension) |

---

## 6. Functional Execution Modes & Operation

1. **Instruction Fetch & OBI Handshake**: During `IF`, `instr_req_o` is driven high. When the memory subsystem responds with `instr_gnt_i = 1`, the bus pipeline registers the request, and `instr_rvalid_i = 1` delivers the instruction word.
2. **PULP Hardware Loop Execution**: When executing loops initialized by `lp.setup`, the instruction fetch engine automatically loops between `lpstart0` and `lpend0` without branch penalty until `lpcount0` decrements to 0.
3. **Interrupt Handling**: When any line of `irq_i[31:0]` is asserted and enabled in `mie`, the core completes the current pipeline stage, latches the vector into `irq_id_o`, asserts `irq_ack_o`, jumps to `mtvec + (irq_id << 2)`, and latches `mepc`.
