---
Document: H264D-U1000-CFG-REGS-SPEC
Title: h264d_cfg_regs — Complete Module Specification
Version: 1.0
Date: 2026-09-30
Module ID: 4.2 (per block-level design doc, user baseline)
Governs requirements: REQ-4.2.1, REQ-4.2.2, REQ-4.3.5, REQ-6.3.5, REQ-6.4.5, REQ-6.6.1, REQ-6.6.2
---

# h264d_cfg_regs — Complete Module Specification

## 1. Overview

`h264d_cfg_regs` is the configuration and status interface of the H264D-U1000.
It implements the complete AXI4-Lite register file (datasheet §4), per-context
banking, the FEATURE_LOCK write-once/eFuse mechanism, interrupt aggregation
and hold, and the CDC-safe distribution of configuration into the core clock
domain. It is the single point through which software controls the decoder;
no other register block exists.

| Attribute | Value |
|---|---|
| Instance count | 1 |
| Clock domain | `cfg_clk` (single clock; all logic synchronous to it) |
| Resets | `cfg_rst_n` (derived from `core_rst_n`, see §3.2) for general state; `por_n`-domain flops for FEATURE_LOCK |
| Power domain | ALWAYS_ON (never power-gated; must respond to register access in every state) |
| Bus interface | AXI4-Lite slave, 12-bit address, 32-bit data |
| Tiers | all (A100/B300/C400/D500) — identical RTL, parameter-visible differences only |

## 2. Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `NUM_CONTEXTS` | int | 1 | Number of context banks (1/1/1/4 for A/B/C/D) |
| `FUSED_SKU` | bit | 0 | 1 = eFuse shadow mode compiled in (C/D fused builds) |
| `ADDR_W` | int | 12 | AXI-Lite address width |
| `DATA_W` | int | 32 | AXI-Lite data width (fixed) |
| `SYNC_STAGES` | int | 2 | CDC synchronizer depth for status inputs |

## 3. Clock & Reset

### 3.1 Clock

- **cfg_clk** — sole clock for all logic. No internally generated clocks, no
  clock gating of the register storage (REQ-6.2.3 allows gating between
  transactions; internally this module keeps storage clocks free-running and
  gates only the AXI slave front-end enable — simplest CDC-safe choice).
- Frequency: 50-100 MHz nominal (datasheet §8.1). Fully static design; works
  at any frequency ≤ core_clk.
- cfg_clk is asynchronous to core_clk and mem_clk by definition (REQ-6.1.2).

### 3.2 Reset

| Signal | Polarity | Source | What it resets |
|---|---|---|---|
| `cfg_rst_n` | active-low, sync | `core_rst_n` from h264d_reset_ctrl, synchronized into cfg_clk | AXI slave FSM, all RW registers, bank storage, interrupt logic, snapshot handshake |
| `por_n` | active-low, async | External pin (via synchronizer) | FEATURE_LOCK storage + eFuse shadow latch ONLY (REQ-6.3.5, REQ-6.6.1) |

Reset ordering consequences:
- FEATURE_LOCK survives SOFT_RESET, per-context reset, and FLUSH_DPB —
  only a power-on reset can change it.
- After cfg_rst_n release, register access must be fully responsive within
  100 cfg_clk cycles (REQ-6.4.5); this module meets it with ≤ 4-cycle address
  decode + AXI pipelined response.

## 4. Complete Port List

### 4.1 AXI4-Lite Slave Interface (cfg_clk domain)

| Port | Dir | Width | Description |
|---|---|---|---|
| `s_axil_aclk` | in | 1 | = cfg_clk (port naming per AXI convention) |
| `s_axil_aresetn` | in | 1 | = cfg_rst_n |
| `s_axil_awaddr[11:0]` | in | 12 | Write address |
| `s_axil_awvalid` | in | 1 | Write address valid |
| `s_axil_awready` | out | 1 | Write address ready |
| `s_axil_wdata[31:0]` | in | 32 | Write data |
| `s_axil_wstrb[3:0]` | in | 4 | Byte enables (all registers 32-bit; partial writes supported per strobe) |
| `s_axil_wvalid` | in | 1 | Write data valid |
| `s_axil_wready` | out | 1 | Write data ready |
| `s_axil_bresp[1:0]` | out | 2 | Write response (OKAY=00; SLVERR=10 on decode faults) |
| `s_axil_bvalid` | out | 1 | Write response valid |
| `s_axil_bready` | in | 1 | Write response ready |
| `s_axil_araddr[11:0]` | in | 12 | Read address |
| `s_axil_arvalid` | in | 1 | Read address valid |
| `s_axil_arready` | out | 1 | Read address ready |
| `s_axil_rdata[31:0]` | out | 32 | Read data |
| `s_axil_rresp[1:0]` | out | 2 | Read response |
| `s_axil_rvalid` | out | 1 | Read data valid |
| `s_axil_rready` | in | 1 | Read data ready |

### 4.2 eFuse / Lock Interface

| Port | Dir | Width | Description |
|---|---|---|---|
| `lock_image[31:0]` | in | 32 | FEATURE_LOCK image from h264d_efuse_shadow (efuse_clk domain → synced) |
| `fuse_valid` | in | 1 | 1 = eFuse image is valid ECC-checked; 0 = treat as unfused |
| `fuse_shadow` | out | 1 | 1 = FUSE_SHADOW bit (FEATURE_LOCK is read-only mirror) |

### 4.3 Context Control / Status (per context i)

| Port | Dir | Width | Description |
|---|---|---|---|
| `cfg_snapshot[i]` | out | ~96 | CDC-safe config bundle to context i: outbuf_base, stride, frame dims, ref_config, conceal_en (see §6.4) |
| `snapshot_ack[i]` | in | 1 | Context i has latched the new snapshot (core_clk domain) |
| `irq_req[i]` | in | 1 | Interrupt request from context i (core_clk domain, synchronized) |
| `irq_en[i]` | out | 1 | Interrupt enable to context i |
| `irq[i]` | out | 1 | Interrupt line (level) to pins |

### 4.4 Reset Controller Interface

| Port | Dir | Width | Description |
|---|---|---|---|
| `rst_state[3:0]` | in | 4 | From h264d_reset_ctrl — drives RST_STATE (0x4C) readback |
| `sw_reset_req[i]` | out | 1 | SOFT_RESET request to reset_ctrl for context i (level until accepted) |
| `flush_req[i]` | out | 1 | FLUSH_DPB request to reset_ctrl for context i |
| `rst_ack[i]` | in | 1 | Reset/flush complete handshake from reset_ctrl |

### 4.5 Misc Status In (synchronized from core_clk)

| Port | Dir | Width | Description |
|---|---|---|---|
| `err_code[i][7:0]` | in | 8/ctx | Current error code from context i |
| `status_bits[i][3:0]` | in | 4/ctx | busy, frame_done, underrun, dpb_full (sticky at source) |
| `perf_bins[i][31:0]` | in | 32/ctx | CABAC bin counter |
| `perf_mbs[i][31:0]` | in | 32/ctx | MB counter |
| `err_conceal_cnt[i][15:0]` | in | 16/ctx | Concealed MB counter |

## 5. Register Map (authoritative — datasheet §4 restated with behavior)

### 5.1 Address Map

| Offset | Name | Access | W1C | Reset | Notes |
|---|---|---|---|---|---|
| 0x000 | CTRL | RW | — | 0 | bank 0 only; see 5.2 |
| 0x004 | STATUS | RO | — | 0 | per-bank |
| 0x008 | STREAM_MODE | RW | — | 0 | |
| 0x00C/0x010 | STREAM_DESC_PTR / CNT | RW | — | 0 | |
| 0x014/0x018 | OUTBUF_BASE / STRIDE | RW | — | 0 | |
| 0x01C/0x020 | FRAME_W_MB / FRAME_H_MB | RW | — | 0 | |
| 0x024 | REF_CONFIG | RW (clamped) | — | 0 | writes clamped per REQ-4.3.5 |
| 0x028 | PROFILE_LEVEL | RO | — | 0 | from seq_hdr (synced) |
| 0x02C | IRQ_STATUS | RW | W1C | 0 | |
| 0x030/0x034 | PERF_BIN_CNT / PERF_MB_CNT | RO | — | 0 | |
| 0x038 | ERR_CONCEAL_CNT | RO | — | 0 | |
| 0x03C | ERR_CODE | RO | — | 0 | latched until W1C via IRQ_STATUS or new picture |
| 0x040 | FEATURE_LOCK | W1C-once → RO | — | 0 | see §6.3 |
| 0x044 | LOCK_STATUS | RO | — | lock | mirror + fuse_shadow |
| 0x048 | RST_CMD | WO | — | — | b0 SW_RESET, b1 FLUSH_DPB (self-clearing; drives §4.4) |
| 0x04C | RST_STATE | RO | — | 0 | from reset_ctrl |
| 0x050 | VERSION | RO | — | 0x0100_0000 | RTL version, RO constant |

### 5.2 CTRL (0x000, bank 0)

| Bit | Name | Behavior |
|---|---|---|
| 0 | START | Write 1 → raises start pulse to all enabled contexts; self-clearing (reads 0) |
| 1 | SOFT_RESET | Write 1 → RST_CMD path to reset_ctrl (all contexts); self-clearing |
| 2 | IRQ_EN | Global interrupt enable |
| 3 | FLUSH_DPB | Write 1 → flush all contexts; self-clearing |

### 5.3 STATUS (0x004, per bank)

| Bit | Name | Source |
|---|---|---|
| 0 | BUSY | context busy (synced) |
| 1 | FRAME_DONE | sticky at context; W1C via IRQ_STATUS |
| 2 | STREAM_UNDERRUN | sticky |
| 3 | DPB_FULL | level from DPB |
| 15:8 | ERR_CODE | see unified error-code table (datasheet §4); ERR 1/10 from feature_qual |

### 5.4 IRQ_STATUS (0x02C, per bank) — Write-1-to-Clear

| Bit | Event |
|---|---|
| 0 | frame_done |
| 1 | error (any ERR_CODE ≠ 0) |
| 2 | stream underrun |
| 3 | dpb_full |
| 4 | lock_violation (ERR 1/10 raised by feature_qual) |
| 5 | soft_reset_done / flush_done (from rst_ack) |

Behavior: irq[i] = irq_en[i] & (IRQ_STATUS != 0). Level held until W1C
(REQ-6.1.4). Read of IRQ_STATUS returns unmasked pending bits.

## 6. Working Information (Functional Operation)

### 6.1 AXI4-Lite Slave Front-End

- Accepts one outstanding transaction each direction (AXI4-Lite compliant);
  awready/wready decoupled from bvalid generation so back-to-back writes
  pipeline at 1/cycle.
- Write flow: `AW+W` → address decode → per-byte masked write (wstrb) →
  `B(OKAY)`. Illegal address (unmapped offset or disabled bank) → `B(SLVERR)`,
  no state change.
- Read flow: `AR` → decode → mux readback → `R(OKAY/SLVERR)`. Read-only regs
  ignore writes silently (OKAY, no effect) — except FEATURE_LOCK which
  latches (§6.3).
- Decode fault cases: address above 0x050, bank ≥ NUM_CONTEXTS, access to
  context registers while that context is fused off (reads 0 / SLVERR per
  integration config; default SLVERR).

### 6.2 Banked Storage

- Address bits [11:10] select bank (context); bits [9:0] select register.
- Bank 0 also holds the global registers (CTRL, FEATURE_LOCK, LOCK_STATUS,
  RST_CMD, RST_STATE, VERSION) which ignore bank select (aliased in every
  bank for software convenience — recommended; strict alternative: only
  accessible in bank 0 → chosen at integration via `BANK_ALIAS_EN` param).
- All storage is 32-bit flops; no RAM required. Total ≈ 28 registers × 4 banks
  max = trivial area in D500.

### 6.3 FEATURE_LOCK Mechanism

The heart of tier control:

```
por_n ──┐
        ▼
┌──────────────────┐   fuse_valid=1     ┌───────────────┐
│ eFuse shadow     │───────────────────►│ FEATURE_LOCK  │
│ latch (por domain)│  lock_image       │ storage       │
└──────────────────┘                    │ (por domain)  │
        ▲                               └──────┬────────┘
        │                              first write │ (if unfused)
   lock_image, fuse_valid              after por ──► latch & freeze
```

- **Fused (FUSED_SKU=1, fuse_valid=1):** FEATURE_LOCK is a read-only mirror;
  writes return OKAY but have no effect; LOCK_STATUS.fuse_shadow=1.
- **Unfused:** first write after por_n latches the value; all subsequent
  writes ignored; LOCK_STATUS shows latched value with fuse_shadow=0.
- The lock value fans out (already synchronized) to: feature_qual
  (qualification), cg_ctrl (clock-gate masks), and the snapshot bundle
  (REF_CONFIG clamping).
- Only por_n can reset FEATURE_LOCK storage — never cfg_rst_n (REQ-6.3.5);
  a soft reset therefore never changes the licensed tier (REQ-6.6.1).

### 6.4 CDC-Safe Config Distribution (snapshot mechanism)

cfg_snapshot carries OUTBUF_BASE, STRIDE, FRAME_W/H_MB, REF_CONFIG, CONCEAL_EN
into the core_clk domain without direct CDC:

```
cfg_clk:  SW writes regs ──► snapshot_pending=1 ──► request toggle (T)
                                    │                      │
core_clk:                            │               2-flop sync T'
                                    │                      │
                                    │               latch snapshot regs
                                    │               (stable while pending)
                                    │                      │
                                    │               snapshot_ack pulse
                                    │◄─────────────────────┘
cfg_clk:  2-flop sync ack ──► clear pending; allow next SW write
```

Rules:
- Snapshot registers are stable from SW-write until ack returns — the
  handshake guarantees the core sees a consistent bundle (REQ-6.5.1).
- Multiple writes while pending: coalesce (latest value wins); no loss because
  pending blocks only the *next* snapshot request, not the register writes.

### 6.5 Interrupt Logic

- `irq_req[i]` synchronized (2-flop) from core_clk; sets the corresponding
  IRQ_STATUS sticky bit.
- `irq[i] = (IRQ_STATUS[i] != 0) & irq_en[i] & global_irq_en`.
- Level output held until W1C (REQ-6.1.4). No pulse stretching needed —
  sticky status bits absorb any request pulse.

### 6.6 RST_CMD / Reset Handshake

- Write to RST_CMD: bit set → drive `sw_reset_req[i]`/`flush_req[i]` level
  to reset_ctrl; register self-clears immediately (WO, reads 0).
- reset_ctrl executes the operation and returns `rst_ack[i]`; the ack sets
  IRQ_STATUS.soft_reset_done (bit 5) so software gets completion via interrupt.
- Denied second request while rst_ack pending: write accepted but flagged via
  STATUS bit (sticky "reset_busy").

### 6.7 REF_CONFIG Clamping (REQ-4.3.5)

- On write: value clamped to min(elaboration NUM_REF_FRAMES, lock-equivalent
  limit) and stored; read returns the clamped value.
- Clamp limit lives in the lock image; recomputed only when FEATURE_LOCK
  latches (por), so the clamp is static per power-cycle.

### 6.8 Performance / Error Behavior

| Property | Value |
|---|---|
| Register access latency | ≤ 4 cfg_clk cycles (AR→RVALID) |
| Back-to-back throughput | 1 transaction/cycle sustained |
| Unmapped access | SLVERR, no side effects |
| Access during decoder busy | Fully safe — all config registers are shadowed; contexts read snapshots only at picture boundaries |
| Behavior in any reset state | Registers always accessible (ALWAYS_ON PD); values reflect reset progress via RST_STATE |

## 7. Internal Block Structure

```
s_axil_* ──►┌──────────────┐ addr/bank ──►┌──────────────┐
            │ AXI4-LITE    │              │ ADDRESS      │
            │ SLAVE FSM    │              │ DECODE +     │
            │ (cfg_clk)    │              │ BANK SELECT  │
            └──────┬───────┘              └──────┬───────┘
                   │ wdata/wstrb                 │
                   ▼                             ▼
            ┌─────────────────────────────────────┐
            │ REGISTER STORAGE (banked flops)     │
            │ CTRL/STATUS/DESC/OUTBUF/DIMS/REF    │
            └──────┬──────────────────┬───────────┘
                   │                  │
        ┌──────────▼───────┐   ┌──────▼──────────┐
        │ FEATURE_LOCK     │   │ IRQ LOGIC       │
        │ por-domain latch │   │ (W1C, mask, lvl)│
        └──────────┬───────┘   └──────┬──────────┘
                   │                  │
        ┌──────────▼──────────────────▼───────────┐
        │ SNAPSHOT HANDSHAKE + CDC (toggle/ack)   │
        └──────────┬──────────────────┬───────────┘
                   │ cfg_snapshot[i]  │ irq_en[i]
                   ▼                  ▼
              contexts (core_clk)   intr_ctrl/pins
```

## 8. Verification Checklist (for this module)

- W1C semantics: set/clear/no-clear on 0-write, readback correctness
- FEATURE_LOCK: first-write latch, second-write ignore, por-only reset,
  fused read-only mirror mode
- Bank decode: all banks, disabled-bank SLVERR
- Snapshot handshake: no lost updates under back-to-back writes; stable
  bundle during core_clk latch; ack round-trip
- Interrupt: level hold, W1C clear, enable/mask paths
- Clamping: REF_CONFIG min() behavior with each lock image
- Reset: cfg_rst_n clears storage except FEATURE_LOCK; ≤100-cycle
  responsiveness post-release (REQ-6.4.5)
- Protocol: AXI4-Lite compliance (SVA assertions: stable-state rules,
  XVALID→XREADY progress, no OKAY-on-fault)
