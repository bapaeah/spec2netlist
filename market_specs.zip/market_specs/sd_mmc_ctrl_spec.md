# sd_mmc_ctrl — SD/eMMC Physical Layer v3.0 Host Specification

**Document Version**: 2.0  
**Compliance Standard**: SD Physical Layer Specification v3.0 / eMMC v4.51  
**Module Name**: `sd_mmc_ctrl`  

---

## 1. Overview & Theory of Operation

`sd_mmc_ctrl` is a high-speed SD/eMMC host controller supporting 1-bit and 4-bit bus widths, High Speed (50 MHz) clock rates, hardware CRC7 command verification, CRC16 data block verification, and automatic command response decoding.

---

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | Clock |
| `rst_n` | in | 1 | Reset |
| `haddr[7:0]` | in | 8 | AHB address |
| `hsel` | in | 1 | AHB select |
| `hwrite` | in | 1 | AHB write strobe |
| `htrans[1:0]` | in | 2 | AHB transfer type |
| `hwdata[31:0]` | in | 32 | AHB write data |
| `hreadyout` | out | 1 | AHB ready |
| `hrdata[31:0]` | out | 32 | AHB read data |
| `hresp` | out | 1 | AHB response |
| `sd_clk` | out | 1 | SD card clock output |
| `sd_cmd_in` | in | 1 | SD command in |
| `sd_cmd_out` | out | 1 | SD command out |
| `sd_cmd_oe` | out | 1 | SD command enable |
| `sd_data_in[3:0]` | in | 4 | SD data in |
| `sd_data_out[3:0]` | out | 4 | SD data out |
| `sd_data_oe` | out | 1 | SD data enable |
| `irq` | out | 1 | SD interrupt |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `ARGUMENT` | RW | `0x00000000` | 32-bit Command Argument |
| `0x04` | `COMMAND` | RW | `0x00000000` | Command Index, Response Type, Transfer Mode |
| `0x08` | `RESP0` | RO | `0x00000000` | Card Response Word 0 |
| `0x0C` | `RESP1` | RO | `0x00000000` | Card Response Word 1 |
| `0x10` | `STATUS` | RO | `0x00000000` | Cmd Busy, Data Busy, CRC Error flags |
| `0x14` | `INTR_ENABLE`| RW | `0x00000000` | Interrupt enable mask |
