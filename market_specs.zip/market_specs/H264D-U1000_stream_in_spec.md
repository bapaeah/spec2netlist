---
Document: H264D-U1000-STREAM-IN-SPEC
Title: h264d_stream_in — Complete Module Specification
Version: 1.0
Date: 2026-10-01
Module ID: 5.1 (per block-level design doc, user baseline)
Governs requirements: REQ-5.3.1 (throughput), REQ-6.4.3 (reset), REQ-6.5 (CDC), REQ-4.3.4 (per-context isolation)
---

# h264d_stream_in — Complete Module Specification

## 1. Overview

`h264d_stream_in` is the input front-end of each decode context. It captures the
H.264 byte stream (Annex-B format) from one of two sources — an AXI4-Stream
slave port, or a DRAM ring buffer filled by an autonomous DMA engine — and
delivers it to `h264d_nal_parse` in the core clock domain with flow control,
overflow/underrun protection, and clean quiescence under context reset.

| Attribute | Value |
|---|---|
| Instance count | NUM_CONTEXTS (1 per context) |
| Clock domains | `core_clk` (main datapath), `mem_clk` (DMA/AXI side), `s_axis_aclk[i]` (external, async) |
| Resets | `ctx_rst_n` (core side), `mem_rst_n`-aligned DMA reset (see §3.2) |
| Power domain | PD_CTX[i] (power-gates with its context) |
| Tiers | all (A100 uses Mode 0 only — A100 has no DRAM); B/C/D use both modes |

### 1.1 Operating Modes (selected by cfg snapshot `STREAM_MODE`)

| Mode | Source | Path |
|---|---|---|
| 0 — AXIS | Live stream (TS demux, network, CSI) | s_axis → async FIFO → nal_parse |
| 1 — DRAM descriptor | CPU/file-backed stream | descriptors → DMA → DRAM ring → nal_parse |

Mode is sampled at picture start; mid-stream mode switches are rejected
(ERR latched, mode change honored at next picture boundary).

## 2. Parameters

| Parameter | Type | Default | Description |
|---|---|---|---|
| `AXIS_DATA_W` | int | 32 | s_axis data width (fixed 32 in v1) |
| `FIFO_DEPTH` | int | 512 | AXIS async FIFO depth (words) → 2 KB buffering |
| `RING_BYTES` | int | 2 MB | DRAM ring capacity (B300); 4 MB C/D |
| `DMA_MAX_BURST` | int | 64 | Max AXI beats per DMA write burst |
| `DESC_MAX` | int | 256 | Max descriptors per list |
| `SYNC_STAGES` | int | 2 | CDC synchronizer depth |

## 3. Clock & Reset

### 3.1 Clocks

| Clock | Used for | Notes |
|---|---|---|
| `core_clk` | Output datapath to nal_parse, mode/ring control FSM, status regs | Sole clock for logic seen by the rest of the decode pipeline |
| `mem_clk` | DMA write engine, descriptor fetch, AXI request generation | Async to core_clk (REQ-6.1.2) |
| `s_axis_aclk[i]` | AXIS slave port only | Fully external; may equal any system clock; crossed via async FIFO |

### 3.2 Reset

| Signal | Domain | Behavior |
|---|---|---|
| `ctx_rst_n` | core_clk (from reset_ctrl) | Resets all core-side logic: output staging, ring read pointer, mode FSM, status. On assertion: stop forwarding to nal_parse within 1 cycle |
| `dma_rst_n` | mem_clk | = mem_rst_n ANDed with synchronized ctx_rst_n request. Resets DMA engine, descriptor state, AXI pending counters, ring write pointer |
| Reset sequencing | — | ctx_rst_n assert → DMA stop request synchronized to mem_clk → engine finishes or aborts outstanding bursts → `busy` drops → reset_ctrl sees quiescence (REQ-6.4.3) |

Guarantee: **zero outstanding AXI transactions** before reset completes —
the DMA engine counts issued vs. completed bursts (`aw` issued, `b` received)
and reset_ctrl only proceeds after they match (REQ-6.4.3b).

## 4. Complete Port List

### 4.1 AXI4-Stream Slave (s_axis_aclk[i] domain)

| Port | Dir | Width | Description |
|---|---|---|---|
| `s_axis_tdata` | in | 32 | Bitstream words, Annex-B byte order (tdata[7:0] = first byte) |
| `s_axis_tvalid` | in | 1 | Data valid |
| `s_axis_tready` | out | 1 | Ready; deasserts on FIFO full or ctx reset |
| `s_axis_tlast` | in | 1 | Marks end of NAL-unit delivery batch (informational; logged) |
| `s_axis_tuser` | in | 1 | Sideband: tuser=1 marks timestamp sync point (PTS capture) |

### 4.2 Configuration Snapshot (core_clk, from cfg_regs — stable per picture)

| Port | Dir | Width | Description |
|---|---|---|---|
| `stream_mode` | in | 1 | 0 = AXIS, 1 = DRAM descriptor |
| `desc_list_ptr[31:0]` | in | 32 | DRAM address of descriptor array (Mode 1) |
| `desc_count[15:0]` | in | 16 | Number of descriptors (≤ DESC_MAX) |
| `ring_base[31:0]` | in | 32 | Ring buffer DRAM base (Mode 1) |
| `cfg_update` | in | 1 | Strobe: new snapshot latched at last picture boundary |

### 4.3 To nal_parse (core_clk domain)

| Port | Dir | Width | Description |
|---|---|---|---|
| `strm_data[7:0]` | out | 8 | Byte-serial RBSP-boundary stream (start codes included) |
| `strm_valid` | out | 1 | Data valid |
| `strm_ready` | in | 1 | Back-pressure from nal_parse |
| `strm_underrun` | out | 1 | Pulse: consumer starved in Mode 1 (ring empty) |
| `pts_meta[31:0]` | out | 32 | Timestamp captured at tuser sync point, propagated with the stream |

### 4.4 Memory Arbiter Interface — DMA Engine (mem_clk domain)

| Port | Dir | Width | Description |
|---|---|---|---|
| `dma_ar_req / ar_addr / ar_len` | out | 32+8 | Descriptor fetch reads (from desc_list_ptr) |
| `dma_r_data / r_valid` | in | AXI_DATA_W | Read data return |
| `dma_aw_req / aw_addr / aw_len` | out | 32+8 | Ring-buffer write bursts |
| `dma_w_data / w_valid / w_last` | out | AXI_DATA_W+2 | Write data channel |
| `dma_b_valid / b_resp` | in | 2 | Write completion; SLVERR → DMA abort + ERR 8 path |
| `dma_qos` | out | 4 | Fixed 0x2 (stream class) |

### 4.5 Ring Read Port — Mode 1 replay (core_clk domain, issues via mem_clk)

| Port | Dir | Width | Description |
|---|---|---|---|
| `ring_rd_req / rd_addr / rd_len` | out | 32+8 | Reads of ring content for nal_parse (arbitrated, QoS 0x2) |
| `ring_rd_data / rd_valid` | in | AXI_DATA_W | Returned ring data |

### 4.6 Status / Handshake

| Port | Dir | Width | Description |
|---|---|---|---|
| `busy` | out | 1 | Core has in-flight data or DMA activity (to reset_ctrl quiesce check) |
| `underrun_sticky` | out | 1 | Latched underrun → STATUS.STREAM_UNDERRUN |
| `desc_err` | out | 1 | Pulse: descriptor fault → STATUS.ERR_CODE = 8 |
| `fifo_level[8:0]` | out | 9 | Diagnostic: AXIS FIFO occupancy |
| `ring_wptr[31:0]`, `ring_rptr[31:0]` | out | 32+32 | Diagnostic: ring pointers |

## 5. Functional Operation

### 5.1 Mode 0 — AXI4-Stream Path

```
s_axis(tdata 32b, aclk) ──►┌───────────────┐ strm_data[7:0] ──► nal_parse
                           │ ASYNC FIFO    │ (byte de-serializer:
             tready ◄──────│ 512 x 32b    │  4 bytes/word, MSB first)
   full/empty (gray ptrs)  │ gray-coded    │◄── strm_ready back-pressure
                           └───────────────┘
```

- 32-bit words are de-serialized to byte stream: `tdata[7:0]` first, per
  Annex-B byte order; `strm_valid` held until `strm_ready`.
- `tready = ~fifo_full & ~ctx_reset_active`. FIFO full for >1 µs → overflow
  flag (sticky; decode continues, bytes dropped — logged via PERF/debug).
- `tuser` sync points latch the 32-bit PTS into `pts_meta`, forwarded
  alongside the byte stream so DPB/display can align audio.
- Depth rationale: 2 KB absorbs AXIS jitter at 120 Mbps with ≥ 100 µs margin.

### 5.2 Mode 1 — DRAM Descriptor + Ring Buffer

This mode lets software hand the decoder a scatter-list of stream chunks
(e.g., a file from the OS, an HLS segment chain) and decode autonomously.

**Descriptor format (4 words each, little-endian in DRAM):**

| Word | Field |
|---|---|
| 0 | `addr[31:0]` — DRAM address of stream chunk |
| 1 | `len[31:0]` — chunk length in bytes |
| 2 | `flags[7:0]` — b0=PTS_valid, b1=last_descriptor, b7:4=rsvd |
| 3 | `pts[31:0]` — optional timestamp |

**DMA FSM (mem_clk):**

```
IDLE ──(cfg_update & mode=1)──► FETCH_DESC ──► DMA_CHUNK ──► NEXT?
   ▲                                                    │
   │              (desc_err: SLVERR/bad len)             │ last desc?
   └─────────────────────────────────────────────────────┘
        ▲ ring_full ──► STALL (wptr == rptr-1, wait)
```

- FETCH_DESC: reads 16B descriptor via arbiter read.
- DMA_CHUNK: copies `len` bytes from `addr` to ring at `wptr`, bursting
  ≤ DMA_MAX_BURST beats; handles unaligned head/tail bytes. Ring wrap at
  RING_BYTES boundary. `b_resp` SLVERR or `len` misaligned (<4 with no tail
  handling) → abort, `desc_err`, ERR 8.
- Flow control: DMA stalls when ring would overwrite unread data
  (`wptr_next == rptr_synced`); resumes on read progress.

**Ring replay (core_clk):** a read engine issues `ring_rd_req` bursts ahead of
nal_parse consumption (64-256B prefetch), buffers in a small skid FIFO, and
feeds `strm_data` identically to Mode 0 — **nal_parse cannot tell the modes
apart** (key simplification: one downstream contract).
- Ring empty at a NAL boundary → wait; empty mid-NAL with `strm_valid` demanded
  → `strm_underrun` pulse + sticky status (software must refill ring or abort).

### 5.3 Reset & Quiescence Behavior (REQ-6.4.3)

On `ctx_rst_n` assertion:
1. `strm_valid` deasserts ≤ 1 core_clk cycle; nal_parse sees clean stream end.
2. Reset request synced to mem_clk; DMA engine: finish current beat, **no new
   bursts**, wait `b_valid` for all issued writes (`pending == 0`).
3. AXIS FIFO flushed; ring pointers cleared.
4. `busy` drops → reset_ctrl proceeds; whole sequence ≤ 500 core cycles budget
   (shared with context pipeline, REQ-6.4.3e).

### 5.4 Error Handling

| Condition | Detection | Action |
|---|---|---|
| FIFO overflow (Mode 0) | FIFO full & tvalid | Drop bytes, sticky overflow flag, continue |
| Ring underrun (Mode 1) | ring empty & nal_parse requesting | strm_underrun pulse + sticky STATUS bit |
| Descriptor fault | SLVERR on desc read, len==0, addr misaligned beyond tail handling | Abort list, ERR_CODE=8, FRAME_DONE-err interrupt |
| Ring overflow (logic fault) | wptr crosses rptr despite stall | Fatal: ERR 5-family (internal), SOFT_RESET required |

### 5.5 Performance

| Property | Value |
|---|---|
| Sustained input rate | ≥ 120 Mbps per context (D500 4K30 headroom) |
| AXIS back-pressure tolerance | 512 words (2 KB) without underrun |
| Mode 1 prefetch | ≥ 256 bytes ahead of consumption; DRAM latency 200 cycles hidden |
| DMA efficiency | ≥ 90% of beats full-length (descriptor tails excepted) |

## 6. Internal Block Structure

```
Mode 0: s_axis ──► async FIFO ──┐
                                ├──►┌──────────────┐ strm_data/valid ──► nal_parse
Mode 1: desc DMA ──► DRAM ring ─┘   │ BYTE STAGE + │◄── strm_ready
        (mem_clk: desc FSM,         │ SKID FIFO    │
         write engine,              └──────┬───────┘
         burst packer)                     │ ring read prefetch engine
        ┌──────────────────────────────────┤ (core_clk requester,
        │ RING PTR MGMT (wptr mem_clk,     │  mem_clk datapath)
        │ rptr core_clk, synced both ways) │
        └──────────────────────────────────┘
```

CDC boundaries: AXIS FIFO (gray), ring pointers (gray + handshake), DMA
status→core (2-flop + pulse stretch), reset request (toggle handshake).

## 7. Verification Checklist

- Mode 0: byte order, tready back-pressure, overflow drop + flag, tuser/PTS latch
- Mode 1: descriptor walk (multi-chunk, last flag), ring wrap-around, DMA stall
  on full, underrun pulse timing, SLVERR → ERR 8 abort
- Reset: zero-outstanding guarantee asserted (SVA: `pending == 0` before ack),
  strm_valid clean deassert, ≤ 500-cycle budget
- CDC: FIFO gray-pointer protocol assertions, pointer sync correctness under
  randomized delay
- Equivalence: Mode 0 vs Mode 1 outputs bit-identical on same stream bytes
- Throughput: sustained 120 Mbps per context, 4 contexts concurrent (D500),
  no underrun with 200-cycle DRAM latency injection
