# Top-Level SoC Subsystem Specification (`soc_subsystem_top`)

**Module Name**: `soc_subsystem_top`  
**Architecture**: Heterogeneous RISC-V Multimedia & Edge AI SoC Subsystem  
**Target Submission**: IEEE/ACM DAC 2027  
**Specification Version**: v1.0.0  

---

## 1. Executive Summary & SoC Architecture

`soc_subsystem_top` is an integrated System-on-Chip (SoC) benchmarking platform that connects a 32-bit RISC-V CPU Core (`ibex_cpu` or `cv32e40p_cpu`), 15 market-standard peripheral and hardware acceleration IPs, a dual-layer interconnect (AXI4 High-Speed Crossbar + APB Peripheral Bridge), a 32-Vector Platform-Level Interrupt Controller (PLIC), and an Always-On (AON) low-power clock domain.

The SoC provides an end-to-end silicon-proven benchmark platform covering three performance tiers:
1. **Low-Speed Control Tier**: GPIO, UART 16550, I2C Host, Quad-SPI Host, Timer/PWM, Watchdog, Real-Time Clock (RTC).
2. **Medium-Speed System Tier**: CAN-FD, SD/MMC Host, I2S Audio, RISC-V PLIC, AXI4 Scatter-Gather DMA.
3. **High-Speed Acceleration Tier**: H.264 Video Decoder (Configuration Registers, Stream Input Engine, Annex-B NAL Parser).

---

## 2. Block Diagram & System Architecture

```
                                      ┌───────────────────────────────────────────────────────────┐
                                      │                  `soc_subsystem_top`                      │
                                      └───────────────────────────────────────────────────────────┘
                                                                    │
           ┌────────────────────────────────────────────────────────┴────────────────────────────────────────────────────────┐
           │                                                                                                                 │
   ┌───────────────┐                                                                                                 ┌───────────────┐
   │  ibex_cpu /   │ (Master Host Core)                                                                              │ Boot ROM &    │
   │  cv32e40p_cpu │                                                                                                 │ System SRAM   │
   └───────┬───────┘                                                                                                 └───────┬───────┘
           │ Instruction / Data OBI / AXI                                                                                    │ 128KB SRAM
           ▼                                                                                                                 ▼
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                             AXI4 HIGH-SPEED SYSTEM CROSSBAR MATRIX                                               │
└───────┬──────────────────────┬──────────────────────┬──────────────────────┬──────────────────────┬──────────────────────┬───────┘
        │                      │                      │                      │                      │                      │
        ▼                      ▼                      ▼                      ▼                      ▼                      ▼
┌───────────────┐      ┌───────────────┐      ┌───────────────┐      ┌───────────────┐      ┌───────────────┐      ┌───────────────┐
│ AXI SG-DMA    │      │ H.264 Stream  │      │ H.264 NAL     │      │ H.264 Config  │      │ SD/MMC Host   │      │ APB Bridge    │
│ (dma_axi_sg)  │      │ (stream_in)   │      │ (nal_parse)   │      │ (cfg_regs)    │      │ (sd_mmc_ctrl) │      │ Controller    │
└───────────────┘      └───────────────┘      └───────────────┘      └───────────────┘      └───────────────┘      └───────┬───────┘
                                                                                                                           │ APB Bus
                                                                                                                           ▼
┌──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│                                                   APB PERIPHERAL BUS SLAVES                                                      │
├──────────────┬──────────────┬──────────────┬──────────────┬──────────────┬──────────────┬──────────────┬──────────────┬──────────────┤
│ PLIC (IRQ)   │ GPIO         │ UART 16550   │ I2C Host     │ SPI Host     │ Timer & PWM  │ Watchdog WDT │ RTC Core     │ CAN-FD       │
│ 0x4000_0000  │ 0x4001_0000  │ 0x4002_0000  │ 0x4003_0000  │ 0x4004_0000  │ 0x4005_0000  │ 0x4006_0000  │ 0x4007_0000  │ 0x4008_0000  │
└──────────────┴──────────────┴──────────────┴──────────────┴──────────────┴──────────────┴──────────────┴──────────────┴──────────────┘
```

---

## 3. Clock & Reset Tree

The SoC subsystem operates across 5 decoupled clock domains to optimize power consumption and performance:

| Clock Domain | Frequency | Primary Modules Connected | Description |
|---|---|---|---|
| `clk_sys` | **50 – 100 MHz** | `ibex_cpu`, APB Bridge, PLIC, GPIO, UART, I2C, SPI, Timer | Main System Bus & CPU Clock |
| `clk_32k` | **32.768 kHz** | `rtc_core`, `watchdog_wdt` | Always-On (AON) Crystal Clock for Low-Power Timekeeping |
| `can_clk` | **40.000 MHz** | `can_fd_ctrl` | Dedicated ISO 11898-1 CAN Transceiver Clock |
| `mclk_audio`| **12.288 MHz** | `i2s_audio` | Audio Master Clock for 48/96 kHz Audio Sampling |
| `clk_video` | **150 – 250 MHz**| `dma_axi_sg`, `stream_in`, `nal_parse`, `cfg_regs` | High-Speed Video Processing & AXI Memory Clock |

### Reset Distribution
- `rst_sys_n`: Global active-low system reset synchronized across `clk_sys`.
- `rst_aon_n`: Power-On-Reset (POR) active-low reset for the 32.768 kHz domain (`rtc_core` and `watchdog_wdt`).

---

## 4. SoC System Memory & Peripheral Register Map

The SoC utilizes a 32-bit flat memory-mapped address space.

### 4.1 Global Memory Map Overview

| Address Range | Size | Allocation / Subsystem | Interface | Access |
|---|---|---|---|---|
| `0x0000_0000 – 0x0000_7FFF` | 32 KB | **Boot ROM** (Bootloader Firmware) | AXI4 Slave | Read-Only |
| `0x4000_0000 – 0x400E_FFFF` | 1 MB | **Peripheral & Accelerator Register Space** | APB / AXI-Lite | Read / Write |
| `0x8000_0000 – 0x8001_FFFF` | 128 KB | **On-Chip System SRAM** (Data/Stack RAM) | AXI4 Slave | Read / Write |
| `0x9000_0000 – 0x9FFF_FFFF` | 256 MB | **External DDR Memory Window** | AXI4 Master | Read / Write |

---

### 4.2 Peripheral Base Address & Detailed Register Map

All peripheral slave blocks are mapped into the `0x4000_0000` base region with 64 KB alignment per module:

```
+---------------------------------------------------------------------------------------------------+
| BASE ADDRESS | MODULE NAME           | TYPE     | REGISTERS & OFFSETS MAP                          |
+---------------------------------------------------------------------------------------------------+
| 0x4000_0000   | interrupt_ctrl        | PLIC     | 0x00: PRIORITY[1..31]  (RW)                      |
|              | (RISC-V PLIC)         |          | 0x04: PENDING_0        (RO)                      |
|              |                       |          | 0x08: ENABLE_0         (RW)                      |
|              |                       |          | 0x0C: THRESHOLD        (RW)                      |
|              |                       |          | 0x10: CLAIM_COMPLETE   (RW)                      |
+---------------------------------------------------------------------------------------------------+
| 0x4001_0000   | gpio_opentitan        | APB      | 0x00: DATA_IN          (RO)                      |
|              | (GPIO Controller)     |          | 0x04: DATA_OUT         (RW)                      |
|              |                       |          | 0x08: DIRECT_OE        (RW)                      |
|              |                       |          | 0x18: INTR_ENABLE      (RW)                      |
|              |                       |          | 0x30: CTRL_DEBOUNCE    (RW)                      |
+---------------------------------------------------------------------------------------------------+
| 0x4002_0000   | uart_16550            | APB      | 0x00: RBR / THR / DLL  (RW)                      |
|              | (16550 UART)          |          | 0x04: IER / DLM        (RW)                      |
|              |                       |          | 0x08: IIR / FCR        (RW/WO)                   |
|              |                       |          | 0x0C: LCR              (RW)                      |
|              |                       |          | 0x10: MCR              (RW)                      |
|              |                       |          | 0x14: LSR              (RO)                      |
+---------------------------------------------------------------------------------------------------+
| 0x4003_0000   | i2c_opentitan         | APB      | 0x00: INTR_STATE       (RW1C)                    |
|              | (I2C Host)            |          | 0x04: INTR_ENABLE      (RW)                      |
|              |                       |          | 0x08: CTRL             (RW)                      |
|              |                       |          | 0x0C: STATUS           (RO)                      |
|              |                       |          | 0x10: FDATA            (WO) Command/Tx FIFO      |
|              |                       |          | 0x14: RDATA            (RO) Rx FIFO Data         |
+---------------------------------------------------------------------------------------------------+
| 0x4004_0000   | spi_host_opentitan    | APB      | 0x00: CONTROL          (RW)                      |
|              | (Quad-SPI Host)       |          | 0x04: STATUS           (RO)                      |
|              |                       |          | 0x08: CONFIGOP         (RW) CS/CPOL/CPHA         |
|              |                       |          | 0x10: COMMAND          (WO) Command Issue        |
|              |                       |          | 0x14: TXDATA           (WO) Tx FIFO              |
|              |                       |          | 0x18: RXDATA           (RO) Rx FIFO              |
+---------------------------------------------------------------------------------------------------+
| 0x4005_0000   | timer_pwm_opentitan   | APB      | 0x00: CTRL             (RW) Prescaler En         |
|              | (Timer & PWM)         |          | 0x04: MTIME_LOW        (RW) 64-bit Counter Low   |
|              |                       |          | 0x08: MTIME_HIGH       (RW) 64-bit Counter High  |
|              |                       |          | 0x0C: MTIMECMP_LOW     (RW) Compare Reg Low      |
|              |                       |          | 0x10: MTIMECMP_HIGH    (RW) Compare Reg High     |
|              |                       |          | 0x18: PWM0_DUTY        (RW) Duty Cycle           |
+---------------------------------------------------------------------------------------------------+
| 0x4006_0000   | watchdog_wdt          | APB      | 0x00: WDT_CTRL         (RW) Enable & Lock        |
|              | (Watchdog Timer)      |          | 0x04: WDT_BARK_TH      (RW) Warning Threshold    |
|              |                       |          | 0x08: WDT_BITE_TH      (RW) Reset Threshold      |
|              |                       |          | 0x0C: WDT_VALUE        (RO) Current Counter      |
|              |                       |          | 0x10: WDT_FEED         (WO) Feed Key (0x55AA)    |
+---------------------------------------------------------------------------------------------------+
| 0x4007_0000   | rtc_core              | APB      | 0x00: RTC_CTRL         (RW) Start/Stop           |
|              | (Real-Time Clock)     |          | 0x04: SECONDS          (RW) BCD Seconds          |
|              |                       |          | 0x08: MINUTES          (RW) BCD Minutes          |
|              |                       |          | 0x0C: HOURS            (RW) BCD Hours            |
|              |                       |          | 0x10: ALARM_TIME       (RW) Alarm Register       |
+---------------------------------------------------------------------------------------------------+
| 0x4008_0000   | can_fd_ctrl           | APB      | 0x00: MODE_CTRL        (RW) Reset/Operation      |
|              | (ISO CAN-FD)          |          | 0x04: BIT_TIMING_NOM   (RW) Nominal Bitrate      |
|              |                       |          | 0x08: BIT_TIMING_DATA  (RW) Data Bitrate         |
|              |                       |          | 0x10: TX_BUFFER        (WO) Frame TX Window      |
|              |                       |          | 0x20: RX_BUFFER        (RO) Frame RX Window      |
+---------------------------------------------------------------------------------------------------+
| 0x4009_0000   | sd_mmc_ctrl           | AXI-Lite | 0x00: ARGUMENT         (RW) Command Argument     |
|              | (SD/MMC Host)         |          | 0x04: COMMAND          (RW) Command Opcode       |
|              |                       |          | 0x08: RESPONSE_0       (RO) Resp Reg 0           |
|              |                       |          | 0x14: BLOCK_SIZE       (RW) Transfer Size        |
|              |                       |          | 0x18: DATA_PORT        (RW) FIFO Port            |
+---------------------------------------------------------------------------------------------------+
| 0x400A_0000   | i2s_audio             | APB      | 0x00: I2S_CTRL         (RW) Enable/Format        |
|              | (I2S Audio)           |          | 0x04: CLKDIV           (RW) Bit Clock Divider    |
|              |                       |          | 0x08: TX_FIFO          (WO) Audio Out FIFO       |
|              |                       |          | 0x0C: RX_FIFO          (RO) Audio In FIFO        |
+---------------------------------------------------------------------------------------------------+
| 0x400B_0000   | dma_axi_sg            | AXI4-Lite| 0x00: CR               (RW) Control Register     |
|              | (AXI SG-DMA)          |          | 0x04: SR               (RO) Status Register      |
|              |                       |          | 0x08: CURDESC          (RW) Desc Ptr Low         |
|              |                       |          | 0x10: TAILDESC         (RW) Tail Ptr Low         |
+---------------------------------------------------------------------------------------------------+
| 0x400C_0000   | H264D-U1000_cfg_regs  | AXI4-Lite| 0x00: SW_RESET         (RW) Core Software Reset  |
|              | (H.264 Cfg Registers) |          | 0x04: START_PIC        (WO) Pulse Decode Start   |
|              |                       |          | 0x08: PIC_PARAM        (RW) Width/Height         |
|              |                       |          | 0x0C: INTR_MASK        (RW) Interrupt Mask       |
|              |                       |          | 0x10: STATUS           (RO) Frame Done Status    |
+---------------------------------------------------------------------------------------------------+
| 0x400D_0000   | H264D-U1000_stream_in | AXI4-Lite| 0x00: STRM_CTRL        (RW) Stream Enable/Mode   |
|              | (H.264 Stream Engine) |          | 0x04: RING_BASE        (RW) Ring Buffer Base     |
|              |                       |          | 0x08: RING_SIZE        (RW) Ring Buffer Size     |
|              |                       |          | 0x0C: RING_WPTR        (RW) Write Pointer        |
|              |                       |          | 0x10: RING_RPTR        (RO) Read Pointer         |
+---------------------------------------------------------------------------------------------------+
| 0x400E_0000   | h264d_nal_parse       | Internal | 0x00: NAL_CTRL         (RW) Strip Emulation Byte |
|              | (H.264 NAL Parser)    | Pipe     | 0x04: NAL_HEADER       (RO) Last Parsed Header   |
+---------------------------------------------------------------------------------------------------+
```

---

## 5. Interrupt Map & RISC-V PLIC Mapping

All peripheral hardware interrupt lines are routed to the central RISC-V Platform-Level Interrupt Controller (`interrupt_ctrl`). The PLIC prioritizes and aggregates these signals into the single `irq_external_i` line connected to the CPU core.

| PLIC Vector ID | Interrupt Source | Source IP Module | Interrupt Trigger Description |
|---|---|---|---|
| **IRQ 0** | *Reserved* | Ground | Tied to 0 (No Interrupt) |
| **IRQ 1** | `gpio_irq` | `gpio_opentitan` | Pin edge transition / level match |
| **IRQ 2** | `uart_irq` | `uart_16550` | RX Data Ready / TX Holding Reg Empty |
| **IRQ 3** | `i2c_irq` | `i2c_opentitan` | Command Complete / NACK / Arbitration Loss |
| **IRQ 4** | `spi_irq` | `spi_host_opentitan` | SPI Transmission Finished / RX FIFO Watermark |
| **IRQ 5** | `timer_irq` | `timer_pwm_opentitan` | 64-bit `mtimecmp` match interrupt |
| **IRQ 6** | `wdt_irq` | `watchdog_wdt` | Watchdog Bark Warning interrupt |
| **IRQ 7** | `rtc_irq` | `rtc_core` | Real-Time Alarm match interrupt |
| **IRQ 8** | `can_irq` | `can_fd_ctrl` | CAN-FD Frame Received / Transmitted / Bus Error |
| **IRQ 9** | `sd_irq` | `sd_mmc_ctrl` | SD Card Transfer Done / CRC Error |
| **IRQ 10**| `i2s_irq` | `i2s_audio` | Audio FIFO Empty / Full Watermark |
| **IRQ 11**| `dma_irq` | `dma_axi_sg` | Scatter-Gather DMA Buffer Complete |
| **IRQ 12**| `h264_pic_done_irq` | `H264D-U1000_cfg_regs` | Video Picture Frame Decode Complete |
| **IRQ 13**| `h264_strm_err_irq` | `H264D-U1000_stream_in` | Bitstream FIFO Overflow / Ring Error |
| **IRQ 14**| `h264_nal_hdr_irq`  | `h264d_nal_parse` | Annex-B NAL Header Parsed |

---

## 6. Verification & Test Plan

1. **System Bus Integration Test**: Bootloader firmware loaded into Boot ROM (`0x0000_0000`) executes an APB scan writing to `0x4001_0004` (`GPIO_DATA_OUT`) and reading back `0x4002_0014` (`UART_LSR`).
2. **Interrupt Aggregation Test**: Asserting `gpio_irq` causes PLIC `PENDING_0` bit 1 to rise, pulling `irq_external_i` high to the CPU. CPU reads PLIC `CLAIM_COMPLETE` register (`0x4000_0010`), receiving value `1`, handles the GPIO interrupt, and writes `1` back to complete the claim.
3. **Video Pipeline Transfer Test**: AXI SG-DMA (`dma_axi_sg`) fetches an H.264 bitstream from system SRAM (`0x8000_0000`), transfers it via AXI-Stream into `H264D-U1000_stream_in`, which passes RBSP bytes into `h264d_nal_parse`, triggering `h264_pic_done_irq` on picture completion.
