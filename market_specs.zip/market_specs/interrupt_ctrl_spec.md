# interrupt_ctrl — RISC-V PLIC / NVIC Interrupt Aggregator

**Document Version**: 2.0  
**Compliance Standard**: RISC-V Platform-Level Interrupt Controller (PLIC) Specification  
**Module Name**: `interrupt_ctrl`  

---

## 1. Overview & Theory of Operation

`interrupt_ctrl` is a 32-channel prioritized interrupt controller. It aggregates 32 peripheral interrupt request vectors (`irq_sources`), evaluates priority levels, and presents the highest-priority pending interrupt to the CPU.

---

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | Clock |
| `rst_n` | in | 1 | Reset |
| `paddr[7:0]` | in | 8 | APB address |
| `psel` | in | 1 | APB select |
| `penable` | in | 1 | APB enable |
| `pwrite` | in | 1 | APB write strobe |
| `pwdata[31:0]` | in | 32 | APB write data |
| `pready` | out | 1 | APB ready |
| `prdata[31:0]` | out | 32 | APB read data |
| `pslverr` | out | 1 | APB error |
| `irq_sources[31:0]` | in | 32 | 32 peripheral interrupt input vector lines |
| `cpu_irq` | out | 1 | Single prioritized CPU interrupt line output |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `ENABLE` | RW | `0x00000000` | Interrupt Enable Bitmask (32 bits) |
| `0x04` | `PENDING` | RO | `0x00000000` | Raw Pending Interrupt Vector |
| `0x08` | `CLAIM_COMPLETE`| RW | `0x00000000` | Read to Claim highest ID, Write to Complete ID |
| `0x0C` | `THRESHOLD` | RW | `0x00000000` | Priority Threshold limit |
