# uart_16550 — Complete Industry-Standard UART Controller Specification

**Document Version**: 2.5  
**Compliance Standard**: National Semiconductor PC16550D / ARM APB Peripheral Specification  
**Module Name**: `uart_16550`  

---

## 1. Overview & Theory of Operation

`uart_16550` is an industry-standard Universal Asynchronous Receiver-Transmitter (UART) serial communication controller. It incorporates 16-byte transmit (TX) and receive (RX) FIFOs, a programmable 16-bit fractional baud rate generator, line status monitoring, modem control handshaking, and a prioritized 4-level interrupt controller.

### 1.1 Key Architecture Features
- **Full Duplex Operation**: Independent 16-byte TX and RX FIFOs with programmable trigger thresholds (1, 4, 8, or 14 bytes).
- **Programmable Serial Parameters**: 5, 6, 7, or 8 data bits; 1, 1.5, or 2 stop bits; Even/Odd/Mark/Space/No parity.
- **Baud Rate Generator**: 16-bit clock prescaler dividing system clock down to $16\times$ baud rate clock.
- **Prioritized Interrupt Engine**: Identifies Line Status Errors, RX Data Ready, Character Timeout, TX FIFO Empty, and Modem Status changes.

---

## 2. Ports

### 2.1 Bus Interface (APB Slave) & System Signals

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | System clock (50–100 MHz) |
| `rst_n` | in | 1 | Active-low asynchronous reset |
| `paddr[7:0]` | in | 8 | APB address bus |
| `psel` | in | 1 | APB select signal |
| `penable` | in | 1 | APB strobe enable |
| `pwrite` | in | 1 | APB write control (1=Write, 0=Read) |
| `pwdata[31:0]` | in | 32 | APB write data bus |
| `pready` | out | 1 | APB slave ready output |
| `prdata[31:0]` | out | 32 | APB read data bus |
| `pslverr` | out | 1 | APB slave error response |

### 2.2 Serial & Modem Interface Signals

| Port | Dir | Width | Description |
|---|---|---|---|
| `rxd` | in | 1 | Serial receive data pin |
| `txd` | out | 1 | Serial transmit data pin |
| `cts_n` | in | 1 | Clear to Send modem input (active-low) |
| `rts_n` | out | 1 | Request to Send modem output (active-low) |
| `dtr_n` | out | 1 | Data Terminal Ready modem output (active-low) |
| `dsr_n` | in | 1 | Data Set Ready modem input (active-low) |
| `irq` | out | 1 | Aggregated level interrupt line to CPU |

---

## 3. Register Map

Note: When Divisor Latch Access Bit (`LCR[7] == 1`), offsets `0x00` and `0x04` access the Baud Rate Divisor Latches (`DLL` & `DLM`).

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `RBR` / `THR` / `DLL` | Mixed | `0x00` | RX Buffer (RO) / TX Holding (WO) [LCR[7]=0] / Divisor Latch LSB [LCR[7]=1] |
| `0x04` | `IER` / `DLM` | RW | `0x00` | Interrupt Enable Register [LCR[7]=0] / Divisor Latch MSB [LCR[7]=1] |
| `0x08` | `IIR` / `FCR` | Mixed | `0x01` | Interrupt Identification (RO) / FIFO Control Register (WO) |
| `0x0C` | `LCR` | RW | `0x00` | Line Control Register (Word length, stop bits, parity, DLAB) |
| `0x10` | `MCR` | RW | `0x00` | Modem Control Register (RTS, DTR, Loopback) |
| `0x14` | `LSR` | RO | `0x60` | Line Status Register (DR, OE, PE, FE, BI, THRE, TEMT, FIFO_ERR) |
| `0x18` | `MSR` | RO | `0x00` | Modem Status Register (CTS, DSR, Delta CTS, Delta DSR) |
| `0x1C` | `SCR` | RW | `0x00` | Scratchpad Register (free software storage byte) |

---

## 4. Detailed Functional Operation & State Machines

### 4.1 Baud Rate Generation FSM
The 16-bit divisor $D = \{\text{DLM}, \text{DLL}\}$ produces a baud sample clock:
$$f_{\text{sample}} = \frac{f_{\text{clk}}}{16 \times D}$$

### 4.2 Transmit FSM (mem_clk / clk)
```
IDLE ──(TX FIFO not empty)──► START_BIT ──► DATA_BITS (5-8) ──► PARITY (optional) ──► STOP_BITS (1-2)
  ▲                                                                                         │
  └─────────────────────────────────────────────────────────────────────────────────────────┘
```
1. **START_BIT**: Drives `txd = 0` for 16 sample clock ticks.
2. **DATA_BITS**: Shifts out LSB first (`wdata[0]` to `wdata[7]`), 16 ticks per bit.
3. **PARITY**: If `LCR[3] == 1`, calculates and drives even/odd parity bit.
4. **STOP_BITS**: Drives `txd = 1` for 16, 24, or 32 sample ticks. Updates `LSR.THRE` and `LSR.TEMT`.

### 4.3 Receive FSM & Line Error Detection
1. Filters incoming `rxd` pin through a 3-sample majority voter at the center of each bit period (ticks 7, 8, 9).
2. Detects Start Bit falling edge. Samples data bits into RX Shift Register.
3. Checks Parity (`LSR.PE`), Framing (`LSR.FE`), and Break Condition (`LSR.BI`).
4. Pushes valid byte + 3 error bits into 16-byte RX FIFO. Sets `LSR.DR = 1`.

### 4.4 Prioritized Interrupt Controller Logic
`IIR` (Interrupt Identification Register) reports pending interrupts in strict priority:
1. **Priority 1 (Highest)**: Receiver Line Status (`LSR` Overrun, Parity, Framing, or Break error).
2. **Priority 2**: Received Data Available (`RBR` full or RX FIFO threshold reached).
3. **Priority 3**: Character Timeout (RX FIFO has bytes, no read for 4 character times).
4. **Priority 4**: Transmitter Holding Register Empty (`THR` empty).
5. **Priority 5**: Modem Status Change (CTS / DSR delta).
