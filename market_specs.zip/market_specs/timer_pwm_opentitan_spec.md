# timer_pwm_opentitan — Complete Industry-Standard Timer & PWM Specification

**Document Version**: 2.0  
**Compliance Standard**: OpenTitan RV_TIMER / ARM APB Timer Specification  
**Module Name**: `timer_pwm_opentitan`  

---

## 1. Overview & Theory of Operation

`timer_pwm_opentitan` is a dual 64-bit timer and pulse-width modulation (PWM) subsystem. It contains a 16-bit clock prescaler, two independent 64-bit free-running counters, threshold compare registers for interrupt generation, and dual-channel PWM outputs with programmable duty cycles and dead-time insertion.

### 1.1 Key Architecture Features
- **64-bit Timebase Counter**: High-resolution 64-bit tick counter (`mtime`) driven by a 16-bit prescaler.
- **64-bit Compare Registers**: Generates a high-priority timer interrupt whenever `mtime >= mtimecmp`.
- **Dual PWM Generators**: Independent duty-cycle and period control with center-aligned and edge-aligned modes.
- **Dead-time Generator**: Prevents shoot-through currents in power electronic driving applications.

---

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | System clock (50–100 MHz) |
| `rst_n` | in | 1 | Active-low asynchronous reset |
| `paddr[7:0]` | in | 8 | APB address bus |
| `psel` | in | 1 | APB select |
| `penable` | in | 1 | APB strobe enable |
| `pwrite` | in | 1 | APB write control |
| `pwdata[31:0]` | in | 32 | APB write data |
| `pready` | out | 1 | APB ready output |
| `prdata[31:0]` | out | 32 | APB read data |
| `pslverr` | out | 1 | APB slave error |
| `pwm_out_0` | out | 1 | Channel 0 PWM output |
| `pwm_out_1` | out | 1 | Channel 1 PWM output |
| `irq` | out | 1 | Timer compare interrupt output |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `CTRL` | RW | `0x00000000` | Timer enable, PWM enable, Prescaler divide ratio |
| `0x04` | `MTIME_LOW` | RW | `0x00000000` | Lower 32 bits of 64-bit timer counter |
| `0x08` | `MTIME_HIGH` | RW | `0x00000000` | Upper 32 bits of 64-bit timer counter |
| `0x0C` | `MTIMECMP_LOW`| RW | `0xFFFFFFFF` | Lower 32 bits of timer compare threshold |
| `0x10` | `MTIMECMP_HIGH`| RW | `0xFFFFFFFF` | Upper 32 bits of timer compare threshold |
| `0x14` | `PWM0_DUTY` | RW | `0x00000000` | Channel 0 PWM duty cycle threshold |
| `0x18` | `PWM1_DUTY` | RW | `0x00000000` | Channel 1 PWM duty cycle threshold |
| `0x1C` | `INTR_STATE` | W1C | `0x00000000` | Pending timer overflow/compare interrupt |

---

## 4. Theory of Operation & FSM

1. Prescaler counter divides `clk` by `CTRL.prescaler + 1`.
2. `mtime` increments on prescaler tick. When `mtime >= mtimecmp`, `INTR_STATE` bit 0 is set and `irq` asserts.
3. PWM counter wraps at `PWM0_DUTY` threshold, toggling `pwm_out_0` output.
