# i2s_audio — Complete Stereo I2S Audio Transceiver Specification

**Document Version**: 2.0  
**Compliance Standard**: Philips I2S Bus Specification / OpenTitan Audio Standard  
**Module Name**: `i2s_audio`  

---

## 1. Overview & Theory of Operation

`i2s_audio` is a stereo Inter-IC Sound (I2S) audio interface supporting 16-bit, 24-bit, and 32-bit audio word formats. It includes master clock generation, 32-entry TX/RX ping-pong audio FIFOs, and left/right channel time-slot alignment.

---

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk` | in | 1 | Clock |
| `rst_n` | in | 1 | Reset |
| `mclk` | in | 1 | Audio master clock input (12.288 MHz / 24.576 MHz) |
| `paddr[7:0]` | in | 8 | APB address |
| `psel` | in | 1 | APB select |
| `penable` | in | 1 | APB enable |
| `pwrite` | in | 1 | APB write strobe |
| `pwdata[31:0]` | in | 32 | APB write data |
| `pready` | out | 1 | APB ready |
| `prdata[31:0]` | out | 32 | APB read data |
| `pslverr` | out | 1 | APB error |
| `sck` | out | 1 | Serial bit clock |
| `ws` | out | 1 | Word Select / Left-Right clock |
| `sd_out` | out | 1 | Serial Data Output (DAC drive) |
| `sd_in` | in | 1 | Serial Data Input (ADC sample) |
| `irq` | out | 1 | Audio FIFO watermark interrupt |

---

## 3. Register Map

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| `0x00` | `CTRL` | RW | `0x00000000` | Enable I2S, Word Length (16/24/32), Master Mode |
| `0x04` | `CLKDIV` | RW | `0x00000004` | Bit Clock Divider ratio |
| `0x08` | `TX_FIFO` | WO | `0x00000000` | Push stereo audio sample into TX FIFO |
| `0x0C` | `RX_FIFO` | RO | `0x00000000` | Pop stereo audio sample from RX FIFO |
| `0x10` | `STATUS` | RO | `0x00000000` | FIFO Full, Empty, Overrun, Underrun flags |
