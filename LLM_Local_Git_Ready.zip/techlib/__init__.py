"""
Open Standard Cell Libraries for Logic Synthesis and Technology Mapping.
Includes NanGate 45nm and SkyWater 130nm Liberty files and Verilog simulation models.
"""
