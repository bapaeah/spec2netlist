# Windows Setup Guide: Local RTL LLM & Spec2RTL-UPF Integration

This guide explains how to install and run both **`LLM_Local`** (general RTL copilot & verification) and **`Spec2rtl_upf`** (full SoC architecture, CDC, UPF 2.1 power intent, SDC, and gate netlist) on Windows 10 or 11.

---

## 1. Directory Layout on Windows

Place both repositories side-by-side on your Windows machine, for example:
```text
C:\Users\<YourUser>\
├── LLM_Local\          (Copilot, Ollama models, self-healing iverilog verification)
└── Spec2rtl_upf\       (SoC spec ingestion, bus decoders, UPF 2.1, CDC, SDC, Netlist)
```

---

## 2. Quick Automated Setup (One-Click)

Open **PowerShell as Administrator or Standard User**, navigate into `LLM_Local`, and run:

```powershell
cd C:\Users\<YourUser>\LLM_Local

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\setup_windows.ps1
```

### What this script automates:
1. Installs **Ollama for Windows** (with automatic NVIDIA CUDA / AMD GPU acceleration).
2. Installs **Python 3.12** and **Icarus Verilog** (including `iverilog`, `vvp`, and GTKWave).
3. Installs Python document readers (`pdfplumber`, `python-docx`, `openpyxl`) for reading PDF, Word, and Excel specs.
4. Pulls base models (`7b` and `3b`) and builds specialized `rtl-coder` and `rtl-coder-fast` models.
5. Links `Spec2rtl_upf` with local Ollama by creating `run_local.ps1`.
6. Configures the **Continue** extension in VS Code for offline in-editor autocompletion and chat.

---

## 3. Manual Step-by-Step Installation (Alternative)

If you prefer installing tools manually:

### Step A: Install Software via winget
```powershell
# 1. Install Ollama
winget install Ollama.Ollama

# 2. Install Python 3.12
winget install Python.Python.3.12

# 3. Install Icarus Verilog via winget (try one of these IDs):
winget install -e --id Icarus.Verilog
# Or if not found:
winget install -e --id Verilog.IcarusVerilog
# Or search available packages:
winget search iverilog

# (Alternative) Direct Installer if winget does not find it:
# Download iverilog setup from: https://bleyer.org/icarus/
# During installation, check "Add executable folders to system PATH".

# 4. Install document parsing libraries
python -m pip install pdfplumber python-docx openpyxl
```

### Step B: Build Local Models in PowerShell
```powershell
cd C:\Users\<YourUser>\LLM_Local

ollama pull qwen2.5-coder:7b
ollama pull qwen2.5-coder:3b

ollama create rtl-coder -f Modelfile.rtl
ollama create rtl-coder-fast -f Modelfile.rtl-fast
```

---

## 4. Running the Tools on Windows

### A. General RTL Generation & Verification (`rtl_assistant.py`)
```powershell
cd C:\Users\<YourUser>\LLM_Local

# 1. Terminal Chat
python rtl_assistant.py chat

# 2. Generate RTL from natural language prompt
python rtl_assistant.py generate --spec "8-bit dual-port synchronous RAM" -o ram.v

# 3. Generate RTL directly from a Word (.docx) or PDF (.pdf) spec
python rtl_assistant.py generate --file C:\path\to\spec.docx -o module.v

# 4. Generate self-checking testbench
python rtl_assistant.py testbench ram.v -o ram_tb.v

# 5. Compile & auto-fix errors with local iverilog
python rtl_assistant.py verify ram.v ram_tb.v

# 6. Technology-Agnostic Memory Compiler (AI-parsed or direct)
# AI Natural language memory synthesis:
python rtl_assistant.py memory --spec "16KB Simple Dual-Port RAM with 64-bit width and Wishbone bus"
# Direct flag compilation:
python rtl_assistant.py memory --type spram --size 4KB --bus axi5 --name sram_4k -o generated_mem
# View all supported presets:
python rtl_assistant.py memory --list-presets
```

### B. Complete SoC & Power Intent Pipeline (`Spec2rtl_upf`)
You can run the full SoC architecture flow using either script:

**Via `Spec2rtl_upf` PowerShell launcher:**
```powershell
cd C:\Users\<YourUser>\Spec2rtl_upf

# RTL + CDC constraints only:
.\run_local.ps1 --spec benchmarks\H264D-U1000_cfg_regs_spec.md --rtl-only

# Complete Flow (RTL + CDC + UPF 2.1 + SDC + 45nm Gate Netlist):
.\run_local.ps1 --spec benchmarks\H264D-U1000_cfg_regs_spec.md `
                --config benchmarks\power_config.json `
                --filelist benchmarks\soc_filelist.f `
                --all

# Batch Generation across an entire folder of specs:
.\run_local.ps1 --spec market_specs\ --rtl-only
```

**Or directly through `rtl_assistant.py`:**
```powershell
cd C:\Users\<YourUser>\LLM_Local
python rtl_assistant.py soc --spec market_specs\ --rtl-only
```

---

## 5. VS Code / Cursor Setup on Windows

1. Install the **Continue** extension from the VS Code Marketplace.
2. In PowerShell, copy the configuration to your user profile:
   ```powershell
   Copy-Item .\continue_config.json "$env:USERPROFILE\.continue\config.json" -Force
   ```
3. Open any `.v` or `.sv` file in VS Code—you now have free, zero-latency tab autocompletion and `Cmd+L` / `Ctrl+L` in-editor chat.

---

## 6. WSL2 (Alternative for Heavy Linux EDA Users)

If you use Linux-native tools like **Verilator** or **Yosys** on Windows:
1. In PowerShell run: `wsl --install -d Ubuntu`
2. Open Ubuntu terminal and follow [`SETUP_LINUX.md`](file:///Users/bappi/LLM_Local/SETUP_LINUX.md).
3. WSL2 shares your Windows NVIDIA GPU automatically with native CUDA performance.
