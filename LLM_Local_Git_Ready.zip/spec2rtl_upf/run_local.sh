#!/usr/bin/env bash
# Run Spec2RTL + AutoUPF using local Ollama (100% token-free & offline)
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$DIR"

# Configure local LLM environment variables
export SPEC2RTL_LLM_URL="http://localhost:11434/v1/chat/completions"
export SPEC2RTL_LLM_KEY="ollama"
export SPEC2RTL_LLM_MODEL="${SPEC2RTL_LLM_MODEL:-rtl-coder-fast}"

echo "============================================================"
echo " Running Spec2RTL + AutoUPF with Local LLM (${SPEC2RTL_LLM_MODEL})"
echo " Endpoint: ${SPEC2RTL_LLM_URL}"
echo "============================================================"

# Pass all arguments directly to main.py, ensuring --llm is enabled
if [[ "$*" == *"--llm"* ]]; then
    python3 main.py "$@"
else
    python3 main.py --llm "$@"
fi
