# Implementation Plan: Specification to Netlist CAD Framework

**Project Title:** Specification to Netlist  
**Authors/Team:** Bapaiah Katepalli and Team  
**Framework Name:** `Spec2RTL + AutoUPF-AI`  
**Target:** Autonomous Specification-to-Netlist Synthesis, Closed-Loop RTL/TB/Synthesis Verification, Hierarchical IEEE 1801 UPF 2.1 Alignment, and Level of Logic Optimization  

---

## 1. Executive Summary & Framework Overview

The **Specification to Netlist** framework is an autonomous end-to-end Electronic Design Automation (EDA) flow that translates high-level system architecture specifications (in Markdown, PDF, Excel, JSON, or CSV formats) directly into synthesizable, clean, gate-level SystemVerilog netlists and low-power IEEE 1801 UPF 2.1 specifications.

The framework operates through a **5-stage closed-loop pipeline**, replacing traditional 4.5–6 month manual front-end design iterations with an automated execution flow completed in under **5 minutes**, achieving over **3,000× speedup in Turn-Around Time (TAT)**.

---

## 2. End-to-End System Setup & Architecture

```
                                SYSTEM IMPLEMENTATION FLOW
                                
  ┌──────────────────────────────────────────────────────────────────────────────────┐
  │ Stage 1: Multi-Format Input Ingestion                                            │
  │   ├── Multi-Format Specs (.md, .pdf, .json, .xlsx, .csv)                         │
  │   ├── Power Domain Configurations (power_config.json)                            │
  │   └── EDA Verilog Filelists (.f / .flist)                                        │
  └─────────────────────────────────┬────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌──────────────────────────────────────────────────────────────────────────────────┐
  │ Stage 2: Spec-to-RTL & TB Generation Core                                        │
  │   ├── Register Map Address Decoder (*_regs.sv)                                   │
  │   ├── Functional Core RTL Implementation (*_core.sv)                             │
  │   └── Self-Checking SystemVerilog Testbenches (tb_*.sv)                           │
  └─────────────────────────────────┬────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌──────────────────────────────────────────────────────────────────────────────────┐
  │ Stage 3: Closed-Loop Multi-Stage CAD & Verification Engine                       │
  │   ├── 🔁 Loop 3.1: Verilator Lint & Syntax Repair                                │
  │   ├── 🔁 Loop 3.2: iVerilog / Verilator TB Simulation & Functional Validation     │
  │   ├── 🔁 Loop 3.3: Yosys Gate Synthesis Verification                             │
  │   └── 🔁 Loop 3.4: Level of Logic (Logic Depth) Optimization Engine              │
  └─────────────────────────────────┬────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌──────────────────────────────────────────────────────────────────────────────────┐
  │ Stage 4: Clock & Reset Domain Crossing (CDC/RDC) Engine (IP & SoC Level)         │
  │   ├── IP-Level CDC: 2-FF/3-FF Synchronizers, Pulse Syncs & Async FIFOs           │
  │   ├── SoC-Level CDC: Multi-Clock Crossbar Bridges & Clock Domain Matrix          │
  │   ├── RDC Engine: Glitch-Free Reset Synchronizer Trees & PMU Power-OK Binding    │
  │   └── CDC/RDC Verification: Open SDC Constraint Gen & SymbiYosys Formal Checks   │
  └─────────────────────────────────┬────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌──────────────────────────────────────────────────────────────────────────────────┐
  │ Stage 5: Hierarchical IEEE 1801 UPF 2.1 & Low-Power Alignment Audit              │
  │   ├── Modular IP UPF Generation (*.upf)                                          │
  │   ├── Output Isolation Clamping & Voltage Level Shifter Insertion                │
  │   ├── Master Power State Table (PST) Synthesis                                   │
  │   └── RTL-UPF Boundary Alignment Auditor                                         │
  └─────────────────────────────────┬────────────────────────────────────────────────┘
                                    │
                                    ▼
  ┌──────────────────────────────────────────────────────────────────────────────────┐
  │ Stage 6: Netlist Delivery & Synthesis Benchmarking                               │
  │   ├── Clean 45nm Gate-Level Netlist (NanGate 45nm Open Cell Library)             │
  │   ├── Validated Low-Power UPF 2.1 File Suite                                     │
  │   └── Area, Timing, and Power Benchmark Reports                                  │
  └──────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. Stage-by-Stage Implementation Details

### Stage 1: Multi-Format Input Ingestion
- **Parsers:** Extract register definitions, bit fields, bus interfaces (AXI4, APB, OBI), clock/reset trees, and power state constraints from specification documents.
- **Normalization:** Converts input files into a unified JSON architecture schema (`spec.json`).

### Stage 2: Spec-to-RTL Core Synthesis
- **Register Map Generator (`*_regs.sv`):** Auto-generates read/write address decoders, strobe masking, reset defaults, and interrupt status registers.
- **Functional Core Generator (`*_core.sv`):** Synthesizes non-stub SystemVerilog functional logic (state machines, FIFOs, counters, stream parsers).
- **Testbench Generator (`tb_*.sv`):** Constructs self-checking testbenches with assertion monitors and clock/reset stimulus generators.

### Stage 3: Closed-Loop CAD & Verification Pipeline
The verification engine executes four automated feedback loops:
1. **Verilator Syntax & Lint Loop:** Runs static code analysis. If lint errors or syntax warnings occur (e.g., width mismatches, unassigned nets), errors are fed back into the code generator for auto-correction.
2. **TB Simulation Loop:** Runs `iverilog` / `verilator` testbenches. Test failures trigger automated RTL/TB assertion alignment fixes.
3. **Yosys Synthesis Gate Loop:** Synthesizes RTL into gate primitives (`yosys`). Unsynthesizable logic constructs (e.g., initial blocks in hardware paths, invalid latch inferences) are flagged and rewritten.
4. **Level of Logic (Logic Depth) Optimization Loop:** Evaluates critical paths, applies tree balancing, and inserts pipeline registers to meet target clock frequencies.

### Stage 4: Clock & Reset Domain Crossing (CDC / RDC) Engine
- **IP-Level CDC Synthesis:**
  - Automatically synthesizes 2-FF or 3-FF synchronizers for single-bit control and status signals crossing clock boundaries.
  - Automatically instantiates toggle/pulse synchronizers for fast-to-slow and slow-to-fast event transfers.
  - Generates parameterizable dual-clock asynchronous FIFOs (`async_fifo.sv`) with Gray-coded read/write pointer synchronization for multi-bit data buses.
  - Generates 4-phase req/ack handshake synchronizers for asynchronous control register transfers.
- **SoC-Level CDC Synthesis:**
  - Manages the heterogeneous clock domain matrix across the SoC (`clk_sys` @ 100MHz, `clk_aon` @ 32kHz, `clk_video` @ 200MHz, `clk_dma` @ 150MHz).
  - Inserts asynchronous AXI4/APB bridge adapters between high-speed crossbars and low-power peripheral clusters.
- **Reset Domain Crossing (RDC) Architecture:**
  - Synthesizes 2-stage glitch-free reset synchronizer trees (`rst_*_sync_n`) for each power and clock domain.
  - Ensures reset assertion occurs asynchronously for instant shutdown, but de-assertion is strictly synchronized to the destination clock edge only after power supply rails stabilize (`pmu_*_pwr_ok`).
- **Free CDC/RDC Verification & Constraint Generation:**
  - Automatically outputs SDC constraints (`set_clock_groups -asynchronous`).
  - Synthesizes SystemVerilog Assertions (SVA) and executes formal CDC protocol verification via **SymbiYosys (`sby`)**.
  - Runs Verilator static checks (`-Wall`, `SYNCASYNCNET`) to guarantee zero CDC/RDC violations.

### Stage 5: Hierarchical UPF 2.1 & Low-Power Alignment
- **Domain Definition:** Automatically partitions design blocks into distinct power domains (`PD_TOP`, `PD_AON`, `PD_CPU`, `PD_VIDEO`, `PD_DMA`, `PD_PERIPH`).
- **Low-Power Cell Insertion:** Generates rules for isolation cells (`set_isolation`), level shifters (`set_level_shifter`), and retention registers (`set_retention`).
- **PST Synthesis:** Constructs top-level Power State Tables (`create_pst`, `add_pst_state`) ensuring valid SoC operational modes.
- **RTL-UPF Audit:** Checks for missing level shifters across voltage boundaries, un-clamped floating signals, and reset synchronizer alignment.

### Stage 6: Netlist & Release Delivery
- Synthesizes technology-mapped netlists against NanGate 45nm Open Cell Library.
- Generates cell area counts, gate density metrics, and final UPF package artifacts.

---

## 4. Level of Logic (Logic Depth) Analysis & Optimization Plan

### 4.1 Concept & Purpose
**Level of Logic (Logic Depth / Gate Count per Path)** measures the maximum number of combinational logic gates along a critical path between sequential storage elements (flip-flops/latches) or I/O boundaries:

$$\text{Critical Delay } (T_{\text{comb}}) = \sum_{i=1}^{N_{\text{levels}}} t_{\text{gate\_delay}, i} + t_{\text{net\_delay}}$$

$$\text{Maximum Clock Frequency } (F_{\text{max}}) = \frac{1}{T_{\text{clk}} - T_{\text{setup}} - T_{\text{clk-q}}}$$

High logic levels severely degrade maximum achievable clock frequency ($F_{\text{max}}$) and lead to timing closure failure in physical design. The framework incorporates **automated logic level analysis and structural retiming** directly within Stage 3.

---

### 4.2 Analysis Strategy (Measuring Logic Levels)

```
                       LOGIC LEVEL ANALYSIS PIPELINE
                       
  SystemVerilog RTL
        │
        ├─► [ 1. Pre-Synthesis AST Analysis ]
        │      ├── Parses expression tree depths in conditional statements
        │      └── Flags deep nested priority chains (if-else depth > 8)
        │
        └─► [ 2. Post-Synthesis Gate Level Path Tracing (Yosys / OpenSTA) ]
               ├── Executes topological longest path extraction (`yosys ltp`)
               ├── Counts logic cell levels per register-to-register path
               └── Maps gate depth histogram per module
```

1. **Pre-Synthesis AST Analysis:**
   - Evaluates expression tree depth and priority encoder cascades during RTL generation.
   - Computes an estimated logic depth metric ($N_{\text{est}}$) based on operator precedence and bit-vector widths.

2. **Post-Synthesis Topological Gate-Level Tracing:**
   - Uses Yosys gate-level topological path analysis (`yosys ltp` / `abc`) and OpenSTA timing path reporting.
   - Extracts the exact gate level count ($N_{\text{levels}}$) for every register-to-register timing path.
   - Identifies paths exceeding target thresholds (e.g., $N > 12$ gates for 1 GHz clock target on 45nm technology).

---

### 4.3 Autonomous Optimization & Implementation Techniques

When a logic path exceeds the maximum permissible depth budget, the framework executes four structural optimization techniques:

```
                          LOGIC LEVEL OPTIMIZATION
                          
   Deep Logic Path Identified (e.g., N = 22 gates)
                         │
        ┌────────────────┼────────────────┬────────────────┐
        ▼                ▼                ▼                ▼
 ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
 │ Tree         │ │ Auto Stage   │ │ Control      │ │ Technology   │
 │ Balancing    │ │ Pipelining   │ │ Precompute   │ │ Retiming     │
 ├──────────────┤ ├──────────────┤ ├──────────────┤ ├──────────────┤
 │ Converts     │ │ Inserts      │ │ Evaluates    │ │ Runs Yosys   │
 │ nested       │ │ pipeline     │ │ control      │ │ register     │
 │ if-else to   │ │ registers    │ │ signals      │ │ retiming     │
 │ parallel     │ │ across multi-│ │ early in     │ │ (`retime`) & │
 │ case / tree  │ │ cycle logic  │ │ parallel     │ │ ABC delay    │
 │ encoders     │ │ paths        │ │ path         │ │ map (`abc-D`)│
 └──────────────┘ └──────────────┘ └──────────────┘ └──────────────┘
```

1. **Tree Balancing (RTL-Level):**
   - Re-architects sequential `if-else-if` decision ladders into balanced binary tree encoder structures (`case` statements or balanced tree multiplexers), reducing path depth from $\mathcal{O}(N)$ to $\mathcal{O}(\log_2 N)$.

2. **Auto-Stage Pipelining (RTL-Level):**
   - Automatically inserts intermediate registers (`stage_1_reg`, `stage_2_reg`) across multi-stage arithmetic blocks (e.g., multipliers, ALUs, H.264 bitstream parsers).

3. **Early Control Signal Pre-computation:**
   - Moves control condition evaluations earlier in the pipeline, decoupling control-path depth from data-path depth.

4. **Technology Mapping Retiming (Synthesis-Level):**
   - Applies Yosys register retiming (`retime`) to push registers backward or forward through combinational logic.
   - Configures ABC mapper with target delay optimization flags (`abc -D <target_period>`).

---

### 4.4 Closed-Loop Logic Depth Auto-Fixing Workflow

```
 [ Generated RTL ]
        │
        ▼
 [ Yosys / STA Logic Depth Audit ]
        │
        ├─► (Pass: Max Depth N <= Target N_max) ──► Proceed to Stage 4 (UPF Alignment)
        │
        └─► (Fail: Max Depth N > Target N_max)
               │
               ▼
 [ LOGIC_DEPTH_VIOLATION Report ]
               │
               ▼
 [ Closed-Loop Auto-Refactoring Engine ]
               │  - Parses failing path start/end points
               │  - Selects optimization: Tree Balancing or Auto-Pipelining
               │  - Rewrites SystemVerilog RTL module
               ▼
 [ Re-Synthesis & Re-Verification ]
```

- **Violation Generation:** If $N_{\text{levels}} > N_{\text{max\_threshold}}$, a `LOGIC_DEPTH_VIOLATION` event is triggered containing start point, end point, and logic path breakdown.
- **Auto-Refactoring Prompt:** The feedback loop re-invokes the generator with specific constraints:
  > *"Refactor `h264d_nal_parse_core.sv`: Critical path between `nal_state_reg` and `rbsp_byte_out` has 22 logic levels. Apply binary tree balancing to the state decode tree and insert a 1-stage pipeline register to achieve N <= 12 levels."*
- **Re-Verification:** The refactored module is re-verified through linting, simulation, and synthesis to ensure zero timing/logic-depth violations.

---

## 5. Clock & Reset Domain Crossing (CDC/RDC) Generation & Verification Plan (IP & SoC Level)

### 5.1 Motivation & Technical Objectives
Heterogeneous SoCs operate across multiple asynchronous clock domains (e.g., 100\,MHz AXI bus, 32\,kHz Always-On RTC, 200\,MHz Video pipeline) and decoupled power-gated reset domains. Failure to properly synchronize signals across these boundaries causes **metastability**, **data corruption**, **multi-flop reconvergence glitches**, and **system deadlocks**.

Our framework elevates **CDC and RDC generation and verification** into a dedicated automated stage operating at both the **IP Level** and the **SoC Subsystem Level**.

```
                   CDC & RDC HIERARCHICAL EXECUTION FLOW
                   
   IP-Level Generation                  SoC-Level Integration & Verification
 ┌─────────────────────────────┐       ┌─────────────────────────────────────┐
 │ • 2-FF/3-FF Control Syncs   │       │ • Top-Level Clock Domain Matrix     │
 │ • Fast-to-Slow Pulse Syncs  │ ────► │ • Asynchronous Inter-IP AXI Bridges │
 │ • Dual-Clock Async FIFOs    │       │ • PMU Glitch-Free Reset Trees       │
 │ • 4-Phase Req/Ack Handshake │       │ • Open SDC & SymbiYosys Formal Audit│
 └─────────────────────────────┘       └─────────────────────────────────────┘
```

---

### 5.2 IP-Level CDC Generation Strategies
During IP core synthesis (`spec2rtl`), the engine inspects port clock associations and synthesizes standardized synchronizer primitives:

1. **Single-Bit Control Synchronization (2-FF & 3-FF Synchronizers):**
   - Injects dedicated 2-stage (or 3-stage for high-frequency targets) flip-flop synchronizers with `(* ASYNC_REG = "TRUE" *)` synthesis attributes to guarantee placement in the same physical cell tile and prevent tool-driven logic optimization.
   
2. **Pulse & Event Synchronizers:**
   - For single-cycle pulse transfers crossing from fast clock domains to slow clock domains (where a standard 2-FF would miss the pulse), the engine synthesizes toggle-based handshake circuits (Toggle $\rightarrow$ 2-FF Sync $\rightarrow$ Edge Detector).

3. **Multi-Bit Data Buses (Dual-Clock Asynchronous FIFOs):**
   - For multi-bit data transfers, direct 2-FF synchronization is strictly forbidden due to bus skew.
   - The framework auto-generates dual-clock asynchronous FIFOs (`async_fifo.sv`) implementing Gray-coded write and read pointer conversions:
     - Converts binary pointers to Gray code: $\text{Gray} = \text{Binary} \oplus (\text{Binary} \gg 1)$
     - Passes Gray pointers across domain boundaries via 2-FF synchronizers (guaranteeing only 1 bit transitions per cycle)
     - Reconstructs empty/full status flags in native domains to prevent FIFO underflow/overflow.

4. **Coordinated Multi-Bit Handshaking (Req/Ack Handshake):**
   - For quasi-static configuration register transfers, the framework synthesizes 4-phase request/acknowledge handshaking controllers with level-holding registers.

---

### 5.3 SoC-Level CDC & RDC Architecture
At the SoC integration level (`soc_subsystem_top`), the engine harmonizes all inter-IP communication:

1. **Clock Domain Matrix:**
   - **`clk_sys` (100\,MHz):** High-speed interconnect, CPU, DMA, and SRAM.
   - **`clk_aon` (32.768\,kHz):** Real-Time Clock (`rtc_core`) and Watchdog timer.
   - **`clk_video` (200\,MHz):** H.264 video decoder acceleration pipeline.
   - **`clk_periph` (50\,MHz):** Low-speed APB peripheral controllers (UART, I2C, SPI, CAN-FD).

2. **Asynchronous Crossbar & Bridge Adapters:**
   - Automatically instantiates asynchronous bridges between the 100\,MHz AXI crossbar and the 50\,MHz APB bridge matrix, ensuring transaction boundaries preserve burst ordering and response latency.

3. **Reset Domain Crossing (RDC) Synchronizer Trees:**
   - To prevent catastrophic reset recovery/removal timing violations, the framework implements **Asynchronous Assert / Synchronous De-assert** reset synchronizers for every power domain:
   ```systemverilog
   // Auto-generated RDC Reset Synchronizer for PD_CPU Domain
   always_ff @(posedge clk_sys or negedge rst_sys_n) begin
       if (!rst_sys_n) begin
           rst_cpu_meta_n <= 1'b0;
           rst_cpu_sync_n <= 1'b0; // Instant asynchronous assert
       end else if (pmu_cpu_pwr_ok) begin
           rst_cpu_meta_n <= 1'b1;
           rst_cpu_sync_n <= rst_cpu_meta_n; // Synchronized release on clk_sys
       end
   end
   ```
   - **Power-OK Gating:** Resets de-assert only when the PMU confirms power rails have stabilized (`pmu_*_pwr_ok == 1'b1`), eliminating cold-boot metastability.

---

### 5.4 Automated CDC/RDC Verification & Free Tool Flow
The framework provides a zero-cost automated verification suite for CDC and RDC:

1. **Open SDC Timing Constraints Generation:**
   - Automatically outputs `soc_constraints.sdc` defining asynchronous clock groups:
   ```tcl
   set_clock_groups -asynchronous \
       -group [get_clocks clk_sys] \
       -group [get_clocks clk_aon] \
       -group [get_clocks clk_video] \
       -group [get_clocks clk_periph]
   ```
2. **Formal CDC Protocol Verification (SymbiYosys `sby`):**
   - Generates SystemVerilog Assertions (SVA) proving FIFO pointers never corrupt, Gray code Hamming distances equal 1, and request/acknowledge sequences never deadlock.
   - Solves formal properties using open-source SMT solvers (Z3 / Boolector).

3. **Verilator Static Checks:**
   - Runs Verilator with `-Wall -Wno-MULTIDRIVEN` to catch un-synchronized clock transitions and sensitivity list bugs.

---

## 6. Software Tools, Directory Layout & Execution Setup

### 6.1 Repository & Directory Structure
```text
Spec2rtl_upf/
├── main.py                           # Master CLI Entry Point (Unified / RTL-only / UPF-only)
├── README.md                         # Framework Overview & Execution Documentation
├── IMPLEMENTATION_PLAN.md            # Comprehensive Implementation Plan & Setup Document
├── paper_soc_spec2rtl_upf.tex        # IEEE Conference Paper LaTeX Source
├── presentation_idea_submission.tex  # Beamer Presentation Deck LaTeX Source
├── build_clean_pptx.py               # PowerPoint OpenXML Deck Builder Script
│
├── spec2rtl/                         # Track 1: Spec-to-RTL Core Engine
│   ├── spec2rtl.py                   # Spec Parser & RTL Synthesizer CLI
│   ├── llm_code_gen.py               # Closed-Loop Code Generator & Refactor Engine
│   ├── verilator_lint.py             # Verilator Syntax & Lint Auditor
│   ├── yosys_synth.py                # Yosys Gate Synthesis & Logic Depth Analyzer
│   └── tb_sim.py                     # iVerilog / Verilator Testbench Simulator
│
├── upf_engine/                       # Track 10: IEEE 1801 UPF 2.1 Engine
│   ├── upf_generator.py              # Modular & Top-Level UPF Synthesizer
│   ├── upf_auditor.py                # RTL-UPF Boundary Alignment Auditor
│   └── pst_synthesizer.py            # Power State Table Generator
│
├── src/                              # Orchestration Utilities
│   └── combined_pipeline.py          # Unified Multi-Stage Execution Orchestrator
│
├── benchmarks/                       # Test Benches & Configurations
│   ├── power_config_market_soc.json  # Multi-Domain Power Domain Definition
│   └── market_soc_filelist.f         # Complete SoC Verilog Source Filelist
│
├── market_specs/                     # Input Architecture Specifications Catalog
│   ├── H264D-U1000_cfg_regs_spec.md
│   ├── H264D-U1000_stream_in_spec.md
│   ├── H264D-U1000_nal_parse_spec.md
│   └── ... (15+ Market Spec Documents)
│
└── output_market_soc/                # Generated Release Deliverables Directory
    ├── generated_ip/                 # Per-IP Synthesizable SV, TB, and Specs
    ├── partitions/                   # Modular Sub-Partition UPFs (pd_cpu.upf, etc.)
    ├── soc_subsystem_top.upf         # Master IEEE 1801 UPF 2.1 Specification
    └── upf_rtl_alignment_report.json # Comprehensive RTL-UPF Alignment Audit Report
```

---

### 6.2 Required Tool Dependencies

| Tool / Environment | Recommended Version | Role / Function in Flow |
| :--- | :--- | :--- |
| **Python** | `3.10+` | Framework CLI, Spec parsing, UPF engine, AST analysis |
| **Yosys** | `0.30+` | Gate synthesis, netlist generation, logic level path tracing (`ltp`) |
| **SymbiYosys (`sby`)** | `YosysHQ formal` | Formal CDC protocol verification & SVA model checking |
| **Verilator** | `5.00+` | Static linting, syntax checking, fast C++ TB simulation |
| **Icarus Verilog (`iverilog`)** | `11.0+` | Event-driven SystemVerilog testbench simulation |
| **OpenSTA** | `2.4+` | Gate-level static timing analysis & path depth extraction |
| **LaTeX / pdflatex** | TeX Live 2023+ | Paper & Presentation slide compilation |

---

### 6.3 Framework Execution Modes

#### Mode 1: RTL-Only Generation (`--rtl-only`)
Synthesizes SystemVerilog RTL, testbenches, and logic level verification without generating UPF files:
```bash
python3 main.py --spec market_specs/H264D-U1000_cfg_regs_spec.md \
               --rtl-only \
               --output-dir output_rtl_only
```

#### Mode 2: Full Unified Spec-to-Netlist & UPF Synthesis (Default)
Executes end-to-end spec ingestion, RTL core synthesis, closed-loop verification, logic level tuning, UPF synthesis, and low-power audit:
```bash
python3 main.py --spec market_specs/H264D-U1000_cfg_regs_spec.md \
               --config benchmarks/power_config_market_soc.json \
               --filelist benchmarks/market_soc_filelist.f \
               --output-dir output_market_soc
```

#### Mode 3: UPF-Only Generation & Alignment Audit (`--upf-only`)
Audits existing RTL against low-power power intent configurations and generates IEEE 1801 UPF 2.1 files:
```bash
python3 main.py --filelist benchmarks/market_soc_filelist.f \
               --config benchmarks/power_config_market_soc.json \
               --upf-only \
               --output-dir output_upf_only
```

---

## 7. Turn-Around Time (TAT) & Performance Benchmark

| Metric / Dimension | Traditional Industry Practice | Specification to Netlist Flow | Speedup / Advantage |
| :--- | :--- | :--- | :--- |
| **Spec-to-RTL Translation** | 2.5–3 Months (Manual Coding) | **< 20 Seconds** | **> 300,000× Speedup** |
| **RTL Verification & Debug Loop** | 1.0–1.5 Months (Manual Debug) | **< 90 Seconds** (Automated Closed-Loop) | **> 40,000× Speedup** |
| **Level of Logic Tuning** | 2–3 Weeks (Manual Pipelining) | **< 30 Seconds** (Auto-Retiming/Pipelining) | **> 40,000× Speedup** |
| **CDC & RDC Synthesis & Audit** | 2–3 Weeks (Manual CDC Debug) | **< 20 Seconds** (Auto Syncs & SDC Constraints) | **> 60,000× Speedup** |
| **IEEE 1801 UPF 2.1 Generation** | 3–4 Weeks (Manual UPF Coding) | **< 15 Seconds** | **> 120,000× Speedup** |
| **RTL-UPF Boundary Audit** | 1–2 Weeks (Post-Synthesis Verification) | **< 5 Seconds** | **> 150,000× Speedup** |
| **Total Spec-to-Netlist TAT** | **4.5–6 Months** | **< 5 Minutes Total** | **> 3,000× Faster Turn-Around** |
| **Engineering Effort & Cost** | Large CAD Team ($> \$500\text{k}$) | **Single Script Execution** ($0 EDA Tool Cost$) | **100% Automated** |

---

## 8. Summary & Next Steps

1. **Implementation Plan Document:** Available at [`IMPLEMENTATION_PLAN.md`](IMPLEMENTATION_PLAN.md).
2. **Current Project Status:**
   - All `.tex` files ([`presentation_idea_submission.tex`](presentation_idea_submission.tex) and [`paper_soc_spec2rtl_upf.tex`](paper_soc_spec2rtl_upf.tex)) are fully aligned with the updated title, author ("Bapaiah Katepalli and Team"), non-crossing flowchart, and Turn-Around Time (TAT) comparison tables.
   - Pending final compilation signal from user to build final PDF, PPTX, and ZIP distribution artifacts.
