#!/usr/bin/env python3
"""
Combined Spec2RTL + AutoUPF-AI Command Line Interface (CLI)

Operating Modes:
1. RTL-Only Mode (--rtl-only or --mode rtl-only):
   - Ingests spec documents & generates synthesizable SystemVerilog RTL, testbenches & filelists.
   - Generates formal Clock Domain Crossing (CDC) and RDC constraints (.cdc / .sdc) for IPs and SoC.
   - Verifies the RTL through:
     * Lint: Verilator static lint check (syntax, widths, multi-drivers)
     * CDC: Static structural CDC/RDC analysis (crossings, 2-FF synchronizers, reset trees)
     * TB: Verilator self-checking testbench simulation (registers, resets, assertions)

2. All / Full Unified Mode (--all or --mode all):
   - Executes everything in Mode 1 (RTL + CDC Constraints + Lint + CDC + TB).
   - Generates IEEE 1801 UPF 2.1 intent (modular IP UPFs + Master SoC UPF with PST).
   - Audits RTL hierarchy against power intent and emits alignment JSON report.
   - Generates comprehensive Synopsys Design Constraints (.sdc) for synthesis & STA.
   - Runs gate-level synthesis (NanGate 45nm standard cell mapping, latch checks).
   - Generates and writes the final gate-level netlist file (*_gate_netlist.v).

Usage Examples:
1. Run Mode 1 (Only RTL + CDC + Lint, CDC, TB verification):
   python3 main.py --spec benchmarks/H264D-U1000_cfg_regs_spec.md --rtl-only

2. Run Mode 2 (All: RTL + CDC + Verification + UPF + SDC + Synthesis + Gate Netlist):
   python3 main.py --spec benchmarks/H264D-U1000_cfg_regs_spec.md \
                  --config benchmarks/power_config.json \
                  --filelist benchmarks/soc_filelist.f \
                  --all
"""

import sys
import argparse
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.combined_pipeline import CombinedSpec2RTLUPFPipeline


def main():
    parser = argparse.ArgumentParser(
        description="Spec2RTL + AutoUPF-AI: Specification to Synthesizable RTL, CDC, UPF & Gate Netlist Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Input Flags
    parser.add_argument(
        "--spec", "-s", nargs="+",
        help="Multi-format spec input document(s) (.md, .pdf, .docx, .xlsx, .csv)"
    )
    parser.add_argument(
        "--config", "-c", type=str,
        help="Path to JSON power domain & voltage config (e.g., power_config.json)"
    )
    parser.add_argument(
        "--filelist", "-fl", type=str,
        help="Path to SoC EDA filelist (.f, .flist, .vc)"
    )
    parser.add_argument(
        "--files", "-f", nargs="+",
        help="Direct list of Verilog/SystemVerilog source files or glob patterns"
    )
    parser.add_argument(
        "--dir", "-d", type=str,
        help="Directory containing Verilog/SystemVerilog files (.v, .sv)"
    )
    parser.add_argument(
        "--existing-upf", "-u", type=str,
        help="Path to existing UPF file for alignment auditing"
    )
    parser.add_argument(
        "--output-dir", "-o", type=str, default="output",
        help="Directory where generated RTL, IP UPF, SoC Master UPF, and audit reports are saved"
    )
    parser.add_argument(
        "--name", type=str,
        help="Override target IP module name"
    )

    # Mode Selector
    parser.add_argument(
        "--mode", choices=["rtl-only", "all"],
        help="Execution mode: 'rtl-only' (RTL + CDC + Lint/CDC/TB verification) or 'all' (RTL + CDC + Verif + UPF + SDC + Synth + Netlist)"
    )
    parser.add_argument(
        "--rtl-only", action="store_true",
        help="Generate RTL + CDC constraints + verify with Lint, CDC, and TB (Skip UPF, SDC, synth & netlist)"
    )
    parser.add_argument(
        "--all", action="store_true",
        help="Run complete flow: RTL + CDC + Lint/CDC/TB + UPF + SDC + Synthesis + Gate Netlist"
    )
    parser.add_argument(
        "--upf-only", action="store_true",
        help="Generate IEEE 1801 UPF files & perform RTL-UPF alignment audit ONLY (Skip spec-to-RTL synthesis)"
    )
    parser.add_argument(
        "--llm", action="store_true",
        help="Use LLM to complete functional core implementation"
    )
    parser.add_argument(
        "--lint", action="store_true",
        help="Run Verilator static lint pass on generated RTL"
    )
    parser.add_argument(
        "--synth", action="store_true",
        help="Run synthesis & latch check pass on generated RTL"
    )
    parser.add_argument(
        "--sim", action="store_true",
        help="Run Verilator / Icarus Verilog testbench simulation pass"
    )
    parser.add_argument(
        "--non-interactive", action="store_true",
        help="Run without interactive prompts"
    )

    args = parser.parse_args()

    # Determine mode:
    # 1. If --rtl-only or --mode rtl-only -> rtl_only = True
    # 2. If --all or --mode all -> run_all = True
    # 3. If neither specified and not upf_only -> default to --all mode!
    is_rtl_only = args.rtl_only or (args.mode == "rtl-only")
    is_all = args.all or (args.mode == "all") or (not is_rtl_only and not args.upf_only)

    # Defaults if no inputs provided
    if not args.spec and not args.filelist and not args.files and not args.dir:
        print("\n\033[93m[Default Benchmark Mode]\033[0m No input parameters provided. Running with built-in benchmarks...\n")
        args.spec = ["benchmarks/H264D-U1000_cfg_regs_spec.md"]
        args.config = "benchmarks/power_config.json"
        args.filelist = "benchmarks/soc_filelist.f"

    # Automatically expand directories passed to --spec into all matching spec files
    if args.spec:
        expanded_specs = []
        for s in args.spec:
            sp = Path(s)
            if sp.is_dir():
                for ext in ["*.md", "*.pdf", "*.docx", "*.xlsx", "*.csv", "*.txt"]:
                    expanded_specs.extend([str(f) for f in sorted(sp.glob(ext))])
            else:
                expanded_specs.append(s)
        args.spec = expanded_specs

    pipeline = CombinedSpec2RTLUPFPipeline(output_dir=args.output_dir)
    res = pipeline.run(
        spec_files=args.spec,
        power_config_file=args.config,
        filelist_file=args.filelist,
        rtl_files=args.files,
        rtl_dir=args.dir,
        existing_upf=args.existing_upf,
        ip_name=args.name,
        use_llm=args.llm,
        rtl_only=is_rtl_only,
        upf_only=args.upf_only,
        run_lint=args.lint,
        run_synth=args.synth,
        run_sim=args.sim,
        run_all=is_all,
    )

    if res["success"]:
        print("=" * 78)
        print(f" PIPELINE EXECUTION SUCCESSFUL [Mode: {res.get('mode')}]")
        print("=" * 78)
        if res.get("ip_rtl_files"):
            print(f"  • Synthesized IP RTL     : \033[92m{res['ip_rtl_files']}\033[0m")
        if res.get("ip_cdc_file"):
            print(f"  • IP CDC Constraints     : \033[92m{res['ip_cdc_file']}\033[0m")
        if res.get("soc_cdc_file"):
            print(f"  • SoC CDC Constraints    : \033[92m{res['soc_cdc_file']}\033[0m")
        if res.get("verification"):
            verif = res["verification"]
            print(f"  • Verification Status    : Lint=\033[92m{verif.get('lint')}\033[0m | CDC=\033[92m{verif.get('cdc')}\033[0m | TB=\033[92m{verif.get('sim')}\033[0m")
        if res.get("ip_upf_file"):
            print(f"  • IP Modular UPF         : \033[92m{res['ip_upf_file']}\033[0m")
        if res.get("soc_top_module"):
            print(f"  • SoC Top Module         : \033[93m{res['soc_top_module']}\033[0m")
        if res.get("soc_master_upf"):
            print(f"  • SoC Master UPF         : \033[92m{res['soc_master_upf']}\033[0m")
        if res.get("soc_sdc_file"):
            print(f"  • SoC SDC Constraints    : \033[92m{res['soc_sdc_file']}\033[0m")
        if res.get("gate_netlist_file"):
            print(f"  • Gate-Level Netlist     : \033[92m{res['gate_netlist_file']}\033[0m")
        if res.get("alignment_report"):
            print(f"  • UPF-RTL Audit JSON     : \033[96m{res['alignment_report']}\033[0m")
        print("=" * 78 + "\n")
    else:
        print("\n\033[91m✖ Unified Pipeline Execution Failed.\033[0m\n")
        sys.exit(1)


if __name__ == "__main__":
    main()
