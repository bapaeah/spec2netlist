#!/usr/bin/env python3
"""spec2rtl - generate synthesizable SystemVerilog + TB from an IP spec.

  spec2rtl.py extract  <spec.{pdf,docx,doc,xlsx,csv,md,txt}> -o out/spec.json
  spec2rtl.py generate out/spec.json -o out [--llm]
  spec2rtl.py run      <spec file> -o out [--llm]      (extract + generate)
  spec2rtl.py lint     out        (Verilator -Wall)
  spec2rtl.py synth    out        (Yosys generic synth + latch/comb-loop check)
  spec2rtl.py sim      out        (build + run TB with Verilator, fallback Icarus)
  spec2rtl.py all      <spec file> -o out  (run + lint + synth + sim)
"""
from __future__ import annotations
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from spec2rtl import extract as X, parse as P, generate as G  # noqa: E402


def tool(*names):
    for n in names:
        if shutil.which(n):
            return n
    return None


def sh(cmd, cwd=None):
    print("$ " + " ".join(cmd))
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def files_of(out: Path):
    return [str(out / f) for f in (out / "files.f").read_text().split()], \
        (out / "top.txt").read_text().strip()


# ---------------------------------------------------------------- steps
def do_extract(spec_file, out_json, name=None):
    text, tables = X.extract(spec_file)
    spec = P.parse(text, tables, name)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(spec, indent=2))
    print(f"[extract] module={spec['module']}  clock={spec['clock']}  reset={spec['reset']}")
    print(f"[extract] bus={spec['bus']['type']}  ports={len(spec['ports'])}  "
          f"registers={len(spec['registers'])}  -> {out_json}")
    for w in spec["warnings"]:
        print(f"[extract] WARNING: {w}")
    return spec


def lint_files(files, top):
    v = tool("verilator", "verilator-cli")
    if not v:
        return None, "verilator not found"
    return sh([v, "--lint-only", "-Wall", "--top-module", top, *files])


def do_generate(spec_json, out, use_llm=False):
    spec = json.loads(Path(spec_json).read_text())
    c = G.write_all(spec, out)
    if use_llm:
        from spec2rtl import llm
        stub = G.gen_core_stub(c)
        files, top = files_of(out)

        def lint_fn(code):
            with tempfile.TemporaryDirectory() as td:
                p = Path(td) / f"{c.m}_core.sv"
                p.write_text(code)
                fl = [str(p) if f.endswith("_core.sv") else f for f in files]
                rc, log = lint_files(fl, top)
                return rc == 0, log
        G.write_all(spec, out, core_text=llm.fill_core(spec, stub, lint_fn))
    print(f"[generate] RTL + TB written to {out}/rtl, {out}/tb")


def do_lint(out):
    files, top = files_of(out)
    rc, log = lint_files(files, top)
    print(log)
    print("LINT: CLEAN" if rc == 0 else "LINT: FAILED")
    return rc == 0


def do_synth(out):
    y = tool("yosys", "yowasp-yosys")
    if not y:
        print("yosys not found (pip install yowasp-yosys)")
        return False
    files, top = files_of(out)
    files = [str(Path(f).relative_to(out)) for f in files]  # run inside out/ (yowasp sandbox)
    script = (f"read_verilog -sv {' '.join(files)}; hierarchy -check -top {top}; "
              f"proc; flatten; opt; "
              f"select -assert-none t:$dlatch t:$adlatch t:$dlatchsr; "  # no latches
              f"synth -top {top}; check -assert; stat")
    rc, log = sh([y, "-q", "-p", script, "-l", "synth.log"], cwd=str(out))
    tail = log.strip().splitlines()[-15:]
    print("\n".join(tail))
    print("SYNTH: PASS (no latches, no comb loops, no multi-drivers)" if rc == 0 else
          f"SYNTH: FAILED (see {out}/synth.log)")
    return rc == 0


def do_sim(out):
    files, top = files_of(out)
    tb = str(out / "tb" / f"tb_{top}.sv")
    v = tool("verilator", "verilator-cli")
    build = out / "sim_build"
    if v:
        rc, log = sh([v, "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style",
                      "--top-module", f"tb_{top}", "-Mdir", str(build), "-o", "simv", *files, tb])
        if rc:
            print(log)
            return False
        rc, log = sh([str(build / "simv")])
    elif tool("iverilog"):
        rc, log = sh(["iverilog", "-g2012", "-o", str(out / "simv"), "-s", f"tb_{top}", *files, tb])
        if rc == 0:
            rc, log = sh(["vvp", str(out / "simv")])
    else:
        print("No simulator (verilator/iverilog) found")
        return False
    print(log)
    return "TEST PASSED" in log


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("cmd", choices=["extract", "generate", "run", "lint", "synth", "sim", "all"])
    ap.add_argument("input", help="spec file, spec.json, or output dir")
    ap.add_argument("-o", "--out", default="out")
    ap.add_argument("--name", help="override module name")
    ap.add_argument("--llm", action="store_true", help="fill functional core with an LLM")
    a = ap.parse_args()
    out = Path(a.out)
    if a.cmd == "extract":
        do_extract(a.input, out if out.suffix == ".json" else out / "spec.json", a.name)
    elif a.cmd == "generate":
        do_generate(a.input, out, a.llm)
    elif a.cmd in ("run", "all"):
        do_extract(a.input, out / "spec.json", a.name)
        do_generate(out / "spec.json", out, a.llm)
        if a.cmd == "all":
            res = {"lint": do_lint(out), "synth": do_synth(out), "sim": do_sim(out)}
            print("\nSUMMARY: " + "  ".join(f"{k.upper()}={'PASS' if v else 'FAIL'}" for k, v in res.items()))
            sys.exit(0 if all(res.values()) else 1)
    else:
        d = Path(a.input)
        ok = {"lint": do_lint, "synth": do_synth, "sim": do_sim}[a.cmd](d)
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
