# PowerShell Launcher for Spec2RTL + AutoUPF with Local LLM (Windows Native)
$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $ScriptDir

# Set local LLM environment variables for Ollama
$env:SPEC2RTL_LLM_URL = "http://localhost:11434/v1/chat/completions"
$env:SPEC2RTL_LLM_KEY = "ollama"
if (-not $env:SPEC2RTL_LLM_MODEL) {
    $env:SPEC2RTL_LLM_MODEL = "rtl-coder-fast"
}

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " Running Spec2RTL + AutoUPF with Local LLM ($env:SPEC2RTL_LLM_MODEL)" -ForegroundColor Cyan
Write-Host " Endpoint: $env:SPEC2RTL_LLM_URL" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# Check if --llm is already passed, otherwise append it
$hasLLM = $false
foreach ($arg in $args) {
    if ($arg -eq "--llm") { $hasLLM = $true; break }
}

if ($hasLLM) {
    python main.py @args
} else {
    python main.py --llm @args
}
