#!/usr/bin/env bash
set -e

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$DIR"

echo "============================================================"
echo " Unified Local RTL LLM & Spec2RTL-UPF Setup (Linux)"
echo "============================================================"

# 1. Install Ollama if missing
if ! command -v ollama &> /dev/null; then
    echo "[1] Ollama not found. Installing via official Linux installer..."
    curl -fsSL https://ollama.com/install.sh | sh
else
    echo "[1] Ollama is already installed at: $(which ollama)"
fi

# 2. Check EDA tools
echo ""
echo "[2] Checking EDA tools (iverilog, verilator, yosys)..."
MISSING_PKGS=""
if ! command -v iverilog &> /dev/null; then MISSING_PKGS="$MISSING_PKGS iverilog"; fi
if ! command -v verilator &> /dev/null; then MISSING_PKGS="$MISSING_PKGS verilator"; fi
if ! command -v yosys &> /dev/null; then MISSING_PKGS="$MISSING_PKGS yosys"; fi

if [ -n "$MISSING_PKGS" ]; then
    echo "    Missing tools:$MISSING_PKGS"
    if command -v apt &> /dev/null; then
        echo "    Installing via apt..."
        sudo apt update && sudo apt install -y $MISSING_PKGS python3 python3-pip
    elif command -v dnf &> /dev/null; then
        echo "    Installing via dnf..."
        sudo dnf install -y $MISSING_PKGS python3 python3-pip
    else
        echo "    Please install: $MISSING_PKGS using your package manager."
    fi
else
    echo "    ✓ EDA tools already installed."
fi

# 3. Install Python Document Ingestion Packages
echo ""
echo "[3] Installing spec parsing packages (PDF, Word, Excel)..."
python3 -m pip install --quiet --break-system-packages pdfplumber python-docx openpyxl 2>/dev/null || \
python3 -m pip install --quiet pdfplumber python-docx openpyxl 2>/dev/null || true

# 4. Pull models and create custom RTL models
echo ""
echo "[4] Pulling base models and building custom RTL models in Ollama..."
ollama pull qwen2.5-coder:7b
ollama pull qwen2.5-coder:3b

echo "    Building 'rtl-coder' (7B)..."
ollama create rtl-coder -f Modelfile.rtl

echo "    Building 'rtl-coder-fast' (3B)..."
ollama create rtl-coder-fast -f Modelfile.rtl-fast

# 5. Check Spec2rtl_upf integration
echo ""
echo "[5] Checking Spec2rtl_upf integration..."
SPEC2RTL_DIR="$DIR/spec2rtl_upf"
if [ ! -d "$SPEC2RTL_DIR" ]; then
    SPEC2RTL_DIR="$(cd "$DIR/../Spec2rtl_upf" 2>/dev/null && pwd || echo "$HOME/Spec2rtl_upf")"
fi
if [ -d "$SPEC2RTL_DIR" ]; then
    echo "    Found Spec2rtl_upf at: $SPEC2RTL_DIR"
    chmod +x "$SPEC2RTL_DIR/run_local.sh" 2>/dev/null || true
else
    echo "    Spec2rtl_upf not detected in sibling or home directory."
    echo "    To integrate it, place 'Spec2rtl_upf' next to 'LLM_Local'."
fi

# 6. Configure Continue extension if ~/.continue exists or create it
CONTINUE_DIR="$HOME/.continue"
mkdir -p "$CONTINUE_DIR"
if [ -f "continue_config.json" ]; then
    cp -f continue_config.json "$CONTINUE_DIR/config.json"
    echo "    Configured VS Code Continue extension at: $CONTINUE_DIR/config.json"
fi

# 7. Check Memory Compiler
if [ -f "$DIR/memory/memgen.py" ]; then
    echo ""
    echo "[7] Memory Compiler detected. Running test suite..."
    python3 -m unittest discover "$DIR/memory/tests" > /dev/null 2>&1 && echo "    ✓ Memory compiler unit tests passed."
fi

# 8. Install CLI package
echo ""
echo "[8] Registering system-wide CLI tools (rtl-assistant, llm-local, memgen, spec2rtl)..."
python3 -m pip install -e . --no-build-isolation > /dev/null 2>&1 || python3 -m pip install -e . --user > /dev/null 2>&1 || true

# 9. Run health check
echo ""
echo "[9] Running environment health check..."
python3 rtl_assistant.py check

echo ""
echo "============================================================"
echo " Linux Setup Complete!"
echo "============================================================"
echo "Quick Commands:"
echo "  • System-Wide CLI:            rtl-assistant --help"
echo "  • Interactive Chat:           rtl-assistant chat  (or: python3 rtl_assistant.py chat)"
echo "  • AI Memory Compiler:         rtl-assistant memory --spec '16KB SDP RAM with Wishbone bus'"
echo "                                (or standalone: memgen --list-presets)"
echo "  • Generate RTL from prompt:   rtl-assistant generate --spec '4-bit counter' -o counter.v"
echo "  • Generate from Spec File:    rtl-assistant generate --file my_spec.pdf -o module.v"
echo "  • Testbench & Simulation:     rtl-assistant testbench counter.v -o counter_tb.v"
echo "                                rtl-assistant verify counter.v counter_tb.v"
echo "  • Full Spec2RTL + UPF Flow:   rtl-assistant soc --spec my_spec.md --all"
echo "                                (or standalone: spec2rtl --spec my_spec.md --all)"
echo ""
