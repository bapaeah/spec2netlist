# Local RTL LLM: 100% Offline & Token-Free Hardware Engineering Assistant

This repository sets up a completely local, private, and unlimited LLM environment tuned specifically for **RTL Design and Verification** (Verilog, SystemVerilog, VHDL, and cocotb).

> [!TIP]
> **Looking for quick commands?** See the [Command Reference Guide](file:///Users/bappi/LLM_Local/COMMANDS.md) for a single-page reference of all commands, switches, and copy-paste examples.

---

## 1. System & Model Architecture

### Your Hardware Profile
* **System**: Apple Silicon (MacBook / A18 Pro)
* **Memory**: **8 GB Unified Memory**
* **Local EDA Tools Detected**: `iverilog` (Icarus Verilog), `verilator`, `yosys`

### Why These Models?
Running local models on 8 GB unified memory requires careful memory budgeting so your OS, IDE, and simulation tools have plenty of headroom:

| Model Name | Parameter Size | Memory Footprint | Best Used For |
| :--- | :--- | :--- | :--- |
| **`rtl-coder`** (Qwen 2.5 Coder 7B) | 7 Billion (Q4_K_M) | ~4.7 GB RAM | **Primary Model**: Complex RTL modules, FSMs, AXI/APB bus protocols, self-checking testbenches, bug fixing |
| **`rtl-coder-fast`** (Qwen 2.5 Coder 3B) | 3 Billion (Q4_K_M) | ~2.0 GB RAM | **Fast Model & Copilot Autocomplete**: Instant responses, tab-autocomplete in editor, simple module generation |

---

## 2. Installation & Quick Setup

Run the automated setup script:
```bash
./setup_local_llm.sh
```

This script will:
1. Check or install **Ollama** via Homebrew.
2. Start the local inference server (`http://localhost:11434`).
3. Download the optimized base weights.
4. Build the custom `rtl-coder` and `rtl-coder-fast` models embedding strict digital hardware engineering rules (preventing unintended latches, enforcing non-blocking assignments in sequential logic, handling resets and clock domain crossings).

---

## 3. One Common Command: `rtl` (With Simple Switches)

You can execute **any task** in this environment using the single, unified **`rtl`** command (or `./rtl`) with simple switches:

```
SWITCHES:
  --rtl, -r          Generate synthesizable RTL module from prompt or document
  --tb, -t           Generate self-checking testbench with assertions & GTKWave VCD
  --verify, -v       Autonomous verify & self-healing simulation loop (RTL + TB)
  --synth            Synthesize RTL with Open Standard Cell Library (NanGate45 / Sky130)
  --convert, -c      Convert Markdown (.md) to PDF, TXT, HTML, DOCX, RTF, LaTeX, JSON
  --mem, --memory    Technology-Agnostic Memory Compiler (AI prompt or direct flags)
  --soc              Full SoC CAD Engine (RTL + CDC + UPF 2.1 + SDC + Gate Netlist)
  --chat             Start interactive VLSI / RTL Engineer terminal chat session
  --check            Check local Ollama daemon, models, and EDA tooling status
```

### A. Environment Check
```bash
rtl --check
```

### B. Interactive VLSI / RTL Chat
Chat directly with the specialized Principal Hardware Engineer model:
```bash
rtl --chat
# Or use the fast 3B model:
rtl --chat --model rtl-coder-fast
```

### C. Generate Synthesizable RTL from Spec or Document
```bash
# From natural language prompt:
rtl --rtl --spec "4-bit priority encoder with active-low async reset" -o encoder.v

# Directly from specification document (.docx, .pdf, .md, .xlsx):
rtl --rtl --file /path/to/spec.docx -o module.v
```

### D. Generate Self-Checking Testbench
```bash
rtl --tb encoder.v -o encoder_tb.v
```

### E. Autonomous Self-Healing Verification Loop
Simulates RTL + Testbench with `iverilog`. If errors occur, it automatically feeds the compiler/assertion log back to the local LLM to fix the code until verification passes cleanly:
```bash
rtl --verify encoder.v encoder_tb.v
```

### F. Logic Synthesis with Open Standard Cell Libraries (`--synth`)
Maps Verilog/SystemVerilog RTL into real standard cells using **Yosys** and open Liberty (`.lib`) timing/synthesis models, calculating exact cell counts and silicon area ($\mu m^2$):
```bash
# Synthesize to NanGate 45nm standard cells (default):
rtl --synth encoder.v -o encoder_gate.v

# Synthesize to SkyWater 130nm standard cells:
rtl --synth encoder.v --lib sky130 -o encoder_sky130_gate.v

# Gate-Level Simulation (GLS) with Icarus Verilog and included cell models:
iverilog -g2012 techlib/nangate45/nangate45_cells.v encoder_gate.v encoder_tb.v && vvp a.out
```

### G. Universal Markdown Document Converter (`--convert` / `-c`)
Converts any Markdown (`.md`) specification, datasheet, or notes into formatted PDF, TXT, HTML, DOCX (Word), RTF, or LaTeX:
```bash
# Convert to PDF:
rtl --convert spec.md -o spec.pdf

# Convert to Plain Text:
rtl --convert spec.md -o spec.txt

# Convert to Microsoft Word (DOCX):
rtl --convert spec.md -o spec.docx

# Convert to all formats at once:
rtl --convert spec.md --to all
```

### H. Technology-Agnostic Memory Compiler
```bash
# Natural language AI memory synthesis:
rtl --mem --spec "16KB Simple Dual-Port RAM with 64-bit width and Wishbone bus"

# Direct parameter compilation:
rtl --mem --type spram --size 4KB --bus axi5 -o generated_mem

# Preset inspection:
rtl --mem --list-presets
```

### H. Full SoC CAD Flow & Power Intent (Spec2rtl_upf)
```bash
# RTL + CDC constraints + Verilator lint & simulation:
rtl --soc --spec benchmarks/H264D-U1000_cfg_regs_spec.md --rtl-only

# Complete unified tapeout flow (RTL + CDC + UPF 2.1 + SDC + 45nm Gate Netlist):
rtl --soc --spec benchmarks/H264D-U1000_cfg_regs_spec.md --all

# Batch generation across an entire folder of specs:
rtl --soc --spec market_specs/ --rtl-only
```

---

## 4. Free Local Copilot in VS Code / Cursor (Zero Tokens)

You can get GitHub Copilot-like tab autocompletion and sidebar chat inside VS Code or Cursor completely offline:

1. Install the free **Continue** extension from the VS Code Marketplace (search `Continue`).
2. Open Continue settings (`~/.continue/config.json`) or copy the pre-configured [continue_config.json](file:///Users/bappi/LLM_Local/continue_config.json) into `~/.continue/config.json`.
3. You now have:
   * **Tab Autocomplete**: Powered by local `qwen2.5-coder:3b` at zero latency.
   * **In-Editor Chat**: Select code, press `Cmd + L`, and ask the model to explain, refactor, or optimize your RTL.
   * **Custom Slash Commands**: `/rtl-testbench` and `/rtl-lint` configured out of the box.

---

## 5. Full SoC CAD & Low-Power Intent Integration (`Spec2rtl_upf`)

You can run complete SoC architectural synthesis (register decoding, AXI/APB bus interfaces, CDC constraints, IEEE 1801 UPF 2.1 power intent, SDC timing, and 45nm gate netlist) directly through `rtl_assistant.py`:

```bash
# RTL-Only Mode (RTL + CDC Constraints + Verilator Lint + TB Simulation)
python3 rtl_assistant.py soc --spec /path/to/spec.docx --rtl-only

# Full Unified Tapeout Flow (RTL + CDC + UPF 2.1 + SDC + 45nm Netlist)
python3 rtl_assistant.py soc --spec /path/to/spec.md --all

# Batch Generation across an entire folder of specs:
python3 rtl_assistant.py soc --spec /path/to/specs_folder/ --rtl-only
```

---

## 6. Technology-Agnostic Memory Compiler Integration (`memory/memgen.py`)

Integrated directly in `LLM_Local/memory/`, the memory compiler generates synthesizable SystemVerilog memory subsystems (ROM, Single-Port RAM, Simple Dual-Port RAM, True Dual-Port RAM) targeting Behavioral Simulation, FPGA (XPM/BRAM/URAM), and ASIC hard macros, along with standard SoC bus wrappers (`axi5`, `ahb-lite`, `wishbone`, `riscv-ibus`).

You can compile memories either via direct flags or by asking the local LLM in plain English:

```bash
# A. Natural Language AI Memory Synthesis (Local LLM extracts parameters & compiles):
python3 rtl_assistant.py memory --spec "Generate a 16KB Simple Dual-Port RAM with 64-bit width and Wishbone bus"

# B. Direct CLI Memory Compilation:
python3 rtl_assistant.py memory --type spram --size 4KB --bus axi5 --name sram_4k -o generated_mem

# C. Preset Inspection:
python3 rtl_assistant.py memory --list-presets
```

Each compilation automatically generates:
* `<name>_behavioral.sv`: Golden simulation model.
* `<name>_fpga.sv`: FPGA vendor-portable instantiation (Xilinx XPM primitives).
* `<name>_asic.sv`: Technology-independent ASIC pinout & wrapper.
* `<name>_<bus>.sv`: Protocol bridge adapter (AXI5 / AHB-Lite / Wishbone / RISC-V).
* `<name>.sv`: Unified top-level selector multiplexing all targets.

---

## 7. Python Package & System-Wide CLI (`llm-local`)

This repository is structured as a full Python package with standard PEP 517/621 metadata ([`pyproject.toml`](file:///Users/bappi/LLM_Local/pyproject.toml), [`setup.py`](file:///Users/bappi/LLM_Local/setup.py), [`setup.cfg`](file:///Users/bappi/LLM_Local/setup.cfg)).

### 1-Step Installation
Run the installer script:
```bash
# macOS / Linux:
./install.sh

# Windows (PowerShell):
.\install.ps1
```
Or install directly using pip:
```bash
pip install -e .
```

### Registered System-Wide CLI Commands
Once installed, the following commands are available anywhere in your terminal:

| Command | Purpose | Example |
| :--- | :--- | :--- |
| **`rtl-assistant`** | Primary hardware engineering assistant & chat | `rtl-assistant chat` |
| **`llm-local`** | Package status and environment check alias | `llm-local check` |
| **`memgen`** | Technology-agnostic memory compiler | `memgen --type spram --size 16KB --bus axi5` |
| **`spec2rtl`** | Full SoC CAD, CDC, UPF 2.1 & netlist generator | `spec2rtl --spec spec.md --all` |

### Building Distributable Release Packages
To build wheels, source distributions, and portable release archives:
```bash
python3 package_release.py
```
This automatically produces in `dist/`:
* `llm_local-1.0.0-py3-none-any.whl`: Standard Python wheel.
* `llm-local-1.0.0.tar.gz`: Standard Python source distribution.
* `LLM_Local-1.0.0-portable.zip`: Standalone, clean archive for Windows/Mac.
* `LLM_Local-1.0.0-portable.tar.gz`: Standalone, clean archive for Linux servers.

---

## 8. Multi-OS Deployment Guides

* **Linux (Servers & Desktops)**: Follow [`SETUP_LINUX.md`](file:///Users/bappi/LLM_Local/SETUP_LINUX.md) or run `./setup_linux.sh`
* **Windows (10/11 & WSL2)**: Follow [`SETUP_WINDOWS.md`](file:///Users/bappi/LLM_Local/SETUP_WINDOWS.md) or run `.\setup_windows.ps1`
* **Samsung Galaxy Tab (Android & DeX)**: Follow [`SETUP_SAMSUNG_TAB.md`](file:///Users/bappi/LLM_Local/SETUP_SAMSUNG_TAB.md) or run `./setup_termux.sh`


---

## 9. Directory Structure

* [`pyproject.toml`](file:///Users/bappi/LLM_Local/pyproject.toml): Modern PEP 517/621 Python package configuration.
* [`setup.py`](file:///Users/bappi/LLM_Local/setup.py): Setuptools packaging script and console scripts definition.
* [`setup.cfg`](file:///Users/bappi/LLM_Local/setup.cfg): Declarative packaging metadata.
* [`MANIFEST.in`](file:///Users/bappi/LLM_Local/MANIFEST.in): Distribution asset manifest.
* [`install.sh`](file:///Users/bappi/LLM_Local/install.sh): One-click package installer for macOS/Linux.
* [`install.ps1`](file:///Users/bappi/LLM_Local/install.ps1): One-click package installer for Windows.
* [`package_release.py`](file:///Users/bappi/LLM_Local/package_release.py): Release automation for wheels, sdist, and portable archives.
* [`Modelfile.rtl`](file:///Users/bappi/LLM_Local/Modelfile.rtl): Custom Ollama model configuration with ASIC/FPGA design guidelines and memory macro rules.
* [`Modelfile.rtl-fast`](file:///Users/bappi/LLM_Local/Modelfile.rtl-fast): Lightweight 3B model configuration for fast generation and low memory.
* [`rtl_assistant.py`](file:///Users/bappi/LLM_Local/rtl_assistant.py): Python CLI for module generation, testbenches, memory compilation, and self-healing EDA verification.
* [`llm_local.py`](file:///Users/bappi/LLM_Local/llm_local.py): Package entry point module.
* [`setup_local_llm.sh`](file:///Users/bappi/LLM_Local/setup_local_llm.sh): macOS automated setup script.
* [`setup_linux.sh`](file:///Users/bappi/LLM_Local/setup_linux.sh): Linux automated setup script.
* [`setup_windows.ps1`](file:///Users/bappi/LLM_Local/setup_windows.ps1): Windows PowerShell automated setup script.
* [`SETUP_LINUX.md`](file:///Users/bappi/LLM_Local/SETUP_LINUX.md): Step-by-step Linux server deployment & GPU guide.
* [`SETUP_WINDOWS.md`](file:///Users/bappi/LLM_Local/SETUP_WINDOWS.md): Step-by-step Windows native & WSL2 setup guide.
* [`continue_config.json`](file:///Users/bappi/LLM_Local/continue_config.json): Configuration file for VS Code / Cursor Continue extension.
* [`memory/`](file:///Users/bappi/LLM_Local/memory): Technology-agnostic memory compiler engine (`memgen.py`) with AXI5/AHB/Wishbone/RISC-V bus wrappers.
* [`spec2rtl_upf/`](file:///Users/bappi/LLM_Local/spec2rtl_upf): Bundled full SoC architecture, CDC, UPF 2.1, SDC, and gate netlist CAD engine.
* [`examples/`](file:///Users/bappi/LLM_Local/examples): Example testbench simulation files and test modules.
* [`dist/`](file:///Users/bappi/LLM_Local/dist): Packaged distribution artifacts (`.whl`, `.tar.gz`, portable `.zip`).
