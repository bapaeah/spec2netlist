#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# Local RTL LLM & EDA Toolkit - Samsung Galaxy Tab / Android Termux Setup Script
# ==============================================================================
# This script configures a complete RTL design, memory compilation, document
# conversion, and simulation environment directly on your Samsung Galaxy Tab.
# ==============================================================================

set -e

echo "============================================================"
echo "    Samsung Tab / Termux Setup for Local RTL LLM & EDA      "
echo "============================================================"

# Verify running inside Termux
if [ -z "$TERMUX_VERSION" ] && [ ! -d "/data/data/com.termux" ]; then
    echo "[!] Warning: This script is intended to run inside the Termux app on Android."
    echo "    Continuing anyway using standard bash..."
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null 2>&1 && pwd)"
cd "$SCRIPT_DIR"

# 1. Update Termux Package Repositories
echo ""
echo "[1] Updating Termux packages..."
pkg update -y || apt update -y

# 2. Install Core Languages and Tools
echo ""
echo "[2] Installing Python, Git, and build tools..."
pkg install -y python git clang make openssh || apt install -y python git clang make openssh

# 3. Install Icarus Verilog (native ARM64 simulation)
echo ""
echo "[3] Installing Verilog simulation engine (iverilog)..."
if pkg install -y iverilog 2>/dev/null || pkg install -y verilog 2>/dev/null; then
    echo "    ✔ Icarus Verilog installed successfully."
else
    echo "    [i] Native iverilog package not available in main repo, checking proot..."
fi

# 4. Install Proot Distro for Full Linux & Yosys Synthesis (Optional/Recommended)
echo ""
echo "[4] Checking Linux proot environment for Yosys Gate Synthesis..."
if ! command -v proot-distro &> /dev/null; then
    echo "    Installing proot-distro..."
    pkg install -y proot-distro
fi

echo "    To install full Ubuntu with Yosys on your Tab:"
echo "      proot-distro install ubuntu"
echo "      proot-distro login ubuntu -- apt update && apt install -y yosys iverilog python3"

# 5. Install Python Document Parser Packages (Optional - pure python stdlib handles most)
echo ""
echo "[5] Installing optional Python spec parsers..."
pip install --upgrade pip 2>/dev/null || true
pip install pdfplumber python-docx openpyxl 2>/dev/null || echo "    [i] Optional parsers skipped; pure-Python engine will be used."

# 6. Setup Convenient Aliases in ~/.bashrc
echo ""
echo "[6] Setting up convenient aliases in ~/.bashrc..."
BASHRC="$HOME/.bashrc"
touch "$BASHRC"

# Add rtl shortcut
if ! grep -q "alias rtl=" "$BASHRC"; then
    echo "alias rtl=\"python3 $SCRIPT_DIR/rtl_assistant.py\"" >> "$BASHRC"
    echo "alias md-convert=\"python3 $SCRIPT_DIR/md_converter.py\"" >> "$BASHRC"
    echo "alias memgen=\"python3 $SCRIPT_DIR/memory/memgen.py\"" >> "$BASHRC"
    echo "    ✔ Added 'rtl', 'md-convert', and 'memgen' aliases to ~/.bashrc"
fi

# 7. Configure Ollama Host (Connect to Host PC or Local)
echo ""
echo "============================================================"
echo "               Ollama AI Engine Setup                       "
echo "============================================================"
echo "How would you like to connect to Ollama from your Samsung Tab?"
echo "  1) Remote Host PC/Mac (Recommended - uses PC GPU over Wi-Fi)"
echo "  2) Local On-Device (Experimental - runs lightweight model on Tab)"
echo "  3) Configure later manually"
echo ""

read -p "Enter choice [1-3] (default 1): " CHOICE
CHOICE=${CHOICE:-1}

if [ "$CHOICE" = "1" ]; then
    read -p "Enter your Host PC/Mac IP address (e.g., 192.168.1.50): " HOST_IP
    if [ -n "$HOST_IP" ]; then
        EXPORT_CMD="export OLLAMA_HOST=\"http://${HOST_IP}:11434\""
        if ! grep -q "OLLAMA_HOST" "$BASHRC"; then
            echo "$EXPORT_CMD" >> "$BASHRC"
            echo "    ✔ Configured: $EXPORT_CMD in ~/.bashrc"
        fi
        export OLLAMA_HOST="http://${HOST_IP}:11434"
        echo "    Testing connection to http://${HOST_IP}:11434..."
        curl -s --connect-timeout 3 "http://${HOST_IP}:11434/api/tags" && echo " ✔ Connected to Host Ollama!" || echo " [!] Could not reach Host Ollama. Ensure Ollama is running with OLLAMA_HOST=0.0.0.0 on your PC."
    fi
fi

echo ""
echo "============================================================"
echo "          Samsung Tab Setup Complete!                       "
echo "============================================================"
echo "You can now run:"
echo "  • source ~/.bashrc"
echo "  • rtl --chat                  (Interactive VLSI Engineer Chat)"
echo "  • rtl --rtl \"priority encoder\" -o enc.v"
echo "  • rtl --verify enc.v enc_tb.v (Icarus Verilog Simulation)"
echo "  • rtl --convert spec.md --to all (Pure-Python Universal Converter)"
echo "  • memgen --type spram --size 4KB"
echo "============================================================"
