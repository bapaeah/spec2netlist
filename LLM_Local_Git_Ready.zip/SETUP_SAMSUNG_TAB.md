# Samsung Galaxy Tab Setup Guide: Local RTL LLM & EDA Toolkit

This guide explains how to set up and run the **Local RTL LLM & EDA Toolkit** on any Samsung Galaxy Tab (Galaxy Tab S7, S8, S9, S10, Tab A series, or Galaxy Active Tab) running Android and **Samsung DeX**.

---

## 3 Ways to Use on Your Samsung Tab

Choose the method that best matches your workflow:

| Method | Best For | Requirements | Performance |
| :--- | :--- | :--- | :--- |
| **Option 1: VS Code Web / Tunnel (Recommended)** | Full desktop IDE with GUI, file explorer, code completion, and 1-click tasks | Host PC/Mac running on same Wi-Fi or Internet | **Maximum** (Uses PC CPU/GPU, zero battery drain on Tab) |
| **Option 2: Termux SSH / LAN Client** | Fast command-line workflow (`./rtl --chat`, `./rtl --synth`) | Host PC/Mac running Ollama on local Wi-Fi | **Maximum** (Instant terminal response) |
| **Option 3: 100% Standalone On-Device** | Offline travel, field work, no PC running | Samsung Tab with 6GB+ RAM | **Portable** (Runs native Python, Icarus Verilog & PRoot Linux) |

---

## Option 1: VS Code Web / Tunnel + Samsung DeX (Recommended)

This gives you the **exact same desktop VS Code experience** on your Samsung Tab as on a Mac or PC, complete with file trees, terminal panes, Continue/Copilot extensions, and 1-click Markdown-to-PDF conversion tasks.

```
┌─────────────────────────────────┐           Wi-Fi / Web           ┌─────────────────────────────────┐
│     Host Machine (Mac / PC)     │ ◄─────────────────────────────► │       Samsung Galaxy Tab        │
│ • Ollama (7B / 3B Models)       │       Secure VS Code Tunnel     │ • Samsung DeX Desktop Mode      │
│ • Yosys & Icarus Verilog        │       or Local LAN Connection   │ • Chrome / Samsung Internet     │
│ • Full Workspace & Tools        │                                 │ • Keyboard Cover / Mouse / SPen │
└─────────────────────────────────┘                                 └─────────────────────────────────┘
```

### Step 1: Start VS Code Tunnel on your Host Machine (Mac/PC)

On your computer where `LLM_Local` is installed:

1. Open a terminal in the project directory:
   ```bash
   cd ~/LLM_Local
   code tunnel
   ```
   *(Or inside VS Code: Click the **Accounts** icon in the bottom-left corner → Select **Turn on Remote Tunnel Access**)*.
2. Follow the prompt to log in with your GitHub or Microsoft account.
3. The terminal will print a permanent link, e.g.:
   ```text
   Open this link in your browser: https://vscode.dev/tunnel/<your-machine-name>/Users/<user>/LLM_Local
   ```

### Step 2: Open on Samsung Tab

1. Switch your Samsung Tab to **Samsung DeX Mode** (pull down notification bar → tap **DeX**).
2. Open **Samsung Internet** or **Google Chrome**.
3. Navigate to your tunnel URL (`https://vscode.dev/tunnel/...`).
4. *(Optional)* Tap the browser menu (**⋮**) → **Install app** / **Add to Home screen** to make it a standalone full-screen desktop app on your tablet!
5. You now have full access:
   - Press **`Ctrl + \``** to toggle the built-in terminal.
   - Run `./rtl --chat` or `./rtl --synth`.
   - Run VS Code tasks: `Ctrl + Shift + P` → `Tasks: Run Task` → `Markdown: Convert Active File to PDF`.

---

## Option 2: Connect Samsung Tab to Host Ollama over Local Wi-Fi

If you want to run the `rtl` CLI directly on your tablet while offloading AI model computation to your host PC:

### Step 1: Allow Ollama on Host PC to Accept LAN Connections

**On macOS:**
```bash
# Set OLLAMA_HOST to listen on all interfaces
launchctl setenv OLLAMA_HOST "0.0.0.0:11434"
# Or run manually in terminal:
OLLAMA_HOST=0.0.0.0:11434 ollama serve
```

**On Linux:**
```bash
sudo systemctl edit ollama.service
# Add lines:
# [Service]
# Environment="OLLAMA_HOST=0.0.0.0:11434"
sudo systemctl daemon-reload && sudo systemctl restart ollama
```

**On Windows:**
1. Open Windows Search → **Edit environment variables for your account**.
2. Add variable: `OLLAMA_HOST` with value `0.0.0.0:11434`.
3. Restart Ollama from the Windows system tray.

Find your Host PC's IP address (e.g. `192.168.1.50`) via `ipconfig` (Windows) or `ifconfig` / `ip a` (Mac/Linux).

### Step 2: Configure Samsung Tab

In Termux or your tablet terminal:
```bash
export OLLAMA_HOST="http://192.168.1.50:11434"

# Test connection:
curl http://192.168.1.50:11434/api/tags

# Run interactive VLSI chat:
python3 rtl_assistant.py chat
```

---

## Option 3: 100% Standalone On-Device Setup (Termux)

To run completely independently on the tablet with zero connection to any external PC:

### Step 1: Install Termux

> [!WARNING]
> **Do NOT install Termux from the Google Play Store!** The Google Play build has been deprecated and cannot update packages.
> 
> Install the official build from **F-Droid** or **GitHub**:
> - **F-Droid Download**: [f-droid.org/packages/com.termux](https://f-droid.org/packages/com.termux/)
> - **GitHub APK**: [github.com/termux/termux-app/releases](https://github.com/termux/termux-app/releases)

### Step 2: Transfer Workspace to Tablet

You can copy the `LLM_Local-1.0.0-portable.zip` from your PC to your tablet via USB cable, Google Drive, or local network:

In Termux:
```bash
# Request storage permission
termux-setup-storage

# Navigate to home directory and copy/unzip
cd ~
cp /sdcard/Download/LLM_Local-1.0.0-portable.zip ~/
unzip LLM_Local-1.0.0-portable.zip -d LLM_Local
cd ~/LLM_Local
```

### Step 3: Run Automated Setup Script

Run the automated tablet installer:
```bash
chmod +x setup_termux.sh
./setup_termux.sh
```

This installs:
- **Python 3** & build dependencies.
- **Icarus Verilog (`iverilog`, `vvp`)** for native RTL testbench simulations.
- **Document Converter** & **Memory Compiler** (both use pure standard Python and run at full native speed on ARM64).
- Terminal shortcuts (`rtl`, `md-convert`, `memgen`).

### Step 4: (Optional) Install Ubuntu PRoot for Yosys Gate Synthesis

Termux allows running a complete ARM64 Ubuntu Linux environment with full access to `yosys`:

```bash
# 1. Install Ubuntu PRoot
pkg install -y proot-distro
proot-distro install ubuntu

# 2. Enter Ubuntu and install Yosys & EDA tools
proot-distro login ubuntu

# Inside Ubuntu:
apt update && apt install -y yosys iverilog python3 python3-pip
exit
```

---

## Samsung DeX Multi-Tasking Setup

Samsung DeX turns your tablet into a multi-window workstation. Here is the recommended desktop layout:

```
┌───────────────────────────────────────┬───────────────────────────────────────┐
│              Window 1                 │               Window 2                │
│       Termux / VS Code Web            │          Samsung Notes / Docs         │
│                                       │                                       │
│  VLSI-Engineer> rtl --chat            │  • Architecture block diagram         │
│  Generating synthesizable RTL...      │  • Specification notes with S-Pen     │
│  Synthesis: 45nm Gate Netlist PASS    │  • Converted PDF/Word specs open      │
│                                       │                                       │
└───────────────────────────────────────┴───────────────────────────────────────┘
```

### Recommended Samsung Tab Accessories
1. **Samsung Book Cover Keyboard** or any Bluetooth keyboard with trackpad.
2. **S-Pen** for sketching digital timing diagrams, state machines, and register block diagrams in Samsung Notes.
3. **USB-C Hub / HDMI**: Plug into an external 4K monitor to get a full dual-screen engineering setup.

---

## Verification Commands on Samsung Tab

Test the installation on your tablet:

```bash
# 1. Test offline document conversion (Pure Python)
rtl --convert COMMANDS.md -o /sdcard/Download/commands.pdf
rtl --convert COMMANDS.md -o /sdcard/Download/commands.docx

# 2. Test memory compiler
python3 memory/memgen.py --type spram --size 4KB --bus axi5 -o sram_4k

# 3. Test Verilog simulation
rtl --verify examples/counter.v examples/counter_tb.v

# 4. Interactive chat (via host Ollama or local)
rtl --chat
```
